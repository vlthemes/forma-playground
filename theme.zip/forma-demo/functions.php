<?php
/**
 * Forma Demo: the theme of the Forma demo on WordPress Playground (scripts/build-playground.js zips it)
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_setup_theme', static function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', [ 'search-form', 'gallery', 'caption', 'style', 'script' ] );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );

	register_nav_menus( [ 'primary' => __( 'Header', 'forma-demo' ) ] );
} );

add_action( 'wp_enqueue_scripts', static function () {
	// The Forma site's fonts; the demo runs with networking on
	wp_enqueue_style( 'forma-demo-fonts', 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wdth,wght@12..96,75..100,200..800&family=Inter:wght@400..700&display=swap', [], null );
	wp_enqueue_style( 'forma-demo', get_stylesheet_uri(), [ 'forma-demo-fonts' ], wp_get_theme()->get( 'Version' ) );
} );
