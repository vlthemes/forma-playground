<?php
/**
 * Every page of the demo: header, the post or the list, footer
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="header">
	<div class="wrap">
		<div class="bar">
			<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<svg viewBox="0 0 32 32" aria-hidden="true"><defs><linearGradient id="forma-demo-logo" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6d5cff"/><stop offset="1" stop-color="#ff5a3c"/></linearGradient></defs><rect width="32" height="32" rx="9" fill="url(#forma-demo-logo)"/><rect x="7" y="7" width="8" height="18" rx="2.5" fill="#fff"/><rect x="17" y="7" width="8" height="8" rx="2.5" fill="#fff" fill-opacity=".9"/><rect x="17" y="17" width="8" height="8" rx="2.5" fill="#fff" fill-opacity=".55"/></svg>
				<?php bloginfo( 'name' ); ?>
			</a>
			<nav class="nav" aria-label="<?php esc_attr_e( 'Main', 'forma-demo' ); ?>">
				<?php wp_nav_menu( [ 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => 'wp_page_menu', 'depth' => 1 ] ); ?>
			</nav>
		</div>
	</div>
</header>

<main class="main">
	<div class="wrap">
		<?php if ( is_singular() ) : ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<article <?php post_class( 'entry' ); ?>>
					<h1><?php the_title(); ?></h1>
					<?php the_content(); ?>
				</article>
			<?php endwhile; ?>
		<?php else : ?>
			<div class="page-head">
				<h1><?php echo is_home() ? esc_html__( 'Journal', 'forma-demo' ) : wp_kses_post( get_the_archive_title() ); ?></h1>
				<?php the_archive_description(); ?>
			</div>
			<div class="cards">
				<?php while ( have_posts() ) : the_post(); ?>
					<a class="card" href="<?php the_permalink(); ?>">
						<?php the_post_thumbnail( 'medium_large' ); ?>
						<h3><?php the_title(); ?></h3>
					</a>
				<?php endwhile; ?>
			</div>
			<?php the_posts_pagination(); ?>
		<?php endif; ?>
	</div>
</main>

<footer class="footer">
	<div class="wrap">
		<span><?php bloginfo( 'name' ); ?></span>
		<span><?php printf( esc_html__( 'Grids by %s', 'forma-demo' ), '<a href="https://forma.vlthemes.me/">Forma</a>' ); ?></span>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
