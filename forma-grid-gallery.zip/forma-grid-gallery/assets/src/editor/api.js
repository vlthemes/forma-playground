/**
 * REST requests of the Grid Layout editor (forma/v1, Rest.php): apiFetch sends the nonce
 */
import apiFetch from '@wordpress/api-fetch';
import { addQueryArgs } from '@wordpress/url';

export function request( route, params = {} ) {
	return apiFetch( { path: addQueryArgs( '/forma/v1' + route, params ) } );
}
