/**
 * Filters settings, shown under the Toolbar board when its chip is picked
 */
import { __ } from '@wordpress/i18n';
import StyleSelect from '../style-select.js';
import { Select, Text, Toggle } from '../components/controls.js';

const { filterTemplates } = window.formaEditor;

export default function FiltersPanel( { config, update, source } ) {
	const filters = config.filters;
	const taxonomies = source?.taxonomies || [];

	return (
		<>
			<Select
				label={ __( 'Filter by', 'forma-grid-gallery' ) }
				help={ __( 'If the query is limited to some terms of this taxonomy, only those (and their children) are offered.', 'forma-grid-gallery' ) }
				value={ filters.taxonomy }
				options={ taxonomies }
				onChange={ ( value ) => update( 'filters.taxonomy', value ) }
				__nextHasNoMarginBottom
			/>
			<StyleSelect
				value={ filters.template }
				templates={ filterTemplates }
				help={ __( 'More styles come from the theme (forma_filters_styles, files in filters/{style}/filter.php).', 'forma-grid-gallery' ) }
				onChange={ ( value ) => update( 'filters.template', value ) }
			/>
			<Text label={ __( '"All" label', 'forma-grid-gallery' ) } placeholder={ __( 'All', 'forma-grid-gallery' ) } value={ filters.all_label } onChange={ ( value ) => update( 'filters.all_label', value ) } __nextHasNoMarginBottom />
			<Toggle label={ __( 'Show item counts', 'forma-grid-gallery' ) } checked={ filters.show_count } onChange={ ( value ) => update( 'filters.show_count', value ) } __nextHasNoMarginBottom />
		</>
	);
}
