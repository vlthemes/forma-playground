/**
 * Search settings, shown under the Toolbar board when its chip is picked
 */
import { __ } from '@wordpress/i18n';
import StyleSelect from '../style-select.js';
import { Text } from '../components/controls.js';

const { searchTemplates } = window.formaEditor;

export default function SearchPanel( { config, update } ) {
	const search = config.search;

	return (
		<>
			<StyleSelect
				value={ search.template }
				templates={ searchTemplates }
				help={ __( 'More styles come from the theme (forma_search_styles, files in search/{style}/search.php).', 'forma-grid-gallery' ) }
				onChange={ ( value ) => update( 'search.template', value ) }
			/>
			<Text label={ __( 'Placeholder', 'forma-grid-gallery' ) } placeholder={ __( 'Search…', 'forma-grid-gallery' ) } value={ search.placeholder } onChange={ ( value ) => update( 'search.placeholder', value ) } __nextHasNoMarginBottom />
		</>
	);
}
