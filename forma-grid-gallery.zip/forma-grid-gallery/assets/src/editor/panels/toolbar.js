/**
 * Toolbar panel: search, filter and sort on two rows of left / center / right zones (Renderer::toolbar()), per device.
 * The chip picked on the board shows its settings under it.
 */
import { __, sprintf } from '@wordpress/i18n';
import { useRef, useState } from '@wordpress/element';
import { Button } from '@wordpress/components';
import { DEVICES, useDevice } from '../device.js';
import { deviceLabel } from '../components/device-fields.js';
import SearchPanel from './search.js';
import FiltersPanel from './filters.js';
import SortPanel from './sort.js';

const { defaults } = window.formaEditor;

const SETTINGS = { search: SearchPanel, filters: FiltersPanel, sort: SortPanel };

const CONTROLS = {
	search: __( 'Search', 'forma-grid-gallery' ),
	filters: __( 'Filter', 'forma-grid-gallery' ),
	sort: __( 'Sorting', 'forma-grid-gallery' ),
};

const ZONES = {
	left: __( 'Left', 'forma-grid-gallery' ),
	center: __( 'Center', 'forma-grid-gallery' ),
	right: __( 'Right', 'forma-grid-gallery' ),
};

// Config::TOOLBAR_PLACES
const PLACES = [ '1-left', '1-center', '1-right', '2-left', '2-center', '2-right' ];

// Config::toolbar_key()
const keyOf = ( device ) => ( 'desktop' === device ? 'toolbar' : `toolbar_${ device }` );

const hasPlaces = ( places ) => PLACES.some( ( place ) => places?.[ place ]?.length );

/**
 * Places of the shown controls on a device, as Renderer::places(): a device without any placed takes the wider one's;
 * a control without a place goes on row 1, the filter in the center when it is alone, else on the left, the others right
 */
function resolve( config, device, shown ) {
	let base = {};

	for ( const item of DEVICES ) {
		if ( hasPlaces( config[ keyOf( item.value ) ] ) ) {
			base = config[ keyOf( item.value ) ];
		}

		if ( item.value === device ) {
			break;
		}
	}

	const places = Object.fromEntries( PLACES.map( ( place ) => [ place, ( base[ place ] || [] ).filter( ( control ) => shown.includes( control ) ) ] ) );
	const placed = Object.values( places ).flat();

	shown.filter( ( control ) => ! placed.includes( control ) ).forEach( ( control ) => {
		places[ 'filters' !== control ? '1-right' : ( 1 === shown.length ? '1-center' : '1-left' ) ].push( control );
	} );

	return places;
}

const PLUS = (
	<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
		<path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z" />
	</svg>
);

/**
 * The toolbar with a control moved: into a place, before another control (else at the end)
 */
function move( toolbar, control, place, before ) {
	const next = Object.fromEntries( PLACES.map( ( key ) => [ key, ( toolbar[ key ] || [] ).filter( ( item ) => item !== control ) ] ) );
	const at = before ? next[ place ].indexOf( before ) : -1;

	next[ place ].splice( at < 0 ? next[ place ].length : at, 0, control );

	return next;
}

export default function ToolbarPanel( props ) {
	const { config, replace, source } = props;
	const [ device ] = useDevice();
	const shown = Object.keys( CONTROLS ).filter( ( control ) => config[ control ]?.enabled );
	const toolbar = resolve( config, device, shown );
	const own = 'desktop' === device || hasPlaces( config[ keyOf( device ) ] );
	const [ chosen, setChosen ] = useState( null );
	const [ over, setOver ] = useState( null );
	// The last clicked or added, else the first
	const picked = shown.includes( chosen ) ? chosen : shown[ 0 ];
	const Settings = SETTINGS[ picked ];
	const dropped = useRef( false );
	const dragging = useRef( null );
	// Dragged off the board: removed on release
	const [ leaving, setLeaving ] = useState( null );

	const isOutside = ( event, board ) => {
		const box = board.getBoundingClientRect();

		return event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom;
	};

	const taxonomies = source?.taxonomies || [];

	const save = ( next ) => replace( { ...config, [ keyOf( device ) ]: next } );

	// The filter starts on the source's first taxonomy
	const add = ( control ) => {
		const next = { ...config[ control ], enabled: true };

		if ( 'filters' === control && ! next.taxonomy ) {
			next.taxonomy = taxonomies[ 0 ]?.value || '';
		}

		replace( { ...config, [ control ]: next } );
		setChosen( control );
	};

	const changed = ( control ) => JSON.stringify( { ...config[ control ], enabled: true } ) !== JSON.stringify( { ...defaults[ control ], enabled: true } );

	// Alt + left / right: the next zone, Alt + up / down: the other row, Delete: removed
	const keyMove = ( event, control, place ) => {
		const steps = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -3, ArrowDown: 3 };

		if ( 'Delete' === event.key || 'Backspace' === event.key ) {
			event.preventDefault();
			remove( control );
			return;
		}

		if ( ! event.altKey || ! steps[ event.key ] ) {
			return;
		}

		event.preventDefault();

		const target = PLACES[ ( PLACES.indexOf( place ) + steps[ event.key ] + PLACES.length ) % PLACES.length ];
		const element = event.currentTarget;

		save( move( toolbar, control, target, null ) );
		window.requestAnimationFrame( () => element.ownerDocument.querySelector( `.forma-editor__toolbar [data-control="${ control }"] button` )?.focus() );
	};

	// Cleared on every device, so it comes back in its usual place
	const remove = ( control ) => replace( {
		...config,
		[ control ]: { ...config[ control ], enabled: false },
		...Object.fromEntries( DEVICES.map( ( item ) => [ keyOf( item.value ), Object.fromEntries( PLACES.map( ( place ) => [ place, ( config[ keyOf( item.value ) ]?.[ place ] || [] ).filter( ( name ) => name !== control ) ] ) ) ] ) ),
	} );

	// The filter needs a source with taxonomies
	const left = Object.keys( CONTROLS ).filter( ( control ) => ! shown.includes( control ) && ( 'filters' !== control || taxonomies.length ) );

	// Dropped on a chip: before it, or after it in its right half
	const drop = ( event, place ) => {
		event.preventDefault();
		setOver( null );
		dropped.current = true;

		const control = event.dataTransfer.getData( 'text/vlt-toolbar' );
		const chip = event.target.closest( '[data-control]' );

		if ( ! CONTROLS[ control ] ) {
			return;
		}

		let before = null;

		if ( chip && chip.dataset.control !== control ) {
			const box = chip.getBoundingClientRect();
			const list = toolbar[ place ] || [];

			before = event.clientX < box.left + box.width / 2 ? chip.dataset.control : list[ list.indexOf( chip.dataset.control ) + 1 ] ?? null;
		}

		save( move( toolbar, control, place, before ) );
	};

	return (
		<>
			{ !! left.length && (
				<div className="forma-editor__toolbar-adds">
					{ left.map( ( control ) => (
						<Button key={ control } variant="secondary" size="small" icon={ PLUS } onClick={ () => add( control ) }>
							{ CONTROLS[ control ] }
						</Button>
					) ) }
				</div>
			) }

			<div className="forma-editor__toolbar-head">
				{ deviceLabel( device, __( 'Places', 'forma-grid-gallery' ) ) }
				{ 'desktop' !== device && ( own ? (
					<Button variant="link" onClick={ () => save( Object.fromEntries( PLACES.map( ( place ) => [ place, [] ] ) ) ) }>
						{ __( 'As wider device', 'forma-grid-gallery' ) }
					</Button>
				) : (
					<span className="forma-editor__muted">{ __( 'As wider device', 'forma-grid-gallery' ) }</span>
				) ) }
			</div>

			{ /* dragleave, as the page gets no dragover over the canvas iframe */ }
			<div
				className={ 'forma-editor__toolbar' + ( leaving ? ' is-removing' : '' ) }
				data-removing={ __( 'Release to remove', 'forma-grid-gallery' ) }
				onDragOver={ () => leaving && setLeaving( null ) }
				onDragLeave={ ( event ) => dragging.current && ! event.currentTarget.contains( event.relatedTarget ) && setLeaving( dragging.current ) }
			>
				{ [ '1', '2' ].map( ( row ) => (
					<div key={ row } className="forma-editor__toolbar-row">
						{ Object.keys( ZONES ).map( ( zone ) => {
							const place = `${ row }-${ zone }`;

							return (
								<div
									key={ zone }
									className={ `forma-editor__toolbar-zone is-${ zone }` + ( over === place ? ' is-over' : '' ) }
									onDragOver={ ( event ) => {
										event.preventDefault();
										setOver( place );
									} }
									onDragLeave={ ( event ) => ! event.currentTarget.contains( event.relatedTarget ) && setOver( null ) }
									onDrop={ ( event ) => drop( event, place ) }
								>
									{ toolbar[ place ].map( ( control ) => (
										<span
											key={ control }
											draggable
											data-control={ control }
											className={ 'forma-editor__toolbar-chip' + ( picked === control ? ' is-picked' : '' ) + ( leaving === control ? ' is-removing' : '' ) }
											onDragStart={ ( event ) => {
												event.dataTransfer.setData( 'text/vlt-toolbar', control );
												event.dataTransfer.effectAllowed = 'move';
												dropped.current = false;
												dragging.current = control;
											} }
											onDragEnd={ ( event ) => {
												const board = event.currentTarget.closest( '.forma-editor__toolbar' );

												dragging.current = null;
												setOver( null );
												setLeaving( null );

												// The editor accepts drops everywhere, so dropEffect can't tell
												if ( ! dropped.current && isOutside( event, board ) ) {
													remove( control );
												}
											} }
										>
											<button
												type="button"
												aria-pressed={ picked === control }
												title={ sprintf( /* translators: %s: control (Search, Filter, Sorting) */ __( '%s: click to edit, drag (or Alt + arrows) to move, drag off the board (or Delete) to remove', 'forma-grid-gallery' ), CONTROLS[ control ] ) }
												onClick={ () => setChosen( control ) }
												onKeyDown={ ( event ) => keyMove( event, control, place ) }
											>
												{ CONTROLS[ control ] }
												{ changed( control ) && <span className="forma-editor__panel-dot" /> }
											</button>
										</span>
									) ) }
								</div>
							);
						} ) }
					</div>
				) ) }
				{ /* The grid under the toolbar, fading out */ }
				<div className="forma-editor__toolbar-grid" aria-hidden="true">
					<i />
					<i />
					<i />
				</div>
			</div>

			<p className="forma-editor__muted">
				{ config.display.attach_controls
					? __( 'Click a control to edit it below. Drag it to another zone, or off the board to remove it. Each device can have its own places. A row stays on one line while its controls fit, otherwise the center gets a line of its own.', 'forma-grid-gallery' )
					: __( 'Drag a control to its zone. Placed by their own shortcodes, controls only take the zone as their alignment. Turn on "Output … with the grid" (Shortcodes) for the rows.', 'forma-grid-gallery' ) }
			</p>

			{ Settings && (
				<div className="forma-editor__toolbar-settings">
					<div className="forma-editor__toolbar-settings-head">
						<h3 className="forma-editor__label">{ CONTROLS[ picked ] }</h3>
						<Button variant="link" isDestructive onClick={ () => remove( picked ) }>
							{ __( 'Remove', 'forma-grid-gallery' ) }
						</Button>
					</div>
					<Settings { ...props } />
				</div>
			) }
		</>
	);
}
