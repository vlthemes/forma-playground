/**
 * Query Builder panel
 */
import { __, _n, sprintf, isRTL } from '@wordpress/i18n';
import { Button, ExternalLink, FormTokenField, Modal, TextControl, TextareaControl, __experimentalHStack as HStack } from '@wordpress/components';
import { MediaUpload, MediaUploadCheck } from '@wordpress/block-editor';
import { useSelect } from '@wordpress/data';
import { createInterpolateElement, useEffect, useMemo, useRef, useState } from '@wordpress/element';
import { applyFilters } from '@wordpress/hooks';
import { request } from '../api.js';
import Hint from '../hint.js';
import { ImageExtraFields } from './extra.js';
import Group from '../group.js';
import ProNotice from '../pro-notice.js';
import { Select, Text, Textarea, Toggle } from '../components/controls.js';
import TokenSelect from '../components/token-select.js';
import SourcePicker from '../components/source-picker.js';
import ValueControl from '../components/value-control.js';
import { isChanged } from '../components/field.js';

const termsCache = new Map();

/**
 * Terms of several taxonomies: { taxonomy: [ terms ] } (missing key = still loading), cached per page view
 */
function useTermsMap( taxonomies ) {
	const key = taxonomies.join( ',' );
	const [ map, setMap ] = useState( {} );

	useEffect( () => {
		let active = true;

		taxonomies.forEach( ( taxonomy ) => {
			const done = ( list ) => active && setMap( ( current ) => ( { ...current, [ taxonomy ]: list } ) );

			if ( termsCache.has( taxonomy ) ) {
				done( termsCache.get( taxonomy ) );
				return;
			}

			request( '/terms', { taxonomy } )
				.then( ( list ) => {
					termsCache.set( taxonomy, list );
					done( list );
				} )
				// A taxonomy that can't be loaded behaves like an empty one: hidden
				.catch( () => done( [] ) );
		} );

		return () => {
			active = false;
		};
	}, [ key ] ); // eslint-disable-line react-hooks/exhaustive-deps

	return map;
}

function TermsControl( { label, terms, selected, onChange } ) {
	return <TokenSelect label={ label } options={ terms.map( ( term ) => ( { value: term.id, label: term.name } ) ) } value={ selected } onChange={ onChange } placeholder={ __( 'Any', 'forma-grid-gallery' ) } />;
}

/**
 * Thumbnail of a post (its featured image), a blank square without one
 */
function PostThumb( { post } ) {
	return post?.thumb ? <img className="forma-editor__post-thumb" src={ post.thumb } alt="" /> : <span className="forma-editor__post-thumb is-empty" aria-hidden="true" />;
}

/**
 * Pick authors: users who can write posts (core REST list)
 */
function AuthorsControl( { value, onChange } ) {
	const users = useSelect( ( select ) => select( 'core' ).getUsers( { who: 'authors', per_page: 100, _fields: 'id,name' } ) || [], [] );

	return (
		<TokenSelect
			label={ __( 'Authors', 'forma-grid-gallery' ) }
			help={ __( 'Only items by these users.', 'forma-grid-gallery' ) }
			options={ users.map( ( user ) => ( { value: user.id, label: user.name } ) ) }
			value={ value }
			onChange={ onChange }
			placeholder={ __( 'Any author', 'forma-grid-gallery' ) }
		/>
	);
}

/**
 * Searchable post picker for "Specific items" and "Exclude items", with thumbnails
 */
function PostsControl( { label, help, source, value, onChange } ) {
	const [ posts, setPosts ] = useState( {} );
	const add = ( list ) => setPosts( ( current ) => ( { ...current, ...Object.fromEntries( list.map( ( post ) => [ post.id, post ] ) ) } ) );

	// Resolve stored IDs to titles and images once
	useEffect( () => {
		const missing = value.filter( ( id ) => ! posts[ id ] );

		if ( missing.length ) {
			request( '/posts', { source, include: missing.join( ',' ) } ).then( add ).catch( () => {} );
		}
	}, [ source, value.join( ',' ) ] ); // eslint-disable-line react-hooks/exhaustive-deps

	const search = ( text ) => {
		if ( text.length < 2 ) {
			return;
		}

		request( '/posts', { source, search: text } ).then( add ).catch( () => {} );
	};

	const titleOf = ( id ) => posts[ id ]?.title || __( 'Post', 'forma-grid-gallery' );

	return (
		<>
			<TokenSelect
				label={ label }
				help={ help }
				// Every post seen so far: the picked ones and the search results
				options={ Object.keys( posts ).map( ( id ) => ( { value: Number( id ), label: `${ titleOf( id ) } (#${ id })` } ) ) }
				value={ value }
				onChange={ onChange }
				onInputChange={ search }
				renderOption={ ( option ) => (
					<span className="forma-editor__post-option">
						<PostThumb post={ posts[ option.value ] } />
						<span>{ option.label }</span>
					</span>
				) }
				placeholder={ __( 'Type to search…', 'forma-grid-gallery' ) }
			/>
			{ !! value.length && (
				<ul className="forma-editor__posts">
					{ value.map( ( id ) => (
						<li key={ id } className="forma-editor__post">
							<PostThumb post={ posts[ id ] } />
							<span className="forma-editor__post-title">
								{ titleOf( id ) }
								{ posts[ id ] && ! posts[ id ].thumb && <small>{ __( 'No featured image', 'forma-grid-gallery' ) }</small> }
							</span>
							<Button icon="no-alt" size="small" label={ __( 'Remove', 'forma-grid-gallery' ) } onClick={ () => onChange( value.filter( ( item ) => item !== id ) ) } />
						</li>
					) ) }
				</ul>
			) }
		</>
	);
}

/**
 * Plain text of rendered HTML (REST "rendered" fields), parsed inertly
 */
const plain = ( html ) => new window.DOMParser().parseFromString( html || '', 'text/html' ).body.textContent.trim();

// Image fields of the Media Library an item's title or description can come from (MediaSource::FIELDS)
const MEDIA_FIELDS = [
	{ value: 'title', label: __( 'Image title', 'forma-grid-gallery' ) },
	{ value: 'caption', label: __( 'Image caption', 'forma-grid-gallery' ) },
	{ value: 'alt', label: __( 'Image alt text', 'forma-grid-gallery' ) },
	{ value: 'description', label: __( 'Image description', 'forma-grid-gallery' ) },
	{ value: 'none', label: __( 'None', 'forma-grid-gallery' ) },
];

// What a field gives for an image, as the REST API (context view) returns it
const mediaField = ( media, field ) => ( {
	title: plain( media.title?.rendered ),
	caption: plain( media.caption?.rendered ),
	alt: media.alt_text || '',
	description: plain( media.description?.rendered ),
}[ field ] || '' );

// WordPress's chevronLeft / chevronRight icons (@wordpress/icons isn't a dependency)
const chevron = ( d ) => (
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true">
		<path d={ d } />
	</svg>
);
const CHEVRON_LEFT = chevron( 'M14.6 7l-1.2-1L8 12l5.4 6 1.2-1-4.6-5z' );
const CHEVRON_RIGHT = chevron( 'M10.6 6L9.4 7l4.6 5-4.6 5 1.2 1 5.4-6z' );

// File size in KB or MB
const fileSize = ( bytes ) => ( bytes >= 1048576 ? `${ ( bytes / 1048576 ).toFixed( 1 ) } MB` : `${ Math.round( bytes / 1024 ) } KB` );

const thumbOf = ( item ) => item.media_details?.sizes?.thumbnail?.source_url || item.source_url;

/**
 * Overrides of one image inside this layout, in a popup of WordPress's own components; empty fields fall back to the
 * Media Library and every change is saved as it is made. The arrows, the ← / → keys (outside a field) and the strip
 * of the selection go from image to image without closing it.
 */
function ImageDetails( { media, images, value, labels, fields, edited, onChange, onSelect, onClose, onReplace, onClear, onRemove } ) {
	const set = ( key, next ) => onChange( { ...value, [ key ]: next } );
	// Several fields at once (a format choice clears the other one's)
	const assign = ( changes ) => onChange( { ...value, ...changes } );
	const at = images.findIndex( ( item ) => item.id === media.id );
	const prev = images[ at - 1 ];
	const next = images[ at + 1 ];
	const strip = useRef( null );
	const sizes = media.media_details?.sizes || {};
	const { width, height, filesize } = media.media_details || {};
	const file = [
		( media.source_url || '' ).split( '/' ).pop(),
		filesize && fileSize( filesize ),
		width && height && `${ width } × ${ height }`,
	].filter( Boolean ).join( ' · ' );

	useEffect( () => {
		const onKey = ( event ) => {
			const step = { ArrowLeft: -1, ArrowRight: 1 }[ event.key ] * ( isRTL() ? -1 : 1 );
			const target = images[ at + step ];

			if ( ! target || event.altKey || event.metaKey || event.ctrlKey || event.target.closest( 'input, textarea, select, [contenteditable="true"]' ) ) {
				return;
			}

			event.preventDefault();
			onSelect( target.id );
		};

		document.addEventListener( 'keydown', onKey );

		return () => document.removeEventListener( 'keydown', onKey );
	}, [ at, images, onSelect ] );

	// The current image stays in view in the strip
	useEffect( () => {
		strip.current?.querySelector( '.is-active' )?.scrollIntoView( { block: 'nearest', inline: 'nearest' } );
	}, [ media.id ] );

	return (
		<Modal
			title={ value.title || plain( media.title?.rendered ) || `#${ media.id }` }
			onRequestClose={ onClose }
			// The fields, not the arrows in the header: they would open with a focus ring and their tooltip
			focusOnMount="firstContentElement"
			size="large"
			className="forma-editor__image-modal"
			headerActions={
				<div className="forma-editor__image-nav">
					<span>{ `${ at + 1 } / ${ images.length }` }</span>
					<Button icon={ isRTL() ? CHEVRON_RIGHT : CHEVRON_LEFT } label={ __( 'Previous image', 'forma-grid-gallery' ) } disabled={ ! prev } onClick={ () => onSelect( prev.id ) } />
					<Button icon={ isRTL() ? CHEVRON_LEFT : CHEVRON_RIGHT } label={ __( 'Next image', 'forma-grid-gallery' ) } disabled={ ! next } onClick={ () => onSelect( next.id ) } />
				</div>
			}
		>
			<div key={ media.id } className="forma-editor__image">
				<div className="forma-editor__image-side">
					{ /* WordPress's featured image card (its editor styles): the image opens the Media Library, the actions sit on it */ }
					<MediaUpload
						allowedTypes={ [ 'image' ] }
						value={ media.id }
						onSelect={ ( picked ) => onReplace( picked.id ) }
						render={ ( { open } ) => (
							<div className="editor-post-featured-image__container forma-editor__image-card">
								<Button __next40pxDefaultSize className="editor-post-featured-image__preview" onClick={ open } aria-label={ __( 'Replace the image', 'forma-grid-gallery' ) } aria-haspopup="dialog">
									<img className="editor-post-featured-image__preview-image" src={ ( sizes.large || sizes.medium_large || sizes.medium )?.source_url || media.source_url } alt="" />
								</Button>
								<HStack className="editor-post-featured-image__actions">
									<Button __next40pxDefaultSize className="editor-post-featured-image__action" onClick={ open } aria-haspopup="dialog">
										{ __( 'Replace', 'forma-grid-gallery' ) }
									</Button>
									{ /* An add-on's actions on the image (forma.imageActions: Forma Pro's Crop) */ }
									{ applyFilters( 'forma.imageActions', null, { media, onReplace, className: 'editor-post-featured-image__action' } ) }
									<Button __next40pxDefaultSize className="editor-post-featured-image__action" onClick={ onRemove }>
										{ __( 'Remove', 'forma-grid-gallery' ) }
									</Button>
								</HStack>
							</div>
						) }
					/>
					<p className="forma-editor__image-file">{ file }</p>
					<p className="forma-editor__image-links">
						<ExternalLink href={ media.source_url }>{ __( 'Open file', 'forma-grid-gallery' ) }</ExternalLink>
						<ExternalLink href={ window.formaEditor.editMediaUrl + media.id }>{ __( 'Edit in Media Library', 'forma-grid-gallery' ) }</ExternalLink>
						<Button variant="link" disabled={ ! edited } onClick={ onClear }>
							{ __( 'Clear fields', 'forma-grid-gallery' ) }
						</Button>
					</p>
				</div>
				<div className="forma-editor__image-fields">
					<TextControl label={ __( 'Title', 'forma-grid-gallery' ) } value={ value.title || '' } placeholder={ mediaField( media, fields.title ) } onChange={ ( text ) => set( 'title', text ) } __nextHasNoMarginBottom __next40pxDefaultSize />
					<TextareaControl label={ __( 'Description', 'forma-grid-gallery' ) } rows={ 3 } value={ value.caption || '' } placeholder={ mediaField( media, fields.description ) } onChange={ ( text ) => set( 'caption', text ) } __nextHasNoMarginBottom />
					<TextControl type="url" label={ __( 'Link', 'forma-grid-gallery' ) } value={ value.link || '' } placeholder={ __( 'Full-size image', 'forma-grid-gallery' ) } onChange={ ( text ) => set( 'link', text ) } __nextHasNoMarginBottom __next40pxDefaultSize />
					{ applyFilters( 'forma.imageMedia', null, { value, set, assign } ) }
					<FormTokenField
						label={ __( 'Categories', 'forma-grid-gallery' ) }
						value={ value.labels || [] }
						suggestions={ labels }
						onChange={ ( tokens ) => set( 'labels', tokens.map( ( token ) => String( token?.value ?? token ).trim() ).filter( Boolean ) ) }
						__experimentalExpandOnFocus
						__experimentalShowHowTo={ false }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					{ !! Object.keys( window.formaEditor.imageControls || {} ).length && (
						// The theme's fields are the editor's own controls: they come with its styles
						<div className="forma-editor__modal forma-editor__image-theme">
							<ImageExtraFields value={ value.extra } onChange={ ( extra ) => set( 'extra', extra ) } />
						</div>
					) }
					<p className="components-base-control__help">{ __( 'Only for this layout; empty fields use the Media Library. Categories work as filter terms.', 'forma-grid-gallery' ) }</p>
				</div>
			</div>
			<div ref={ strip } className="forma-editor__image-strip">
				{ images.map( ( item ) => (
					<Button
						key={ item.id }
						className={ item.id === media.id ? 'is-active' : undefined }
						label={ plain( item.title?.rendered ) || `#${ item.id }` }
						aria-pressed={ item.id === media.id }
						onClick={ () => onSelect( item.id ) }
					>
						<img src={ thumbOf( item ) } alt="" />
					</Button>
				) ) }
			</div>
		</Modal>
	);
}

function ImagesControl( { value, data, fields, onChange } ) {
	const [ current, setCurrent ] = useState( 0 );
	// Several images picked for removal: Shift + click = range from the last pick, Cmd / Ctrl + click = one more
	const [ picked, setPicked ] = useState( [] );
	const [ anchor, setAnchor ] = useState( 0 );
	// While dragging the thumbnails move on screen only; the order is saved once, on drop (one undo step)
	const [ order, setOrder ] = useState( null );
	const [ dragged, setDragged ] = useState( 0 );
	const media = useSelect( ( select ) => value.map( ( id ) => select( 'core' ).getMedia( id, { context: 'view' } ) ).filter( Boolean ), [ value.join( ',' ) ] ); // eslint-disable-line react-hooks/exhaustive-deps
	const labels = useMemo( () => [ ...new Set( Object.values( data ).flatMap( ( entry ) => entry.labels || [] ) ) ], [ data ] );
	const active = media.find( ( item ) => item.id === current );
	const shown = ( order || value ).map( ( id ) => media.find( ( item ) => item.id === id ) ).filter( Boolean );

	const move = ( ids, id, to ) => {
		const next = ids.filter( ( item ) => item !== id );

		next.splice( to, 0, id );

		return next;
	};

	// Overrides of images that left the selection are dropped with them
	const select = ( items ) => {
		const ids = items.map( ( item ) => item.id );
		onChange( ids, Object.fromEntries( Object.entries( data ).filter( ( [ id ] ) => ids.includes( Number( id ) ) ) ) );
	};

	// Arrays (labels) and objects (the theme's fields) count when not empty
	const edited = ( id ) => Object.values( data[ id ] || {} ).some( ( field ) => ( field && 'object' === typeof field ? Object.keys( field ).length : field ) );

	// Popup actions on one image. Its fields go with it to the image replacing it
	const without = ( id ) => Object.fromEntries( Object.entries( data ).filter( ( [ key ] ) => Number( key ) !== id ) );

	const replaceImage = ( id, next ) => {
		if ( id === next ) {
			return;
		}

		const ids = value.includes( next ) ? value.filter( ( item ) => item !== id ) : value.map( ( item ) => ( item === id ? next : item ) );

		onChange( ids, data[ id ] ? { ...without( id ), [ next ]: data[ id ] } : without( id ) );
		setCurrent( next );
	};

	const removeImage = ( id ) => {
		const at = value.indexOf( id );
		const ids = value.filter( ( item ) => item !== id );

		onChange( ids, without( id ) );
		setCurrent( ids[ Math.min( at, ids.length - 1 ) ] || 0 );
	};

	const onThumb = ( event, id ) => {
		if ( event.shiftKey && anchor && value.includes( anchor ) ) {
			const [ from, to ] = [ value.indexOf( anchor ), value.indexOf( id ) ].sort( ( a, b ) => a - b );
			setPicked( [ ...new Set( [ ...picked, ...value.slice( from, to + 1 ) ] ) ] );
			setCurrent( 0 );
			return;
		}

		if ( event.metaKey || event.ctrlKey || event.shiftKey ) {
			setPicked( picked.includes( id ) ? picked.filter( ( item ) => item !== id ) : [ ...picked, id ] );
			setAnchor( id );
			setCurrent( 0 );
			return;
		}

		// A plain click opens the image's fields (and ends a multiple pick)
		setPicked( [] );
		setAnchor( id );
		setCurrent( current === id ? 0 : id );
	};

	const removePicked = () => {
		select( value.filter( ( id ) => ! picked.includes( id ) ).map( ( id ) => ( { id } ) ) );
		setPicked( [] );
		setCurrent( 0 );
	};

	return (
		<div className="forma-editor__images">
			<MediaUploadCheck fallback={ <Hint status="warning">{ __( 'You are not allowed to choose media.', 'forma-grid-gallery' ) }</Hint> }>
				<MediaUpload
					multiple
					gallery
					allowedTypes={ [ 'image' ] }
					value={ value }
					onSelect={ select }
					render={ ( { open } ) => (
						<Button variant="secondary" onClick={ open }>
							{ value.length ? __( 'Edit images', 'forma-grid-gallery' ) : __( 'Choose images', 'forma-grid-gallery' ) }
						</Button>
					) }
				/>
				{ /* More ways to add images (forma.imagesAdd: Forma Pro's "From URL"), added at the end */ }
				{ applyFilters( 'forma.imagesAdd', null, { onAdd: ( id ) => ! value.includes( id ) && onChange( [ ...value, id ], data ) } ) }
			</MediaUploadCheck>
			{ !! value.length && (
				<>
					{ !! picked.length && (
						<div className="forma-editor__picked">
							<span>
								{ /* translators: %d: number of selected images */ }
								{ sprintf( /* translators: %d: number of selected items */ _n( '%d selected', '%d selected', picked.length, 'forma-grid-gallery' ), picked.length ) }
							</span>
							<Button variant="secondary" isDestructive size="small" onClick={ removePicked }>
								{ __( 'Remove', 'forma-grid-gallery' ) }
							</Button>
							<Button variant="tertiary" size="small" onClick={ () => setPicked( [] ) }>
								{ __( 'Clear', 'forma-grid-gallery' ) }
							</Button>
						</div>
					) }
					<ul className="forma-editor__thumbs">
						{ shown.map( ( item, index ) => (
							<li
								key={ item.id }
								className={ dragged === item.id ? 'is-dragging' : undefined }
								draggable
								onDragStart={ ( event ) => {
									event.dataTransfer.effectAllowed = 'move';
									setDragged( item.id );
									setOrder( value );
								} }
								onDragOver={ ( event ) => {
									event.preventDefault();

									if ( dragged && dragged !== item.id ) {
										setOrder( move( order || value, dragged, index ) );
									}
								} }
								onDragEnd={ () => {
									if ( order && order.join() !== value.join() ) {
										onChange( order, data );
									}

									setDragged( 0 );
									setOrder( null );
								} }
							>
								<button
									type="button"
									className={ [ current === item.id && 'is-active', picked.includes( item.id ) && 'is-picked', edited( item.id ) && 'is-edited' ].filter( Boolean ).join( ' ' ) || undefined }
									aria-pressed={ current === item.id || picked.includes( item.id ) }
									aria-label={ plain( item.title?.rendered ) || `#${ item.id }` }
									onClick={ ( event ) => onThumb( event, item.id ) }
									// Alt + arrow keys move the image without a mouse
									onKeyDown={ ( event ) => {
										const step = { ArrowLeft: -1, ArrowUp: -1, ArrowRight: 1, ArrowDown: 1 }[ event.key ];

										if ( event.altKey && step && value[ index + step ] ) {
											event.preventDefault();
											onChange( move( value, item.id, index + step ), data );
										}
									} }
								>
									<img src={ item.media_details?.sizes?.thumbnail?.source_url || item.source_url } alt="" />
								</button>
							</li>
						) ) }
					</ul>
					{ active && (
						<ImageDetails
							media={ active }
							images={ shown }
							fields={ fields }
							value={ data[ active.id ] || {} }
							labels={ labels }
							edited={ edited( active.id ) }
							onChange={ ( entry ) => onChange( value, { ...data, [ active.id ]: entry } ) }
							onSelect={ setCurrent }
							onClose={ () => setCurrent( 0 ) }
							onReplace={ ( next ) => replaceImage( active.id, next ) }
							onClear={ () => onChange( value, without( active.id ) ) }
							onRemove={ () => removeImage( active.id ) }
						/>
					) }
					<p className="forma-editor__muted">
						{ createInterpolateElement(
							__( 'Click an image to set its title, description, link and categories. <kbd>Shift</kbd> / <kbd>Cmd</kbd> + click selects several to remove. Drag the images (or <kbd>Alt</kbd> + <kbd>←</kbd> <kbd>→</kbd>) to order them; the grid follows it with Order set to Selection order.', 'forma-grid-gallery' ),
							{ kbd: <kbd /> }
						) }
					</p>
				</>
			) }
		</div>
	);
}

/**
 * Content: where items come from and which of them
 */
export function ContentPanel( { config, update, replace, source, sources } ) {
	const query = config.query;
	const taxonomies = source?.taxonomies || [];
	const selected = useMemo( () => query.taxonomies || {}, [ query.taxonomies ] );
	// Post types: the terms to narrow them by; a terms source: its own terms, to pick
	const termsMap = useTermsMap( source?.isPostType ? taxonomies.map( ( taxonomy ) => taxonomy.value ) : [ source?.terms ].filter( Boolean ) );
	const ownTerms = source?.terms ? termsMap[ source.terms ] || [] : [];

	// Taxonomies without terms are hidden; the AND/OR switch only matters with two or more left
	const withTerms = taxonomies.filter( ( taxonomy ) => termsMap[ taxonomy.value ]?.length );

	// Switching source drops what belongs to the old one (terms, picked posts, filter taxonomy)
	const changeSource = ( value ) => {
		const next = sources.find( ( item ) => item.value === value );
		// Media: the images in the order they are picked and dragged in
		const orderby = next.isMedia ? 'post__in' : next.orderby.some( ( option ) => option.value === query.orderby ) ? query.orderby : next.orderby[ 0 ]?.value;

		replace( {
			...config,
			query: { ...query, source: value, orderby, taxonomies: {}, include: [], exclude: [] },
			filters: { ...config.filters, enabled: false, taxonomy: '' },
		} );
	};

	return (
		<>
			<Group title={ __( 'Source', 'forma-grid-gallery' ) }>
				<SourcePicker sources={ sources } value={ query.source } onChange={ changeSource } />
				{ source?.isMedia && (
					<ImagesControl
						value={ query.images }
						// PHP encodes an empty map as []
						data={ Array.isArray( query.image_data ) ? {} : query.image_data || {} }
						fields={ { title: query.media_title, description: query.media_description } }
						onChange={ ( images, data ) => {
							const count = query.images?.length || 0;
							// Per page follows the image count while it equals it, and never goes above it
							const perPage = images.length && ( query.per_page > images.length || query.per_page === count ) ? images.length : query.per_page;

							replace( { ...config, query: { ...query, images, image_data: data, per_page: perPage } } );
						} }
					/>
				) }
				{ source?.isMedia && (
					<>
						<Select label={ __( 'Title source', 'forma-grid-gallery' ) } path="query.media_title" options={ MEDIA_FIELDS } help={ __( 'The image field each item\'s title comes from. A title set on one image in this layout comes first.', 'forma-grid-gallery' ) } __nextHasNoMarginBottom />
						<Select label={ __( 'Description source', 'forma-grid-gallery' ) } path="query.media_description" options={ MEDIA_FIELDS } help={ __( 'The image field each item\'s description comes from. A description set on one image in this layout comes first.', 'forma-grid-gallery' ) } __nextHasNoMarginBottom />
					</>
				) }
			</Group>

			{ source?.isPostType && (
				<Group title={ __( 'Items', 'forma-grid-gallery' ) }>
					<PostsControl
						label={ __( 'Specific items', 'forma-grid-gallery' ) }
						help={ __( 'Show only these. Sort by "Selection order" to keep the order you picked them in.', 'forma-grid-gallery' ) }
						source={ query.source }
						value={ query.include }
						onChange={ ( value ) => update( 'query.include', value ) }
					/>
					<PostsControl label={ __( 'Exclude items', 'forma-grid-gallery' ) } source={ query.source } value={ query.exclude } onChange={ ( value ) => update( 'query.exclude', value ) } />
					{ source.hasAuthors && <AuthorsControl value={ query.authors || [] } onChange={ ( value ) => update( 'query.authors', value ) } /> }
					<Text label={ __( 'Search', 'forma-grid-gallery' ) } help={ __( 'Only items matching these words.', 'forma-grid-gallery' ) } value={ query.search } onChange={ ( value ) => update( 'query.search', value ) } __nextHasNoMarginBottom />
				</Group>
			) }

			{ source?.terms && (
				<Group title={ __( 'Terms', 'forma-grid-gallery' ) }>
					<TokenSelect
						label={ __( 'Specific terms', 'forma-grid-gallery' ) }
						help={ __( 'Show only these. Sort by "Selection order" to keep the order you picked them in.', 'forma-grid-gallery' ) }
						options={ ownTerms.map( ( term ) => ( { value: term.id, label: term.name } ) ) }
						value={ query.include }
						onChange={ ( value ) => update( 'query.include', value ) }
						placeholder={ __( 'All', 'forma-grid-gallery' ) }
					/>
					<TokenSelect
						label={ __( 'Exclude terms', 'forma-grid-gallery' ) }
						options={ ownTerms.map( ( term ) => ( { value: term.id, label: term.name } ) ) }
						value={ query.exclude }
						onChange={ ( value ) => update( 'query.exclude', value ) }
						placeholder={ __( 'None', 'forma-grid-gallery' ) }
					/>
					<Text label={ __( 'Search', 'forma-grid-gallery' ) } help={ __( 'Only terms whose name has these words.', 'forma-grid-gallery' ) } path="query.search" />
					<Toggle label={ __( 'Top level only', 'forma-grid-gallery' ) } help={ __( 'Leave out subcategories.', 'forma-grid-gallery' ) } path="query.top_level" />
					<Toggle label={ __( 'Hide empty terms', 'forma-grid-gallery' ) } help={ __( 'Terms without published items are left out.', 'forma-grid-gallery' ) } path="query.hide_empty" />
					<p className="forma-editor__muted">{ __( 'Each item is a term with its link, description and number of items. Its image: the term\'s own when it has one, else the featured image of its newest item.', 'forma-grid-gallery' ) }</p>
				</Group>
			) }

			{ source?.isPostType && !! withTerms.length && (
				<Group title={ __( 'Terms', 'forma-grid-gallery' ) }>
					{ withTerms.map( ( taxonomy ) => (
						<TermsControl
							key={ taxonomy.value }
							label={ taxonomy.label }
							terms={ termsMap[ taxonomy.value ] }
							selected={ selected[ taxonomy.value ] || [] }
							onChange={ ( ids ) => update( `query.taxonomies.${ taxonomy.value }`, ids ) }
						/>
					) ) }

					{ withTerms.length > 1 && (
						<Select
							label={ __( 'Match terms of', 'forma-grid-gallery' ) }
							value={ query.tax_relation }
							options={ [
								{ value: 'OR', label: __( 'Any taxonomy (OR)', 'forma-grid-gallery' ) },
								{ value: 'AND', label: __( 'Every taxonomy (AND)', 'forma-grid-gallery' ) },
							] }
							onChange={ ( value ) => update( 'query.tax_relation', value ) }
							__nextHasNoMarginBottom
						/>
					) }
				</Group>
			) }

			{ /* An add-on's query settings (forma.query); without one, what Forma Pro adds here, in one note */ }
			{ applyFilters(
				'forma.query',
				( source?.isPostType && <ProNotice feature={ __( 'Several post types in one grid, publish date and custom field filters, leaving out items without a featured image or sticky posts', 'forma-grid-gallery' ) } /> ) ||
					( source?.isMedia && <ProNotice feature={ __( 'Video and audio for the images, images from a URL, and cropping', 'forma-grid-gallery' ) } /> ) ||
					null,
				{ config, update, replace, source, sources }
			) }
		</>
	);
}

/**
 * Order & limit: sorting, how many, offset
 */
export function OrderPanel( { config, update, source } ) {
	const query = config.query;
	// An order of an add-on's that has no direction (forma.orderDirection false), e.g. one arranged by hand
	const direction = applyFilters( 'forma.orderDirection', true, query, source );
	// Media: no more per page than the images picked
	const max = ( source?.isMedia && query.images?.length ) || 100;
	const perPage = query.per_page > max ? max : query.per_page;

	return (
		<>
			<Group title={ __( 'Sorting', 'forma-grid-gallery' ) }>
			<div className={ direction ? 'forma-editor__row is-2' : undefined }>
				<Select
					label={ __( 'Order by', 'forma-grid-gallery' ) }
					value={ query.orderby }
					options={ source?.orderby || [] }
					onChange={ ( value ) => update( 'query.orderby', value ) }
					__nextHasNoMarginBottom
				/>
				{ direction && (
					<Select
						label={ __( 'Order', 'forma-grid-gallery' ) }
						value={ query.order }
						options={ [
							{ value: 'DESC', label: __( 'Descending', 'forma-grid-gallery' ) },
							{ value: 'ASC', label: __( 'Ascending', 'forma-grid-gallery' ) },
						] }
						onChange={ ( value ) => update( 'query.order', value ) }
						__nextHasNoMarginBottom
					/>
				) }
			</div>
			{ /* An add-on's fields of its own orders */ }
			{ applyFilters( 'forma.orderBy', null, { config, update, source } ) }
			</Group>

			<Group title={ __( 'On the page', 'forma-grid-gallery' ) }>
				<Toggle
					label={ __( 'Skip items shown above', 'forma-grid-gallery' ) }
					help={ __( 'Items the grids higher on the same page already show are left out, e.g. under a "Featured" grid.', 'forma-grid-gallery' ) }
					checked={ !! query.skip_shown }
					onChange={ ( value ) => update( 'query.skip_shown', value ) }
					__nextHasNoMarginBottom
				/>
			</Group>

			<Group title={ __( 'Limit', 'forma-grid-gallery' ) }>
			<div className="forma-editor__row is-2">
				<ValueControl
					numeric
					units={ [ '' ] }
					min={ -1 }
					max={ max }
					label={ __( 'Per page', 'forma-grid-gallery' ) }
					help={ sprintf( /* translators: %d: the largest number per page */ __( '1–%d, or -1 for all items (pagination is off then).', 'forma-grid-gallery' ), max ) }
					value={ perPage }
					changed={ isChanged( 'query.per_page', perPage ) }
					onChange={ ( value ) => {
						const number = Math.round( value );

						if ( '' === value ) {
							return;
						}

						// Below 1 is "all" (-1); the arrows step over 0: down from 1 to -1, up from -1 to 1
						if ( number < 1 ) {
							update( 'query.per_page', -1 === query.per_page && 0 === number ? 1 : -1 );
							return;
						}

						update( 'query.per_page', Math.min( number, max ) );
					} }
				/>
				<ValueControl numeric units={ [ '' ] } min={ 0 } max={ 1000 } label={ __( 'Offset', 'forma-grid-gallery' ) } help={ __( 'Skips the first items of the whole result once; pages start after them.', 'forma-grid-gallery' ) } path="query.offset" />
			</div>
			</Group>
		</>
	);
}
