/**
 * Theme controls declared in PHP (Controls.php)
 */
import { __ } from '@wordpress/i18n';
import { BaseControl, Button, ColorPalette, Dropdown, GradientPicker, Icon, TabPanel } from '@wordpress/components';
import { MediaUpload, MediaUploadCheck } from '@wordpress/block-editor';
import { useSelect } from '@wordpress/data';
import { useState } from '@wordpress/element';
import Group from '../group.js';
import { DEVICES, inherited, useDevice } from '../device.js';
import { Select, Text, Textarea, Toggle } from '../components/controls.js';
import ValueControl, { parse } from '../components/value-control.js';
import KnobControl from '../components/knob-control.js';
import { PositionControl } from '../components/place-control.js';
import AlignControl from '../align-control.js';

export const controls = window.formaEditor.controls || {};
const imageControls = window.formaEditor.imageControls || {};

/**
 * Value at a dotted config path
 */
const valueAt = ( config, path ) => path.split( '.' ).reduce( ( value, key ) => ( value && typeof value === 'object' ? value[ key ] : undefined ), config );

/**
 * Same rules as Controls::matches()
 */
export function matches( condition, config ) {
	return Object.entries( condition || {} ).every( ( [ path, values ] ) => {
		const actual = valueAt( config, path );

		return values.some( ( value ) => ( typeof value === 'boolean' ? !! actual === value : String( value ) === String( actual ?? '' ) ) );
	} );
}

function ImageField( { label, help, value, onChange } ) {
	const media = useSelect( ( select ) => ( value ? select( 'core' ).getMedia( value, { context: 'view' } ) : null ), [ value ] );
	const thumb = media?.media_details?.sizes?.medium?.source_url || media?.source_url;

	return (
		<BaseControl label={ label } help={ help } __nextHasNoMarginBottom>
			<MediaUploadCheck>
				<MediaUpload
					allowedTypes={ [ 'image' ] }
					value={ value || undefined }
					onSelect={ ( image ) => onChange( image.id ) }
					render={ ( { open } ) => (
						<div className="forma-editor__extra-image">
							{ !! thumb && (
								<button type="button" className="forma-editor__extra-thumb" onClick={ open }>
									<img src={ thumb } alt="" />
								</button>
							) }
							<div className="forma-editor__extra-actions">
								<Button variant="secondary" size="small" onClick={ open }>
									{ value ? __( 'Replace', 'forma-grid-gallery' ) : __( 'Select image', 'forma-grid-gallery' ) }
								</Button>
								{ !! value && (
									<Button variant="tertiary" size="small" isDestructive onClick={ () => onChange( 0 ) }>
										{ __( 'Remove', 'forma-grid-gallery' ) }
									</Button>
								) }
							</div>
						</div>
					) }
				/>
			</MediaUploadCheck>
		</BaseControl>
	);
}

function ColorField( { label, help, value, gradient = false, onChange } ) {
	const { colors, gradients } = useSelect( ( select ) => {
		const settings = select( 'core/block-editor' )?.getSettings?.() || {};

		return { colors: settings.colors || [], gradients: settings.gradients || [] };
	}, [] );
	const isGradient = /gradient\(/.test( value || '' );
	const set = ( next ) => onChange( next || '' );

	const solid = <ColorPalette colors={ colors } value={ isGradient ? undefined : value || undefined } onChange={ set } enableAlpha clearable __experimentalIsRenderedInSidebar />;

	return (
		<BaseControl className="forma-editor__extra-color-field" help={ help } __nextHasNoMarginBottom>
			<Dropdown
				className="forma-editor__extra-color"
				contentClassName="forma-editor__extra-color-dropdown"
				popoverProps={ { placement: 'left-start', offset: 36, shift: true } }
				renderToggle={ ( { isOpen, onToggle } ) => (
					<Button className={ 'forma-editor__extra-color-toggle' + ( isOpen ? ' is-open' : '' ) } onClick={ onToggle } aria-expanded={ isOpen }>
						<span className="forma-editor__extra-color-indicator" style={ { background: value || undefined } } />
						<span className="forma-editor__extra-color-label">{ label }</span>
					</Button>
				) }
				renderContent={ () =>
					gradient ? (
						<TabPanel tabs={ [ { name: 'solid', title: __( 'Solid', 'forma-grid-gallery' ) }, { name: 'gradient', title: __( 'Gradient', 'forma-grid-gallery' ) } ] } initialTabName={ isGradient ? 'gradient' : 'solid' }>
							{ ( tab ) => ( 'gradient' === tab.name ? <GradientPicker value={ isGradient ? value : undefined } gradients={ gradients } onChange={ set } clearable __nextHasNoMargin /> : solid ) }
						</TabPanel>
					) : (
						solid
					)
				}
			/>
		</BaseControl>
	);
}

const same = ( a, b ) => JSON.stringify( a ?? null ) === JSON.stringify( b ?? null );

export function Field( { field, label, value, onChange, fallback = field.default } ) {
	const common = { label: label ?? field.label, help: field.help || undefined, changed: ! same( value, fallback ), __nextHasNoMarginBottom: true };

	switch ( field.type ) {
		case 'separator':
			return (
				<div className="forma-editor__extra-separator" role="separator">
					{ !! field.label && <span>{ field.label }</span> }
				</div>
			);

		case 'toggle':
			return <Toggle { ...common } checked={ !! value } onChange={ onChange } />;

		case 'select':
			return <Select { ...common } value={ value } options={ Object.entries( field.options ).map( ( [ key, text ] ) => ( { value: key, label: text } ) ) } onChange={ onChange } />;

		case 'number':
			return <ValueControl { ...common } value={ value } numeric units={ [ field.unit ] } min={ field.min ?? undefined } max={ field.max ?? undefined } step={ field.step } onChange={ ( next ) => onChange( '' === next ? field.min ?? 0 : next ) } />;

		case 'dimension': {
			// min / max of the unit shown: one number for every unit, or one per unit
			const unit = parse( value, field.units, field.keywords ).mode;
			const limit = ( bound ) => ( bound && 'object' === typeof bound ? bound[ unit ] : bound ) ?? undefined;

			return <ValueControl { ...common } value={ value } units={ field.units } functions={ field.functions } keywords={ field.keywords } min={ limit( field.min ) } max={ limit( field.max ) } onChange={ onChange } />;
		}

		case 'knob':
			return <KnobControl { ...common } value={ value } options={ Object.entries( field.options ).map( ( [ key, text ] ) => ( { value: key, label: text } ) ) } onChange={ onChange } />;

		// '' = the skin's own; clicking the chosen one again goes back to it (position only)
		case 'position':
			return <PositionControl { ...common } value={ value } onChange={ onChange } />;

		case 'align':
			return <AlignControl label={ common.label } help={ common.help } value={ value } values={ [ 'start', 'center', 'end' ] } onChange={ onChange } />;

		case 'textarea':
			return <Textarea { ...common } rows={ 3 } value={ value ?? '' } onChange={ onChange } />;

		case 'color':
			return <ColorField { ...common } value={ value } gradient={ field.gradient } onChange={ onChange } />;

		case 'image':
			return <ImageField { ...common } value={ value } onChange={ onChange } />;

		default:
			return <Text { ...common } value={ value ?? '' } onChange={ onChange } />;
	}
}

/**
 * Edits the value of the device picked in the device switch
 */
function ResponsiveField( { field, value, onChange } ) {
	const [ device ] = useDevice();
	const info = DEVICES.find( ( item ) => item.value === device );
	// One value (a field that became per device) is the desktop's
	const values = value && typeof value === 'object' ? value : { desktop: value };

	return (
		<Field
			field={ field }
			label={
				<span className="forma-editor__device-label" title={ info.label }>
					<Icon icon={ info.icon } size={ 16 } />
					{ field.label }
				</span>
			}
			value={ values[ device ] ?? inherited( values, device ) }
			fallback={ field.default?.[ device ] ?? inherited( field.default || {}, device ) }
			onChange={ ( next ) => onChange( { ...values, [ device ]: next } ) }
		/>
	);
}

/**
 * A group of a section's fields: an accordion, closed unless the theme opens it ('open' => true)
 */
function Accordion( { field, changed, children } ) {
	const [ open, setOpen ] = useState( !! field.open );

	return (
		<div className={ 'forma-editor__accordion' + ( open ? ' is-open' : '' ) }>
			<button type="button" className="forma-editor__accordion-head" aria-expanded={ open } onClick={ () => setOpen( ! open ) }>
				<span className="forma-editor__accordion-label">
					{ field.label }
					{ /* A field inside differs from its default: seen without opening the group */ }
					{ changed && <span className="vlt-field__dot" title={ __( 'Changed from the default', 'forma-grid-gallery' ) } /> }
				</span>
				<Icon icon="arrow-right-alt2" size={ 16 } />
			</button>
			{ open && (
				<div className="forma-editor__accordion-body">
					{ !! field.help && <p className="forma-editor__accordion-help">{ field.help }</p> }
					{ children }
				</div>
			) }
		</div>
	);
}

export default function ExtraFields( { id, config, update, grouped = false } ) {
	const section = controls[ id ];

	if ( ! matches( section.condition, config ) ) {
		return null;
	}

	const entries = Object.entries( section.fields ).filter( ( [ , field ] ) => matches( field.condition, config ) );

	const control = ( [ key, field ] ) => {
		const Control = field.responsive ? ResponsiveField : Field;

		return <Control key={ key } field={ field } value={ config.extra?.[ id ]?.[ key ] ?? field.default } onChange={ ( value ) => update( `extra.${ id }.${ key }`, value ) } />;
	};

	// A group holds the fields that name it (Controls::fields() puts them right after it)
	const fields = entries
		.filter( ( [ , field ] ) => ! field.group )
		.map( ( [ key, field ] ) => {
			if ( 'group' !== field.type ) {
				return control( [ key, field ] );
			}

			const children = entries.filter( ( [ , child ] ) => child.group === key );
			const changed = children.some( ( [ child, item ] ) => ! same( config.extra?.[ id ]?.[ child ] ?? item.default, item.default ) );

			return children.length ? <Accordion key={ key } field={ field } changed={ changed }>{ children.map( control ) }</Accordion> : null;
		} );

	return grouped ? <Group title={ section.title }>{ fields }</Group> : <>{ fields }</>;
}

/**
 * Image fields; values equal to the default are dropped, as in Controls::sanitize_image()
 */
export function ImageExtraFields( { value = {}, onChange } ) {
	const entries = Object.entries( imageControls );

	if ( ! entries.length ) {
		return null;
	}

	const set = ( key, next ) => {
		const rest = { ...value };
		delete rest[ key ];

		onChange( next === imageControls[ key ].default ? rest : { ...rest, [ key ]: next } );
	};

	return entries.map( ( [ key, field ] ) => <Field key={ key } field={ field } value={ value[ key ] ?? field.default } onChange={ ( next ) => set( key, next ) } /> );
}
