/**
 * Pagination panel: on/off switch + style (stored as pagination.type: none | numbers | loadmore, or a type an add-on
 * adds with forma_pagination_types and the forma.paginationTypes filter, of the Load More kind)
 */
import { __ } from '@wordpress/i18n';
import { useRef } from '@wordpress/element';
import { applyFilters } from '@wordpress/hooks';
import Hint from '../hint.js';
import StyleSelect from '../style-select.js';
import AlignControl from '../align-control.js';
import { Select, Text, Toggle } from '../components/controls.js';
import ValueControl from '../components/value-control.js';

const { paginationTemplates } = window.formaEditor;

export default function PaginationPanel( { config, update } ) {
	const pagination = config.pagination;
	const enabled = pagination.type !== 'none';

	// Switching off and on again brings back the style picked before
	const lastStyle = useRef( enabled ? pagination.type : 'numbers' );

	if ( enabled ) {
		lastStyle.current = pagination.type;
	}

	return (
		<>
			<Toggle
				label={ __( 'Show pagination', 'forma-grid-gallery' ) }
				help={ __( 'Pages are loaded over AJAX and keep the current filter.', 'forma-grid-gallery' ) }
				checked={ enabled }
				onChange={ ( checked ) => update( 'pagination.type', checked ? lastStyle.current : 'none' ) }
				__nextHasNoMarginBottom
			/>

			{ enabled && -1 === config.query.per_page && (
				<Hint status="warning">{ __( 'Per page is -1 (show all), so there is nothing to paginate.', 'forma-grid-gallery' ) }</Hint>
			) }

			{ enabled && (
				<Select
					label={ __( 'Type', 'forma-grid-gallery' ) }
					value={ pagination.type }
					options={ applyFilters( 'forma.paginationTypes', [
						{ value: 'numbers', label: __( 'Page numbers', 'forma-grid-gallery' ) },
						{ value: 'loadmore', label: __( 'Load More button', 'forma-grid-gallery' ) },
					] ) }
					onChange={ ( value ) => update( 'pagination.type', value ) }
					__nextHasNoMarginBottom
				/>
			) }

			{ enabled && (
				<StyleSelect
					value={ pagination.template }
					templates={ paginationTemplates }
					help={ __( 'More styles come from the theme (forma_pagination_styles, files in pagination/{style}/: numbers.php, load-more.php).', 'forma-grid-gallery' ) }
					onChange={ ( value ) => update( 'pagination.template', value ) }
				/>
			) }

			{ enabled && <AlignControl value={ pagination.align } onChange={ ( value ) => update( 'pagination.align', value ) } /> }

			{ pagination.type === 'numbers' && (
				<ValueControl
					numeric
					units={ [ 'px' ] }
					min={ 0 }
					max={ 1000 }
					label={ __( 'Scroll offset', 'forma-grid-gallery' ) }
					help={ __( 'After a page loads, the grid comes into view this far below the top of the screen, e.g. the height of a sticky header.', 'forma-grid-gallery' ) }
					value={ pagination.scroll_offset ?? 0 }
					changed={ !! pagination.scroll_offset }
					onChange={ ( value ) => update( 'pagination.scroll_offset', '' === value ? 0 : Math.round( value ) ) }
				/>
			) }

			{ enabled && applyFilters( 'forma.pagination', null, { config, update } ) }

			{ ! [ 'none', 'numbers' ].includes( pagination.type ) && (
				<>
					{ pagination.type === 'loadmore' && (
						<Text label={ __( 'Button label', 'forma-grid-gallery' ) } placeholder={ __( 'Load More', 'forma-grid-gallery' ) } value={ pagination.load_more_label } onChange={ ( value ) => update( 'pagination.load_more_label', value ) } __nextHasNoMarginBottom />
					) }
					<Toggle label={ __( 'Hide when all items are shown', 'forma-grid-gallery' ) } help={ __( 'Once the last items are in, the pagination goes away instead of saying there are no more.', 'forma-grid-gallery' ) } path="pagination.hide_end" />
					<div className={ pagination.hide_end ? undefined : 'forma-editor__row is-2' }>
						<Text label={ __( 'While loading', 'forma-grid-gallery' ) } placeholder={ __( 'Loading…', 'forma-grid-gallery' ) } value={ pagination.loading_label } onChange={ ( value ) => update( 'pagination.loading_label', value ) } __nextHasNoMarginBottom />
						{ ! pagination.hide_end && (
							<Text label={ __( 'No more items', 'forma-grid-gallery' ) } placeholder={ __( 'No more items', 'forma-grid-gallery' ) } value={ pagination.no_more_label } onChange={ ( value ) => update( 'pagination.no_more_label', value ) } __nextHasNoMarginBottom />
						) }
					</div>
				</>
			) }
		</>
	);
}
