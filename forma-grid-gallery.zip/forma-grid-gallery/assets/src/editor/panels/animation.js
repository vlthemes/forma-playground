/**
 * Animation: entrance effect of items (pure CSS, see Animations.php), on load, after filtering and for loaded items.
 * Fade up comes with Forma; Forma Pro adds the other effects to the list (proAnimations).
 */
import { __ } from '@wordpress/i18n';
import { useEffect, useRef, useState } from '@wordpress/element';
import Group from '../group.js';
import ProNotice from '../pro-notice.js';
import { Select } from '../components/controls.js';
import ValueControl from '../components/value-control.js';

const { animations, proAnimations } = window.formaEditor;

// CSS times: ms, s or a custom property
const TIME = { units: [ 'ms', 's' ], functions: [ 'var' ] };

// A CSS time in ms; a custom property (unknown here) counts as the fallback
const ms = ( value, fallback ) => {
	const match = String( value ).match( /^(\d*\.?\d+)(ms|s)$/ );

	return match ? parseFloat( match[ 1 ] ) * ( 's' === match[ 2 ] ? 1000 : 1 ) : fallback;
};

// Items of the demo grid
const ITEMS = 6;

// Pauses of the demo loop, ms: the grid rests once in, and empty before it comes in again
const REST = 2000;
const EMPTY = 700;

// Effects without a way out: the whole grid fades, as on the front end, only softer
const FADE = 500;

/**
 * Animation demo. Keeps the effect and timings a round started with; changing them mid-round would flicker.
 */
function Demo( { animation, preset } ) {
	const timing = {
		name: preset.name,
		keyframes: preset.keyframes,
		ease: preset.ease,
		out: preset.out,
		duration: ms( animation.duration, 500 ),
		stagger: ms( animation.stagger, 60 ),
		outDuration: ms( animation.out_duration, 300 ),
		outStagger: ms( animation.out_stagger, 30 ),
	};
	const latest = useRef( timing );
	const [ round, setRound ] = useState( { count: 0, out: false, timing } );
	const mounted = useRef( false );

	latest.current = timing;

	// A new effect or time: the items go out (no cut) and come in again with it, once the value settles
	useEffect( () => {
		if ( ! mounted.current ) {
			mounted.current = true;
			return;
		}

		const timer = setTimeout( () => setRound( ( current ) => ( current.out ? current : { ...current, out: true } ) ), 250 );

		return () => clearTimeout( timer );
	}, [ animation.effect, timing.duration, timing.stagger, timing.outDuration, timing.outStagger ] );

	useEffect( () => {
		const used = round.timing;
		const wait = round.out
			? ( used.out ? used.outDuration + ( ITEMS - 1 ) * used.outStagger : FADE ) + EMPTY
			: used.duration + ( ITEMS - 1 ) * used.stagger + REST;
		// The next round starts with the values set by then
		const timer = setTimeout( () => setRound( ( current ) => ( current.out ? { count: current.count + 1, out: false, timing: latest.current } : { ...current, out: true } ) ), wait );

		return () => clearTimeout( timer );
	}, [ round ] );

	const used = round.timing;
	const style = ( index ) => ( round.out && used.out
		? { animation: `forma-out ${ used.outDuration }ms cubic-bezier(.55,.085,.68,.53) ${ index * used.outStagger }ms both` }
		: { animation: `${ used.name } ${ used.duration }ms ${ used.ease } ${ index * used.stagger }ms both` } );

	return (
		<div className="forma-editor__animation-demo" aria-hidden="true">
			{ used.keyframes && <style>{ used.keyframes }</style> }
			<div className={ 'forma-editor__animation-demo-items' + ( round.out && ! used.out ? ' is-out' : '' ) } style={ { '--fade': `${ FADE }ms` } }>
				{ Array.from( { length: ITEMS }, ( _, index ) => (
					<div key={ `${ index }-${ round.count }-${ round.out && used.out }` } className="forma-editor__animation-demo-item" style={ style( index ) } />
				) ) }
			</div>
		</div>
	);
}

export default function AnimationPanel( { config, update } ) {
	const animation = config.animation;
	const preset = animations.find( ( option ) => option.value === animation.effect );
	const hasOut = !! preset?.out;

	return (
		<>
			<Group title={ __( 'Effect', 'forma-grid-gallery' ) }>
				<Select
					label={ __( 'Entrance effect', 'forma-grid-gallery' ) }
					help={ __( 'Plays when items appear: on load, after filtering and for items loaded later. Off for visitors who prefer reduced motion.', 'forma-grid-gallery' ) }
					path="animation.effect"
					options={ animations.map( ( { value, label } ) => ( { value, label } ) ) }
				/>
				{ preset?.name && <Demo animation={ animation } preset={ preset } /> }
				{ ! proAnimations && <ProNotice feature={ __( 'More effects (fade, slide, zoom, blur and reveal)', 'forma-grid-gallery' ) } /> }
			</Group>

			{ animation.effect !== 'none' && (
				<Group title={ __( 'Timing', 'forma-grid-gallery' ) }>
					<div className="forma-editor__row is-2">
						<ValueControl { ...TIME } min={ 100 } max={ 2000 } label={ __( 'Duration', 'forma-grid-gallery' ) } path="animation.duration" />
						<ValueControl { ...TIME } min={ 0 } max={ 300 } label={ __( 'Stagger', 'forma-grid-gallery' ) } help={ __( 'Delays each next item a little, so they appear one after another.', 'forma-grid-gallery' ) } path="animation.stagger" />
					</div>
				</Group>
			) }

			{ hasOut && (
				<Group title={ __( 'Exit', 'forma-grid-gallery' ) }>
					<div className="forma-editor__row is-2">
						<ValueControl { ...TIME } min={ 100 } max={ 1000 } label={ __( 'Out duration', 'forma-grid-gallery' ) } help={ __( 'On a filter, search or page the old items go one by one before the new ones come in.', 'forma-grid-gallery' ) } path="animation.out_duration" />
						<ValueControl { ...TIME } min={ 0 } max={ 150 } label={ __( 'Out stagger', 'forma-grid-gallery' ) } path="animation.out_stagger" />
					</div>
				</Group>
			) }
		</>
	);
}
