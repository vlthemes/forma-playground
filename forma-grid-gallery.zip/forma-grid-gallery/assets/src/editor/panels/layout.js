/**
 * Layout panel: the type, then its own groups (its editor module, src/Layouts/{Name}/editor.js, or a theme type's
 * layout.php settings), then the current device's groups and Columns & gaps
 */
import { __ } from '@wordpress/i18n';
import ResponsivePanel from './responsive.js';
import Group from '../group.js';
import { deviceLabel } from '../components/device-fields.js';
import { DEVICES, useDevice } from '../device.js';
import { layoutModule } from '../layouts.js';
import { skinFor } from '../skins.js';
import { Select, Text, Toggle } from '../components/controls.js';
import ValueControl from '../components/value-control.js';

const { layouts, layoutData } = window.formaEditor;

/**
 * Settings of a theme layout type (from its layout.php). With a device: only the responsive ones.
 */
function ThemeSettings( { type, values, update, device } ) {
	const schema = layoutData[ type ];
	const entries = Object.entries( schema.settings ).filter( ( [ , setting ] ) => !! device === !! setting.responsive );

	if ( ! entries.length ) {
		return null;
	}

	// A responsive value saved before it became per-device (one number) applies to every device
	const perDevice = ( value, fallback ) => ( value && 'object' === typeof value ? value : Object.fromEntries( DEVICES.map( ( item ) => [ item.value, value ?? fallback[ item.value ] ] ) ) );

	return (
		<Group title={ device ? __( 'Per device', 'forma-grid-gallery' ) : __( 'Settings', 'forma-grid-gallery' ) }>
			{ entries.map( ( [ key, setting ] ) => {
				const all = device ? perDevice( values?.[ key ], setting.default ) : null;
				const fallback = device ? setting.default[ device ] : setting.default;
				const value = device ? all[ device ] ?? fallback : values?.[ key ] ?? fallback;
				const set = ( next ) => update( `layout.${ type }.${ key }`, device ? { ...all, [ device ]: next } : next );
				const common = { label: device ? deviceLabel( device, setting.label ) : setting.label, help: setting.help || undefined, __nextHasNoMarginBottom: true };

				switch ( setting.type ) {
					case 'number':
						return (
							<ValueControl
								key={ key }
								label={ common.label }
								help={ common.help }
								numeric
								units={ [ setting.unit || '' ] }
								min={ setting.min ?? undefined }
								max={ setting.max ?? undefined }
								step={ setting.step }
								value={ value }
								changed={ value !== fallback }
								onChange={ ( next ) => set( '' === next ? fallback : next ) }
							/>
						);
					case 'select':
						return <Select key={ key } { ...common } value={ value } options={ setting.options } onChange={ set } />;
					case 'toggle':
						return <Toggle key={ key } { ...common } checked={ !! value } onChange={ set } />;
					default:
						return <Text key={ key } { ...common } value={ value } onChange={ set } />;
				}
			} ) }
		</Group>
	);
}

export default function LayoutPanel( props ) {
	const { config, update, replace } = props;
	const layout = config.layout;
	// A new type keeps the card style when it takes it, else gets the first it does (both at once: update() writes
	// one path from this render's config)
	const setType = ( type ) => replace( { ...config, layout: { ...layout, type }, skin: skinFor( config.skin, type ) } );
	const [ device ] = useDevice();
	const { description, Settings, Device } = layoutModule( layout.type );
	const data = layoutData[ layout.type ] || {};
	const own = { layout, settings: layout[ layout.type ] || {}, update };

	return (
		<>
			<Group title={ __( 'Type', 'forma-grid-gallery' ) }>
				<Select label={ __( 'Layout type', 'forma-grid-gallery' ) } hideLabelFromVision value={ layout.type } options={ layouts } onChange={ setType } __nextHasNoMarginBottom />
				{ ( description || data.description ) && <p className="forma-editor__muted">{ description || data.description }</p> }
			</Group>

			{ Settings && <Settings { ...own } /> }
			{ data.settings && <ThemeSettings type={ layout.type } values={ layout[ layout.type ] } update={ update } /> }

			{ /* The device comes from the switch pinned to the top of the sidebar (DeviceBar) */ }
			{ Device && <Device { ...own } device={ device } /> }
			{ data.settings && <ThemeSettings type={ layout.type } values={ layout[ layout.type ] } update={ update } device={ device } /> }
			<ResponsivePanel { ...props } device={ device } />
		</>
	);
}
