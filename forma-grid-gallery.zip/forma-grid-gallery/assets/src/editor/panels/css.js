/**
 * Custom CSS panel (scoped to this layout by CssScoper.php), on WordPress's code editor
 */
import { __ } from '@wordpress/i18n';
import { Button, Modal } from '@wordpress/components';
import { useEffect, useRef, useState } from '@wordpress/element';
import Hint from '../hint.js';

const { canEditCss, codeEditor, cssClasses, metaCss } = window.formaEditor;

const EXAMPLE = `selector {
    background-color: #f5f5f5;
}

selector .forma__item {
    border-radius: 12px;
}`;

// What the page may already have: printed scripts have an id, concatenated ones only their global
const PRESENT = {
	'jquery-core': () => window.jQuery,
	'jquery-migrate': () => window.jQuery,
	underscore: () => window._,
	'wp-codemirror': () => window.wp?.CodeMirror,
	csslint: () => window.CSSLint,
	'code-editor': () => window.wp?.codeEditor,
};

let loading;

/**
 * The code editor's styles and scripts, loaded once when the panel first opens; scripts in order, each needs the
 * ones before it
 */
function loadCodeEditor() {
	if ( loading ) {
		return loading;
	}

	Object.entries( codeEditor.styles ).forEach( ( [ handle, url ] ) => {
		if ( ! document.getElementById( `${ handle }-css` ) ) {
			document.head.appendChild( Object.assign( document.createElement( 'link' ), { id: `${ handle }-css`, rel: 'stylesheet', href: url } ) );
		}
	} );

	loading = Object.entries( codeEditor.scripts ).reduce( ( previous, [ handle, url ] ) => previous.then( () => {
		if ( document.getElementById( `${ handle }-js` ) || PRESENT[ handle ]?.() ) {
			return null;
		}

		return new Promise( ( resolve, reject ) => {
			const script = Object.assign( document.createElement( 'script' ), { id: `${ handle }-js`, src: url, onload: resolve, onerror: reject } );

			document.head.appendChild( script );
		} );
	} ), Promise.resolve() );

	return loading;
}

/**
 * One code editor instance bound to the CSS value
 */
function CssEditor( { value, onChange, minLines, maxLines, editorRef } ) {
	const textarea = useRef();
	const change = useRef( onChange );

	// The editor instance outlives renders: keep the latest setter
	change.current = onChange;

	useEffect( () => {
		if ( ! codeEditor ) {
			return;
		}

		let cm;
		let closed = false;

		// Until it loads the plain textarea works; CodeMirror then takes what was typed in it
		loadCodeEditor().then( () => {
			if ( closed || ! textarea.current || ! window.wp?.codeEditor ) {
				return;
			}

			cm = window.wp.codeEditor.initialize( textarea.current, codeEditor.settings ).codemirror;

			const lineHeight = cm.defaultTextHeight();

			// Grow with the content between minLines and maxLines
			const fit = () => cm.setSize( null, Math.min( maxLines, Math.max( minLines, cm.lineCount() ) ) * lineHeight + 24 );

			fit();
			cm.on( 'change', () => {
				fit();
				change.current( cm.getValue() );
			} );

			if ( editorRef ) {
				editorRef.current = cm;
			}
		} ).catch( () => {} );

		// React may already have removed the wrapper: CodeMirror then cleans up a detached tree, harmlessly
		return () => {
			closed = true;
			cm?.toTextArea();
		};
	}, [] ); // eslint-disable-line react-hooks/exhaustive-deps

	// Own wrapper: CodeMirror adds its DOM next to the textarea, and React must only ever remove this div as a whole
	return (
		<div className="forma-editor__css-wrap">
		<textarea
			ref={ textarea }
			className="forma-editor__css"
			rows={ minLines }
			defaultValue={ value }
			onChange={ ( event ) => onChange( event.target.value ) }
			spellCheck={ false }
			aria-label={ __( 'Custom CSS', 'forma-grid-gallery' ) }
		/>
		</div>
	);
}

/**
 * Classes of the grid markup: click inserts a scoped rule at the end
 */
function ClassesTree( { editorRef, onInsert } ) {
	return (
		<div className="forma-editor__classes">
			<span className="forma-editor__label">{ __( 'Classes', 'forma-grid-gallery' ) }</span>
			<ul>
				{ cssClasses.map( ( item ) => (
					<li key={ item.selector } style={ { '--vlt-depth': item.depth } }>
						<button
							type="button"
							title={ item.description }
							onClick={ () => {
								const rule = `\n${ item.selector } {\n\t\n}\n`;
								const cm = editorRef.current;

								if ( cm ) {
									cm.replaceRange( rule, { line: cm.lastLine() } );
									cm.focus();
									cm.setCursor( { line: cm.lastLine() - 1, ch: 1 } );
								} else {
									onInsert( rule );
								}
							} }
						>
							{ item.selector }
						</button>
					</li>
				) ) }
			</ul>
		</div>
	);
}

/**
 * How the rules are scoped, with an example
 */
function Help() {
	return (
		<div className="forma-editor__help">
			<p>
				{ __( 'Use the', 'forma-grid-gallery' ) } <code>selector</code> { __( 'rule to style this grid; other selectors stay inside it too.', 'forma-grid-gallery' ) }
			</p>
			<pre>{ EXAMPLE }</pre>
		</div>
	);
}

export default function CssPanel( { meta, setMeta } ) {
	const css = meta[ metaCss ] ?? '';
	const setCss = ( value ) => setMeta( metaCss, value );
	const [ isOpen, setOpen ] = useState( false );
	const [ version, setVersion ] = useState( 0 );
	const sidebarEditor = useRef();
	const modalEditor = useRef();

	if ( ! canEditCss ) {
		return <Hint status="info">{ __( 'Only users allowed to edit CSS (like Additional CSS) can change this.', 'forma-grid-gallery' ) }</Hint>;
	}

	const close = () => {
		setOpen( false );
		// Re-create the sidebar editor with what was written in the modal
		setVersion( ( current ) => current + 1 );
	};

	return (
		<>
			{ ! isOpen && (
				<div className="forma-editor__css-field">
					<CssEditor key={ version } value={ css } onChange={ setCss } minLines={ 5 } maxLines={ 20 } editorRef={ sidebarEditor } />
					{ /* Expand in the corner of the field, like code editors do */ }
					<Button className="forma-editor__css-expand" icon="fullscreen-alt" size="small" label={ __( 'Expand editor', 'forma-grid-gallery' ) } onClick={ () => setOpen( true ) } />
				</div>
			) }

			<ClassesTree editorRef={ sidebarEditor } onInsert={ ( rule ) => setCss( css + rule ) } />

			<Help />

			{ isOpen && (
				<Modal title={ __( 'Custom CSS', 'forma-grid-gallery' ) } onRequestClose={ close } size="large" className="forma-editor__modal forma-editor__css-modal">
					<div className="forma-editor__css-modal-body">
						<CssEditor value={ css } onChange={ setCss } minLines={ 26 } maxLines={ 26 } editorRef={ modalEditor } />
						<aside className="forma-editor__css-aside">
							<ClassesTree editorRef={ modalEditor } onInsert={ ( rule ) => setCss( css + rule ) } />
							<Help />
						</aside>
					</div>
					<div className="forma-editor__css-modal-footer">
						<p className="forma-editor__muted">{ __( 'Scoped to this grid, saved with the layout.', 'forma-grid-gallery' ) }</p>
						<Button variant="primary" onClick={ close }>
							{ __( 'Done', 'forma-grid-gallery' ) }
						</Button>
					</div>
				</Modal>
			) }
		</>
	);
}
