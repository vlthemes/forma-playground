/**
 * Sort settings, shown under the Toolbar board when its chip is picked
 */
import { __ } from '@wordpress/i18n';
import StyleSelect from '../style-select.js';
import { Text } from '../components/controls.js';
import TokenSelect from '../components/token-select.js';

const { sortTemplates } = window.formaEditor;

export default function SortPanel( { config, update, source } ) {
	const sort = config.sort;
	const choices = source?.sorts || [];

	return (
		<>
			<StyleSelect
				value={ sort.template }
				templates={ sortTemplates }
				help={ __( 'More styles come from the theme (forma_sort_styles, files in sort/{style}/sort.php).', 'forma-grid-gallery' ) }
				onChange={ ( value ) => update( 'sort.template', value ) }
			/>
			<TokenSelect label={ __( 'Orders to offer', 'forma-grid-gallery' ) } options={ choices } path="sort.options" />
			<Text
				label={ __( 'First option', 'forma-grid-gallery' ) }
				help={ __( 'The layout\'s own order, listed first when it is not one of the orders above.', 'forma-grid-gallery' ) }
				placeholder={ __( 'Default order', 'forma-grid-gallery' ) }
				value={ sort.default_label }
				onChange={ ( value ) => update( 'sort.default_label', value ) }
				__nextHasNoMarginBottom
			/>
		</>
	);
}
