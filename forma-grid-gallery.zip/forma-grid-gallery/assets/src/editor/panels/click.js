/**
 * Click panel, what a click on an item does: open its link, the image in the lightbox, or nothing.
 * The same for every layout and skin (Renderer::click()).
 */
import { __ } from '@wordpress/i18n';
import { applyFilters } from '@wordpress/hooks';
import Hint from '../hint.js';
import ProNotice from '../pro-notice.js';
import { Select, Text } from '../components/controls.js';

const { lightboxEnabled, settingsUrl } = window.formaEditor;

export default function ClickPanel( { config, update, source } ) {
	const click = config.click;

	return (
		<>
			<Select
				label={ __( 'Action', 'forma-grid-gallery' ) }
				value={ click.action }
				options={ [
					{ value: 'open', label: __( 'Open the link', 'forma-grid-gallery' ) },
					{ value: 'lightbox', label: __( 'Open the image in a lightbox', 'forma-grid-gallery' ) },
					{ value: 'none', label: __( 'Nothing (no link)', 'forma-grid-gallery' ) },
				] }
				help={
					{
						open: source?.isMedia ? __( 'An image’s own link (Content → Images), else the image file.', 'forma-grid-gallery' ) : __( 'The item’s page.', 'forma-grid-gallery' ),
						lightbox: __( 'The items of this grid form one gallery: arrows, swipe, zoom, Esc. Images with a link of their own keep it.', 'forma-grid-gallery' ),
						none: __( 'Cards are not clickable.', 'forma-grid-gallery' ),
					}[ click.action ]
				}
				onChange={ ( value ) => update( 'click.action', value ) }
				__nextHasNoMarginBottom
			/>

			{ 'lightbox' === click.action && (
				<>
					<Select
						label={ __( 'Title', 'forma-grid-gallery' ) }
						help={ __( 'The first line of the caption under the image.', 'forma-grid-gallery' ) }
						path="click.title"
						options={ [
							{ value: 'item', label: __( 'Item title', 'forma-grid-gallery' ) },
							{ value: 'image_title', label: __( 'Image title', 'forma-grid-gallery' ) },
							{ value: 'image_caption', label: __( 'Image caption', 'forma-grid-gallery' ) },
							{ value: 'image_alt', label: __( 'Image alt text', 'forma-grid-gallery' ) },
							{ value: 'none', label: __( 'None', 'forma-grid-gallery' ) },
						] }
					/>
					<Select
						label={ __( 'Description', 'forma-grid-gallery' ) }
						help={ __( 'The text under the title. Image fields come from the Media Library.', 'forma-grid-gallery' ) }
						path="click.description"
						options={ [
							{ value: 'excerpt', label: __( 'Item excerpt', 'forma-grid-gallery' ) },
							{ value: 'image_caption', label: __( 'Image caption', 'forma-grid-gallery' ) },
							{ value: 'image_description', label: __( 'Image description', 'forma-grid-gallery' ) },
							{ value: 'image_alt', label: __( 'Image alt text', 'forma-grid-gallery' ) },
							{ value: 'none', label: __( 'None', 'forma-grid-gallery' ) },
						] }
					/>
				</>
			) }

			{ 'lightbox' === click.action && ! lightboxEnabled && (
				<Hint status="warning">
					{ __( 'The lightbox is turned off in the settings, so the image file opens instead.', 'forma-grid-gallery' ) }{ ' ' }
					<a href={ settingsUrl } target="_blank" rel="noreferrer">{ __( 'Settings', 'forma-grid-gallery' ) }</a>
				</Hint>
			) }

			{ 'open' === click.action && (
				<div className="forma-editor__row is-2">
					<Select
						label={ __( 'Target', 'forma-grid-gallery' ) }
						value={ click.target }
						options={ [
							{ value: '', label: __( 'Default', 'forma-grid-gallery' ) },
							{ value: '_blank', label: __( 'New tab (_blank)', 'forma-grid-gallery' ) },
							{ value: '_top', label: __( 'Top frame (_top)', 'forma-grid-gallery' ) },
						] }
						onChange={ ( value ) => update( 'click.target', value ) }
						__nextHasNoMarginBottom
					/>
					<Text
						label={ __( 'Rel', 'forma-grid-gallery' ) }
						placeholder="nofollow"
						value={ click.rel }
						onChange={ ( value ) => update( 'click.rel', value ) }
						__nextHasNoMarginBottom
					/>
				</div>
			) }

			{ /* Forma Pro: no right-click, dragging or saving on this grid's images (forma.protect) */ }
			{ applyFilters( 'forma.protect', <ProNotice feature={ __( 'Image protection', 'forma-grid-gallery' ) } />, { config, update } ) }
		</>
	);
}
