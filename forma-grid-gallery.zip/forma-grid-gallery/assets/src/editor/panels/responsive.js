/**
 * Columns & spacing: columns per device and gaps, compact number fields in rows
 */
import { __, sprintf } from '@wordpress/i18n';
import { useState } from '@wordpress/element';
import { Button } from '@wordpress/components';
import Group from '../group.js';
import Hint from '../hint.js';
import { DeviceColumns, DeviceNumber } from '../components/device-fields.js';
import { inherited } from '../device.js';
import { layoutModule } from '../layouts.js';

const { layoutData } = window.formaEditor;

// Tweaks to the shared fields from the layout type: false hides a field, an object overrides its props
const fieldsOf = ( layout, device ) => ( { ...layoutModule( layout.type ).fields?.( layout, device ), ...layoutData[ layout.type ]?.fields } );

// Older layouts store one gap number: it is the desktop's
const perDevice = ( value ) => ( value && 'object' === typeof value ? value : { desktop: value ?? 24 } );

// WordPress's link / linkOff icons (@wordpress/icons isn't a dependency)
const LINK = <svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="M10 17.389H8.444A5.194 5.194 0 1 1 8.444 7H10v1.5H8.444a3.694 3.694 0 0 0 0 7.389H10v1.5ZM14 7h1.556a5.194 5.194 0 0 1 0 10.39H14v-1.5h1.556a3.694 3.694 0 0 0 0-7.39H14V7Zm-4.5 6h5v-1.5h-5V13Z" /></svg>;
const UNLINK = <svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="M17.031 4.703 15.576 4l-1.56 3H14v.03l-2.324 4.47H9.5V13h1.396l-1.502 2.889h-.95a3.694 3.694 0 0 1 0-7.389H10V7H8.444a5.194 5.194 0 1 0 0 10.389h.17L7.5 19.53l1.416.719L15.049 8.5h.507a3.694 3.694 0 0 1 0 7.39H14v1.5h1.556a5.194 5.194 0 0 0 .273-10.383l1.202-2.304Z" /></svg>;

export default function ResponsivePanel( { config, update, device } ) {
	const fields = fieldsOf( config.layout, device );
	const wider = 'desktop' !== device && __( 'Empty: the wider device\'s value.', 'forma-grid-gallery' );
	const gapX = perDevice( config.responsive.gap_x );
	const gapY = perDevice( config.responsive.gap_y );
	// Linked while both gaps are the same: one value sets both
	const [ linked, setLinked ] = useState( () => JSON.stringify( gapX ) === JSON.stringify( gapY ) );
	const setGaps = ( next ) => update( 'responsive', { ...config.responsive, gap_x: next, gap_y: next } );

	const field = ( name, props ) => {
		if ( false === fields[ name ] ) {
			return null;
		}

		const field = fields[ name ] || {};
		const Control = 'columns' === name ? DeviceColumns : DeviceNumber;

		return (
			<Control
				key={ name }
				{ ...props }
				{ ...field }
				path={ `responsive.${ name }` }
				device={ device }
				disabled={ !! field.disabled }
				onChange={ ( next ) => ( linkable && linked && name.startsWith( 'gap_' ) ? setGaps( next ) : update( `responsive.${ name }`, next ) ) }
			/>
		);
	};

	const columns = field( 'columns', {
		label: __( 'Columns', 'forma-grid-gallery' ),
		values: config.responsive.columns,
		min: 1,
		max: 12,
		fallback: 3,
	} );
	const gaps = [
		field( 'gap_x', { label: __( 'Horizontal', 'forma-grid-gallery' ), values: gapX, min: 0, max: 200, fallback: 24 } ),
		field( 'gap_y', { label: __( 'Vertical', 'forma-grid-gallery' ), values: gapY, min: 0, max: 200, fallback: 24 } ),
	].filter( Boolean );

	// No link while one gap is fixed (the slider's single row)
	const linkable = 2 === gaps.length && ! fields.gap_x?.disabled && ! fields.gap_y?.disabled;

	if ( linkable ) {
		gaps.splice( 1, 0, (
			<Button
				key="link"
				className="forma-editor__gap-link"
				size="small"
				icon={ linked ? LINK : UNLINK }
				isPressed={ linked }
				label={ linked ? __( 'Unlink gaps', 'forma-grid-gallery' ) : __( 'Link gaps', 'forma-grid-gallery' ) }
				onClick={ () => {
					// Linking gives the vertical gap the horizontal one
					if ( ! linked ) {
						setGaps( gapX );
					}
					setLinked( ! linked );
				} }
			/>
		) );
	}

	if ( ! columns && ! gaps.length ) {
		return null;
	}

	// Fewer items on a page than columns on this device: part of the row stays empty
	const count = Number( config.responsive.columns?.[ device ] ?? inherited( config.responsive.columns, device ) ?? 3 );
	const perPage = config.query.per_page;
	const short = columns && count > 0 && perPage > 0 && perPage < count;

	return (
		<Group title={ columns ? __( 'Columns & gaps', 'forma-grid-gallery' ) : __( 'Gaps', 'forma-grid-gallery' ) }>
			{ columns }
			{ short && (
				<Hint>
					{ sprintf(
						/* translators: 1: items per page, 2: columns */
						__( 'A page shows %1$d items, fewer than the %2$d columns: the row stays part empty. Lower the columns or raise the items per page (Order & limit).', 'forma-grid-gallery' ),
						perPage,
						count
					) }
				</Hint>
			) }
			{ gaps.length > 0 && <div className={ linkable ? 'forma-editor__row is-linked' : `forma-editor__row is-${ gaps.length }` }>{ gaps }</div> }
			{ wider && <p className="forma-editor__muted">{ wider }</p> }
		</Group>
	);
}
