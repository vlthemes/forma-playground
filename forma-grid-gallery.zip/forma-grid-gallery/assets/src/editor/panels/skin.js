/**
 * Skin panel, the card template: the plugin's neutral built-in one and the theme's skins; how video items show
 * (Forma Pro fills it through the forma.video filter)
 */
import { __, sprintf } from '@wordpress/i18n';
import { applyFilters } from '@wordpress/hooks';
import { StyleOptions } from '../style-select.js';
import Group from '../group.js';
import ProNotice from '../pro-notice.js';
import { Select } from '../components/controls.js';
import { skinsFor } from '../skins.js';

const { skinsPath } = window.formaEditor;

export default function SkinPanel( { config, update } ) {
	return (
		<>
			<Select
				label={ __( 'Skin', 'forma-grid-gallery' ) }
				help={ sprintf( /* translators: %s: skin path inside the theme */ __( 'The theme registers skins (forma_skins_styles) with their files in %s; the built-in Default stays in the list.', 'forma-grid-gallery' ), skinsPath ) }
				value={ config.skin }
				onChange={ ( value ) => update( 'skin', value ) }
				__nextHasNoMarginBottom
			>
				{ /* The styles the layout type takes (skins.js) */ }
				<StyleOptions styles={ skinsFor( config.layout.type ) } />
			</Select>

			<Group title={ __( 'Video', 'forma-grid-gallery' ) }>
				{ applyFilters( 'forma.video', <ProNotice feature={ __( 'Video items (play on hover, autoplay)', 'forma-grid-gallery' ) } />, { config, update } ) }
			</Group>
		</>
	);
}
