/**
 * The card styles a layout type takes, as SkinManager::fits(): one made for given types (its layouts) fits those;
 * any other fits the types that don't take marked styles only (layoutData[ type ].marked_skins, as Forma Pro's List)
 */
const { skins, layoutData } = window.formaEditor;

export const fits = ( skin, type ) => ( skin.layouts?.length ? skin.layouts.includes( type ) : ! layoutData[ type ]?.marked_skins );

export const skinsFor = ( type ) => skins.filter( ( skin ) => fits( skin, type ) );

// The style for a layout type: the one chosen when it fits, else the first that does
export const skinFor = ( value, type ) => {
	const chosen = skins.find( ( skin ) => skin.value === value );

	return chosen && fits( chosen, type ) ? value : skinsFor( type )[ 0 ]?.value ?? value;
};
