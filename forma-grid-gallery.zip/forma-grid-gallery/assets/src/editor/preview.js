/**
 * Preview of the unsaved settings, rendered by Preview.php in an iframe at real size
 */
import { useSelect } from '@wordpress/data';
import { useEffect, useRef, useState } from '@wordpress/element';
import { applyFilters } from '@wordpress/hooks';
import { __, sprintf } from '@wordpress/i18n';
import Hint from './hint.js';
import * as icons from './icons.js';
import Loader from './components/loader.js';
import { sendLive, structural } from './live-css.js';
import { DEVICES, previewWidth, useDevice } from './device.js';

// Padding of the viewport and border of the device window, both sides
const FRAME = 2 * ( 12 + 1 );

const DELAY = 600;

// Height of the window while the query finds nothing: room for the note
const EMPTY_HEIGHT = 320;

const STATES = {
	empty: __( 'No items match this query.', 'forma-grid-gallery' ),
	'no-skin': __( 'The theme has no skin yet, so the preview shows placeholders in the layout.', 'forma-grid-gallery' ),
};

const { previewUrl, nonce, canEditCss, metaCss } = window.formaEditor;

let frames = 0;

export default function Preview( { config, meta } ) {
	const postId = useSelect( ( select ) => select( 'core/editor' ).getCurrentPostId(), [] );
	const [ state, setState ] = useState( { loading: true, error: false, status: 'ok', height: 0 } );
	const [ device ] = useDevice();
	const frame = useRef();
	const stage = useRef();
	const [ available, setAvailable ] = useState( 0 );
	const name = useRef( `forma-preview-${ ++frames }` );
	const configJson = JSON.stringify( config );
	// Live values (theme controls that only set CSS) restyle the frame in place; the rest renders it again
	const structuralJson = JSON.stringify( structural( config ) );
	// The unsaved custom CSS (without edit_css the preview uses the saved one), plus other plugins' unsaved values,
	// read by the forma_preview_config filter
	const extra = applyFilters( 'forma.previewData', canEditCss ? { css: meta[ metaCss ] ?? '' } : {}, meta );
	const extraJson = JSON.stringify( extra );

	useEffect( () => {
		const timer = window.setTimeout( () => {
			// The form must be in the canvas document, like the frame
			const owner = frame.current?.ownerDocument || document;
			const form = owner.createElement( 'form' );

			form.method = 'post';
			form.action = previewUrl;
			form.target = name.current;
			form.style.display = 'none';

			const isolated = owner.defaultView?.crossOriginIsolated ? '1' : '';

			Object.entries( { ...JSON.parse( extraJson ), post_id: postId, config: configJson, nonce, isolated } ).forEach( ( [ key, value ] ) => {
				const input = owner.createElement( 'input' );
				input.type = 'hidden';
				input.name = key;
				input.value = value ?? '';
				form.append( input );
			} );

			owner.body.append( form );
			setState( ( current ) => ( { ...current, loading: true } ) );
			form.submit();
			form.remove();
		}, DELAY );

		return () => window.clearTimeout( timer );
	}, [ postId, structuralJson, extraJson ] ); // eslint-disable-line react-hooks/exhaustive-deps -- posts the latest config

	// The live values, sent to the frame as they change (and after each load, in onLoad)
	const live = () => sendLive( frame.current?.contentWindow, postId, config );

	useEffect( live, [ configJson ] ); // eslint-disable-line react-hooks/exhaustive-deps

	// Rebound on every load: the frame's window changes when the block moves into the canvas
	const listening = useRef( null );
	const handler = useRef( null );
	const observers = useRef( [] );

	handler.current ??= ( event ) => {
		if ( event.source !== frame.current?.contentWindow || ! event.data?.formaPreview ) {
			return;
		}

		const { height, state: status } = event.data;

		setState( ( current ) => ( { ...current, loading: false, error: false, status: status || 'ok', height: height || current.height } ) );
	};

	const listen = () => {
		const view = frame.current?.ownerDocument?.defaultView;

		if ( view && listening.current !== view ) {
			listening.current?.removeEventListener( 'message', handler.current );
			view.addEventListener( 'message', handler.current );
			listening.current = view;
		}
	};

	useEffect( () => {
		listen();

		return () => listening.current?.removeEventListener( 'message', handler.current );
	}, [] ); // eslint-disable-line react-hooks/exhaustive-deps

	// about:blank fires load too; a page without the marker is an error page
	const onLoad = () => {
		listen();
		live();

		let doc;

		try {
			doc = frame.current?.contentDocument;
		} catch {
			// Cross-origin: rely on postMessage
			return;
		}

		if ( ! doc || 'about:blank' === doc.location?.href ) {
			return;
		}

		const marker = doc.body?.getAttribute( 'data-forma-state' );

		if ( ! marker ) {
			setState( ( current ) => ( { ...current, loading: false, error: true } ) );
			return;
		}

		const wrapper = doc.querySelector( '.forma-preview' ) || doc.body;
		const view = doc.defaultView;
		const measure = () => {
			const style = view.getComputedStyle( wrapper );
			const height = Math.ceil( wrapper.offsetHeight + ( parseFloat( style.marginTop ) || 0 ) + ( parseFloat( style.marginBottom ) || 0 ) );

			setState( ( current ) => ( current.height === height && ! current.loading ? current : { ...current, loading: false, error: false, status: marker, height } ) );
		};

		observers.current.forEach( ( observer ) => observer.disconnect() );
		observers.current = [ new view.ResizeObserver( measure ), new view.MutationObserver( measure ) ];
		observers.current[ 0 ].observe( wrapper );
		observers.current[ 1 ].observe( wrapper, { childList: true, subtree: true } );
		measure();
	};

	useEffect( () => () => observers.current.forEach( ( observer ) => observer.disconnect() ), [] );

	useEffect( () => {
		const element = stage.current;
		const Observer = element?.ownerDocument?.defaultView?.ResizeObserver;

		if ( ! Observer ) {
			return;
		}

		const observer = new Observer( ( [ entry ] ) => setAvailable( Math.floor( entry.contentRect.width ) ) );
		observer.observe( element );

		return () => observer.disconnect();
	}, [] );

	const empty = 'empty' === state.status;
	const hidden = state.error;
	const room = Math.max( 0, available - FRAME );
	const width = previewWidth( device, room );
	// Wider than the canvas (desktop is never narrower than its breakpoint): shown smaller, laid out at its own width
	const scale = room > 0 && width > room ? room / width : 1;
	const label = DEVICES.find( ( item ) => item.value === device )?.label;
	// The first load has no height yet: room for the loader
	const height = hidden ? 0 : ( empty ? EMPTY_HEIGHT : state.height || ( state.loading ? 260 : 0 ) );

	return (
		<div className={ 'forma-editor__preview' + ( state.loading ? ' is-loading' : '' ) }>
			{ state.error && <Hint status="error">{ __( 'Could not render the preview.', 'forma-grid-gallery' ) }</Hint> }
			{ ! empty && STATES[ state.status ] && <p className="forma-editor__preview-note">{ STATES[ state.status ] }</p> }
			<div ref={ stage } className="forma-editor__stage">
				{ /* The device: a window with its name and width in the bar. Always mounted (the form targets the
				   iframe); hidden only when the preview failed */ }
				<div className={ 'forma-editor__device is-' + device + ( hidden ? ' is-hidden' : '' ) }>
					<div className="forma-editor__device-head">
						{ DEVICES.find( ( item ) => item.value === device )?.icon }
						<span>{ label }</span>
						<span className="forma-editor__device-size">
							{ /* translators: %d: preview width in px */ }
							{ sprintf( /* translators: %d: preview width in pixels */ __( '%dpx', 'forma-grid-gallery' ), width ) }
						</span>
						{ scale < 1 && (
							<span className="forma-editor__device-note">
								{ sprintf( /* translators: %d: zoom of the preview, in percent */ __( 'shown at %d%%', 'forma-grid-gallery' ), Math.floor( scale * 100 ) ) }
							</span>
						) }
					</div>
					<div className={ 'forma-editor__viewport' + ( state.loading ? ' is-loading' : '' ) + ( state.height ? '' : ' is-first' ) } style={ { width: Math.floor( width * scale ), height: Math.ceil( height * scale ) } }>
						{ /* While the new preview loads: the old one faint, under the Forma loader */ }
						{ state.loading && ! hidden && <div className="forma-editor__loading"><Loader /></div> }
						{ /* Nothing matches: the note in the window, in place of the grid */ }
						{ empty && (
							<div className="forma-editor__empty">
								<span className="forma-editor__empty-icon" aria-hidden="true">{ icons.search }</span>
								<strong>{ STATES.empty }</strong>
								<span>{ __( 'Pick another source or loosen the query in the sidebar.', 'forma-grid-gallery' ) }</span>
							</div>
						) }
						<iframe
							ref={ frame }
							name={ name.current }
							title={ __( 'Grid preview', 'forma-grid-gallery' ) }
							sandbox="allow-same-origin allow-scripts"
							onLoad={ onLoad }
							className="forma-editor__frame"
							scrolling="no"
							style={ { width, height: empty ? 0 : height, overflow: 'hidden', transform: scale < 1 ? `scale(${ scale })` : undefined, transformOrigin: '0 0' } }
						/>
					</div>
				</div>
			</div>
		</div>
	);
}
