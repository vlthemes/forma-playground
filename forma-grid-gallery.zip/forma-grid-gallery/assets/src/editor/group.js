/**
 * Group of fields inside a sidebar section, titled like a dashboard widget head
 */
export default function Group( { title, children } ) {
	return (
		<div className="forma-editor__group">
			<div className="forma-editor__group-title">{ title }</div>
			<div className="forma-editor__group-body">{ children }</div>
		</div>
	);
}
