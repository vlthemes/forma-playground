/**
 * Grid Layout sidebar
 *
 * A plugin sidebar rather than document panels, which WordPress always lists after its own.
 */
import { __ } from '@wordpress/i18n';
import { Icon, PanelBody } from '@wordpress/components';
import { useDispatch, useSelect } from '@wordpress/data';
import { PluginSidebar, PluginSidebarMoreMenuItem } from '@wordpress/editor';
import { useCallback, useEffect, useMemo, useRef, useState } from '@wordpress/element';
import { applyFilters } from '@wordpress/hooks';
import useLayout from './use-layout.js';
import Shortcodes from './shortcodes.js';
import { ContentPanel, OrderPanel } from './panels/query.js';
import LayoutPanel from './panels/layout.js';
import SkinPanel from './panels/skin.js';
import ToolbarPanel from './panels/toolbar.js';
import ClickPanel from './panels/click.js';
import PaginationPanel from './panels/pagination.js';
import CssPanel from './panels/css.js';
import AnimationPanel from './panels/animation.js';
import ProNotice from './pro-notice.js';
import ExtraFields, { controls, matches } from './panels/extra.js';
import DeviceBar from './device-bar.js';
import Reset from './reset.js';
import { ShortcutList, useShortcuts } from './shortcuts.js';
import { ConfigContext } from './components/field.js';
import * as icons from './icons.js';

const SIDEBAR = 'forma-sidebar';
export const PLUGIN = 'forma-settings';

const AREA = `${ PLUGIN }/${ SIDEBAR }`;

const { sources, defaults } = window.formaEditor;

const Title = ( { icon, children, changed } ) => (
	<span className="forma-editor__panel-title">
		<Icon icon={ icon } size={ 18 } />
		{ children }
		{ changed && <span className="forma-editor__panel-dot" title={ __( 'Changed from the default', 'forma-grid-gallery' ) } /> }
	</span>
);

// The settings each section holds (Config::defaults()); the Order section's part of the query, Content the rest
const ORDER = [ 'per_page', 'orderby', 'order', 'offset', 'skip_shown', 'manual', 'meta_order' ];
const SETTINGS = {
	content: ( config ) => Object.fromEntries( Object.entries( config.query || {} ).filter( ( [ key ] ) => ! ORDER.includes( key ) ) ),
	order: ( config ) => Object.fromEntries( ORDER.map( ( key ) => [ key, config.query?.[ key ] ] ) ),
	layout: ( config ) => [ config.layout, config.responsive ],
	skin: ( config ) => [ config.skin, config.video ],
	// The controls that are on, their settings and places
	toolbar: ( config ) => [ 'search', 'filters', 'sort' ].map( ( control ) => !! config[ control ]?.enabled && config[ control ] ).concat( [ 'toolbar', 'toolbar_tablet_landscape', 'toolbar_tablet', 'toolbar_mobile' ].map( ( key ) => Object.values( config[ key ] || {} ).map( ( controls ) => controls.filter( ( control ) => config[ control ]?.enabled ) ) ) ),
	...Object.fromEntries( [ 'click', 'pagination', 'animation', 'inserts', 'proofing' ].map( ( key ) => [ key, ( config ) => config[ key ] ] ) ),
};

// Empty lists and maps count as not set (PHP sends an empty map as [])
const plain = ( value ) => JSON.stringify( value ?? null, ( key, item ) => ( item && 'object' === typeof item && ! Object.keys( item ).length ? null : item ) );

const isChanged = ( name, config ) => !! SETTINGS[ name ] && plain( SETTINGS[ name ]( config ) ) !== plain( SETTINGS[ name ]( defaults ) );

const PANELS = [
	{ name: 'content', icon: icons.content, title: __( 'Content', 'forma-grid-gallery' ), Panel: ContentPanel },
	{ name: 'order', icon: icons.order, title: __( 'Order & limit', 'forma-grid-gallery' ), Panel: OrderPanel },
	{ name: 'layout', icon: icons.layout, title: __( 'Layout', 'forma-grid-gallery' ), Panel: LayoutPanel },
	{ name: 'skin', icon: icons.skin, title: __( 'Skin', 'forma-grid-gallery' ), Panel: SkinPanel },
	{ name: 'click', icon: icons.click, title: __( 'Click action', 'forma-grid-gallery' ), Panel: ClickPanel },
	{ name: 'toolbar', icon: icons.toolbar, title: __( 'Toolbar', 'forma-grid-gallery' ), Panel: ToolbarPanel },
	{ name: 'pagination', icon: icons.pagination, title: __( 'Pagination', 'forma-grid-gallery' ), Panel: PaginationPanel },
	{ name: 'animation', icon: icons.animation, title: __( 'Animation', 'forma-grid-gallery' ), Panel: AnimationPanel },
	{ name: 'inserts', icon: icons.inserts, title: __( 'Inserts', 'forma-grid-gallery' ), Panel: () => <ProNotice feature={ __( 'Inserts (a banner, a form or any shortcode between the items)', 'forma-grid-gallery' ) } /> },
	{ name: 'proofing', icon: icons.heart, title: __( 'Proofing', 'forma-grid-gallery' ), Panel: () => <ProNotice feature={ __( 'Proofing (visitors pick their favorite images and send you the selection)', 'forma-grid-gallery' ) } /> },
	{ name: 'css', icon: icons.css, title: __( 'Custom CSS', 'forma-grid-gallery' ), Panel: CssPanel },
];

/**
 * Place theme sections: after "after" (default: before Animation) or inside "panel"
 */
function withExtra( panels ) {
	const list = panels.map( ( panel ) => ( { ...panel, extra: [] } ) );

	Object.entries( controls ).forEach( ( [ id, section ] ) => {
		const host = list.find( ( panel ) => panel.name === section.panel );

		if ( host ) {
			host.extra.push( id );
			return;
		}

		const after = list.findIndex( ( panel ) => panel.name === section.after );
		const at = after >= 0 ? after + 1 : list.findIndex( ( panel ) => 'animation' === panel.name );

		list.splice( at, 0, { name: `extra-${ id }`, id, icon: section.icon, title: section.title, extra: [] } );
	} );

	return list;
}

function useOpenOnReady() {
	const { ready, active } = useSelect(
		( select ) => ( {
			ready: select( 'core/editor' ).__unstableIsEditorReady?.() ?? true,
			active: select( 'core/interface' )?.getActiveComplementaryArea( 'core' ),
		} ),
		[]
	);
	const { enableComplementaryArea, pinItem } = useDispatch( 'core/interface' ) || {};
	const done = useRef( false );

	// The editor opens its own tab while booting; ours wins once
	useEffect( () => {
		if ( ! ready || done.current ) {
			return;
		}

		if ( active === AREA ) {
			done.current = true;
			return;
		}

		pinItem?.( 'core', AREA );
		enableComplementaryArea?.( 'core', AREA );
	}, [ ready, active ] ); // eslint-disable-line react-hooks/exhaustive-deps
}

/**
 * Keep the admin menu on Grid Layout screens without changing the user's fullscreen preference
 */
function useAdminMenu() {
	useEffect( () => {
		const body = document.body;
		const off = () => body.classList.contains( 'is-fullscreen-mode' ) && body.classList.remove( 'is-fullscreen-mode' );

		off();

		const observer = new window.MutationObserver( off );
		observer.observe( body, { attributes: true, attributeFilter: [ 'class' ] } );

		return () => observer.disconnect();
	}, [] );
}

export default function Sidebar() {
	const layout = useLayout();
	const source = sources.find( ( item ) => item.value === layout.config.query.source );
	// Pro swaps the Panel of its sections; read once its script has added the filter
	const all = useMemo( () => withExtra( applyFilters( 'forma.panels', PANELS ) ), [] );
	// Fields bound by path (components/field.js) read and write the config through it
	const binding = useMemo( () => ( { config: layout.config, update: layout.update } ), [ layout.config, layout.update ] );
	const { enableComplementaryArea } = useDispatch( 'core/interface' ) || {};
	const [ opened, setOpened ] = useState( { content: true } );
	const sections = useRef( {} );

	// An opened section scrolls up to right under the pinned device switch (and the sidebar header above it). A
	// closed sidebar renders its sections a moment later, so the section is looked for over a few frames
	const reveal = useCallback( ( name, focus ) => {
		let tries = 20;

		const scroll = () => {
			const section = sections.current[ name ];

			if ( ! section ) {
				if ( tries-- > 0 ) {
					window.requestAnimationFrame( scroll );
				}

				return;
			}

			const bar = section.parentElement?.querySelector( '.forma-editor__device-bar' );

			section.style.scrollMarginTop = bar ? `${ ( parseFloat( bar.style.top ) || 0 ) + bar.offsetHeight }px` : '';
			section.scrollIntoView( { block: 'start', behavior: window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ? 'auto' : 'smooth' } );

			if ( focus ) {
				section.querySelector( '.components-panel__body-toggle' )?.focus( { preventScroll: true } );
			}
		};

		window.requestAnimationFrame( scroll );
	}, [] );

	// One section open at a time: opening one closes the others.
	// A section's shortcut (shortcuts.js): the sidebar shows, the section opens and takes the focus
	const openSection = useCallback( ( name ) => {
		enableComplementaryArea?.( 'core', AREA );
		setOpened( { [ name ]: true } );
		reveal( name, true );
	}, [ enableComplementaryArea, reveal ] );

	useShortcuts( useMemo( () => all.map( ( panel ) => panel.name ), [ all ] ), openSection );
	useOpenOnReady();
	useAdminMenu();

	return (
		<>
			<PluginSidebarMoreMenuItem target={ SIDEBAR } icon="grid-view">
				{ __( 'Grid Settings', 'forma-grid-gallery' ) }
			</PluginSidebarMoreMenuItem>
			<PluginSidebar name={ SIDEBAR } title={ __( 'Grid Settings', 'forma-grid-gallery' ) } icon="grid-view" className="forma-editor__sidebar">
				<ConfigContext.Provider value={ binding }>
					<DeviceBar />
					{ /* Settings from a sentence, written by the site's AI: Forma Pro fills it (forma.describe) */ }
					<PanelBody title={ <Title icon={ icons.sparkles }>{ __( 'Describe your grid', 'forma-grid-gallery' ) }</Title> } initialOpen={ false } className="forma-editor__panel">
						{ applyFilters( 'forma.describe', <ProNotice feature={ __( 'Describe your grid with AI', 'forma-grid-gallery' ) } />, layout ) }
					</PanelBody>
					<PanelBody title={ <Title icon={ icons.shortcodes }>{ __( 'Shortcodes', 'forma-grid-gallery' ) }</Title> } className="forma-editor__panel">
						<Shortcodes config={ layout.config } update={ layout.update } />
					</PanelBody>
					{ all.map( ( { name, id, icon, title, Panel, extra } ) => {
						if ( id && ! matches( controls[ id ].condition, layout.config ) ) {
							return null;
						}

						const panel = id ? (
							<ExtraFields id={ id } { ...layout } />
						) : (
							<>
								<Panel { ...layout } source={ source } sources={ sources } />
								{ extra.map( ( section ) => (
									<ExtraFields key={ section } id={ section } { ...layout } grouped />
								) ) }
							</>
						);

						return (
							<PanelBody
								key={ name }
								ref={ ( element ) => ( sections.current[ name ] = element ) }
								title={ <Title icon={ icon } changed={ isChanged( name, layout.config ) }>{ title }</Title> }
								opened={ !! opened[ name ] }
								onToggle={ () => {
									if ( ! opened[ name ] ) {
										reveal( name, false );
									}

									setOpened( ( current ) => ( { [ name ]: ! current[ name ] } ) );
								} }
								className="forma-editor__panel"
							>
								{ panel }
							</PanelBody>
						);
					} ) }
					<ShortcutList panels={ all } />
					<Reset config={ layout.config } write={ layout.write } />
				</ConfigContext.Provider>
			</PluginSidebar>
		</>
	);
}
