/**
 * Grid Layout editor. The sidebar holds the settings; the canvas is one locked block with a live preview.
 * Settings are saved as post meta (_forma_config), not in the content.
 *
 * Hooks for Pro and themes (@wordpress/hooks):
 *
 *     forma.panels       ( panels )         sidebar sections: { name, icon, title, Panel }
 *     forma.previewData  ( data, meta )     extra fields posted to the preview
 *     forma.layouts      ( modules )        editor modules of layout types (layouts.js)
 *
 * A Panel gets { config, update, replace, meta, setMeta, source, sources }. Shared UI parts: window.formaEditorUI.
 */
import { __ } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { registerPlugin } from '@wordpress/plugins';
import Canvas from './canvas.js';
import Sidebar, { PLUGIN } from './sidebar.js';
import Group from './group.js';
import Hint from './hint.js';
import ImageSettings from './components/image-settings.js';
import { PatternGroup } from './components/patterns.js';
import { DeviceColumns, DeviceNumber, deviceLabel } from './components/device-fields.js';
import { Combobox, Select, Text, Textarea, Toggle } from './components/controls.js';
import TokenSelect from './components/token-select.js';
import ValueControl from './components/value-control.js';
import KnobControl from './components/knob-control.js';
import Field from './components/field.js';
import RepeaterItem from './components/repeater-item.js';
import './editor.scss';

window.formaEditorUI = {
	Group,
	Hint,
	Field,
	RepeaterItem,
	Toggle,
	Select,
	Text,
	Textarea,
	Combobox,
	TokenSelect,
	ValueControl,
	KnobControl,
	ImageSettings,
	PatternGroup,
	DeviceNumber,
	DeviceColumns,
	deviceLabel,
};

registerPlugin( PLUGIN, { render: Sidebar } );

registerBlockType( 'forma/grid-settings', {
	apiVersion: 3,
	title: __( 'Grid Layout Preview', 'forma-grid-gallery' ),
	category: 'widgets',
	icon: 'grid-view',
	// Full canvas width: the preview shows the real desktop / tablet / mobile grid of the editor's device preview
	attributes: {
		align: { type: 'string', default: 'full' },
	},
	supports: {
		align: [ 'full' ],
		inserter: false,
		html: false,
		reusable: false,
		multiple: false,
		lock: false,
		className: false,
		customClassName: false,
	},
	edit: Canvas,
	save: () => null,
} );
