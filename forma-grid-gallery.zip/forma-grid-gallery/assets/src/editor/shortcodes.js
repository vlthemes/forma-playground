/**
 * Shortcodes of the layout (top of the Grid Settings sidebar): a read-only field with "Copy" beside it
 */
import { __ } from '@wordpress/i18n';
import { useCopyToClipboard } from '@wordpress/compose';
import { useSelect } from '@wordpress/data';
import { useState } from '@wordpress/element';
import { Button } from '@wordpress/components';
import { Toggle } from './components/controls.js';

const { shortcode } = window.formaEditor;

const ICON_COPY = (
	<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
		<rect x="9" y="9" width="11" height="11" rx="2" />
		<path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1" />
	</svg>
);

const ICON_DONE = (
	<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
		<path d="M5 12.5l4.5 4.5L19 7.5" />
	</svg>
);

function ShortcodeField( { label, code } ) {
	const [ copied, setCopied ] = useState( false );
	const ref = useCopyToClipboard( code, () => {
		setCopied( true );
		window.setTimeout( () => setCopied( false ), 1500 );
	} );

	return (
		<div>
			<span className="forma-editor__label">{ label }</span>
			<div className="forma-editor__copy">
				<code title={ code }>
					<span>{ code }</span>
				</code>
				<Button
					ref={ ref }
					variant="secondary"
					className={ copied ? 'is-copied' : undefined }
					icon={ copied ? ICON_DONE : ICON_COPY }
					label={ copied ? __( 'Copied', 'forma-grid-gallery' ) : __( 'Copy shortcode', 'forma-grid-gallery' ) }
					__next40pxDefaultSize
				/>
			</div>
		</div>
	);
}

export default function Shortcodes( { config, update } ) {
	const postId = useSelect( ( select ) => select( 'core/editor' ).getCurrentPostId(), [] );
	const code = ( show ) => `[${ shortcode } id="${ postId }"${ show ? ` show="${ show }"` : '' }]`;
	const attached = config.display.attach_controls;

	return (
		<div className="forma-editor__shortcodes">
			<p className="forma-editor__muted">{ __( 'To output this layout and its parts, use these shortcodes:', 'forma-grid-gallery' ) }</p>
			<ShortcodeField label={ __( 'Grid', 'forma-grid-gallery' ) } code={ code() } />
			{ ! attached && config.search?.enabled && <ShortcodeField label={ __( 'Search', 'forma-grid-gallery' ) } code={ code( 'search' ) } /> }
			{ ! attached && config.filters.enabled && <ShortcodeField label={ __( 'Filter', 'forma-grid-gallery' ) } code={ code( 'filter' ) } /> }
			{ ! attached && config.sort?.enabled && <ShortcodeField label={ __( 'Sorting', 'forma-grid-gallery' ) } code={ code( 'sort' ) } /> }
			{ ! attached && config.pagination.type !== 'none' && <ShortcodeField label={ __( 'Pagination', 'forma-grid-gallery' ) } code={ code( 'pagination' ) } /> }
			<Toggle
				label={ __( 'Output search, filter, sorting and pagination with the grid', 'forma-grid-gallery' ) }
				help={ attached ? __( 'The grid shortcode prints the search, the filter and the sorting above and the pagination below it.', 'forma-grid-gallery' ) : __( 'Off: place them on the page yourself, with the shortcodes above.', 'forma-grid-gallery' ) }
				checked={ attached }
				onChange={ ( value ) => update( 'display.attach_controls', value ) }
				__nextHasNoMarginBottom
			/>
		</div>
	);
}
