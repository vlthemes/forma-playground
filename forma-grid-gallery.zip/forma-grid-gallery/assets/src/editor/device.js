/**
 * Device being edited, shared by the sidebar and the preview
 *
 * The editor's own device preview uses widths that don't match the grid breakpoints.
 */
import { useSyncExternalStore } from '@wordpress/element';
import { __ } from '@wordpress/i18n';

const { breakpoints } = window.formaEditor;

// Line icons, inline: the canvas iframe may not load Dashicons. The landscape tablet is the tablet on its side
const line = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round' };
const ICONS = {
	desktop: (
		<svg viewBox="0 0 24 24" aria-hidden="true">
			<rect { ...line } x="3" y="4" width="18" height="12" rx="1.5" />
			<path { ...line } d="M9 20h6M12 16v4" />
		</svg>
	),
	// The tablet icon on its side
	tablet_landscape: (
		<svg viewBox="0 0 24 24" aria-hidden="true">
			<g transform="rotate(90 12 12)">
				<rect { ...line } x="5" y="3" width="14" height="18" rx="2" />
				<path { ...line } d="M11 18h2" />
			</g>
		</svg>
	),
	tablet: (
		<svg viewBox="0 0 24 24" aria-hidden="true">
			<rect { ...line } x="5" y="3" width="14" height="18" rx="2" />
			<path { ...line } d="M11 18h2" />
		</svg>
	),
	mobile: (
		<svg viewBox="0 0 24 24" aria-hidden="true">
			<rect { ...line } x="7" y="3" width="10" height="18" rx="2" />
			<path { ...line } d="M11 18h2" />
		</svg>
	),
};

// Widest first, as Config::DEVICES: a device without its own value takes the wider one's
export const DEVICES = [
	{ value: 'desktop', icon: ICONS.desktop, label: __( 'Desktop', 'forma-grid-gallery' ) },
	{ value: 'tablet_landscape', icon: ICONS.tablet_landscape, label: __( 'Tablet Landscape', 'forma-grid-gallery' ) },
	{ value: 'tablet', icon: ICONS.tablet, label: __( 'Tablet Portrait', 'forma-grid-gallery' ) },
	{ value: 'mobile', icon: ICONS.mobile, label: __( 'Mobile Portrait', 'forma-grid-gallery' ) },
];

/**
 * Value a device shows when it has none of its own: the nearest wider device's
 *
 * @param {Object} values Values per device
 * @param {string} device Device
 * @return {*} Value, undefined when no wider device has one
 */
export function inherited( values, device ) {
	const index = DEVICES.findIndex( ( item ) => item.value === device );

	for ( let i = index - 1; i >= 0; i-- ) {
		const value = values?.[ DEVICES[ i ].value ];

		if ( null !== value && undefined !== value && '' !== value ) {
			return value;
		}
	}

	return undefined;
}


let current = 'desktop';
const listeners = new Set();

const subscribe = ( listener ) => {
	listeners.add( listener );

	return () => listeners.delete( listener );
};

export function setDevice( device ) {
	current = device;
	listeners.forEach( ( listener ) => listener() );
}

export function useDevice() {
	return [ useSyncExternalStore( subscribe, () => current ), setDevice ];
}

/**
 * Preview width in px, always inside the device's range
 *
 * @param {string} device    Device
 * @param {number} available Canvas width for the preview
 * @return {number} Width
 */
export function previewWidth( device, available = 0 ) {
	if ( 'desktop' === device ) {
		return Math.max( available, breakpoints.tablet_landscape + 1 );
	}

	if ( 'mobile' === device ) {
		return Math.min( 375, breakpoints.mobile );
	}

	return breakpoints[ device ];
}
