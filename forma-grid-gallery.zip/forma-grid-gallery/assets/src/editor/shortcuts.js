/**
 * Keyboard shortcuts to the sidebar sections, with WordPress's access modifier. Letters WordPress already uses
 * with it are skipped.
 */
import { __ } from '@wordpress/i18n';
import { useEffect } from '@wordpress/element';
import { displayShortcut, isKeyboardEvent } from '@wordpress/keycodes';

// Section name => letter
const SHORTCUTS = {
	content: 'c',
	order: 'r',
	layout: 'l',
	skin: 's',
};

/**
 * Calls open( section ) on a section's shortcut, for the sections listed
 */
export function useShortcuts( sections, open ) {
	useEffect( () => {
		const onKeyDown = ( event ) => {
			const name = sections.find( ( section ) => SHORTCUTS[ section ] && isKeyboardEvent.access( event, SHORTCUTS[ section ] ) );

			if ( name ) {
				event.preventDefault();
				open( name );
			}
		};

		document.addEventListener( 'keydown', onKeyDown );

		return () => document.removeEventListener( 'keydown', onKeyDown );
	}, [ sections, open ] );
}

/**
 * The list under the sections
 */
export function ShortcutList( { panels } ) {
	const listed = panels.filter( ( panel ) => SHORTCUTS[ panel.name ] );

	return (
		<div className="forma-editor__shortcuts-help">
			<div className="forma-editor__group-title">{ __( 'Keyboard shortcuts', 'forma-grid-gallery' ) }</div>
			<dl>
				{ listed.map( ( panel ) => (
					<div key={ panel.name }>
						<dt>{ panel.title }</dt>
						<dd>
							<kbd>{ displayShortcut.access( SHORTCUTS[ panel.name ] ) }</kbd>
						</dd>
					</div>
				) ) }
			</dl>
		</div>
	);
}
