/**
 * Device switch pinned to the top of the Grid Settings sidebar: picks the device every per-device setting
 * (pattern, columns, gaps, row height…) is edited for, and the width of the preview
 */
import { __ } from '@wordpress/i18n';
import {
	__experimentalToggleGroupControl as ToggleGroupControl,
	__experimentalToggleGroupControlOptionIcon as ToggleGroupControlOptionIcon,
} from '@wordpress/components';
import { useEffect, useRef, useState } from '@wordpress/element';
import { DEVICES, useDevice } from './device.js';

export default function DeviceBar() {
	const [ device, setDevice ] = useDevice();
	const bar = useRef();
	const [ top, setTop ] = useState( 0 );

	// The sidebar header is sticky in the same scroll area: stick right under it, whatever its height
	useEffect( () => {
		const header = bar.current?.closest( '.interface-complementary-area' )?.querySelector( '.interface-complementary-area-header' );

		if ( ! header ) {
			return;
		}

		const measure = () => setTop( header.offsetHeight );
		const observer = new window.ResizeObserver( measure );

		measure();
		observer.observe( header );

		return () => observer.disconnect();
	}, [] );

	return (
		<div ref={ bar } className="forma-editor__device-bar" style={ { top } }>
			<ToggleGroupControl label={ __( 'Device', 'forma-grid-gallery' ) } hideLabelFromVision value={ device } onChange={ setDevice } isBlock __nextHasNoMarginBottom __next40pxDefaultSize>
				{ DEVICES.map( ( item ) => (
					<ToggleGroupControlOptionIcon key={ item.value } value={ item.value } icon={ item.icon } label={ item.label } />
				) ) }
			</ToggleGroupControl>
		</div>
	);
}
