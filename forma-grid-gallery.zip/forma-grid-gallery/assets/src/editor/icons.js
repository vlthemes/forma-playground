/**
 * Section icons from assets/icons/ (svgr), shared with PHP through Admin::icon()
 */
import { ReactComponent as Shortcodes } from '../../icons/shortcodes.svg';
import { ReactComponent as Content } from '../../icons/content.svg';
import { ReactComponent as Order } from '../../icons/order.svg';
import { ReactComponent as Layout } from '../../icons/layout.svg';
import { ReactComponent as Skin } from '../../icons/skin.svg';
import { ReactComponent as Filter } from '../../icons/filter.svg';
import { ReactComponent as Pagination } from '../../icons/pagination.svg';
import { ReactComponent as Animation } from '../../icons/animation.svg';
import { ReactComponent as Inserts } from '../../icons/inserts.svg';
import { ReactComponent as Css } from '../../icons/css.svg';
import { ReactComponent as Search } from '../../icons/search.svg';
import { ReactComponent as Click } from '../../icons/click.svg';
import { ReactComponent as Sort } from '../../icons/sort.svg';
import { ReactComponent as Toolbar } from '../../icons/toolbar.svg';
import { ReactComponent as Sparkles } from '../../icons/sparkles.svg';
import { ReactComponent as Heart } from '../../icons/heart.svg';

export const shortcodes = <Shortcodes />;
export const content = <Content />;
export const order = <Order />;
export const layout = <Layout />;
export const skin = <Skin />;
export const filter = <Filter />;
export const pagination = <Pagination />;
export const animation = <Animation />;
export const inserts = <Inserts />;
export const css = <Css />;
export const search = <Search />;
export const click = <Click />;
export const sort = <Sort />;
export const toolbar = <Toolbar />;
export const sparkles = <Sparkles />;
export const heart = <Heart />;
