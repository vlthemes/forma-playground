/**
 * Pattern picker of the pattern layout types (Metro, Freeform): one pattern per device, the smaller devices inherit
 * the wider one's or use their own. The type gives the sketch of a pattern.
 */
import { __ } from '@wordpress/i18n';
import { useEffect, useRef } from '@wordpress/element';
import Group from '../group.js';

// Pattern key of each device in the type's settings, and what an empty one inherits
const PATTERN_KEYS = {
	desktop: { key: 'pattern' },
	tablet_landscape: { key: 'pattern_tablet_landscape', inherit: __( 'As desktop', 'forma-grid-gallery' ) },
	tablet: { key: 'pattern_tablet', inherit: __( 'As tablet landscape', 'forma-grid-gallery' ) },
	mobile: { key: 'pattern_mobile', inherit: __( 'As tablet portrait', 'forma-grid-gallery' ) },
};

/**
 * Columns of the pattern a device has of its own (desktop always has one); undefined when it inherits
 */
export const ownColumns = ( patterns, settings, device ) => patterns.find( ( pattern ) => pattern.value === settings?.[ PATTERN_KEYS[ device ].key ] )?.columns;

function PatternPicker( { patterns, value, inherit, label, Sketch, onChange } ) {
	const group = useRef();

	// A sketch taller than its card fades out at the bottom (is-cut); the sketches' heights follow the card width
	useEffect( () => {
		const element = group.current;
		const Observer = element?.ownerDocument.defaultView.ResizeObserver;
		const measure = () => element.querySelectorAll( '.forma-editor__sketch' ).forEach( ( sketch ) => sketch.classList.toggle( 'is-cut', sketch.scrollHeight > sketch.clientHeight + 1 ) );

		if ( ! Observer ) {
			return;
		}

		const observer = new Observer( measure );
		observer.observe( element );

		return () => observer.disconnect();
	}, [ patterns ] );

	const option = ( key, selected, content, extra = {} ) => (
		<button
			key={ key }
			type="button"
			role="radio"
			aria-checked={ selected }
			className={ 'forma-editor__pattern' + ( extra.inherit ? ' is-inherit' : '' ) + ( selected ? ' is-selected' : '' ) }
			onClick={ () => onChange( key ) }
			{ ...extra.attributes }
		>
			{ content }
		</button>
	);

	return (
		<div ref={ group } className="forma-editor__patterns" role="radiogroup" aria-label={ label }>
			{ inherit && option( '', '' === value, <span className="forma-editor__pattern-inherit">{ inherit }</span>, { inherit: true } ) }
			{ patterns.map( ( pattern ) => option( pattern.value, value === pattern.value, <Sketch pattern={ pattern } />, { attributes: { 'aria-label': pattern.label, title: pattern.label } } ) ) }
		</div>
	);
}

/**
 * The Pattern group of one device
 *
 * @param {Object}   props
 * @param {string}   props.type     Layout type (its settings are layout.{type})
 * @param {Array}    props.patterns [ { value, label, columns, tiles } ]
 * @param {Object}   props.settings The type's settings
 * @param {string}   props.device   Device
 * @param {Function} props.update   update( path, value )
 * @param {Function} props.Sketch   Sketch of one pattern
 * @param {string}   props.label    Name of the picker for screen readers
 */
export function PatternGroup( { type, patterns, settings, device, update, Sketch, label } ) {
	const current = PATTERN_KEYS[ device ];

	return (
		<Group title={ __( 'Pattern', 'forma-grid-gallery' ) }>
			<PatternPicker
				patterns={ patterns }
				value={ settings?.[ current.key ] || '' }
				inherit={ current.inherit }
				label={ label }
				Sketch={ Sketch }
				onChange={ ( value ) => update( `layout.${ type }.${ current.key }`, value ) }
			/>
			{ current.inherit && ! settings?.[ current.key ] && (
				<p className="forma-editor__muted">
					{ __( 'Uses the pattern of the wider device, narrowed to the columns below.', 'forma-grid-gallery' ) }
				</p>
			) }
		</Group>
	);
}
