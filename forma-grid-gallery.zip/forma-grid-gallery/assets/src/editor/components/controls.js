/**
 * WordPress controls in the field shell (field.js). Same props, plus path (config path to bind to).
 */
import { ComboboxControl, SelectControl, TextControl, TextareaControl, ToggleControl } from '@wordpress/components';
import Field, { FieldLabel, FieldTip, filterable, useBinding, useField } from './field.js';

function Toggle( { path, label, help, checked, onChange, changed, ...props } ) {
	const binding = useBinding( path, checked, onChange, changed );
	const { id, open, toggle } = useField();

	return (
		<div className={ 'vlt-field vlt-field--toggle' + ( props.disabled ? ' is-disabled' : '' ) }>
			<ToggleControl
				{ ...props }
				label={ <FieldLabel as="span" id={ id } label={ label } changed={ binding.changed } help={ help } open={ open } onToggle={ toggle } /> }
				checked={ !! binding.value }
				onChange={ binding.onChange }
				__nextHasNoMarginBottom
			/>
			<FieldTip id={ id } help={ help } open={ open } />
		</div>
	);
}

function Select( { path, label, help, value, onChange, changed, ...props } ) {
	const binding = useBinding( path, value, onChange, changed );

	// No label row (the label is for screen readers only)
	if ( props.hideLabelFromVision ) {
		return <SelectControl { ...props } label={ label } help={ help } value={ binding.value ?? '' } onChange={ binding.onChange } __nextHasNoMarginBottom __next40pxDefaultSize />;
	}

	return (
		<Field label={ label } help={ help } changed={ binding.changed } disabled={ props.disabled }>
			{ ( id ) => <SelectControl { ...props } id={ id } value={ binding.value ?? '' } onChange={ binding.onChange } __nextHasNoMarginBottom __next40pxDefaultSize /> }
		</Field>
	);
}

function Text( { path, label, help, value, onChange, changed, ...props } ) {
	const binding = useBinding( path, value, onChange, changed );

	if ( props.hideLabelFromVision ) {
		return <TextControl { ...props } label={ label } help={ help } value={ binding.value ?? '' } onChange={ binding.onChange } __nextHasNoMarginBottom __next40pxDefaultSize />;
	}

	return (
		<Field label={ label } help={ help } changed={ binding.changed } disabled={ props.disabled }>
			{ ( id ) => <TextControl { ...props } id={ id } value={ binding.value ?? '' } onChange={ binding.onChange } __nextHasNoMarginBottom __next40pxDefaultSize /> }
		</Field>
	);
}

function Textarea( { path, label, help, value, onChange, changed, ...props } ) {
	const binding = useBinding( path, value, onChange, changed );

	return (
		<Field label={ label } help={ help } changed={ binding.changed } disabled={ props.disabled }>
			{ ( id ) => <TextareaControl { ...props } id={ id } value={ binding.value ?? '' } onChange={ binding.onChange } __nextHasNoMarginBottom /> }
		</Field>
	);
}

/**
 * One value picked from a list that filters as you type (WordPress's ComboboxControl): the single-value
 * counterpart of TokenSelect, for long lists
 */
function Combobox( { path, label, help, value, onChange, changed, ...props } ) {
	const binding = useBinding( path, value, onChange, changed );

	return (
		<Field label={ label } help={ help } changed={ binding.changed } disabled={ props.disabled } className="vlt-combobox">
			{ () => <ComboboxControl { ...props } label={ label } hideLabelFromVision value={ binding.value ?? null } onChange={ ( next ) => null !== next && binding.onChange( next ) } allowReset={ false } __nextHasNoMarginBottom __next40pxDefaultSize /> }
		</Field>
	);
}

const FilteredToggle = filterable( Toggle );
const FilteredSelect = filterable( Select );
const FilteredText = filterable( Text );
const FilteredTextarea = filterable( Textarea );
const FilteredCombobox = filterable( Combobox );

export { FilteredToggle as Toggle, FilteredSelect as Select, FilteredText as Text, FilteredTextarea as Textarea, FilteredCombobox as Combobox };
