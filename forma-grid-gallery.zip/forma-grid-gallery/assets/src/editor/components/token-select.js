/**
 * Multi-select as chips (WordPress's FormTokenField) in the field shell
 *
 *     <TokenSelect label="Categories" options={ [ { value: 12, label: 'Design' } ] } value={ [ 12 ] } onChange={ … } />
 */
import { __ } from '@wordpress/i18n';
import { FormTokenField } from '@wordpress/components';
import Field, { useBinding } from './field.js';

export default function TokenSelect( { path, label, help, options, value, onChange, changed, placeholder, onInputChange, renderOption, disabled = false } ) {
	const binding = useBinding( path, value, onChange, changed );
	const selected = binding.value || [];

	// Labels are the tokens: two options of the same name get their value added to tell them apart
	const counts = options.reduce( ( all, option ) => ( { ...all, [ option.label ]: ( all[ option.label ] || 0 ) + 1 } ), {} );
	const tokenOf = ( option ) => ( counts[ option.label ] > 1 ? `${ option.label } (${ option.value })` : option.label );
	const byToken = new Map( options.map( ( option ) => [ tokenOf( option ), option.value ] ) );
	const byValue = new Map( options.map( ( option ) => [ String( option.value ), tokenOf( option ) ] ) );
	const byTokenOption = new Map( options.map( ( option ) => [ tokenOf( option ), option ] ) );

	return (
		<Field label={ label } help={ help } changed={ binding.changed } disabled={ disabled } className="vlt-token-select">
			{ () => (
				<FormTokenField
					label={ label }
					value={ selected.map( ( item ) => byValue.get( String( item ) ) ?? String( item ) ) }
					suggestions={ [ ...byToken.keys() ] }
					onChange={ ( tokens ) => binding.onChange( [ ...new Set( tokens.map( ( token ) => byToken.get( token ) ).filter( ( item ) => undefined !== item ) ) ] ) }
					onInputChange={ onInputChange }
					placeholder={ selected.length ? '' : placeholder ?? __( 'Choose…', 'forma-grid-gallery' ) }
					disabled={ disabled }
					__experimentalExpandOnFocus
					help=""
					__experimentalValidateInput={ ( token ) => byToken.has( token ) }
					__experimentalRenderItem={ renderOption ? ( { item } ) => ( byTokenOption.has( item ) ? renderOption( byTokenOption.get( item ) ) : item ) : undefined }
					__nextHasNoMarginBottom
					__next40pxDefaultSize
				/>
			) }
		</Field>
	);
}
