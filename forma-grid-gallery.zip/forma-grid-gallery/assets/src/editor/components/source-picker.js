/**
 * What a layout shows, as icon cards (the name in the tooltip, the picked one's under them): each post type, the
 * Media Library, and one card for the terms grids, whose taxonomy is then picked in a list (a site can have many)
 */
import { __ } from '@wordpress/i18n';
import { Tooltip } from '@wordpress/components';
import { Select } from './controls.js';

const TERMS = '__terms';

// A Dashicon, or the post type's own image (an SVG in data: or an address), colored as the text
function SourceIcon( { icon } ) {
	if ( icon.startsWith( 'dashicons-' ) ) {
		return <span className={ `forma-editor__source-icon dashicons ${ icon }` } aria-hidden="true" />;
	}

	return <span className="forma-editor__source-icon is-image" style={ { '--icon': `url("${ icon }")` } } aria-hidden="true" />;
}

export default function SourcePicker( { sources, value, onChange } ) {
	const terms = sources.filter( ( source ) => source.terms );
	const current = sources.find( ( source ) => source.value === value );
	const cards = [
		...sources.filter( ( source ) => ! source.terms ),
		...( terms.length ? [ { value: TERMS, label: __( 'Categories & tags', 'forma-grid-gallery' ), icon: 'dashicons-category' } ] : [] ),
	];
	const selected = current?.terms ? TERMS : value;

	return (
		<>
			<div className="forma-editor__sources" role="radiogroup" aria-label={ __( 'Source', 'forma-grid-gallery' ) }>
				{ cards.map( ( card ) => (
					<Tooltip key={ card.value } text={ card.label }>
						<button
							type="button"
							role="radio"
							aria-checked={ selected === card.value }
							aria-label={ card.label }
							className={ 'forma-editor__source' + ( selected === card.value ? ' is-selected' : '' ) }
							// The terms card: the first taxonomy, unless one is already picked
							onClick={ () => selected !== card.value && onChange( TERMS === card.value ? terms[ 0 ].value : card.value ) }
						>
							<SourceIcon icon={ card.icon || 'dashicons-admin-post' } />
						</button>
					</Tooltip>
				) ) }
			</div>
			<p className="forma-editor__source-name">{ cards.find( ( card ) => card.value === selected )?.label }</p>
			{ current?.terms && (
				<Select
					label={ __( 'Taxonomy', 'forma-grid-gallery' ) }
					value={ value }
					options={ terms.map( ( source ) => ( { value: source.value, label: source.label } ) ) }
					onChange={ onChange }
					__nextHasNoMarginBottom
				/>
			) }
		</>
	);
}
