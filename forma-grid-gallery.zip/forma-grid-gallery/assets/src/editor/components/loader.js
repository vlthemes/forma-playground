/**
 * Forma loader. HTML layers instead of SVG so only transform and opacity animate (GPU, no repaints).
 */
import { __ } from '@wordpress/i18n';
import './loader.scss';

export default function Loader() {
	return (
		<span className="forma-loader" role="progressbar" aria-label={ __( 'Loading', 'forma-grid-gallery' ) }>
			<i />
			<i />
			<i />
		</span>
	);
}
