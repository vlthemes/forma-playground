/**
 * Field shell for every sidebar control: label, "changed" dot and a folded help behind the "i" button
 *
 *     <Toggle path="layout.slider.loop" label="Loop" />   reads, writes and compares with Config::defaults()
 */
import { __ } from '@wordpress/i18n';
import { createContext, useContext, useId, useState } from '@wordpress/element';

const { defaults } = window.formaEditor;

// { config, update }: given by the sidebar
export const ConfigContext = createContext( null );

const get = ( object, path ) => path.split( '.' ).reduce( ( value, key ) => ( null === value || undefined === value ? undefined : value[ key ] ), object );

const same = ( a, b ) => JSON.stringify( a ?? null ) === JSON.stringify( b ?? null );

/**
 * Value, setter and "changed" of a config path; without a path, the props as given
 *
 * @param {string|undefined} path    Config path, e.g. layout.slider.loop
 * @param {*}                value   Value when there is no path
 * @param {Function}         setter  onChange when there is no path
 * @param {boolean}          changed Changed when there is no path
 */
export function useBinding( path, value, setter, changed ) {
	const context = useContext( ConfigContext );

	if ( ! path || ! context ) {
		return { value, onChange: setter, changed: !! changed };
	}

	const current = get( context.config, path );

	return {
		value: current,
		onChange: ( next ) => context.update( path, next ),
		changed: ! same( current, get( defaults, path ) ),
	};
}

/**
 * Whether a value differs from the default at a config path
 */
export const isChanged = ( path, value ) => ! same( value, get( defaults, path ) );

/**
 * The label row: label, changed dot, info button
 */
export function FieldLabel( { id, label, changed, help, open, onToggle, as: Tag = 'label' } ) {
	return (
		<span className="vlt-field__head">
			<Tag className="vlt-field__label" htmlFor={ 'label' === Tag ? id : undefined }>
				{ label }
			</Tag>
			{ changed && <span className="vlt-field__dot" title={ __( 'Changed from the default', 'forma-grid-gallery' ) } /> }
			{ help && (
				<button
					type="button"
					className={ 'vlt-field__info' + ( open ? ' is-active' : '' ) }
					aria-expanded={ open }
					aria-controls={ `${ id }-tip` }
					aria-label={ __( 'Help', 'forma-grid-gallery' ) }
					onClick={ ( event ) => {
						// Inside a toggle's label: the switch stays as it is
						event.preventDefault();
						onToggle();
					} }
				>
					i
				</button>
			) }
		</span>
	);
}

/**
 * The help under a field, shown by its "i" button
 */
export function FieldTip( { id, help, open } ) {
	return help ? (
		<div id={ `${ id }-tip` } className={ 'vlt-field__tip' + ( open ? ' is-open' : '' ) } role="note" hidden={ ! open }>
			{ help }
		</div>
	) : null;
}

/**
 * Id and folded help of one field
 */
export function useField() {
	const id = useId();
	const [ open, setOpen ] = useState( false );

	return { id: `vlt-field-${ id.replace( /:/g, '' ) }`, open, toggle: () => setOpen( ( value ) => ! value ) };
}

/**
 * A custom control with the label row and the tip: children( id ) renders the control
 */
export default function Field( { label, help, changed, className = '', disabled = false, children } ) {
	const { id, open, toggle } = useField();

	return (
		<div className={ `vlt-field ${ className }` + ( disabled ? ' is-disabled' : '' ) }>
			{ label && <FieldLabel id={ id } label={ label } changed={ changed } help={ help } open={ open } onToggle={ toggle } /> }
			<FieldTip id={ id } help={ help } open={ open } />
			{ children( id ) }
		</div>
	);
}
