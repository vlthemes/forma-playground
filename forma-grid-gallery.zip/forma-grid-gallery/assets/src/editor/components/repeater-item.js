/**
 * One entry of a list the user adds to (Inserts, custom field rules): a box with its label and a remove button
 */
import { Button } from '@wordpress/components';

export default function RepeaterItem( { label, removeLabel, onRemove, children } ) {
	return (
		<div className="forma-editor__repeater-item">
			<div className="forma-editor__repeater-head">
				<span className="forma-editor__label">{ label }</span>
				<Button icon="trash" size="small" label={ removeLabel } onClick={ onRemove } />
			</div>
			{ children }
		</div>
	);
}
