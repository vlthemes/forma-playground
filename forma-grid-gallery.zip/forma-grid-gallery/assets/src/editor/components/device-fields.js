/**
 * Per-device fields. Below desktop an empty field inherits the wider device, shown as its placeholder.
 */
import { __, sprintf } from '@wordpress/i18n';
import { Icon } from '@wordpress/components';
import { DEVICES, inherited } from '../device.js';
import ValueControl from './value-control.js';
import KnobControl from './knob-control.js';
import { isChanged } from './field.js';

// Field label with the device icon (same icons as the device switch)
export const deviceLabel = ( device, text ) => {
	const info = DEVICES.find( ( item ) => item.value === device );

	return (
		<span className="forma-editor__device-label" title={ info.label }>
			<Icon icon={ info.icon } size={ 16 } />
			{ text ?? info.label }
		</span>
	);
};

const own = ( values, device ) => 'desktop' === device || ( null !== values[ device ] && undefined !== values[ device ] && '' !== values[ device ] );

/**
 * A number in px of one device (gaps, heights)
 */
export function DeviceNumber( { label, help, values, device, min, max, fallback, onChange, disabled, path, unit = 'px' } ) {
	const wider = inherited( values, device ) ?? fallback;

	return (
		<ValueControl
			label={ deviceLabel( device, label ) }
			help={ help }
			value={ own( values, device ) ? values[ device ] : '' }
			changed={ path ? isChanged( `${ path }.${ device }`, values[ device ] ?? null ) : false }
			units={ [ unit ] }
			numeric
			min={ min }
			max={ max }
			placeholder={ String( wider ) }
			disabled={ disabled }
			onChange={ ( value ) => onChange( { ...values, [ device ]: '' === value ? ( 'desktop' === device ? fallback : null ) : value } ) }
		/>
	);
}

/**
 * Columns of one device on the dial; auto adds Auto (the slider), fixed shows a value set elsewhere (a pattern's)
 */
export function DeviceColumns( { label, help, values, device, min, max, onChange, disabled, fixed, auto = false, path } ) {
	const wider = inherited( values, device );
	const numbers = Array.from( { length: max - min + 1 }, ( _, i ) => min + i );
	const options = [ ...( auto ? [ { value: 'auto', label: __( 'Auto', 'forma-grid-gallery' ) } ] : [] ), ...numbers ];
	const name = ( value ) => ( 'auto' === value ? __( 'Auto', 'forma-grid-gallery' ) : value );
	const value = fixed ?? ( own( values, device ) ? values[ device ] : '' );

	return (
		<KnobControl
			label={ deviceLabel( device, label ) }
			help={ 'auto' === ( values[ device ] ?? wider ) ? __( 'Slides as wide as their content: give the items a static height.', 'forma-grid-gallery' ) : help }
			value={ value }
			changed={ path && undefined === fixed ? isChanged( `${ path }.${ device }`, values[ device ] ?? null ) : false }
			options={ options }
			// translators: %s: columns of the wider device
			inherit={ 'desktop' === device || undefined !== fixed ? undefined : { value: wider, label: sprintf( __( 'As wider device (%s)', 'forma-grid-gallery' ), name( wider ) ) } }
			disabled={ disabled }
			onChange={ ( next ) => onChange( { ...values, [ device ]: '' === next ? null : next } ) }
		/>
	);
}
