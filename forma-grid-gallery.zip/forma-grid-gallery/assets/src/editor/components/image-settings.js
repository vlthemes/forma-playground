/**
 * Image group of the layout types with an image ratio and fit (Grid, Slider, Freeform): handed to the skin's .forma__media
 */
import { __, sprintf } from '@wordpress/i18n';
import { applyFilters } from '@wordpress/hooks';
import Group from '../group.js';
import { DEVICES, inherited, useDevice } from '../device.js';
import { deviceLabel } from './device-fields.js';
import { Select } from './controls.js';

// Layouts\Image::choices(): the built-in ratios and an add-on's (forma_image_ratios)
const { ratios } = window.formaEditor;

// Saved key of a device's ratio (Layouts\Image::DEVICE_KEYS); desktop's is the ratio itself
const ratioKey = ( device ) => ( 'desktop' === device ? 'ratio' : `ratio_${ device }` );

const ratioName = ( value ) => ( 'auto' === value ? __( 'Original', 'forma-grid-gallery' ) : ratios.find( ( ratio ) => ratio.value === value )?.label || value );

/**
 * Image ratio of the device being edited (below desktop empty follows the wider device) and fit, handed to the
 * skin's .forma__media; an add-on's fields for its own ratios come after them (forma.imageSettings)
 */
export default function ImageSettings( { type, values, update, ratioDisabled = false } ) {
	const [ device ] = useDevice();
	const perDevice = Object.fromEntries( DEVICES.map( ( item ) => [ item.value, values[ ratioKey( item.value ) ] ] ) );
	const wider = inherited( perDevice, device );

	return (
		<Group title={ __( 'Image', 'forma-grid-gallery' ) }>
			<div className="forma-editor__row is-2">
				<Select
					label={ deviceLabel( device, __( 'Ratio', 'forma-grid-gallery' ) ) }
					help={ __( 'Applied to .forma__media in the skin. Each device can have its own.', 'forma-grid-gallery' ) }
					disabled={ ratioDisabled }
					path={ `layout.${ type }.${ ratioKey( device ) }` }
					options={ [
						// translators: %s: ratio of the wider device
						...( 'desktop' === device ? [] : [ { value: '', label: sprintf( __( 'As wider device (%s)', 'forma-grid-gallery' ), ratioName( wider ) ) } ] ),
						...ratios.map( ( ratio ) => ( { ...ratio, label: ratioName( ratio.value ) } ) ),
					] }
				/>
				<Select
					label={ __( 'Fit', 'forma-grid-gallery' ) }
					value={ values.fit }
					options={ [
						{ value: 'cover', label: __( 'Cover', 'forma-grid-gallery' ) },
						{ value: 'contain', label: __( 'Contain', 'forma-grid-gallery' ) },
					] }
					onChange={ ( value ) => update( `layout.${ type }.fit`, value ) }
				/>
			</div>
			{ applyFilters( 'forma.imageSettings', null, { type, values, update, perDevice } ) }
		</Group>
	);
}
