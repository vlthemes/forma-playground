/**
 * PositionControl: nine places. Clicking the chosen one again clears it.
 */
import { __ } from '@wordpress/i18n';
import Field from './field.js';

const ROWS = [ 'top', 'center', 'bottom' ];
const COLUMNS = [ 'left', 'center', 'right' ];

const PLACES = {
	'top left': __( 'Top left', 'forma-grid-gallery' ),
	'top center': __( 'Top center', 'forma-grid-gallery' ),
	'top right': __( 'Top right', 'forma-grid-gallery' ),
	'center left': __( 'Middle left', 'forma-grid-gallery' ),
	'center center': __( 'Middle', 'forma-grid-gallery' ),
	'center right': __( 'Middle right', 'forma-grid-gallery' ),
	'bottom left': __( 'Bottom left', 'forma-grid-gallery' ),
	'bottom center': __( 'Bottom center', 'forma-grid-gallery' ),
	'bottom right': __( 'Bottom right', 'forma-grid-gallery' ),
};

/**
 * The blocks: [ value, label ] in rows of `columns`
 */
function Places( { label, help, changed, value, onChange, options, columns, className, content } ) {
	const values = options.map( ( [ key ] ) => key );
	const current = values.includes( value ) ? value : '';

	const move = ( event, index ) => {
		const step = { ArrowUp: -columns, ArrowDown: columns, ArrowLeft: -1, ArrowRight: 1 }[ event.key ];
		const next = values[ index + ( step ?? 0 ) ];

		if ( ! step || ! next ) {
			return;
		}

		event.preventDefault();
		onChange( next );
		event.currentTarget.parentElement.querySelector( `[data-place="${ next }"]` )?.focus();
	};

	return (
		<Field label={ label } help={ help } changed={ changed }>
			{ () => (
				<div className={ 'forma-place ' + className }>
					<div className="forma-place__grid" role="radiogroup" aria-label={ label }>
						{ options.map( ( [ key, text ], index ) => (
							<button
								key={ key }
								type="button"
								role="radio"
								aria-checked={ key === current }
								aria-label={ text }
								title={ text }
								data-place={ key }
								tabIndex={ key === ( current || values[ Math.floor( values.length / 2 ) ] ) ? 0 : -1 }
								className={ 'forma-place__cell' + ( key === current ? ' is-active' : '' ) }
								onClick={ () => onChange( key === current ? '' : key ) }
								onKeyDown={ ( event ) => move( event, index ) }
							>
								{ content?.( key ) }
							</button>
						) ) }
					</div>
				</div>
			) }
		</Field>
	);
}

// Three lines of text, placed as the block's choice
const EDGES = { top: 'flex-start', left: 'flex-start', center: 'center', bottom: 'flex-end', right: 'flex-end' };

function Lines( { x, y = 'center' } ) {
	return (
		<span className="forma-place__lines" style={ { alignItems: EDGES[ x ], alignSelf: EDGES[ y ] } } aria-hidden="true">
			<i />
			<i />
			<i />
		</span>
	);
}

export function PositionControl( props ) {
	return (
		<Places
			{ ...props }
			className="is-position"
			columns={ 3 }
			options={ ROWS.flatMap( ( row ) => COLUMNS.map( ( column ) => [ `${ row } ${ column }`, PLACES[ `${ row } ${ column }` ] ] ) ) }
			content={ ( key ) => <Lines x={ key.split( ' ' )[ 1 ] } y={ key.split( ' ' )[ 0 ] } /> }
		/>
	);
}
