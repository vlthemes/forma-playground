/**
 * A number with a unit (or a CSS function / keyword) and a draggable ruler under it (Shift: steps of 10)
 *
 *     <ValueControl label="Minimal height" value="80vh" units={ [ 'px', 'vh', '%' ] } functions onChange={ … } />
 *     <ValueControl label="Gap" value={ 24 } units={ [ 'px' ] } numeric min={ 0 } max={ 200 } onChange={ … } />
 *     <ValueControl label="Speed" path="layout.slider.speed" units={ [ 'ms', 's' ] } numeric step={ 50 } />
 *
 * numeric: the value is a number in units[0] (ms stays ms even when shown in s).
 */
import { __ } from '@wordpress/i18n';
import { Dropdown } from '@wordpress/components';
import { useEffect, useLayoutEffect, useRef, useState } from '@wordpress/element';
import Field, { filterable, useBinding } from './field.js';

const LENGTH_UNITS = [ 'px', '%', 'em', 'rem', 'vw', 'vh', 'vmin', 'vmax' ];

const FUNCTIONS = [ 'clamp', 'min', 'max', 'calc', 'var' ];

const PLACEHOLDERS = {
	clamp: '200px, 50vh, 600px',
	min: '100px, 50%',
	max: '300px, 50vw',
	calc: '100% - 20px',
	var: '--name',
};

/**
 * Mode (unit, function or keyword) and the text of the field
 */
export function parse( value, units, keywords ) {
	const text = String( value ?? '' ).trim();
	let match = text.match( /^(-?\d*\.?\d+)([a-z%]*)$/i );

	if ( match && ( ! match[ 2 ] || units.includes( match[ 2 ].toLowerCase() ) ) ) {
		return { mode: match[ 2 ].toLowerCase() || units[ 0 ], text: match[ 1 ] };
	}

	match = text.match( /^(clamp|min|max|calc|var)\((.*)\)$/i );

	if ( match ) {
		return { mode: match[ 1 ].toLowerCase(), text: match[ 2 ].trim() };
	}

	if ( keywords.includes( text ) ) {
		return { mode: text, text: '' };
	}

	return { mode: units[ 0 ], text: '' === text ? '' : text };
}

/**
 * The CSS value of a mode and text; '' when the text is empty
 */
export function format( mode, text, keywords ) {
	const value = String( text ).trim();

	if ( keywords.includes( mode ) ) {
		return mode;
	}

	if ( '' === value ) {
		return '';
	}

	if ( 'var' === mode ) {
		const [ name, ...fallback ] = value.split( ',' ).map( ( part ) => part.trim() );
		const variable = name.startsWith( '--' ) ? name : `--${ name }`;

		return fallback.length ? `var(${ variable }, ${ fallback.join( ', ' ) })` : `var(${ variable })`;
	}

	return FUNCTIONS.includes( mode ) ? `${ mode }(${ value })` : `${ value }${ mode }`;
}

// Times a numeric field can switch between, in ms
const TIME = { ms: 1, s: 1000 };

// No float noise (0.30000000000000004) in the field
const tidy = ( number ) => String( parseFloat( number.toFixed( 4 ) ) );

// How far the ruler turns for one step, px
const TURN = 2;

const clamp = ( number, min, max ) => Math.min( max ?? Infinity, Math.max( min ?? -Infinity, number ) );

function UnitMenu( { mode, groups, onSelect } ) {
	return (
		<Dropdown
			className="vlt-value__unit-wrap"
			popoverProps={ { placement: 'bottom-end', className: 'vlt-field-menu' } }
			renderToggle={ ( { isOpen, onToggle } ) => (
				<button type="button" className="vlt-value__unit" aria-haspopup="listbox" aria-expanded={ isOpen } onClick={ onToggle } aria-label={ __( 'Unit', 'forma-grid-gallery' ) }>
					{ mode }
				</button>
			) }
			renderContent={ ( { onClose } ) => (
				<div className="vlt-field-menu__list" role="listbox">
					{ groups.map( ( group ) => (
						<div key={ group.label } className="vlt-field-menu__group" role="group" aria-label={ group.label }>
							<div className="vlt-field-menu__label">{ group.label }</div>
							{ group.options.map( ( option ) => (
								<button
									key={ option }
									type="button"
									role="option"
									aria-selected={ option === mode }
									className={ 'vlt-field-menu__item' + ( option === mode ? ' is-active' : '' ) }
									onClick={ () => {
										onSelect( option );
										onClose();
									} }
								>
									{ option }
								</button>
							) ) }
						</div>
					) ) }
				</div>
			) }
		/>
	);
}

function ValueControl( {
	path,
	label,
	help,
	value,
	onChange,
	changed,
	units = LENGTH_UNITS,
	functions = false,
	keywords = [],
	numeric = false,
	min,
	max,
	step = 1,
	placeholder,
	disabled = false,
} ) {
	const binding = useBinding( path, value, onChange, changed );
	const parsed = parse( binding.value, units, keywords );
	const [ mode, setMode ] = useState( parsed.mode );
	const [ text, setText ] = useState( parsed.text );
	const [ dragging, setDragging ] = useState( false );
	const drag = useRef( null );
	// The ruler turns on its own (it keeps turning at min and max), straight on the element: a render per mouse
	// move would make it stutter
	const track = useRef( null );
	const spin = useRef( 0 );
	// What this field sent last: coming back from the config, it does not overwrite what is being typed
	const sent = useRef( undefined );
	const isLength = units.includes( mode );
	const isKeyword = keywords.includes( mode );
	// How many units[0] one unit shown is (1 but for a time shown in s): min, max and step are in units[0]
	const ratio = ( unit ) => ( TIME[ unit ] && TIME[ units[ 0 ] ] ? TIME[ unit ] / TIME[ units[ 0 ] ] : 1 );
	// The value in units[0]: the number typed, else the placeholder's
	const stored = () => {
		const number = parseFloat( text );

		return Number.isNaN( number ) ? parseFloat( placeholder ) || 0 : number * ratio( mode );
	};

	// A new value from outside (another device, a reset): show it, before the paint so the old text never flashes
	useLayoutEffect( () => {
		// Once only: the same value coming back later (from another device) must show again
		if ( JSON.stringify( binding.value ) === sent.current ) {
			sent.current = undefined;
			return;
		}

		const next = parse( binding.value, units, keywords );

		// A number keeps the unit it is shown in
		if ( numeric ) {
			setText( '' === next.text ? '' : tidy( parseFloat( next.text ) / ratio( mode ) ) );
			return;
		}

		setMode( next.mode );
		setText( next.text );
	}, [ JSON.stringify( binding.value ) ] ); // eslint-disable-line react-hooks/exhaustive-deps

	const commit = ( nextMode, nextText ) => {
		setMode( nextMode );
		setText( nextText );

		const number = parseFloat( nextText );
		const next = numeric
			? ( '' === String( nextText ).trim() ? '' : clamp( Number.isNaN( number ) ? 0 : Math.round( number * ratio( nextMode ) * 1e4 ) / 1e4, min, max ) )
			: format( nextMode, nextText, keywords );

		sent.current = JSON.stringify( next );
		binding.onChange( next );
	};

	// delta in units[0]
	const turn = ( steps ) => {
		spin.current += steps * TURN;

		if ( track.current ) {
			track.current.style.backgroundPositionX = `${ Math.round( spin.current ) }px`;
		}
	};

	const stepBy = ( delta ) => {
		turn( delta / step );

		commit( mode, tidy( clamp( Math.round( ( stored() + delta ) * 100 ) / 100, min, max ) / ratio( mode ) ) );
	};

	const onPointerDown = ( event ) => {
		if ( disabled || ! isLength ) {
			return;
		}

		event.currentTarget.setPointerCapture( event.pointerId );
		drag.current = { x: event.clientX, value: stored(), text: null, frame: 0 };
		setDragging( true );
	};

	const onPointerMove = ( event ) => {
		if ( ! drag.current ) {
			return;
		}

		// Let go where no pointerup came (over the preview frame, out of the window): the drag is over
		if ( ! event.buttons ) {
			onPointerUp();
			return;
		}

		const steps = ( event.clientX - drag.current.x ) * ( event.shiftKey ? 10 : 1 );
		const state = drag.current;
		const rect = track.current.getBoundingClientRect();

		state.x = event.clientX;

		// Off the track (a little slack above and below it) the value stays; back on it, it goes on from where the pointer is
		if ( event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top - 8 || event.clientY > rect.bottom + 8 ) {
			return;
		}

		turn( steps );
		state.value = clamp( state.value + steps * step, min, max );
		state.text = tidy( ( Math.round( state.value / step ) * step ) / ratio( mode ) );

		// The config (and the preview) once a frame
		if ( ! state.frame ) {
			state.frame = requestAnimationFrame( () => {
				state.frame = 0;
				commit( mode, state.text );
			} );
		}
	};

	const onPointerUp = () => {
		const state = drag.current;

		if ( ! state ) {
			return;
		}

		if ( state.frame ) {
			cancelAnimationFrame( state.frame );
			commit( mode, state.text );
		}

		drag.current = null;
		setDragging( false );
	};

	// While dragging, a release anywhere (or the window left) ends it; the latest onPointerUp, it commits the last value
	const release = useRef( onPointerUp );
	release.current = onPointerUp;

	useEffect( () => {
		if ( ! dragging ) {
			return;
		}

		const end = () => release.current();

		window.addEventListener( 'pointerup', end );
		window.addEventListener( 'blur', end );

		return () => {
			window.removeEventListener( 'pointerup', end );
			window.removeEventListener( 'blur', end );
		};
	}, [ dragging ] );

	const offered = true === functions ? FUNCTIONS : FUNCTIONS.filter( ( name ) => ( functions || [] ).includes( name ) );
	const calls = offered.filter( ( name ) => 'var' !== name );

	const groups = [
		units.length > 1 && { label: __( 'Units', 'forma-grid-gallery' ), options: units },
		calls.length && { label: __( 'Functions', 'forma-grid-gallery' ), options: calls },
		offered.includes( 'var' ) && { label: __( 'Variable', 'forma-grid-gallery' ), options: [ 'var' ] },
		keywords.length && { label: __( 'Keywords', 'forma-grid-gallery' ), options: keywords },
	].filter( Boolean );

	return (
		<Field label={ label } help={ help } changed={ binding.changed } disabled={ disabled } className={ 'vlt-value' + ( dragging ? ' is-dragging' : '' ) }>
			{ ( id ) => (
				<>
					<div className={ 'vlt-value__box' + ( isKeyword || disabled ? ' is-disabled' : '' ) }>
						<input
							id={ id }
							className="vlt-value__input"
							type="text"
							inputMode={ isLength ? 'decimal' : 'text' }
							value={ text }
							placeholder={ isKeyword ? mode : PLACEHOLDERS[ mode ] ?? ( numeric && placeholder ? tidy( parseFloat( placeholder ) / ratio( mode ) ) : placeholder ) }
							disabled={ disabled || isKeyword }
							onChange={ ( event ) => {
								const from = parseFloat( text );
								const to = parseFloat( event.target.value );

								if ( isLength && ! Number.isNaN( from ) && ! Number.isNaN( to ) ) {
									turn( ( ( to - from ) * ratio( mode ) ) / step );
								}

								commit( mode, event.target.value );
							} }
							onKeyDown={ ( event ) => {
								if ( isLength && ( 'ArrowUp' === event.key || 'ArrowDown' === event.key ) ) {
									event.preventDefault();
									stepBy( ( 'ArrowUp' === event.key ? 1 : -1 ) * step * ( event.shiftKey ? 10 : 1 ) );
								}
							} }
						/>
						{ groups.length ? (
							<UnitMenu
								mode={ mode }
								groups={ groups }
								onSelect={ ( next ) => {
									// A number keeps its value across units; a function starts from its example, a variable empty
									if ( numeric ) {
										commit( next, '' === text.trim() ? '' : tidy( stored() / ratio( next ) ) );
									} else if ( FUNCTIONS.includes( next ) ) {
										commit( next, 'var' === next ? '' : FUNCTIONS.includes( mode ) ? text : PLACEHOLDERS[ next ] );
									} else if ( TIME[ mode ] && TIME[ next ] && '' !== text.trim() && ! Number.isNaN( parseFloat( text ) ) ) {
										commit( next, tidy( stored() / ratio( next ) ) );
									} else {
										commit( next, units.includes( next ) && ! units.includes( mode ) ? '' : text );
									}
								} }
							/>
						) : (
							mode && <span className="vlt-value__unit is-static">{ mode }</span>
						) }
					</div>
					{ isLength && ! disabled && (
						<div className="vlt-value__ruler">
							<button type="button" className="vlt-value__step" tabIndex={ -1 } aria-hidden="true" onClick={ ( event ) => stepBy( -step * ( event.shiftKey ? 10 : 1 ) ) }>
								◀
							</button>
							<span
								className="vlt-value__track"
								ref={ track }
								onPointerDown={ onPointerDown }
								onPointerMove={ onPointerMove }
								onPointerUp={ onPointerUp }
								onPointerCancel={ onPointerUp }
								onLostPointerCapture={ onPointerUp }
								title={ __( 'Drag to change (Shift: faster)', 'forma-grid-gallery' ) }
							/>
							<button type="button" className="vlt-value__step" tabIndex={ -1 } aria-hidden="true" onClick={ ( event ) => stepBy( step * ( event.shiftKey ? 10 : 1 ) ) }>
								▶
							</button>
						</div>
					) }
				</>
			) }
		</Field>
	);
}

export default filterable( ValueControl );
