/**
 * Pick one of a few values with a dial next to the field (drag, click or keyboard)
 *
 *     <KnobControl label="Columns" value={ 3 } options={ [ 'auto', 1, 2, 3, 4 ] } onChange={ … } />
 */
import { __, sprintf } from '@wordpress/i18n';
import { Popover } from '@wordpress/components';
import { useEffect, useRef, useState } from '@wordpress/element';
import Field, { filterable, useBinding } from './field.js';

// The dial's arc: from bottom left (135°) clockwise to bottom right (405°)
const START = 135;
const END = 405;
const RADIUS = 17.5;
const CENTER = 22;
// Drag distance of one step
const STEP_PX = 24;

const normalize = ( option ) => ( 'object' === typeof option && null !== option ? option : { value: option, label: String( option ) } );

function KnobControl( { path, label, help, value, onChange, changed, options, inherit, disabled = false } ) {
	const binding = useBinding( path, value, onChange, changed );
	const list = options.map( normalize );
	const [ open, setOpen ] = useState( false );
	const [ typed, setTyped ] = useState( null );
	const [ dragging, setDragging ] = useState( false );
	const wrap = useRef();
	const dial = useRef();
	const drag = useRef( null );

	const isEmpty = '' === binding.value || null === binding.value || undefined === binding.value;
	const shown = isEmpty && inherit ? inherit.value : binding.value;
	const index = list.findIndex( ( option ) => String( option.value ) === String( shown ) );
	const angle = ( i ) => START + ( list.length > 1 ? i / ( list.length - 1 ) : 0 ) * ( END - START );
	const text = ( i ) => list[ i ]?.label ?? '';

	const pick = ( i ) => {
		const next = Math.max( 0, Math.min( list.length - 1, i ) );

		setTyped( null );
		binding.onChange( list[ next ].value );
	};

	const choices = [ ...( inherit ? [ { value: '', label: inherit.label } ] : [] ), ...list ];

	const onInputKey = ( event ) => {
		const current = index < 0 ? 0 : index;

		if ( 'ArrowDown' === event.key || 'ArrowUp' === event.key ) {
			event.preventDefault();

			if ( ! open ) {
				setOpen( true );

				return;
			}

			pick( current + ( 'ArrowDown' === event.key ? 1 : -1 ) );
		} else if ( 'Enter' === event.key || 'Escape' === event.key ) {
			if ( open ) {
				event.preventDefault();
				setOpen( false );
			}
		} else if ( 'Tab' === event.key ) {
			setOpen( false );
		}
	};

	// What was typed, on leaving the field: a listed value, empty (inherit) or back to the value
	const onBlur = () => {
		if ( null !== typed ) {
			const found = list.findIndex( ( option ) => String( option.value ).toLowerCase() === typed.trim().toLowerCase() || option.label.toLowerCase() === typed.trim().toLowerCase() );

			if ( found >= 0 ) {
				pick( found );
			} else if ( '' === typed.trim() && inherit ) {
				binding.onChange( '' );
			}
		}

		setTyped( null );
		// Focus stays in the input while the list is open (its items don't take it), so the Popover can't tell
		// a click elsewhere: leaving the input closes it
		setOpen( false );
	};

	const onDialKey = ( event ) => {
		const current = index < 0 ? 0 : index;
		const moves = { ArrowUp: 1, ArrowRight: 1, ArrowDown: -1, ArrowLeft: -1, PageUp: 2, PageDown: -2 };

		if ( 'Home' === event.key || 'End' === event.key ) {
			event.preventDefault();
			pick( 'Home' === event.key ? 0 : list.length - 1 );
		} else if ( moves[ event.key ] ) {
			event.preventDefault();
			pick( current + moves[ event.key ] );
		}
	};

	const onPointerDown = ( event ) => {
		if ( disabled ) {
			return;
		}

		event.preventDefault();
		event.currentTarget.setPointerCapture( event.pointerId );
		event.currentTarget.focus();
		drag.current = { x: event.clientX, y: event.clientY, last: event.clientY, moved: false, index: index < 0 ? 0 : index };
		setDragging( true );
	};

	const onPointerMove = ( event ) => {
		const state = drag.current;

		if ( ! state ) {
			return;
		}

		// Let go where no pointerup came (over the preview frame, out of the window): the drag is over
		if ( ! event.buttons ) {
			cancel();
			return;
		}

		if ( ! state.moved && Math.hypot( event.clientX - state.x, event.clientY - state.y ) > 4 ) {
			state.moved = true;
		}

		// Up turns it on, sideways does nothing
		state.index = Math.max( 0, Math.min( list.length - 1, state.index + ( state.last - event.clientY ) / STEP_PX ) );
		state.last = event.clientY;

		if ( state.moved && Math.round( state.index ) !== index ) {
			pick( Math.round( state.index ) );
		}
	};

	const cancel = () => {
		drag.current = null;
		setDragging( false );
	};

	// While dragging, a release outside the dial (or the window left) ends it without a pick
	useEffect( () => {
		if ( ! dragging ) {
			return;
		}

		window.addEventListener( 'pointerup', cancel );
		window.addEventListener( 'blur', cancel );

		return () => {
			window.removeEventListener( 'pointerup', cancel );
			window.removeEventListener( 'blur', cancel );
		};
	}, [ dragging ] ); // eslint-disable-line react-hooks/exhaustive-deps

	// A click without a drag: the dot nearest to the pointer, by its angle from the center
	const onPointerUp = ( event ) => {
		const state = drag.current;

		drag.current = null;
		setDragging( false );

		if ( ! state || state.moved ) {
			return;
		}

		const box = dial.current.getBoundingClientRect();
		let degrees = ( Math.atan2( event.clientY - ( box.top + box.height / 2 ), event.clientX - ( box.left + box.width / 2 ) ) * 180 ) / Math.PI;

		degrees = degrees < 0 ? degrees + 360 : degrees;
		degrees = degrees < START ? degrees + 360 : degrees;

		pick( Math.round( ( ( Math.min( END, Math.max( START, degrees ) ) - START ) / ( END - START ) ) * ( list.length - 1 ) ) );
	};

	return (
		<Field label={ label } help={ help } changed={ binding.changed } disabled={ disabled } className="vlt-knob">
			{ ( id ) => (
				<div className="vlt-knob__row">
					<div className="vlt-knob__input-wrap" ref={ wrap }>
						<input
							id={ id }
							className="vlt-knob__input"
							type="text"
							role="combobox"
							autoComplete="off"
							aria-expanded={ open }
							aria-controls={ `${ id }-list` }
							aria-autocomplete="list"
							value={ typed ?? ( isEmpty ? '' : text( index ) ) }
							placeholder={ isEmpty && inherit ? text( index ) : '' }
							disabled={ disabled }
							onFocus={ () => setOpen( true ) }
							onClick={ () => setOpen( true ) }
							onChange={ ( event ) => setTyped( event.target.value ) }
							onKeyDown={ onInputKey }
							onBlur={ onBlur }
						/>
						{ open && ! disabled && (
							<Popover anchor={ wrap.current } placement="bottom-start" focusOnMount={ false } onClose={ () => setOpen( false ) } className="vlt-field-menu" offset={ 6 }>
								{ /* Keeps the focus in the input: scrolling the list isn't leaving it */ }
								<div id={ `${ id }-list` } className="vlt-field-menu__list" role="listbox" onMouseDown={ ( event ) => event.preventDefault() }>
									{ choices.map( ( choice ) => {
										const selected = '' === choice.value ? isEmpty : ! isEmpty && String( choice.value ) === String( binding.value );

										return (
											<button
												key={ String( choice.value ) }
												type="button"
												role="option"
												aria-selected={ selected }
												className={ 'vlt-field-menu__item' + ( selected ? ' is-active' : '' ) }
												// Before the input's blur
												onMouseDown={ ( event ) => {
													event.preventDefault();
													setTyped( null );
													binding.onChange( choice.value );
													setOpen( false );
												} }
											>
												{ choice.label }
											</button>
										);
									} ) }
								</div>
							</Popover>
						) }
					</div>
					<div
						ref={ dial }
						className={ 'vlt-knob__dial' + ( dragging ? ' is-dragging' : '' ) + ( isEmpty && inherit ? ' is-inherited' : '' ) }
						tabIndex={ disabled ? -1 : 0 }
						role="slider"
						aria-orientation="vertical"
						aria-labelledby={ id }
						aria-valuemin={ 0 }
						aria-valuemax={ list.length - 1 }
						aria-valuenow={ Math.max( 0, index ) }
						aria-valuetext={ text( index ) }
						aria-disabled={ disabled }
						title={ __( 'Drag up or down, or use the arrow keys', 'forma-grid-gallery' ) }
						onKeyDown={ disabled ? undefined : onDialKey }
						onPointerDown={ onPointerDown }
						onPointerMove={ onPointerMove }
						onPointerUp={ onPointerUp }
						onPointerCancel={ cancel }
						onLostPointerCapture={ cancel }
					>
						<svg viewBox="0 0 44 44" aria-hidden="true" focusable="false">
							{ list.map( ( option, i ) => {
								const radians = ( angle( i ) * Math.PI ) / 180;

								return (
									<circle key={ String( option.value ) } className={ 'vlt-knob__dot' + ( i === index ? ' is-active' : '' ) } cx={ ( CENTER + RADIUS * Math.cos( radians ) ).toFixed( 2 ) } cy={ ( CENTER + RADIUS * Math.sin( radians ) ).toFixed( 2 ) } r="1.6">
										{ /* translators: %s: a value of the dial, e.g. 3 */ }
										<title>{ sprintf( /* translators: %s: option label */ __( 'Set to %s', 'forma-grid-gallery' ), option.label ) }</title>
									</circle>
								);
							} ) }
							<circle className="vlt-knob__disc" cx={ CENTER } cy={ CENTER } r="12" />
							{ index >= 0 && (
								<g style={ { transformOrigin: '22px 22px', transform: `rotate(${ angle( index ) - 180 }deg)` } }>
									<line className="vlt-knob__needle" x1="16" y1="22" x2="11" y2="22" />
								</g>
							) }
						</svg>
					</div>
				</div>
			) }
		</Field>
	);
}

export default filterable( KnobControl );
