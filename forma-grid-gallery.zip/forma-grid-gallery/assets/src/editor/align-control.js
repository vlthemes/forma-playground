/**
 * Left / center / right as WordPress's toggle group: the pagination's alignment and the skins' align fields
 */
import { __ } from '@wordpress/i18n';
import {
	__experimentalToggleGroupControl as ToggleGroupControl,
	__experimentalToggleGroupControlOptionIcon as ToggleGroupControlOptionIcon,
} from '@wordpress/components';

const ICONS = [ 'editor-alignleft', 'editor-aligncenter', 'editor-alignright' ];

/**
 * values: the stored left, center and right ([ 'start', 'center', 'end' ] for the skins). Empty shows the first.
 */
export default function AlignControl( { label = __( 'Alignment', 'forma-grid-gallery' ), help, value, onChange, values = [ 'left', 'center', 'right' ] } ) {
	const labels = [ __( 'Left', 'forma-grid-gallery' ), __( 'Center', 'forma-grid-gallery' ), __( 'Right', 'forma-grid-gallery' ) ];

	return (
		<ToggleGroupControl
			label={ label }
			help={ help }
			value={ value || values[ 0 ] }
			onChange={ onChange }
			isBlock
			__nextHasNoMarginBottom
			__next40pxDefaultSize
		>
			{ values.map( ( item, index ) => (
				<ToggleGroupControlOptionIcon key={ item } value={ item } icon={ ICONS[ index ] } label={ labels[ index ] } />
			) ) }
		</ToggleGroupControl>
	);
}
