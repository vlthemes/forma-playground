/**
 * Builds the theme controls' CSS in the editor (same as Controls::css()), so color or size changes show without
 * reloading the preview
 */
import { controls, matches } from './panels/extra.js';

const DEVICES = [ 'desktop', 'tablet_landscape', 'tablet', 'mobile' ];

const { breakpoints = {} } = window.formaEditor;

/**
 * Live fields: [ section id, field key, field ]
 */
const live = Object.entries( controls ).flatMap( ( [ id, section ] ) =>
	Object.entries( section.fields ).filter( ( [ , field ] ) => field.live ).map( ( [ key, field ] ) => [ id, key, field ] )
);

/**
 * The config without the live values: what the server must render again when it changes
 *
 * @param {Object} config Layout config
 * @return {Object} Config
 */
export function structural( config ) {
	if ( ! live.length || ! config.extra ) {
		return config;
	}

	const extra = {};

	Object.entries( config.extra ).forEach( ( [ id, values ] ) => {
		extra[ id ] = { ...values };
		live.forEach( ( [ section, key ] ) => section === id && delete extra[ id ][ key ] );
	} );

	return { ...config, extra };
}

// Controls::css_value()
const cssValue = ( field, value ) => {
	if ( 'toggle' === field.type ) {
		return value ? '1' : '0';
	}

	return null === value || undefined === value ? '' : String( value ).replace( /[;{}<>\\]+/g, '' ).trim();
};

// Controls::declarations(): a position field gives {property}-y and {property}-x (start, center, end)
const edge = ( word ) => ( { top: 'start', left: 'start', bottom: 'end', right: 'end' }[ word ] || 'center' );

const declarations = ( field, rule, css ) => {
	if ( 'position' !== field.type ) {
		return `${ rule.property }:${ rule.mask.replaceAll( '$', css ) };`;
	}

	const [ y, x ] = css.split( ' ' );

	return `${ rule.property }-y:${ edge( y ) };${ rule.property }-x:${ edge( x ) };`;
};

// Controls::selector()
const selector = ( scope, element ) => ( '' === element ? scope : element.split( ',' ).map( ( part ) => part.trim() ).filter( Boolean ).map( ( part ) => ( part.startsWith( '&' ) ? scope + part.slice( 1 ) : `${ scope } ${ part }` ) ).join( ',' ) );

/**
 * CSS of the theme controls for a config
 *
 * @param {Object} config Layout config
 * @param {string} scope  Grid selector (.forma--{id})
 * @return {string} CSS
 */
function controlsCss( config, scope ) {
	const rules = Object.fromEntries( DEVICES.map( ( device ) => [ device, {} ] ) );

	Object.entries( controls ).forEach( ( [ id, section ] ) => {
		if ( ! matches( section.condition, config ) ) {
			return;
		}

		Object.entries( section.fields ).forEach( ( [ key, field ] ) => {
			if ( ! field.style?.length || [ 'separator', 'group' ].includes( field.type ) || ! matches( field.condition, config ) ) {
				return;
			}

			const value = config.extra?.[ id ]?.[ key ] ?? field.default;
			const values = field.responsive && value && 'object' === typeof value ? value : { desktop: value };
			let wider = null;

			DEVICES.forEach( ( device ) => {
				const css = device in values ? cssValue( field, values[ device ] ) : null;

				// Same as the wider device: inherited
				if ( null !== css && '' !== css && css !== wider ) {
					field.style.forEach( ( rule ) => {
						const target = selector( scope, rule.element );

						rules[ device ][ target ] = ( rules[ device ][ target ] || '' ) + declarations( field, rule, css );
					} );
				}

				wider = css ?? wider;
			} );
		} );
	} );

	const block = ( selectors ) => Object.entries( selectors ).map( ( [ target, declarations ] ) => `${ target }{${ declarations }}` ).join( '' );

	return block( rules.desktop ) + Object.entries( breakpoints ).map( ( [ device, max ] ) => ( Object.keys( rules[ device ] || {} ).length ? `@media (max-width:${ max }px){${ block( rules[ device ] ) }}` : '' ) ).join( '' );
}

/**
 * Send the controls' CSS to the preview frame, which swaps it in (grid-preview.js)
 *
 * @param {Window} frame  The frame's window
 * @param {number} postId Layout ID
 * @param {Object} config Layout config
 */
export function sendLive( frame, postId, config ) {
	frame?.postMessage( { formaPreview: 'controls-css', id: postId, css: controlsCss( config, `.forma--${ postId }` ) }, '*' );
}
