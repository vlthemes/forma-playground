/**
 * Content area of a Grid Layout: live preview (the only, locked block of a forma_layout post)
 */
import { useBlockProps } from '@wordpress/block-editor';
import useLayout from './use-layout.js';
import Preview from './preview.js';

export default function Canvas() {
	const { config, meta } = useLayout();

	return (
		<div { ...useBlockProps( { className: 'forma-editor' } ) }>
			<Preview config={ config } meta={ meta } />
		</div>
	);
}
