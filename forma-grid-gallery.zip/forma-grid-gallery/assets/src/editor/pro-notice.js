/**
 * Note naming what Forma Pro, a separate plugin, adds at this place; nothing of it is in this plugin
 *
 *     <ProNotice feature={ __( 'Infinite scroll', 'forma-grid-gallery' ) } />
 */
import { __ } from '@wordpress/i18n';
import Hint from './hint.js';

const { proUrl, proNotice } = window.formaEditor;

export default function ProNotice( { feature } ) {
	const { text, label, url } = proNotice || {
		text: __( 'Available in Forma Pro, a separate plugin.', 'forma-grid-gallery' ),
		label: __( 'Learn more', 'forma-grid-gallery' ),
		url: proUrl,
	};

	return (
		<Hint>
			{ feature && <strong>{ feature }: </strong> }
			{ text }{ ' ' }
			<a href={ url } target={ proNotice ? undefined : '_blank' } rel="noopener noreferrer">
				{ label }
			</a>
		</Hint>
	);
}
