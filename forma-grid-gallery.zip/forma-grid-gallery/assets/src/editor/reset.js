/**
 * "Reset all settings": back to the defaults, keeping the content (source, picked items, terms). Undoable.
 */
import { __ } from '@wordpress/i18n';
import { Button, __experimentalConfirmDialog as ConfirmDialog } from '@wordpress/components';
import { useState } from '@wordpress/element';
import { applyFilters } from '@wordpress/hooks';

const { defaults, metaConfig, metaCss, defaultCss, canEditCss } = window.formaEditor;

// Query keys that are the layout's content, not its settings
const CONTENT = [ 'source', 'include', 'exclude', 'taxonomies', 'tax_relation', 'search', 'images', 'image_data' ];

export default function Reset( { config, write } ) {
	const [ confirming, setConfirming ] = useState( false );

	const reset = () => {
		const query = { ...defaults.query };

		CONTENT.forEach( ( key ) => {
			if ( key in config.query ) {
				query[ key ] = config.query[ key ];
			}
		} );

		write( { [ metaConfig ]: JSON.stringify( { ...defaults, query } ), ...( canEditCss ? { [ metaCss ]: defaultCss } : {} ), ...applyFilters( 'forma.resetMeta', {} ) } );
		setConfirming( false );
	};

	return (
		<div className="forma-editor__reset">
			<Button variant="secondary" isDestructive onClick={ () => setConfirming( true ) } __next40pxDefaultSize>
				{ __( 'Reset all settings', 'forma-grid-gallery' ) }
			</Button>
			<ConfirmDialog
				isOpen={ confirming }
				onConfirm={ reset }
				onCancel={ () => setConfirming( false ) }
				confirmButtonText={ __( 'Reset', 'forma-grid-gallery' ) }
			>
				{ __( 'Every setting of this layout goes back to its default. The content (source, picked items, terms) stays. You can undo it, and nothing changes on the site until you save.', 'forma-grid-gallery' ) }
			</ConfirmDialog>
		</div>
	);
}
