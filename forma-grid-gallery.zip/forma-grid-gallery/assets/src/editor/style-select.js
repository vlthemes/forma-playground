/**
 * Style picker of the filter / search / pagination: the theme's styles, or the built-in neutral one while the theme
 * registers none (the saved config never holds the built-in one then, see Config::style())
 */
import { __ } from '@wordpress/i18n';
import { Select } from './components/controls.js';

/**
 * Options of a style picker: styles without a group first, then one section per group, in the order registered
 */
export function StyleOptions( { styles } ) {
	const groups = [];

	styles.forEach( ( style ) => {
		const group = groups.find( ( item ) => item.label === ( style.group || '' ) );

		if ( group ) {
			group.styles.push( style );
		} else {
			groups.push( { label: style.group || '', styles: [ style ] } );
		}
	} );

	groups.sort( ( a, b ) => ( a.label ? 1 : 0 ) - ( b.label ? 1 : 0 ) );

	return (
		<>
			{ groups.map( ( group ) => {
				const options = group.styles.map( ( style ) => (
					<option key={ style.value } value={ style.value }>
						{ style.label }
					</option>
				) );

				return group.label ? (
					<optgroup key={ group.label } label={ group.label }>
						{ options }
					</optgroup>
				) : options;
			} ) }
		</>
	);
}

export default function StyleSelect( { value, templates, help, onChange } ) {
	const styles = templates.length ? templates : [ { value: '', label: __( 'Default', 'forma-grid-gallery' ) } ];

	return (
		<Select label={ __( 'Style', 'forma-grid-gallery' ) } help={ help } value={ value } onChange={ onChange }>
			<StyleOptions styles={ styles } />
		</Select>
	);
}
