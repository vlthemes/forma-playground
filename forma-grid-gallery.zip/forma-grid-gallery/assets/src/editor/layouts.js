/**
 * Editor modules of the layout types (src/Layouts/{Name}/editor.js, plus the forma.layouts filter)
 *
 *     export default {
 *         id: 'metro',
 *         description: '…',
 *         Settings: ( { layout, settings, update } ) => …,       // all devices
 *         Device: ( { layout, settings, device, update } ) => …, // current device
 *         fields: ( layout, device ) => ( { columns: { … } } ),  // tweaks to Columns & gaps
 *     };
 */
import { applyFilters } from '@wordpress/hooks';

const context = import.meta.webpackContext( '../../../src/Layouts', { recursive: true, regExp: /\/editor\.js$/ } );

const builtIn = Object.fromEntries( context.keys().map( ( key ) => context( key ).default ).map( ( module ) => [ module.id, module ] ) );

let modules = null;

// Read once the other scripts have added their filters
export const layoutModule = ( type ) => {
	modules ??= applyFilters( 'forma.layouts', builtIn );

	return modules[ type ] || {};
};
