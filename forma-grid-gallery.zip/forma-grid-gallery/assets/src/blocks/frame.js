/**
 * Live preview of a saved layout in the block editor. A layer on top takes the clicks so they select the block.
 */
import { __ } from '@wordpress/i18n';
import { useEffect, useRef, useState } from '@wordpress/element';
import Loader from '../editor/components/loader.js';

const { previewUrl, nonce } = window.formaBlocks;

let frames = 0;

export default function Frame( { layout, part = 'grid' } ) {
	const frame = useRef();
	const name = useRef( `forma-block-preview-${ ++frames }` );
	const [ height, setHeight ] = useState( 0 );
	const [ loading, setLoading ] = useState( true );
	const [ error, setError ] = useState( false );

	// The form must be in the frame's own document (the editor canvas)
	useEffect( () => {
		const owner = frame.current.ownerDocument;
		const form = owner.createElement( 'form' );

		form.method = 'post';
		form.action = previewUrl;
		form.target = name.current;
		form.style.display = 'none';

		Object.entries( { post_id: layout, part, nonce, isolated: owner.defaultView?.crossOriginIsolated ? '1' : '' } ).forEach( ( [ key, value ] ) => {
			const input = owner.createElement( 'input' );
			input.type = 'hidden';
			input.name = key;
			input.value = value;
			form.append( input );
		} );

		owner.body.append( form );
		setLoading( true );
		setError( false );
		form.submit();
		form.remove();
	}, [ layout, part ] );

	// The height the preview reports
	useEffect( () => {
		const view = frame.current.ownerDocument.defaultView;
		const onMessage = ( event ) => {
			if ( event.source === frame.current?.contentWindow && event.data?.formaPreview ) {
				setHeight( event.data.height );
				setLoading( false );
			}
		};

		view.addEventListener( 'message', onMessage );

		return () => view.removeEventListener( 'message', onMessage );
	}, [] );

	// about:blank loads too; a page without the preview's marker is an error (no right to edit the layout, a 403)
	const onLoad = () => {
		let doc;

		try {
			doc = frame.current.contentDocument;
		} catch {
			return;
		}

		if ( doc && 'about:blank' !== doc.location?.href && ! doc.body?.hasAttribute( 'data-forma-state' ) ) {
			setLoading( false );
			setError( true );
		}
	};

	return (
		<div className="forma-block-frame">
			{ loading && ! error && <Loader /> }
			{ error && <p className="forma-block-frame__error">{ __( 'The preview needs the right to edit this Grid Layout. The grid shows on the site as usual.', 'forma-grid-gallery' ) }</p> }
			<iframe
				ref={ frame }
				name={ name.current }
				title={ __( 'Grid Layout preview', 'forma-grid-gallery' ) }
				style={ { height: error ? 0 : height || ( 'grid' === part ? 320 : 60 ) } }
				onLoad={ onLoad }
			/>
			<span className="forma-block-frame__cover" aria-hidden="true" />
		</div>
	);
}
