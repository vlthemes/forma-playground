/**
 * Grid Layout block: a saved layout's grid, or just its filter, search, sort or pagination
 */
import { __ } from '@wordpress/i18n';
import { createInterpolateElement, useMemo } from '@wordpress/element';
import { registerBlockType } from '@wordpress/blocks';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Button, ExternalLink, PanelBody, Placeholder, SelectControl, Spinner, TextControl } from '@wordpress/components';
import { useSelect } from '@wordpress/data';
import { store as coreStore } from '@wordpress/core-data';
import { decodeEntities } from '@wordpress/html-entities';
import { ReactComponent as Logo } from '../../icons/logo.svg';
import Frame from './frame.js';
import './editor.scss';

const { postType, newUrl, listUrl, canEdit } = window.formaBlocks;

/**
 * Published layouts: [ { id, title } ], null while they load
 */
function useLayouts() {
	// The store's records as they are (a new array from the selector would re-render every time), mapped once
	const records = useSelect( ( select ) => select( coreStore ).getEntityRecords( 'postType', postType, { per_page: 100, status: 'publish', _fields: 'id,title' } ), [] );

	return useMemo( () => ( records ? records.map( ( record ) => ( { id: record.id, title: decodeEntities( record.title?.rendered || '' ) || `#${ record.id }` } ) ) : null ), [ records ] );
}

function LayoutSelect( { layouts, value, onChange, hideLabel = false } ) {
	if ( ! layouts ) {
		return <Spinner />;
	}

	return (
		<SelectControl
			label={ __( 'Grid Layout', 'forma-grid-gallery' ) }
			hideLabelFromVision={ hideLabel }
			value={ value }
			options={ [ { value: 0, label: __( 'Choose a layout', 'forma-grid-gallery' ) }, ...layouts.map( ( layout ) => ( { value: layout.id, label: layout.title } ) ) ] }
			onChange={ ( next ) => onChange( Number( next ) ) }
			__nextHasNoMarginBottom
			__next40pxDefaultSize
		/>
	);
}

const PARTS = {
	grid: __( 'Grid', 'forma-grid-gallery' ),
	filter: __( 'Filter', 'forma-grid-gallery' ),
	search: __( 'Search', 'forma-grid-gallery' ),
	sort: __( 'Sorting', 'forma-grid-gallery' ),
	pagination: __( 'Pagination', 'forma-grid-gallery' ),
};

/**
 * Sidebar: the same fields as the Elementor widget and the WPBakery element (FormaWidget, WPBakery\Integration)
 */
function Settings( { attributes, setAttributes, layouts } ) {
	return (
		<InspectorControls>
			<PanelBody title={ __( 'Grid Layout', 'forma-grid-gallery' ) }>
				<LayoutSelect layouts={ layouts } value={ attributes.layout } onChange={ ( layout ) => setAttributes( { layout } ) } />
				<SelectControl
					label={ __( 'Show', 'forma-grid-gallery' ) }
					value={ attributes.show }
					options={ Object.entries( PARTS ).map( ( [ value, label ] ) => ( { value, label } ) ) }
					onChange={ ( show ) => setAttributes( { show } ) }
					__nextHasNoMarginBottom
					__next40pxDefaultSize
				/>
				{ 'grid' !== attributes.show && (
					<TextControl
						type="number"
						min={ 1 }
						label={ __( 'Grid on the page', 'forma-grid-gallery' ) }
						help={ __( 'With this layout on the page more than once: which of its grids this part controls (1 = the first).', 'forma-grid-gallery' ) }
						value={ attributes.instance }
						onChange={ ( instance ) => setAttributes( { instance: Math.max( 1, parseInt( instance, 10 ) || 1 ) } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				) }
				<p className="forma-block-note">
					{ createInterpolateElement(
						/* translators: <a>: link to the Forma Layouts list */
						__( 'The layout\'s content, look and parts are set in <a>Forma Layouts</a>. A filter, search, sorting or pagination shows only when the layout has it turned on.', 'forma-grid-gallery' ),
						{ a: <ExternalLink href={ listUrl } /> }
					) }
				</p>
			</PanelBody>
		</InspectorControls>
	);
}

/**
 * Before a layout is picked: the picker, and a way to make one
 */
function Choose( { layouts, setAttributes } ) {
	return (
		<Placeholder icon={ <Logo /> } label={ __( 'Grid Layout', 'forma-grid-gallery' ) } instructions={ layouts?.length === 0 ? __( 'There is no published Grid Layout yet.', 'forma-grid-gallery' ) : __( 'Pick a saved Grid Layout.', 'forma-grid-gallery' ) }>
			{ !! layouts?.length && <LayoutSelect layouts={ layouts } value={ 0 } onChange={ ( layout ) => setAttributes( { layout } ) } hideLabel /> }
			{ ! layouts && <Spinner /> }
			{ canEdit && (
				<Button variant="secondary" href={ newUrl } target="_blank" __next40pxDefaultSize>
					{ __( 'Create a Grid Layout', 'forma-grid-gallery' ) }
				</Button>
			) }
		</Placeholder>
	);
}

registerBlockType( 'forma/grid', {
	// The Forma mark: the block's picture in the inserter and the toolbar
	icon: <Logo />,
	edit( { attributes, setAttributes } ) {
		const layouts = useLayouts();
		const props = useBlockProps();
		const content = attributes.layout ? <Frame layout={ attributes.layout } part={ attributes.show } /> : <Choose layouts={ layouts } setAttributes={ setAttributes } />;

		return (
			<div { ...props }>
				<Settings attributes={ attributes } setAttributes={ setAttributes } layouts={ layouts } />
				{ content }
			</div>
		);
	},
	save: () => null,
} );
