/* ========================================
 * Lightbox: PhotoSwipe 5 on any element with data-forma-lightbox
 *
 * One delegated click handler, so items added later (filters, Load More) open too.
 * In RTL the slides run in reverse; PhotoSwipe has no RTL of its own.
 *
 * Events (used by Pro's video and audio slides):
 *     forma:lightbox-slide  on the element, detail.item is its slide data
 *     forma:lightbox-open   on the document, detail.pswp before it opens, detail.trigger the element
 * ======================================== */
(function () {
	'use strict';

	const settings = window.formaLightbox || {};
	const i18n = settings.i18n || {};
	const ui = Object.assign({ arrows: true, zoom: true, counter: true, share: true }, settings.ui);

	if (settings.bound || typeof window.PhotoSwipe === 'undefined') {
		return;
	}

	settings.bound = true;

	/**
	 * Line icons of the buttons (templates/icons/lightbox-*.svg, a theme can replace them). One arrow for both:
	 * PhotoSwipe flips the next one. Zoom: four corners pointing out, turned in while zoomed in (lightbox.scss).
	 */
	const ICONS = settings.icons || {};

	/**
	 * Share links: {url} the item's page (else this page), {title}, {image} the image file
	 */
	const NETWORKS = [
		{ name: 'Facebook', url: 'https://www.facebook.com/sharer/sharer.php?u={url}' },
		{ name: 'X', url: 'https://x.com/intent/post?url={url}&text={title}' },
		{ name: 'Pinterest', url: 'https://www.pinterest.com/pin/create/button/?url={url}&media={image}&description={title}', image: true },
	];

	/**
	 * Size of an image not given in the markup: from its loaded thumbnail ratio is not enough (crops), so read the file
	 */
	function size(item) {
		if ('html' === item.type || (item.width && item.height)) {
			return Promise.resolve(item);
		}

		const image = new Image();
		image.src = item.src;

		return image.decode().then(
			function () {
				item.width = image.naturalWidth;
				item.height = image.naturalHeight;
				return item;
			},
			function () {
				// Unreadable: PhotoSwipe shows its error message for it
				item.width = item.width || 1200;
				item.height = item.height || 800;
				return item;
			}
		);
	}

	/**
	 * Slide data of a lightbox element: its <template class="vlt-lightbox-data"> (grid items, title and description
	 * inside), else its data-forma-lightbox-* attributes (WordPress gallery links); forma:lightbox-slide may change it
	 */
	function itemOf(element) {
		const template = element.querySelector('template.vlt-lightbox-data');
		const data = element.dataset;
		const size = template ? (template.dataset.size || '').split('x') : [data.formaLightboxWidth, data.formaLightboxHeight];
		const caption = document.createElement('div');

		if (template) {
			caption.append(template.content.cloneNode(true));
		} else {
			caption.textContent = data.formaLightboxCaption || '';

			// Short lines under it (Lightbox::meta()), as lightbox/item-data.php prints them
			if (data.formaLightboxMeta) {
				const meta = document.createElement('div');

				meta.className = 'vlt-lightbox-data__meta';
				meta.append.apply(meta, data.formaLightboxMeta.split('|').map(function (line) {
					const span = document.createElement('span');
					span.textContent = line;
					return span;
				}));
				caption.append(meta);
			}
		}

		const item = {
			width: parseInt(size[0], 10) || 0,
			height: parseInt(size[1], 10) || 0,
			caption: caption.textContent.trim() ? caption : null,
			// What Share sends
			link: (template && template.dataset.link) || data.formaLightboxLink || '',
			title: (template ? (caption.querySelector('.vlt-lightbox-data__title') || {}).textContent || '' : data.formaLightboxCaption || '').trim(),
			// The thumbnail the opening zoom starts from
			element: element,
		};

		Object.assign(item, {
			src: srcOf(element),
			srcset: (template && template.dataset.srcset) || data.formaLightboxSrcset || undefined,
			alt: (element.querySelector('img') || {}).alt || '',
		});

		element.dispatchEvent(new CustomEvent('forma:lightbox-slide', { bubbles: true, detail: { item: item, element: element } }));

		return item;
	}

	function srcOf(trigger) {
		const template = trigger.querySelector('template.vlt-lightbox-data');
		return (template && template.dataset.src) || trigger.dataset.formaLightboxSrc || trigger.getAttribute('href');
	}

	/**
	 * Counter: the current number and the total apart, to style them (PhotoSwipe's is one text); right to left the
	 * slides are reversed, so it counts from the end
	 */
	function counter(pswp, rtl) {
		return {
			name: 'vlt-counter',
			className: 'pswp__counter',
			order: 5,
			isButton: false,
			onInit: function (element) {
				pswp.on('change', function () {
					const total = pswp.getNumItems();

					element.innerHTML = '<span class="pswp__counter-current">' + (rtl ? total - pswp.currIndex : pswp.currIndex + 1) + '</span><span class="pswp__counter-sep">/</span><span class="pswp__counter-total">' + total + '</span>';
				});
			},
		};
	}

	/**
	 * Share button and its menu: the device's share sheet where there is one, the networks, copy link, download.
	 * The menu closes on another slide, a click outside it or Esc (which then leaves the lightbox open).
	 */
	function shareButton(pswp) {
		let menu = null;
		let button = null;

		function close() {
			if (menu) {
				menu.remove();
				menu = null;
				button.setAttribute('aria-expanded', 'false');
			}
		}

		function entry(label, action) {
			const element = document.createElement('string' === typeof action ? 'a' : 'button');

			element.className = 'pswp__vlt-share-item';
			element.setAttribute('role', 'menuitem');
			element.textContent = label;

			if ('string' === typeof action) {
				element.href = action;
				element.target = '_blank';
				element.rel = 'noopener noreferrer';
				element.addEventListener('click', close);
			} else {
				element.type = 'button';
				element.addEventListener('click', function () {
					action(element);
				});
			}

			menu.append(element);
			return element;
		}

		function openMenu(keyboard) {
			const slide = pswp.currSlide.data;
			const url = slide.link || window.location.href;
			const title = slide.title || document.title;
			const image = 'html' === slide.type || !slide.src ? '' : new URL(slide.src, window.location.href).href;
			const fill = function (pattern) {
				return pattern.replace('{url}', encodeURIComponent(url)).replace('{title}', encodeURIComponent(title)).replace('{image}', encodeURIComponent(image));
			};

			menu = document.createElement('div');
			menu.className = 'pswp__vlt-share';
			menu.setAttribute('role', 'menu');

			if (navigator.share) {
				entry(i18n.more, function () {
					navigator.share({ title: title, url: url }).catch(function () {});
					close();
				});
			}

			NETWORKS.forEach(function (network) {
				if (!network.image || image) {
					entry(network.name, fill(network.url));
				}
			});

			if (navigator.clipboard) {
				entry(i18n.copy, function (element) {
					navigator.clipboard.writeText(url).then(function () {
						element.textContent = i18n.copied;
						element.classList.add('is-done');
						setTimeout(close, 900);
					});
				});
			}

			// download: false (a forma:lightbox-open listener, Forma Pro's image protection) leaves it out
			if (image && false !== pswp.options.download) {
				entry(i18n.download, image).setAttribute('download', '');
			}

			pswp.element.append(menu);
			button.setAttribute('aria-expanded', 'true');

			// From the keyboard the focus goes into the menu; a mouse click leaves it on the button
			if (keyboard) {
				menu.firstChild.focus();
			}
		}

		return {
			name: 'vlt-share',
			className: 'pswp__button--share',
			title: i18n.share,
			order: 9,
			isButton: true,
			html: ICONS.share,
			onInit: function (element) {
				button = element;
				button.setAttribute('aria-haspopup', 'menu');
				button.setAttribute('aria-expanded', 'false');

				pswp.on('change', close);
				pswp.on('close', close);
				pswp.on('keydown', function (event) {
					if (menu && 'Escape' === event.originalEvent.key) {
						event.preventDefault();
						close();
						button.focus();
					}
				});
				pswp.element.addEventListener('pointerdown', function (event) {
					if (menu && !menu.contains(event.target) && !button.contains(event.target)) {
						close();
					}
				});
			},
			onClick: function (event) {
				if (menu) {
					close();
				} else {
					// Enter or Space on the button: a click with no pointer (detail 0)
					openMenu(0 === event.detail);
				}
			},
		};
	}

	function open(trigger) {
		const group = trigger.dataset.formaLightbox;
		const scope = trigger.closest('[data-forma-lightbox-scope]') || document;
		const elements = Array.prototype.filter.call(scope.querySelectorAll('[data-forma-lightbox]'), function (element) {
			return element.dataset.formaLightbox === group;
		});
		const rtl = 'rtl' === getComputedStyle(trigger).direction;
		const items = elements.map(itemOf);
		let index = Math.max(0, elements.indexOf(trigger));

		// PhotoSwipe only runs left to right: the next slide comes from the left when the order is reversed
		if (rtl) {
			items.reverse();
			index = items.length - 1 - index;
		}

		// The clicked one must have its size before opening; the others are measured as they come up
		size(items[index]).then(function () {
			const pswp = new window.PhotoSwipe({
				dataSource: items,
				index: index,
				// A video or audio slide has no image to zoom from
				showHideAnimationType: 'html' === items[index].type ? 'fade' : 'zoom',
				// The tint over the blurred page (lightbox.scss)
				bgOpacity: 0.85,
				// Room for the top bar, the round arrows and the caption card (lightbox.scss): a title and a line or
				// two under it; on phones the arrows sit at the bottom, the caption above them
				paddingFn: function (viewport, slide) {
					// A title and a line or two, a line more with meta (camera details)
					const caption = slide && slide.caption ? (slide.caption.querySelector('.vlt-lightbox-data__meta') ? 88 : 64) : 0;

					if (viewport.x < 600) {
						return { top: 76, bottom: (ui.arrows ? 84 : 24) + caption + 32, left: 12, right: 12 };
					}

					return { top: 76, bottom: caption ? caption + 52 : 40, left: ui.arrows ? 88 : 24, right: ui.arrows ? 88 : 24 };
				},
				// Settings → Lightbox; the counter is counter()
				arrowPrev: ui.arrows,
				arrowNext: ui.arrows,
				zoom: ui.zoom,
				counter: false,
				arrowPrevSVG: ICONS['arrow-left'],
				arrowNextSVG: ICONS['arrow-right'],
				zoomSVG: ICONS.zoom,
				closeSVG: ICONS.close,
				closeTitle: i18n.close,
				zoomTitle: i18n.zoom,
				arrowPrevTitle: rtl ? i18n.next : i18n.prev,
				arrowNextTitle: rtl ? i18n.prev : i18n.next,
				errorMsg: i18n.error,
			});

			pswp.on('gettingData', function (event) {
				if ('html' !== event.data.type && !event.data.width) {
					size(event.data).then(function () {
						pswp.refreshSlideContent(event.index);
					});
				}
			});

			pswp.on('uiRegister', function () {
				if (ui.counter) {
					pswp.ui.registerElement(counter(pswp, rtl));
				}

				if (ui.share) {
					pswp.ui.registerElement(shareButton(pswp));
				}

				// Caption under the image

				pswp.ui.registerElement({
					name: 'vlt-caption',
					// A class of its own next to PhotoSwipe's pswp__hide-on-close, which fades it on close
					className: 'pswp__vlt-caption',
					order: 9,
					isButton: false,
					appendTo: 'root',
					onInit: function (element) {
						pswp.on('change', function () {
							const caption = pswp.currSlide.data.caption;
							element.replaceChildren(caption ? caption.cloneNode(true) : '');
							element.hidden = !caption;
						});
					},
				});
			});

			document.dispatchEvent(new CustomEvent('forma:lightbox-open', { detail: { pswp: pswp, trigger: trigger } }));
			pswp.init();
		});
	}

	// Capture phase, and the click stops here: themes with page transitions (animsition and the like) take every link
	// click on the document and follow it themselves
	document.addEventListener('click', function (event) {
		const trigger = event.target.closest('[data-forma-lightbox]');

		if (!trigger || event.defaultPrevented || 0 !== event.button || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
			return;
		}

		// Another link inside the item (a term in a card) keeps working as a link, a button (Forma Pro's proofing
		// heart) does its own thing
		const link = event.target.closest('a[href]');
		const button = event.target.closest('button');

		if ((link && link !== trigger && trigger.contains(link) && link.getAttribute('href') !== srcOf(trigger)) || (button && button !== trigger && trigger.contains(button))) {
			return;
		}

		event.preventDefault();
		event.stopPropagation();
		open(trigger);
	}, true);
})();
