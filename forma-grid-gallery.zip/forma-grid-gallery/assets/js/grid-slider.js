/* ========================================
 * Forma: slider layout (Swiper). The grid is the Swiper container so filters and Load More keep the same markup.
 * Rebuilt after new items come in (forma:updated).
 * ======================================== */
(function () {
	'use strict';

	const sliders = new WeakMap();

	// Auto: slides as wide as their content, as many as fit
	function columns(root) {
		const value = getComputedStyle(root).getPropertyValue('--forma-cols').trim();

		return 'auto' === value ? 'auto' : parseInt(value, 10) || 1;
	}

	// Fade shows one slide at a time
	function perView(root, settings) {
		return 'fade' === settings.effect ? 1 : columns(root);
	}

	function gap(root) {
		return parseFloat(getComputedStyle(root).getPropertyValue('--forma-gap-x')) || 0;
	}

	function settingsOf(root) {
		try {
			return JSON.parse(root.dataset.forma || '{}').layoutSettings || {};
		} catch {
			return {};
		}
	}

	/**
	 * Arrows and dots in a bar under the slides, made once
	 */
	function controls(root, settings) {
		let bar = root.querySelector(':scope > .forma__slider-nav');

		if (!bar && (settings.arrows || settings.dots)) {
			const i18n = (window.formaGrid && window.formaGrid.i18n) || {};
			const icons = (window.formaGrid && window.formaGrid.icons) || {};

			bar = document.createElement('div');
			bar.className = 'forma__slider-nav';
			bar.innerHTML = (settings.dots ? '<div class="forma__dots"></div>' : '')
				+ (settings.arrows ? '<div class="forma__arrows"><button type="button" class="forma__arrow forma__arrow--prev">' + (icons.previous || '') + '</button><button type="button" class="forma__arrow forma__arrow--next">' + (icons.next || '') + '</button></div>' : '');
			root.append(bar);

			bar.querySelectorAll('.forma__arrow').forEach(function (button) {
				button.setAttribute('aria-label', button.classList.contains('forma__arrow--prev') ? i18n.previous || 'Previous' : i18n.next || 'Next');
			});
		}

		return bar;
	}

	function mount(root, start) {
		const settings = settingsOf(root);
		const bar = controls(root, settings);

		sliders.set(root, new window.Swiper(root, {
			wrapperClass: 'forma__items',
			slideClass: 'forma__item',
			slidesPerView: perView(root, settings),
			effect: settings.effect || 'slide',
			fadeEffect: { crossFade: true },
			coverflowEffect: { rotate: 30, depth: 120, slideShadows: false },
			// Coverflow turns the slides around the one in the middle
			centeredSlides: 'coverflow' === settings.effect || ('fade' !== settings.effect && !!settings.centered),
			spaceBetween: gap(root),
			speed: settings.speed || 500,
			loop: !!settings.loop,
			initialSlide: start || 0,
			watchOverflow: true,
			grabCursor: true,
			freeMode: settings.free_scroll ? { enabled: true, sticky: !!settings.free_scroll_sticky } : false,
			keyboard: { enabled: true, onlyInViewport: true },
			autoplay: settings.autoplay ? { delay: settings.delay || 5000, pauseOnMouseEnter: !!settings.pause_on_hover, disableOnInteraction: false } : false,
			navigation: settings.arrows ? {
				prevEl: bar.querySelector('.forma__arrow--prev'),
				nextEl: bar.querySelector('.forma__arrow--next'),
				disabledClass: 'is-disabled',
			} : false,
			pagination: settings.dots ? {
				el: bar.querySelector('.forma__dots'),
				clickable: true,
				bulletClass: 'forma__dot',
				bulletActiveClass: 'is-active',
			} : false,
			on: {
				// The device's columns and gap, from the layout CSS
				beforeResize: function (swiper) {
					swiper.params.slidesPerView = perView(root, settings);
					swiper.params.spaceBetween = gap(root);
				},
			},
		}));
	}

	function init(root) {
		if (window.Swiper && root.matches('.forma--layout-slider') && !sliders.has(root)) {
			mount(root, 0);
		}
	}

	document.addEventListener('forma:init', function (event) {
		init(event.target);
	});

	document.addEventListener('forma:updated', function (event) {
		const root = event.target;
		const swiper = sliders.get(root);

		if (!swiper) {
			return;
		}

		const start = event.detail.append ? swiper.realIndex : 0;

		swiper.destroy(true, true);
		mount(root, start);
	});

	// Grids that were set up before this script ran
	function initAll() {
		document.querySelectorAll('.forma--layout-slider[data-forma]').forEach(init);
	}

	if ('loading' === document.readyState) {
		document.addEventListener('DOMContentLoaded', initAll);
	} else {
		initAll();
	}
})();
