/**
 * Admin bar "Forma" menu with the layouts on this page. The bar prints before the grids render,
 * so admin_bar_menu can't know them; this adds the menu after the page loads.
 */
( function () {
	'use strict';

	const data = window.formaAdminBar;

	const node = ( tag, attributes, text ) => {
		const element = document.createElement( tag );

		Object.entries( attributes ).forEach( ( [ name, value ] ) => element.setAttribute( name, value ) );

		if ( text ) {
			element.textContent = text;
		}

		return element;
	};

	const add = () => {
		const bar = document.getElementById( 'wp-admin-bar-root-default' );

		if ( ! data || ! bar ) {
			return;
		}

		const menu = node( 'li', { id: 'wp-admin-bar-forma', class: 'menupop' } );
		const wrapper = node( 'div', { class: 'ab-sub-wrapper' } );
		const list = node( 'ul', { class: 'ab-submenu' } );

		data.items.forEach( ( item ) => {
			const entry = node( 'li', {} );

			entry.append( node( 'a', { class: 'ab-item', href: item.url }, item.title ) );
			list.append( entry );
		} );

		wrapper.append( list );
		menu.append( node( 'div', { class: 'ab-item ab-empty-item', tabindex: '0', 'aria-haspopup': 'true' }, data.label ), wrapper );

		// admin-bar.js binds its menus on load only, so this one opens itself (the "hover" class shows the submenu)
		const toggle = ( open ) => () => menu.classList.toggle( 'hover', open );

		menu.addEventListener( 'mouseenter', toggle( true ) );
		menu.addEventListener( 'mouseleave', toggle( false ) );
		menu.addEventListener( 'focusin', toggle( true ) );
		menu.addEventListener( 'focusout', ( event ) => ! menu.contains( event.relatedTarget ) && menu.classList.remove( 'hover' ) );

		bar.append( menu );
	};

	// Themes without wp_body_open print the bar after the footer scripts
	if ( document.getElementById( 'wp-admin-bar-root-default' ) ) {
		add();
	} else {
		document.addEventListener( 'DOMContentLoaded', add );
	}
} )();
