/* ========================================
 * Forma: keeps the filter and sort in the page address (Settings → Filter & Sort, FilterLink.php).
 * ?grid-page only comes from the page links for crawlers; it's removed once the visitor moves on.
 * Back and Forward replay the address through the grid's own controls.
 * ======================================== */
(function () {
	'use strict';

	function linkOf(grid) {
		try {
			return JSON.parse(grid.dataset.formaLink || 'null');
		} catch {
			return null;
		}
	}

	/**
	 * The address with parameters set ('' / null removes one)
	 */
	function address(changes, base) {
		const url = new URL(window.location.href);

		if (base && base.pathname !== url.pathname) {
			url.pathname = base.pathname;
		}

		Object.keys(changes).forEach(function (param) {
			if (!param) {
				return;
			}

			if (changes[param]) {
				url.searchParams.set(param, changes[param]);
			} else {
				url.searchParams.delete(param);
			}
		});

		return url;
	}

	function write(changes, base) {
		const url = address(changes, base);

		if (url.href !== window.location.href) {
			window.history.pushState({ forma: true }, '', url);
		}
	}

	/**
	 * Links of the filter chips and the pagination, after the address changed
	 */
	function sync(grid, link, page) {
		if (link.param) {
			controls(grid, '.forma-filter').forEach(function (filters) {
				filters.querySelectorAll('a[data-forma-term][href]').forEach(function (chip) {
					// Leading to a page of its own (a category page): that stays
					if (new URL(chip.href, window.location.href).pathname === window.location.pathname) {
						chip.href = address({ [link.param]: link.slugs[chip.dataset.formaTerm], [link.pageParam]: '' }).href;
					}
				});
			});
		}

		if (link.pageParam) {
			controls(grid, '.forma-pagination').forEach(function (pagination) {
				pagination.querySelectorAll('a[data-forma-page][href], a[data-forma-more][href]').forEach(function (anchor) {
					const number = anchor.hasAttribute('data-forma-more') ? page + 1 : parseInt(anchor.dataset.formaPage, 10) || 1;

					anchor.href = address({ [link.pageParam]: number > 1 ? number : '' }).href;
				});
			});
		}
	}

	/**
	 * Link of a filter chip, null for the dropdown
	 */
	function chipUrl(grid, term) {
		const chip = controls(grid, '.forma-filter')[0]?.querySelector('a[data-forma-term="' + term + '"][href]');

		return chip ? new URL(chip.href, window.location.href) : null;
	}

	document.addEventListener('forma:filtered', function (event) {
		const link = linkOf(event.target);

		if (link && link.param) {
			const base = chipUrl(event.target, event.detail.term);

			// A chip leading to a page of its own (a category page) carries no parameter
			write({
				[link.param]: base && base.pathname !== window.location.pathname ? base.searchParams.get(link.param) : link.slugs[event.detail.term],
				[link.pageParam]: '',
			}, base);
			sync(event.target, link, event.detail.page);
		} else if (link && link.pageParam) {
			// The filter stays out of the address (Settings → Filter & Sort), a page opened by its address goes
			const url = address({ [link.pageParam]: '' });

			if (url.href !== window.location.href) {
				window.history.replaceState(window.history.state, '', url);
			}

			sync(event.target, link, event.detail.page);
		}
	});

	document.addEventListener('forma:sorted', function (event) {
		const link = linkOf(event.target);

		if (link) {
			write({ [link.sortParam]: link.sortParam ? event.detail.sort : '', [link.pageParam]: '' });
			sync(event.target, link, event.detail.page);
		}
	});

	document.addEventListener('forma:searched', function (event) {
		const link = linkOf(event.target);

		if (link) {
			write({ [link.pageParam]: '' });
			sync(event.target, link, event.detail.page);
		}
	});

	document.addEventListener('forma:paginated', function (event) {
		const link = linkOf(event.target);

		if (link && link.pageParam) {
			// A page the visitor opened by its address no longer matches: no new history entry for that
			const url = address({ [link.pageParam]: '' });

			if (url.href !== window.location.href) {
				window.history.replaceState(window.history.state, '', url);
			}

			sync(event.target, link, event.detail.page);
		}
	});

	/**
	 * Controls of a grid's layout, e.g. its filters
	 */
	function controls(grid, selector) {
		return document.querySelectorAll(selector + '[data-forma-for="' + window.CSS.escape(grid.dataset.formaLayout) + '"]');
	}

	function pick(select, value) {
		if (select.value !== value) {
			select.value = value;
			select.dispatchEvent(new Event('change', { bubbles: true }));
		}
	}

	window.addEventListener('popstate', function () {
		const params = new URLSearchParams(window.location.search);

		document.querySelectorAll('[data-forma-link]').forEach(function (grid) {
			const link = linkOf(grid);

			if (!link) {
				return;
			}

			if (link.param) {
				const slug = params.get(link.param) || '';
				// The chip whose page this is (category pages), else the one of the parameter
				const chip = !slug && Array.from(controls(grid, '.forma-filter')[0]?.querySelectorAll('a[data-forma-term][href]') || []).find(function (a) {
					const url = new URL(a.href, window.location.href);

					return url.pathname === window.location.pathname && !url.searchParams.get(link.param);
				});
				const term = chip ? chip.dataset.formaTerm : Object.keys(link.slugs).find(function (id) {
					return link.slugs[id] === slug;
				}) || '0';

				controls(grid, '.forma-filter').forEach(function (filters) {
					const button = filters.querySelector('[data-forma-term="' + term + '"]');
					const select = filters.querySelector('select[data-forma-filter]');

					if (button) {
						button.click();
					} else if (select) {
						pick(select, term);
					}
				});
			}

			if (link.sortParam) {
				controls(grid, '.forma-sort').forEach(function (box) {
					const value = params.get(link.sortParam) || '';
					const button = box.querySelector('[data-forma-sort-value="' + window.CSS.escape(value) + '"]');
					const select = box.querySelector('select[data-forma-sort]');

					if (button) {
						button.click();
					} else if (select) {
						pick(select, value);
					}
				});
			}

			// Last: a new filter or order goes back to page 1
			if (link.pageParam && window.formaGrid && window.formaGrid.page) {
				window.formaGrid.page(grid, parseInt(params.get(link.pageParam), 10) || 1);
			}
		});
	});
})();
