/* ========================================
 * Forma: editor preview frame. Reports the height, passes the wheel to the editor, blocks clicks,
 * and keeps the page visible when a theme preloader would hide it.
 * ======================================== */

( function () {
	/**
	 * The page and the grid stay visible: inline !important values, which outrank theme stylesheets and the inline
	 * styles scripts set (jQuery's .css() can't set !important). Put back whenever a script changes them.
	 */
	var SHOWN = { opacity: '1', visibility: 'visible', display: '', filter: 'none', transform: 'none', 'clip-path': 'none' };

	function show( element ) {
		Object.keys( SHOWN ).forEach( function ( property ) {
			var value = SHOWN[ property ];

			if ( ! value ) {
				// display: only a script's "none" is undone, the element keeps its own display otherwise
				if ( 'none' === element.style.getPropertyValue( property ) ) {
					element.style.removeProperty( property );
				}

				return;
			}

			// Only when it differs: setting it again would notify the observer below in a loop
			if ( element.style.getPropertyValue( property ) !== value || 'important' !== element.style.getPropertyPriority( property ) ) {
				element.style.setProperty( property, value, 'important' );
			}
		} );
	}

	function guard() {
		[ document.documentElement, document.body, document.querySelector( '.forma-preview' ) ].forEach( function ( element ) {
			if ( element ) {
				show( element );
			}
		} );
	}

	guard();
	new MutationObserver( guard ).observe( document.documentElement, { attributes: true, attributeFilter: [ 'style', 'class' ], subtree: false } );
	new MutationObserver( guard ).observe( document.body, { attributes: true, attributeFilter: [ 'style', 'class' ] } );

	/**
	 * The frame takes the page's background (the body's, else the root's, else white). Above the theme it is its
	 * own layer, which would be see-through otherwise: blended styles (the Cursor card's title) would vanish there.
	 */
	function background() {
		var wrapper = document.querySelector( '.forma-preview' );
		var color = [ document.body, document.documentElement ].map( function ( element ) {
			return getComputedStyle( element ).backgroundColor;
		} ).find( function ( value ) {
			return value && 'transparent' !== value && ! /,\s*0\)$/.test( value );
		} );

		if ( wrapper ) {
			wrapper.style.setProperty( '--forma-preview-background', color || '#fff' );
		}
	}

	background();

	var state = document.body.getAttribute( 'data-forma-state' );
	var last = -1;
	var timer = 0;
	var lastRun = 0;

	// The wrapper, not the body: theme body styles would add height.
	// offsetHeight ignores entrance animation transforms.
	function height() {
		var wrapper = document.querySelector( '.forma-preview' );

		if ( !wrapper ) {
			return document.documentElement.scrollHeight;
		}

		var style = getComputedStyle( wrapper );

		return Math.ceil( wrapper.offsetHeight + ( parseFloat( style.marginTop ) || 0 ) + ( parseFloat( style.marginBottom ) || 0 ) );
	}

	function report( force ) {
		var value = height();

		if ( value && ( force === true || value !== last ) && window.parent !== window ) {
			last = value;
			window.parent.postMessage( { formaPreview: true, height: value, state: state }, '*' );
		}
	}

	// Throttled to one report per frame, the last change always reported
	function schedule() {
		var wait = 16 - ( Date.now() - lastRun );

		clearTimeout( timer );

		if ( wait <= 0 ) {
			lastRun = Date.now();
			report();
		} else {
			timer = setTimeout( function () {
				lastRun = Date.now();
				report();
			}, wait );
		}
	}

	report();

	var wrapper = document.querySelector( '.forma-preview' );
	new ResizeObserver( schedule ).observe( wrapper || document.body );
	new MutationObserver( schedule ).observe( wrapper || document.body, { childList: true, subtree: true } );
	// The theme controls' CSS from the editor as their values change (live-css.js): swapped between the markers
	// Renderer::styles() prints in the layout's style, so it keeps its place before the layout's Custom CSS
	window.addEventListener( 'message', function ( event ) {
		var data = event.data || {};

		// From the editor: the frame's parent, or the top window when the frame sits in the block editor's canvas
		if ( ( event.source !== window.parent && event.source !== window.top ) || 'controls-css' !== data.formaPreview ) {
			return;
		}

		var style = document.getElementById( 'forma-' + parseInt( data.id, 10 ) + '-inline-css' );
		var marker = /\/\*forma-controls\*\/[\s\S]*?\/\*\/forma-controls\*\//;
		var css = '/*forma-controls*/' + String( data.css || '' ) + '/*/forma-controls*/';

		if ( style && marker.test( style.textContent ) && -1 === style.textContent.indexOf( css ) ) {
			style.textContent = style.textContent.replace( marker, function () {
				return css;
			} );
		}
	} );

	window.addEventListener( 'load', function () {
		report( true );
	} );

	/**
	 * What scrolls around the frame: the editor's content panel when the editor isn't in a frame of its own (meta
	 * boxes), else the editor canvas's window
	 */
	function scroller() {
		try {
			for ( var element = window.frameElement && window.frameElement.parentElement; element; element = element.parentElement ) {
				var style = window.parent.getComputedStyle( element );

				if ( /(auto|scroll)/.test( style.overflowY ) && element.scrollHeight > element.clientHeight ) {
					return element;
				}
			}
		} catch ( error ) {
			// Cross-origin parent
		}

		return window.parent;
	}

	// The frame has no scroll of its own. Captured before smooth-scroll scripts (Lenis) can cancel it.
	window.addEventListener( 'wheel', function ( event ) {
		event.stopImmediatePropagation();

		if ( window.parent === window || event.ctrlKey ) {
			return;
		}

		var unit = 1 === event.deltaMode ? 16 : 1;
		var stage = null;

		try {
			stage = window.frameElement && window.frameElement.closest( '.forma-editor__stage' );
		} catch ( error ) {
			// Cross-origin parent
		}

		event.preventDefault();
		// Instant: the editor's smooth scroll-behavior would restart an animation on every event of a trackpad
		scroller().scrollBy( { top: event.deltaY * unit, behavior: 'instant' } );

		if ( stage && event.deltaX ) {
			stage.scrollLeft += event.deltaX * unit;
		}
	}, { capture: true, passive: false } );

	// Static preview
	[ 'click', 'mousedown', 'submit' ].forEach( function ( type ) {
		document.addEventListener( type, function ( event ) {
			event.stopPropagation();
			event.preventDefault();
		}, true );
	} );
} )();
