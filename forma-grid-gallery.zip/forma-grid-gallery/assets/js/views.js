/* ========================================
 * Forma: counts a view of the portfolio item on this page (Portfolio\Views).
 * Sent from the browser so cached pages count too. Each item counts once per browser session.
 * ======================================== */
(function () {
	'use strict';

	var data = window.formaViews;

	if (!data || !data.url) {
		return;
	}

	var key = 'forma-viewed-' + data.id;

	try {
		if (sessionStorage.getItem(key)) {
			return;
		}

		sessionStorage.setItem(key, '1');
	} catch {
		// Storage blocked: count it anyway
	}

	fetch(data.url, { method: 'POST', keepalive: true, credentials: 'omit' }).catch(function () {});
})();
