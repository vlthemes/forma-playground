/* ========================================
 * Forma widget in Elementor: the editor renders the widget again on every change, so its grid is set up
 * again (grid.js sets up the grids of the page only once, when it loads)
 * ======================================== */
(function ($) {
	'use strict';

	$(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction('frontend/element_ready/forma.default', function ($element) {
			if (window.formaGrid && window.formaGrid.init) {
				window.formaGrid.init($element[0]);
			}
		});
	});
})(jQuery);
