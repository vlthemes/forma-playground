/* ========================================
 * Forma: AJAX search, filters, sorting and pagination
 *
 * Events on the grid (they bubble):
 *
 *     forma:init         the grid is ready
 *     forma:before-load  a request starts; cancelable
 *     forma:updated      new items are in, detail.items
 *     forma:filtered     after updated, when the filter changed
 *     forma:searched     after updated, when the search changed
 *     forma:sorted       after updated, when the order changed
 *     forma:paginated    after updated, for page numbers and load more
 *     forma:error        the request failed
 *
 * detail: { grid, layout, layoutSettings, page, maxPages, term, search, sort, action, append, items }
 *
 *     document.addEventListener( 'forma:updated', ( event ) => myLightbox( event.detail.items ) );
 *
 * formaGrid: init( context ), request( params, signal ), params( element, changes ), page( element, page ).
 * ======================================== */
(function () {
	'use strict';

	const settings = window.formaGrid || {};
	const states = new WeakMap();

	function parse(html) {
		const template = document.createElement('template');
		template.innerHTML = html;
		return Array.from(template.content.children);
	}

	function init(root) {
		if (states.has(root)) {
			return states.get(root);
		}

		let config;

		try {
			config = JSON.parse(root.dataset.forma || '{}');
		} catch {
			return null;
		}

		const state = {
			root: root,
			layout: String(config.layout),
			layoutSettings: config.layoutSettings || {},
			page: config.page || 1,
			maxPages: config.maxPages || 1,
			seed: config.seed || 0,
			skip: config.skip || [],
			// The term the page came filtered by (Renderer::initial_term())
			term: config.term || 0,
			search: '',
			searchTimer: 0,
			// The order the page came sorted by (Renderer::initial_sort())
			sort: config.sort || '',
			// "taxonomy:term" of a category or tag page's grid
			scope: config.scope || '',
			request: 0,
			controller: null,
		};

		states.set(root, state);
		masonry(state);
		metro(state);
		toolbars(root.closest('.forma-group'));
		emit(state, 'init', {});
		return state;
	}

	/**
	 * Returns false when a listener canceled the event
	 */
	function emit(state, name, extra, cancelable) {
		return state.root.dispatchEvent(new CustomEvent('forma:' + name, {
			bubbles: true,
			cancelable: !!cancelable,
			detail: Object.assign({
				grid: state.root,
				layout: state.layout,
				layoutSettings: state.layoutSettings,
				page: state.page,
				maxPages: state.maxPages,
				term: state.term,
				search: state.search,
				sort: state.sort,
			}, extra),
		}));
	}

	/**
	 * Grid a control belongs to
	 */
	function gridOf(control) {
		const grids = document.querySelectorAll('[data-forma][data-forma-layout="' + window.CSS.escape(control.dataset.formaFor) + '"]');
		const grid = grids[(parseInt(control.dataset.formaInstance, 10) || 1) - 1];

		return grid ? init(grid) : null;
	}

	/**
	 * Controls (filters, paginations) of a grid
	 */
	function controlsOf(state, selector) {
		return Array.from(document.querySelectorAll(selector + '[data-forma-for="' + window.CSS.escape(state.layout) + '"]')).filter(function (control) {
			return gridOf(control) === state;
		});
	}

	function onClick(event) {
		const control = event.target.closest('[data-forma-for]');
		const state = control && gridOf(control);

		if (!state) {
			return;
		}

		const filter = event.target.closest('[data-forma-term]');
		const order = event.target.closest('[data-forma-sort-value]');
		const page = event.target.closest('[data-forma-page]');
		const more = event.target.closest('[data-forma-more]');
		const link = [filter, order, page, more].find(function (element) {
			return element && element.matches('a[href]');
		});

		// A filter or page link opened in a new tab or window is the browser's
		if (link && (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button > 0)) {
			return;
		}

		if (filter || order || page || more) {
			event.preventDefault();
		}

		if (filter) {
			setTerm(state, parseInt(filter.dataset.formaTerm, 10) || 0);
		} else if (order) {
			setSort(state, order.dataset.formaSortValue);
		} else if (page) {
			load(state, { action: 'page', page: parseInt(page.dataset.formaPage, 10) || 1, append: false, scroll: true });
		} else if (more && !more.disabled && state.page < state.maxPages) {
			load(state, { action: 'more', page: state.page + 1, append: true, button: more });
		}
	}

	/**
	 * Search as you type, or at once on Enter
	 */
	function onInput(event) {
		const input = event.target.closest('[data-forma-search]');
		const control = input && input.closest('[data-forma-for]');
		const state = control && gridOf(control);

		if (!state) {
			return;
		}

		clearTimeout(state.searchTimer);
		state.searchTimer = setTimeout(function () {
			setSearch(state, input.value);
		}, 300);
	}

	function onSubmit(event) {
		const control = event.target.closest('[data-forma-for]');
		const state = control && gridOf(control);
		const input = state && event.target.querySelector('[data-forma-search]');

		if (!input) {
			return;
		}

		event.preventDefault();
		clearTimeout(state.searchTimer);
		setSearch(state, input.value);
	}

	/**
	 * Set the search words and go back to page 1
	 */
	function setSearch(state, value) {
		const search = String(value).trim().slice(0, 100);

		if (search === state.search || !emit(state, 'before-load', { action: 'search', search: search, nextPage: 1 }, true)) {
			return;
		}

		state.search = search;

		controlsOf(state, '.forma-search').forEach(function (box) {
			box.querySelectorAll('[data-forma-search]').forEach(function (input) {
				if (input.value.trim() !== search) {
					input.value = search;
				}
			});
		});

		load(state, { action: 'search', page: 1, append: false, checked: true });
	}

	function onChange(event) {
		const select = event.target.closest('[data-forma-filter], [data-forma-sort]');
		const control = select && select.closest('[data-forma-for]');
		const state = control && gridOf(control);

		if (!state) {
			return;
		}

		if (select.matches('[data-forma-sort]')) {
			setSort(state, select.value);
		} else {
			setTerm(state, parseInt(select.value, 10) || 0);
		}
	}

	/**
	 * Set the visitor's order ('' = the layout's own) and go back to page 1
	 */
	function setSort(state, sort) {
		if (sort === state.sort || !emit(state, 'before-load', { action: 'sort', sort: sort, nextPage: 1 }, true)) {
			return;
		}

		state.sort = sort;

		// Random order: one shuffle for this visitor, kept across pages
		if ('rand' === sort && !state.seed) {
			state.seed = 1 + Math.floor(Math.random() * 999999);
		}

		controlsOf(state, '.forma-sort').forEach(function (box) {
			box.querySelectorAll('[data-forma-sort]').forEach(function (select) {
				select.value = sort;
			});

			// Buttons, one per order (the default style)
			box.querySelectorAll('[data-forma-sort-value]').forEach(function (button) {
				const active = button.dataset.formaSortValue === sort;
				button.classList.toggle('is-active', active);

				// Links (FilterLink.php) say which view is current, buttons that they are pressed
				if (button.hasAttribute('href')) {
					if (active) {
						button.setAttribute('aria-current', 'true');
					} else {
						button.removeAttribute('aria-current');
					}
				} else {
					button.setAttribute('aria-pressed', active ? 'true' : 'false');
				}
			});
		});

		load(state, { action: 'sort', page: 1, append: false, checked: true });
	}

	/**
	 * Set the filter term and go back to page 1
	 */
	function setTerm(state, term) {
		// The active filter again (also while its items load): nothing to do
		if (term === state.term || !emit(state, 'before-load', { action: 'filter', term: term, nextPage: 1 }, true)) {
			return;
		}

		state.term = term;

		controlsOf(state, '.forma-filter').forEach(function (filters) {
			filters.querySelectorAll('[data-forma-term]').forEach(function (button) {
				const active = (parseInt(button.dataset.formaTerm, 10) || 0) === term;
				button.classList.toggle('is-active', active);

				// Links (FilterLink.php) say which view is current, buttons that they are pressed
				if (button.hasAttribute('href')) {
					if (active) {
						button.setAttribute('aria-current', 'true');
					} else {
						button.removeAttribute('aria-current');
					}
				} else {
					button.setAttribute('aria-pressed', active ? 'true' : 'false');
				}
			});

			filters.querySelectorAll('[data-forma-filter]').forEach(function (select) {
				select.value = String(term);
			});
		});

		load(state, { action: 'filter', page: 1, append: false, checked: true });
	}

	/**
	 * Loading state of a grid, its pagination and, during a search, its search fields
	 */
	function setLoading(state, loading, action) {
		const search = !loading || 'search' === action ? controlsOf(state, '.forma-search') : [];

		if (!loading) {
			state.root.classList.remove('is-swapping');
		}

		[state.root].concat(controlsOf(state, '.forma-pagination'), search).forEach(function (element) {
			element.classList.toggle('is-loading', loading);

			if (loading) {
				element.setAttribute('aria-busy', 'true');
			} else {
				element.removeAttribute('aria-busy');
			}
		});

		// The filter picked (already .is-active, setTerm()) while its items load
		controlsOf(state, '.forma-filter').forEach(function (filters) {
			filters.querySelectorAll(loading && 'filter' === action ? '[data-forma-term].is-active' : '[data-forma-term].is-loading').forEach(function (chip) {
				chip.classList.toggle('is-loading', loading);
			});
		});
	}

	/**
	 * Request parameters of a grid; changes (page, term, search, sort) override its current state
	 */
	function params(state, changes) {
		return Object.assign({
			layout: state.layout,
			page: state.page,
			term: state.term,
			search: state.search,
			sort: state.sort,
			scope: state.scope,
			seed: state.seed,
			skip: state.skip.join(','),
		}, changes);
	}

	/**
	 * One page of items, GET {restUrl}{layout}/items (Rest::items()): resolves with { items, pagination, page, maxPages }
	 */
	function request(query, signal) {
		const params = new URLSearchParams();

		Object.keys(query).forEach(function (key) {
			if ('layout' !== key && '' !== query[key] && null !== query[key]) {
				params.append(key, query[key]);
			}
		});

		const url = new URL(settings.restUrl + encodeURIComponent(query.layout) + '/items', window.location.href);
		url.search = url.search ? url.search + '&' + params : params.toString();

		return fetch(url, {
			credentials: 'same-origin',
			headers: settings.nonce ? { 'X-WP-Nonce': settings.nonce } : {},
			signal: signal,
		}).then(function (response) {
			if (!response.ok) {
				throw new Error('forma: bad response');
			}

			return response.json();
		});
	}

	function load(state, options) {
		if (!options.checked && !emit(state, 'before-load', { action: options.action, nextPage: options.page }, true)) {
			return;
		}

		if (state.controller) {
			state.controller.abort();
		}

		const controller = new AbortController();
		const request = ++state.request;
		const button = options.button;

		state.controller = controller;
		setLoading(state, true, options.action);

		// The template has the loading text already; its style shows it while .is-loading
		if (button) {
			button.disabled = true;
			button.classList.add('is-loading');
		}

		settings.request(params(state, { page: options.page }), controller.signal)
			.then(function (data) {
				if (request !== state.request) {
					return;
				}

				const nodes = parse(data.items);

				// Cards appear once, with their image: the old ones stay until the new images are in
				return imagesReady(nodes, onScreen(state)).then(function () {
					if (request !== state.request) {
						return;
					}

					// is-swapping: the moment to take the old items out (a transition of Forma Pro
					// animations), waited for before the new ones go in. Load More keeps the items it has.
					const items = state.root.querySelector('.forma__items');

					if (!options.append) {
						state.root.classList.add('is-swapping');
					}

					return settled(items).then(function () {
						if (request === state.request) {
							render(state, data, options, nodes);
						}
					});
				});
			})
			.catch(function (error) {
				if ('AbortError' === error.name || request !== state.request) {
					return;
				}

				showError(state.root);
				emit(state, 'error', { action: options.action });

				if (button) {
					button.disabled = false;
					button.classList.remove('is-loading');
				}
			})
			.finally(function () {
				if (request === state.request) {
					state.controller = null;
					setLoading(state, false);
				}
			});
	}

	/**
	 * Transitions of an element finished (or canceled)
	 */
	function settled(element) {
		return Promise.all(element && element.getAnimations ? element.getAnimations().map(function (animation) {
			return animation.finished.catch(function () {});
		}) : []);
	}

	/**
	 * Items of a grid on the screen now: about as many new ones will be seen first (6–24)
	 */
	function onScreen(state) {
		const seen = Array.from(state.root.querySelectorAll('.forma__item')).filter(function (item) {
			const box = item.getBoundingClientRect();

			return box.bottom > 0 && box.top < window.innerHeight;
		}).length;

		return Math.min(24, Math.max(6, seen));
	}

	/**
	 * Waits for the first new images (up to 1.5 s) so cards don't pop in empty.
	 * Nodes from a <template> live in an inert document where images never load, so they're adopted first.
	 */
	function imagesReady(nodes, first) {
		const images = [];

		nodes.forEach(function (node, index) {
			node.querySelectorAll('img').forEach(function (image) {
				image.loading = index < first ? 'eager' : 'lazy';
			});

			document.adoptNode(node);

			if (index < first) {
				node.querySelectorAll('img').forEach(function (image) {
					images.push(image.decode ? image.decode().catch(function () {}) : Promise.resolve());
				});
			}
		});

		return images.length ? Promise.race([Promise.all(images), new Promise(function (resolve) {
			setTimeout(resolve, 1500);
		})]) : Promise.resolve();
	}

	function render(state, data, options, nodes) {
		const root = state.root;
		const items = root.querySelector('.forma__items');

		if (options.append) {
			// Past the end the server returns the empty message
			nodes = nodes.filter(function (node) {
				return !node.classList.contains('forma__empty');
			});
			items.append.apply(items, nodes);
		} else {
			items.replaceChildren.apply(items, nodes);
		}

		masonry(state);
		metro(state);

		// The pagination comes with its wrapper: it takes the old one's place, and keeps which grid it belongs to
		controlsOf(state, '.forma-pagination').forEach(function (pagination) {
			const fresh = parse(data.pagination)[0];

			if (fresh) {
				fresh.dataset.formaFor = pagination.dataset.formaFor;
				fresh.dataset.formaInstance = pagination.dataset.formaInstance;
				pagination.replaceWith(fresh);
			}
		});

		const error = root.querySelector('.forma__error');

		if (error) {
			error.remove();
		}

		state.page = data.page;
		state.maxPages = data.maxPages;

		if (options.scroll) {
			// Scroll when the top of the grid is above the offset (scroll-margin-top, e.g. under a sticky header)
			if (root.getBoundingClientRect().top < (parseFloat(getComputedStyle(root).scrollMarginTop) || 0)) {
				const smooth = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
				root.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto', block: 'start' });
			}

			items.setAttribute('tabindex', '-1');
			items.focus({ preventScroll: true });
		}

		const detail = { action: options.action, append: !!options.append, items: nodes };

		emit(state, 'updated', detail);
		emit(state, { filter: 'filtered', search: 'searched', sort: 'sorted' }[options.action] || 'paginated', detail);
	}

	/**
	 * Stacks a toolbar row when its controls don't fit on one line. CSS can't wrap a grid row by content,
	 * so the row is measured at full width (is-measuring).
	 */
	const toolbarWidths = new WeakMap();
	const toolbarObserver = window.ResizeObserver ? new ResizeObserver(function (entries) {
		entries.forEach(function (entry) {
			fitToolbar(entry.target);
		});
	}) : null;

	function fitToolbar(row) {
		const width = row.clientWidth;

		if (toolbarWidths.get(row) === width) {
			return;
		}

		toolbarWidths.set(row, width);
		row.classList.remove('is-stacked');
		row.classList.add('is-measuring');

		const stacked = row.scrollWidth > width + 1;

		row.classList.remove('is-measuring');
		row.classList.toggle('is-stacked', stacked);
	}

	function toolbars(group) {
		if (!group) {
			return;
		}

		const header = group.querySelector(':scope > .forma-group__header[data-forma-toolbar]');

		if (header && !arranged.has(header)) {
			arranged.add(header);
			arrange(header, group);
		}

		group.querySelectorAll('.forma-toolbar').forEach(function (row) {
			if (toolbarWidths.has(row)) {
				return;
			}

			fitToolbar(row);

			if (toolbarObserver) {
				toolbarObserver.observe(row);
			}

			if (document.fonts) {
				document.fonts.ready.then(function () {
					toolbarWidths.delete(row);
					fitToolbar(row);
				});
			}
		});
	}

	/**
	 * A toolbar placed differently on some devices (data-forma-toolbar, Renderer::toolbar_media()): its controls move
	 * into the rows of the width range the page is in
	 */
	const arranged = new WeakSet();
	const TOOLBAR_CONTROLS = { search: '.forma-search', filters: '.forma-filter', sort: '.forma-sort' };

	function arrange(header, group) {
		let devices = [];

		try {
			devices = JSON.parse(header.dataset.formaToolbar);
		} catch (error) {
			return;
		}

		devices.forEach(function (device) {
			const query = window.matchMedia(device[0]);

			query.addEventListener('change', function () {
				if (query.matches) {
					buildToolbar(header, device[1]);
					toolbars(group);
				}
			});

			if (query.matches) {
				buildToolbar(header, device[1]);
			}
		});
	}

	function buildToolbar(header, places) {
		const controls = {};
		const rows = {};

		Object.keys(TOOLBAR_CONTROLS).forEach(function (control) {
			controls[control] = header.querySelector(TOOLBAR_CONTROLS[control]);
		});

		Object.keys(places).forEach(function (place) {
			const parts = place.split('-');
			const zone = document.createElement('div');

			zone.className = 'forma-toolbar__zone forma-toolbar__zone--' + parts[1];
			places[place].forEach(function (control) {
				if (controls[control]) {
					zone.append(controls[control]);
				}
			});

			rows[parts[0]] = (rows[parts[0]] || []).concat(zone);
		});

		header.querySelectorAll(':scope > .forma-toolbar').forEach(function (row) {
			if (toolbarObserver) {
				toolbarObserver.unobserve(row);
			}
		});

		header.replaceChildren.apply(header, Object.keys(rows).map(function (key) {
			const row = document.createElement('div');

			row.className = 'forma-toolbar' + rows[key].map(function (zone) {
				return ' forma-toolbar--' + zone.className.split('--').pop();
			}).join('');
			row.append.apply(row, rows[key]);

			return row;
		}));
	}

	/**
	 * Masonry: each item goes under the shortest column, so appended items never move the ones above
	 * (CSS columns would rebalance).
	 */
	function masonry(state) {
		const items = state.root.querySelector('.forma__items');

		if (!items || !state.root.classList.contains('forma--layout-masonry') || !window.ResizeObserver) {
			return;
		}

		if (!state.masonry) {
			let frame = 0;

			state.masonry = new ResizeObserver(function () {
				cancelAnimationFrame(frame);
				frame = requestAnimationFrame(function () {
					place(items);
				});
			});
			items.classList.add('is-masonry');
		}

		// Observing anew drops the items a filter took out
		state.masonry.disconnect();
		state.masonry.observe(items);
		Array.from(items.children).forEach(function (item) {
			state.masonry.observe(item);
		});

		place(items);
	}

	function place(items) {
		const style = getComputedStyle(items);
		const columns = Math.max(1, parseInt(style.getPropertyValue('--forma-cols'), 10) || 1);
		const gap = parseFloat(style.rowGap) || 0;
		const heights = new Array(columns).fill(0);
		const cells = Array.from(items.children).filter(function (item) {
			return item.classList.contains('forma__item');
		});
		// All heights read before any write: one layout pass
		const sizes = cells.map(function (item) {
			return item.offsetHeight;
		});

		cells.forEach(function (item, index) {
			const column = heights.indexOf(Math.min.apply(Math, heights));

			item.style.setProperty('--vlt-col', column);
			item.style.top = heights[column] + 'px';
			heights[column] += sizes[index] + gap;
		});

		items.style.height = cells.length ? Math.max.apply(Math, heights) - gap + 'px' : '';
	}

	/**
	 * Metro: the media is the tile, the card's text adds to it, so each item spans the rows its height takes
	 */
	function metro(state) {
		const items = state.root.querySelector('.forma__items');

		if (!items || !state.root.classList.contains('forma--layout-metro') || state.root.classList.contains('forma--metro-card') || !window.ResizeObserver) {
			return;
		}

		if (!state.metro) {
			let frame = 0;

			state.metro = new ResizeObserver(function () {
				cancelAnimationFrame(frame);
				frame = requestAnimationFrame(function () {
					span(items);
				});
			});
		}

		state.metro.disconnect();
		state.metro.observe(items);
		Array.from(items.children).forEach(function (item) {
			state.metro.observe(item);
		});

		span(items);
	}

	/**
	 * An item's height with its padding and border, unrounded and unscaled
	 */
	function outerHeight(item) {
		const style = getComputedStyle(item);
		const height = parseFloat(style.height) || item.offsetHeight;

		return 'border-box' === style.boxSizing
			? height
			: height + parseFloat(style.paddingTop) + parseFloat(style.paddingBottom) + parseFloat(style.borderTopWidth) + parseFloat(style.borderBottomWidth);
	}

	function span(items) {
		const row = parseFloat(getComputedStyle(items).getPropertyValue('--forma-metro-row'));
		const cells = Array.from(items.children).filter(function (item) {
			return item.classList.contains('forma__item');
		});

		if (!row || !cells.length) {
			return;
		}

		const gap = parseFloat(getComputedStyle(cells[0]).marginBottom) || 0;
		// All heights read before any write: one layout pass. The exact height: offsetHeight rounds to a whole pixel,
		// and half a pixel up is a row more, a line under the tile. Computed, so the editor preview's scale doesn't
		// count; a hair under a row is rounding, not a row more
		const rows = cells.map(function (item) {
			return Math.max(1, Math.ceil((outerHeight(item) + gap) / row - 0.05));
		});

		cells.forEach(function (item, index) {
			item.style.gridRow = 'span ' + rows[index];
		});
	}

	function showError(root) {
		if (root.querySelector('.forma__error')) {
			return;
		}

		const error = document.createElement('p');
		error.className = 'forma__error';
		error.setAttribute('role', 'alert');
		error.textContent = (settings.i18n && settings.i18n.error) || 'Error';
		root.append(error);
	}

	if (!settings.bound) {
		settings.bound = true;
		document.addEventListener('click', onClick);
		document.addEventListener('change', onChange);
		document.addEventListener('input', onInput);
		document.addEventListener('submit', onSubmit);
	}

	/**
	 * Initialize grids in a container, e.g. after inserting markup
	 */
	settings.init = function (context) {
		(context || document).querySelectorAll('[data-forma]').forEach(init);
	};

	/**
	 * The request every load goes through; replace it to wrap it (Forma Pro caches it)
	 */
	settings.request = request;

	/**
	 * Request parameters of the grid an element is or controls, with changes applied; null for other elements
	 */
	settings.params = function (element, changes) {
		const control = element.closest('[data-forma-for]');
		const state = control ? gridOf(control) : element.matches('[data-forma]') ? init(element) : null;

		return state ? Object.assign(params(state, changes), { maxPages: state.maxPages }) : null;
	};

	/**
	 * Show a page of the grid an element is or controls, as its page numbers do (Back to an address opened with a
	 * page, grid-filter-link.js)
	 */
	settings.page = function (element, page) {
		const control = element.closest('[data-forma-for]');
		const state = control ? gridOf(control) : element.matches('[data-forma]') ? init(element) : null;

		if (state && page !== state.page && page >= 1 && page <= state.maxPages) {
			load(state, { action: 'page', page: page, append: false, scroll: true });
		}
	};

	if ('loading' === document.readyState) {
		document.addEventListener('DOMContentLoaded', function () {
			settings.init();
		});
	} else {
		settings.init();
	}
})();
