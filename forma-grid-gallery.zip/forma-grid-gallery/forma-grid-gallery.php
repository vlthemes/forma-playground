<?php

/**
 * Plugin Name: Forma Grid Gallery
 * Plugin URI: https://vlthemes.me/forma/
 * Description: Portfolio and saved grid layouts: grid, masonry, metro, justified, freeform and slider, with AJAX filters, search, pagination and a lightbox.
 * Version: 1.0.0
 * Author: VLThemes
 * Author URI: https://vlthemes.me/
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: forma-grid-gallery
 * Requires at least: 6.5
 * Requires PHP: 8.0
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

// Pro is the complete plugin: with it active this copy stays off (its classes would clash) and deactivates itself
if ( defined( 'FORMA_FILE' ) || in_array( 'forma-grid-gallery-pro/forma-grid-gallery-pro.php', (array) get_option( 'active_plugins', [] ), true ) || ( is_multisite() && isset( get_site_option( 'active_sitewide_plugins', [] )['forma-grid-gallery-pro/forma-grid-gallery-pro.php'] ) ) ) {
	// Activated while Pro runs: this one wins and Pro goes off, starting on the next request. Pro active on the whole
	// network can't be turned off from one site, so this one isn't activated.
	register_activation_hook( __FILE__, static function () {
		if ( is_multisite() && isset( get_site_option( 'active_sitewide_plugins', [] )['forma-grid-gallery-pro/forma-grid-gallery-pro.php'] ) ) {
			wp_die( esc_html__( 'Forma Grid Gallery Pro is active on the whole network and already includes everything in Forma Grid Gallery.', 'forma-grid-gallery' ), '', [ 'back_link' => true ] );
		}

		deactivate_plugins( 'forma-grid-gallery-pro/forma-grid-gallery-pro.php' );
	} );

	// Both still listed as active (e.g. activated together): Pro stays
	add_action( 'admin_init', static fn() => deactivate_plugins( plugin_basename( __FILE__ ) ) );

	return;
}

require_once __DIR__ . '/src/Autoloader.php';

VLT\Forma\Autoloader::register( __DIR__ . '/src' );
VLT\Forma\Plugin::boot( __FILE__, VLT\Forma\Plugin::FREE );
