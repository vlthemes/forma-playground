<?php
/**
 * Lightbox data of an item, read by lightbox.js on click
 *
 * Variables: $src, $srcset, $width, $height, $link, $title, $description, $meta (extra lines, e.g. camera details), $item.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<template
	class="vlt-lightbox-data"
	data-src="<?php echo esc_url( $src ); ?>"
	data-srcset="<?php echo esc_attr( $srcset ); ?>"
	data-size="<?php echo (int) $width . 'x' . (int) $height; ?>"
	data-link="<?php echo esc_url( $link ); ?>"
>
	<?php if ( $title ) : ?>
		<h3 class="vlt-lightbox-data__title"><?php echo esc_html( $title ); ?></h3>
	<?php endif; ?>
	<?php if ( $description ) : ?>
		<div class="vlt-lightbox-data__description"><?php echo esc_html( $description ); ?></div>
	<?php endif; ?>
	<?php if ( !empty( $meta ) ) : ?>
		<div class="vlt-lightbox-data__meta">
			<?php foreach ( $meta as $forma_line ) : ?>
				<span><?php echo esc_html( $forma_line ); ?></span>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</template>
