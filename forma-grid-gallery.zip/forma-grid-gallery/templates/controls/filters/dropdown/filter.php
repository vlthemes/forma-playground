<?php
/**
 * Filter, dropdown style
 *
 * Variables: $terms, $label, $config. The script listens to a <select data-forma-filter> whose values are term IDs.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<select class="forma-filter__select" data-forma-filter aria-label="<?php echo esc_attr( $label ); ?>">
	<?php foreach ( $terms as $term ) : ?>
		<option value="<?php echo (int) $term['id']; ?>" <?php selected( $term['active'] ); ?>>
			<?php echo esc_html( $term['label'] ); ?>
		</option>
	<?php endforeach; ?>
</select>
