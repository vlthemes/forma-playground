<?php
/**
 * Filter, default style: chips with item counts
 *
 * Variables: $terms [ [ id, name, count, count_label, label, active, url, class, attributes ], … ], $label, $config.
 * Keep class and attributes as they are, the script needs them.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<ul class="forma-filter__list">
	<?php foreach ( $terms as $term ) : ?>
		<li>
			<a
				href="<?php echo esc_url( $term['url'] ); ?>"
				class="<?php echo esc_attr( $term['class'] ); ?>"
				<?php echo $term['attributes']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped attribute string ?>
			>
				<?php echo esc_html( $term['name'] ); ?>
				<?php if ( $term['count_label'] ) : ?>
					<span class="forma-filter__count"><?php echo esc_html( $term['count_label'] ); ?></span>
				<?php endif; ?>
			</a>
		</li>
	<?php endforeach; ?>
</ul>
