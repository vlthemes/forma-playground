<?php
/**
 * Search, default style
 *
 * Variables: $placeholder, $label, $config. The script searches as you type in an input with data-forma-search.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<form class="forma-search__form" role="search">
	<input
		type="search"
		name="search"
		class="forma-search__input"
		data-forma-search
		placeholder="<?php echo esc_attr( $placeholder ); ?>"
		aria-label="<?php echo esc_attr( $label ); ?>"
		autocomplete="off"
		enterkeyhint="search"
	>
</form>
