<?php
/**
 * Pagination "Load More", default style
 *
 * Variables: $data [ type, page, max_pages, more, total, to, progress, count, ended ], $config.
 * more: [ class, url, label, loading, end, attributes ]; no url once everything is loaded. Keep class and attributes as they are.
 * Every style prints the same markup; its style.css shows what it needs.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<span class="forma-pagination__count">
	<?php echo $data['count']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts ?>
</span>

<span
	class="forma-pagination__progress"
	role="progressbar"
	aria-valuemin="0"
	aria-valuemax="<?php echo esc_attr( $data['total'] ); ?>"
	aria-valuenow="<?php echo esc_attr( $data['to'] ); ?>"
	aria-label="<?php esc_attr_e( 'Items shown', 'forma-grid-gallery' ); ?>"
>
	<span class="forma-pagination__progress-bar" style="--forma-progress:<?php echo esc_attr( $data['progress'] ); ?>"></span>
</span>

<a
	<?php if ( $data['more']['url'] ) : ?>
		href="<?php echo esc_url( $data['more']['url'] ); ?>"
	<?php endif; ?>
	class="<?php echo esc_attr( $data['more']['class'] ); ?>"
	<?php echo $data['more']['attributes']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped attribute string ?>
>
	<span class="forma-pagination__label"><?php echo esc_html( $data['more']['label'] ); ?></span>
	<span class="forma-pagination__loading">
		<span class="forma-pagination__spinner" aria-hidden="true"></span>
		<?php echo esc_html( $data['more']['loading'] ); ?>
	</span>
	<span class="forma-pagination__end"><?php echo esc_html( $data['more']['end'] ); ?></span>
</a>
