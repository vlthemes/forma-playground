<?php
/**
 * Pagination "Page numbers", default style
 *
 * Variables: $data [ type, page, max_pages, items, total, from, to, progress, count ], $config.
 * items: [ [ type (prev | page | gap | next), class, url, label, attributes ], … ]. Keep class and attributes as they are.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<ul class="forma-pagination__list">
	<?php foreach ( $data['items'] as $forma_item ) : ?>
		<li>
			<?php if ( $forma_item['url'] ) : ?>
				<a
					href="<?php echo esc_url( $forma_item['url'] ); ?>"
					class="<?php echo esc_attr( $forma_item['class'] ); ?>"
					<?php echo $forma_item['attributes']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped attribute string ?>
				>
			<?php else : ?>
				<span
					class="<?php echo esc_attr( $forma_item['class'] ); ?>"
					<?php echo $forma_item['attributes']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped attribute string ?>
				>
			<?php endif; ?>

				<?php if ( 'prev' === $forma_item['type'] ) : ?>
					<?php echo forma_icon( 'arrow-left' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plugin SVG ?>
					<span class="forma-pagination__label"><?php echo esc_html( $forma_item['label'] ); ?></span>
				<?php elseif ( 'next' === $forma_item['type'] ) : ?>
					<span class="forma-pagination__label"><?php echo esc_html( $forma_item['label'] ); ?></span>
					<?php echo forma_icon( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plugin SVG ?>
				<?php else : ?>
					<?php echo esc_html( $forma_item['label'] ); ?>
				<?php endif; ?>

			<?php echo $forma_item['url'] ? '</a>' : '</span>'; ?>
		</li>
	<?php endforeach; ?>
</ul>

<span class="forma-pagination__count">
	<?php echo $data['count']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts ?>
</span>
