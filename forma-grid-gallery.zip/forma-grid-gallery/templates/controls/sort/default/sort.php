<?php
/**
 * Sort, default style: a pill button per order
 *
 * Variables: $options [ [ value ('' = the layout's own order), label, active ], … ], $label, $config.
 * The script listens to clicks on [data-forma-sort-value].
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php foreach ( $options as $forma_option ) : ?>
	<button
		type="button"
		class="forma-sort__option<?php echo $forma_option['active'] ? ' is-active' : ''; ?>"
		data-forma-sort-value="<?php echo esc_attr( $forma_option['value'] ); ?>"
		aria-pressed="<?php echo $forma_option['active'] ? 'true' : 'false'; ?>"
	>
		<?php echo esc_html( $forma_option['label'] ); ?>
	</button>
<?php endforeach; ?>
