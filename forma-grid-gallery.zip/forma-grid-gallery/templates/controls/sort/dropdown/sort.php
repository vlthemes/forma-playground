<?php
/**
 * Sort, dropdown style
 *
 * Variables: $options [ [ value, label, active ], … ], $label, $config. The script listens to <select data-forma-sort>.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<select name="sort" class="forma-sort__select" data-forma-sort aria-label="<?php echo esc_attr( $label ); ?>">
	<?php foreach ( $options as $forma_option ) : ?>
		<option value="<?php echo esc_attr( $forma_option['value'] ); ?>" <?php selected( $forma_option['active'] ); ?>>
			<?php echo esc_html( $forma_option['label'] ); ?>
		</option>
	<?php endforeach; ?>
</select>
