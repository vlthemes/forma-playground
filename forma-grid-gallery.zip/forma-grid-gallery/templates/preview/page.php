<?php
/**
 * Editor preview frame: the theme's assets, no header or footer
 *
 * Variables: $html, $state (ok, empty or no-skin), $classes (forma_preview_classes), $config.
 * Hooks: forma_preview_before / forma_preview_after ( $config ), around the preview.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?> style="margin-top:0 !important">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'forma-preview-body' ); ?> data-forma-state="<?php echo esc_attr( $state ); ?>">
	<?php do_action( 'forma_preview_before', $config ); ?>
	<div class="<?php echo esc_attr( $classes ); ?>">
		<?php echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rendered templates ?>
	</div>
	<?php do_action( 'forma_preview_after', $config ); ?>
	<?php wp_footer(); ?>
</body>
</html>
