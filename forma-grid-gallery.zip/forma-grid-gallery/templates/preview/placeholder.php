<?php
/**
 * A stand-in card in the editor's preview while the theme's skin template is missing
 *
 * Variables: $index (position in the grid), $config.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="forma__placeholder"></div>
