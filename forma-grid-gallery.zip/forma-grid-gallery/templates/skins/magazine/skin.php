<?php
/**
 * Forma card style, Magazine: for posts: the image, the category as a label, a large title, the excerpt, then the date and "Read more".
 *
 * Inside the card Forma prints; variables as skins/default/skin.php (Forma's templates).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

// The skin's settings (settings.php): the title's tag, the excerpt's length, the date format, the link text, the parts
// to leave out
$forma_title_tag     = $options['title_tag'] ?? 'h3';
$forma_excerpt_words = $options['excerpt_words'] ?? 24;
$forma_date_format   = ( $options['date_format'] ?? '' ) ?: get_option( 'date_format' );
$forma_more_text     = ( $options['more_text'] ?? '' ) ?: __( 'Read more', 'forma-grid-gallery' );
$forma_show_terms    = $options['terms'] ?? true;
$forma_show_date     = $options['date'] ?? true;
$forma_show_excerpt  = $options['excerpt'] ?? true;
$forma_show_more     = $options['more'] ?? true;
?>
<div class="forma__media forma-card__media">
	<?php forma_item_part( 'image', $item ); ?>
	<?php forma_item_part( 'video', $item ); ?>
</div>
<div class="forma-card__body">
	<?php if ( $forma_show_terms ) : ?>
		<?php forma_item_part( 'terms', $item ); ?>
	<?php endif; ?>
	<?php forma_item_part( 'title', $item, [ 'link_class' => 'forma-card__link', 'tag' => $forma_title_tag ] ); ?>
	<?php if ( $forma_show_excerpt ) : ?>
		<?php forma_item_part( 'excerpt', $item, [ 'words' => $forma_excerpt_words ] ); ?>
	<?php endif; ?>
	<div class="forma-card__footer">
		<?php if ( $forma_show_date ) : ?>
			<?php forma_item_part( 'date', $item, [ 'format' => $forma_date_format ] ); ?>
		<?php endif; ?>
		<?php if ( $forma_show_more && $item['url'] ) : ?>
			<span class="forma-card__more" aria-hidden="true">
				<?php echo esc_html( $forma_more_text ); ?>
				<?php echo forma_icon( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- an SVG file of the templates ?>
			</span>
		<?php endif; ?>
	</div>
</div>
