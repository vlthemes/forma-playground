<?php
/**
 * Magazine card style settings, shown in the Skin section. Values reach skin.php as $options.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

return [
	'card'  => [
		'type'   => 'group',
		'label'  => __( 'Card', 'forma-grid-gallery' ),
		'open'   => true,
		'fields' => [
			'radius' => [
				'type'  => 'dimension',
				'label' => __( 'Corner radius', 'forma-grid-gallery' ),
				'units' => [ 'px' ],
				'min'   => 0,
				'max'   => 80,
				'style' => [ [ 'element' => '', 'property' => '--forma-skin-magazine--radius' ] ],
			],
			'gap'    => [
				'type'  => 'dimension',
				'label' => __( 'Space under the image', 'forma-grid-gallery' ),
				'units' => [ 'px' ],
				'min'   => 0,
				'max'   => 80,
				'style' => [ [ 'element' => '', 'property' => '--forma-skin-magazine--gap' ] ],
			],
		],
	],
	'image' => [
		'type'   => 'group',
		'label'  => __( 'Image', 'forma-grid-gallery' ),
		'fields' => [
			'zoom'   => [
				'type'    => 'select',
				'label'   => __( 'Zoom on hover', 'forma-grid-gallery' ),
				'options' => [
					''     => __( 'Default', 'forma-grid-gallery' ),
					'1' => __( 'None', 'forma-grid-gallery' ),
					'1.03' => __( 'Subtle', 'forma-grid-gallery' ),
					'1.08' => __( 'Strong', 'forma-grid-gallery' ),
				],
				'style'   => [ [ 'element' => '', 'property' => '--forma-skin-magazine--zoom' ] ],
			],
			'filter' => [
				'type'    => 'select',
				'label'   => __( 'Filter', 'forma-grid-gallery' ),
				'help'    => __( 'On the image at rest; its true colors come back on hover.', 'forma-grid-gallery' ),
				'options' => [
					''                                                 => __( 'Default', 'forma-grid-gallery' ),
					'none'                                             => __( 'None', 'forma-grid-gallery' ),
					'grayscale(1)'                                     => __( 'Black & white', 'forma-grid-gallery' ),
					'saturate(.55) brightness(1.04)'                   => __( 'Soft', 'forma-grid-gallery' ),
					'sepia(.3) saturate(1.15) hue-rotate(-8deg)'       => __( 'Warm', 'forma-grid-gallery' ),
					'saturate(.85) hue-rotate(12deg) brightness(1.03)' => __( 'Cool', 'forma-grid-gallery' ),
					'saturate(1.35) contrast(1.08)'                    => __( 'Vivid', 'forma-grid-gallery' ),
					'contrast(.85) brightness(1.1) saturate(.75)'      => __( 'Faded', 'forma-grid-gallery' ),
					'blur(1.5px) saturate(1.2) brightness(1.05)'       => __( 'Dreamy', 'forma-grid-gallery' ),
				],
				'style'   => [ [ 'element' => '', 'property' => '--forma-skin-magazine--filter' ] ],
			],
		],
	],
	'text'  => [
		'type'   => 'group',
		'label'  => __( 'Text', 'forma-grid-gallery' ),
		'fields' => [
			'align'      => [
				'type'  => 'align',
				'label' => __( 'Text align', 'forma-grid-gallery' ),
				'style' => [ [ 'element' => '', 'property' => '--forma-skin-magazine--content-x' ] ],
			],
			'text_color' => [
				'type'  => 'color',
				'label' => __( 'Text color', 'forma-grid-gallery' ),
				'style' => [
					[ 'element' => '.forma-card', 'property' => 'color' ],
					[ 'element' => '.forma-card__title', 'property' => 'color' ],
				],
			],
			'accent'     => [
				'type'  => 'color',
				'label' => __( 'Accent color', 'forma-grid-gallery' ),
				'help'  => __( 'The category label and "Read more" on hover. Default: Forma\'s brand color.', 'forma-grid-gallery' ),
				'style' => [ [ 'element' => '', 'property' => '--forma-skin-magazine--accent' ] ],
			],
		],
	],
	'title' => [
		'type'   => 'group',
		'label'  => __( 'Title', 'forma-grid-gallery' ),
		'fields' => [
			'title_size' => [
				'type'  => 'dimension',
				'label' => __( 'Title size', 'forma-grid-gallery' ),
				'units' => [ 'px', 'rem', 'em' ],
				'min'   => 8,
				'max'   => 80,
				'style' => [ [ 'element' => '', 'property' => '--forma-skin-magazine--title-font-size' ] ],
			],
			'title_tag'  => [
				'type'    => 'select',
				'label'   => __( 'Title tag', 'forma-grid-gallery' ),
				'default' => 'h3',
				'options' => [
					'h2'  => 'H2',
					'h3'  => 'H3',
					'h4'  => 'H4',
					'h5'  => 'H5',
					'h6'  => 'H6',
					'p'   => 'p',
					'div' => 'div',
				],
			],
			'title_lines' => [
				'type'    => 'select',
				'label'   => __( 'Title lines', 'forma-grid-gallery' ),
				'help'    => __( 'A longer title ends with an ellipsis.', 'forma-grid-gallery' ),
				'options' => [
					''     => __( 'Default', 'forma-grid-gallery' ),
					'none' => __( 'No limit', 'forma-grid-gallery' ),
					'1'    => '1',
					'2'    => '2',
					'3'    => '3',
					'4'    => '4',
					'5'    => '5',
				],
				'style'   => [ [ 'element' => '', 'property' => '--forma-skin-magazine--title-lines' ] ],
			],
		],
	],
	'summary' => [
		'type'   => 'group',
		'label'  => __( 'Excerpt', 'forma-grid-gallery' ),
		'fields' => [
			'excerpt_words' => [
				'type'    => 'number',
				'label'   => __( 'Excerpt length', 'forma-grid-gallery' ),
				'help'    => __( 'In words; 0 shows the whole excerpt.', 'forma-grid-gallery' ),
				'min'     => 0,
				'max'     => 100,
				'default' => 24,
			],
			'excerpt_lines' => [
				'type'    => 'select',
				'label'   => __( 'Excerpt lines', 'forma-grid-gallery' ),
				'help'    => __( 'A longer excerpt ends with an ellipsis, so the cards of a row stay even.', 'forma-grid-gallery' ),
				'options' => [
					''     => __( 'Default', 'forma-grid-gallery' ),
					'none' => __( 'No limit', 'forma-grid-gallery' ),
					'1'    => '1',
					'2'    => '2',
					'3'    => '3',
					'4'    => '4',
					'5'    => '5',
				],
				'style'   => [ [ 'element' => '', 'property' => '--forma-skin-magazine--excerpt-lines' ] ],
			],
			'excerpt_size'  => [
				'type'  => 'dimension',
				'label' => __( 'Excerpt size', 'forma-grid-gallery' ),
				'units' => [ 'px', 'rem', 'em' ],
				'min'   => 8,
				'max'   => 40,
				'style' => [ [ 'element' => '', 'property' => '--forma-skin-magazine--excerpt-font-size' ] ],
			],
		],
	],
	'footer'  => [
		'type'   => 'group',
		'label'  => __( 'Footer', 'forma-grid-gallery' ),
		'fields' => [
			'date_format' => [
				'type'    => 'select',
				'label'   => __( 'Date format', 'forma-grid-gallery' ),
				'options' => [
					''       => __( 'The site\'s (Settings → General)', 'forma-grid-gallery' ),
					'M j, Y' => wp_date( 'M j, Y' ),
					'j F Y'  => wp_date( 'j F Y' ),
					'F Y'    => wp_date( 'F Y' ),
					'Y'      => wp_date( 'Y' ),
				],
			],
			'more_text'   => [
				'type'  => 'text',
				'label' => __( 'Link text', 'forma-grid-gallery' ),
				'help'  => __( 'Empty: "Read more".', 'forma-grid-gallery' ),
			],
			'divider'     => [
				'type'    => 'select',
				'label'   => __( 'Line above', 'forma-grid-gallery' ),
				'options' => [
					''  => __( 'Show', 'forma-grid-gallery' ),
					'0' => __( 'Hide', 'forma-grid-gallery' ),
				],
				'style'   => [ [ 'element' => '', 'property' => '--forma-skin-magazine--divider-width', 'mask' => '$px' ] ],
			],
		],
	],
	'show'  => [
		'type'   => 'group',
		'label'  => __( 'Show', 'forma-grid-gallery' ),
		'fields' => [
			'terms'   => [
				'type'    => 'toggle',
				'label'   => __( 'Show the categories', 'forma-grid-gallery' ),
				'default' => true,
			],
			'excerpt' => [
				'type'    => 'toggle',
				'label'   => __( 'Show the excerpt', 'forma-grid-gallery' ),
				'default' => true,
			],
			'date'    => [
				'type'    => 'toggle',
				'label'   => __( 'Show the date', 'forma-grid-gallery' ),
				'default' => true,
			],
			'more'    => [
				'type'    => 'toggle',
				'label'   => __( 'Show "Read more"', 'forma-grid-gallery' ),
				'default' => true,
			],
		],
	],
];
