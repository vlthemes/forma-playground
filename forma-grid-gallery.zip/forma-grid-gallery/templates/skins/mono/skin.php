<?php
/**
 * Forma card style, Mono: the image in black and white, in color on hover; the categories and the title under it, a line drawn under the title on hover.
 *
 * Inside the card Forma prints; variables as skins/default/skin.php (Forma's templates).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

// The skin's settings (settings.php): the title's tag, the parts to leave out
$forma_title_tag  = $options['title_tag'] ?? 'h3';
$forma_show_terms = $options['terms'] ?? true;
?>
<div class="forma__media forma-card__media">
	<?php forma_item_part( 'image', $item ); ?>
	<?php forma_item_part( 'video', $item ); ?>
</div>
<div class="forma-card__body">
	<?php if ( $forma_show_terms ) : ?>
		<?php forma_item_part( 'terms', $item ); ?>
	<?php endif; ?>
	<?php forma_item_part( 'title', $item, [ 'link_class' => 'forma-card__link', 'tag' => $forma_title_tag ] ); ?>
</div>
