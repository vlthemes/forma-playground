<?php
/**
 * Default card style: image, categories and year, title, tags. The title link covers the whole card.
 *
 * Forma prints the <article class="forma-card …"> around this template. Override it at
 * your-theme/forma/skins/default/skin.php.
 *
 * Variables: $item (see Sources\SourceInterface, plus url_target, url_rel, aria_label, image),
 * $index, $config, $source, $image_size, $options (the skin's settings).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

// The skin's settings (settings.php): the title's tag, the parts to leave out
$forma_title_tag  = $options['title_tag'] ?? 'h3';
$forma_show_terms = $options['terms'] ?? true;
$forma_show_date  = $options['date'] ?? true;
?>
<div class="forma__media forma-card__media">
	<?php forma_item_part( 'image', $item ); ?>
	<?php forma_item_part( 'video', $item ); ?>
	<?php if ( $item['url'] ) : ?>
		<span class="forma-card__go" aria-hidden="true">
			<?php echo forma_icon( 'arrow-up-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- an SVG file of the templates ?>
		</span>
	<?php endif; ?>
</div>
<div class="forma-card__body">
	<?php if ( ( $forma_show_terms && ( $item['terms'] || $item['count'] ) ) || ( $forma_show_date && $item['year'] ) ) : ?>
		<div class="forma-card__meta">
			<?php if ( $forma_show_terms ) : ?>
				<?php forma_item_part( 'count', $item, [ 'class' => 'forma-card__count' ] ); ?>
				<?php forma_item_part( 'terms', $item, [ 'class' => 'forma-card__terms' ] ); ?>
			<?php endif; ?>
			<?php if ( $forma_show_date ) : ?>
				<?php forma_item_part( 'date', $item, [ 'class' => 'forma-card__date' ] ); ?>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<?php forma_item_part( 'title', $item, [ 'class' => 'forma-card__title', 'link_class' => 'forma-card__link', 'tag' => $forma_title_tag ] ); ?>
	<?php forma_item_part( 'tags', $item, [ 'class' => 'forma-card__tags', 'item_class' => 'forma-card__tag' ] ); ?>
</div>
