<?php
/**
 * Forma card style, Caption: the image alone; on hover (always on touch screens) a caption bar with the title and categories slides up over its bottom.
 *
 * Inside the card Forma prints; variables as skins/default/skin.php (Forma's templates).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

// The skin's settings (settings.php): the title's tag, the parts to leave out
$forma_title_tag  = $options['title_tag'] ?? 'h3';
$forma_show_terms = $options['terms'] ?? true;
?>
<div class="forma__media forma-card__media">
	<?php forma_item_part( 'image', $item ); ?>
	<?php forma_item_part( 'video', $item ); ?>
</div>
<div class="forma-card__caption">
	<?php forma_item_part( 'title', $item, [ 'link_class' => 'forma-card__link', 'tag' => $forma_title_tag ] ); ?>
	<?php if ( $forma_show_terms ) : ?>
		<?php forma_item_part( 'terms', $item ); ?>
	<?php endif; ?>
</div>
