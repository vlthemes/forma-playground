<?php
/**
 * Fade card style: the text sits on a dark overlay that fades in on hover (always shown on touch screens)
 *
 * Variables: as skins/default/skin.php.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

// The skin's settings (settings.php): the title's tag, the parts to leave out
$forma_title_tag  = $options['title_tag'] ?? 'h3';
$forma_show_terms = $options['terms'] ?? true;
$forma_show_date  = $options['date'] ?? true;
?>
<div class="forma__media forma-card__media">
	<?php forma_item_part( 'image', $item ); ?>
	<?php forma_item_part( 'video', $item ); ?>
</div>
<div class="forma-card__overlay">
	<?php if ( ( $forma_show_terms && ( $item['terms'] || $item['count'] ) ) || ( $forma_show_date && $item['year'] ) ) : ?>
		<div class="forma-card__meta">
			<?php if ( $forma_show_terms ) : ?>
				<?php forma_item_part( 'count', $item, [ 'class' => 'forma-card__count' ] ); ?>
				<?php forma_item_part( 'terms', $item, [ 'class' => 'forma-card__terms' ] ); ?>
			<?php endif; ?>
			<?php if ( $forma_show_date ) : ?>
				<?php forma_item_part( 'date', $item, [ 'class' => 'forma-card__date' ] ); ?>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<div class="forma-card__body">
		<?php forma_item_part( 'title', $item, [ 'class' => 'forma-card__title', 'link_class' => 'forma-card__link', 'tag' => $forma_title_tag ] ); ?>
		<?php forma_item_part( 'tags', $item, [ 'class' => 'forma-card__tags' ] ); ?>
	</div>
</div>
