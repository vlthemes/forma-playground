<?php
/**
 * Forma card style, Glass: the image fills the card; the title and categories on a frosted-glass panel floating over its bottom, which lifts on hover.
 *
 * Inside the card Forma prints; variables as skins/default/skin.php (Forma's templates).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

// The skin's settings (settings.php): the title's tag, the parts to leave out
$forma_title_tag  = $options['title_tag'] ?? 'h3';
$forma_show_terms = $options['terms'] ?? true;
?>
<div class="forma__media forma-card__media">
	<?php forma_item_part( 'image', $item ); ?>
	<?php forma_item_part( 'video', $item ); ?>
</div>
<div class="forma-card__overlay">
	<div class="forma-card__panel">
		<?php if ( $forma_show_terms ) : ?>
			<?php forma_item_part( 'terms', $item ); ?>
		<?php endif; ?>
		<?php forma_item_part( 'title', $item, [ 'link_class' => 'forma-card__link', 'tag' => $forma_title_tag ] ); ?>
	</div>
</div>
