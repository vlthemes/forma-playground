<?php
/**
 * Polaroid card style settings, shown in the Skin section. Values reach skin.php as $options.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

return [
	'card'  => [
		'type'   => 'group',
		'label'  => __( 'Card', 'forma-grid-gallery' ),
		'open'   => true,
		'fields' => [
			'tilt'  => [
				'type'  => 'dimension',
				'label' => __( 'Angle', 'forma-grid-gallery' ),
				'help'  => __( 'How far the cards lean, one way and the other. 0deg keeps them straight.', 'forma-grid-gallery' ),
				'units' => [ 'deg' ],
				'min'   => 0,
				'max'   => 10,
				'style' => [ [ 'element' => '', 'property' => '--forma-skin-polaroid--tilt' ] ],
			],
			'frame' => [
				'type'  => 'color',
				'label' => __( 'Frame', 'forma-grid-gallery' ),
				'style' => [ [ 'element' => '', 'property' => '--forma-skin-polaroid--frame' ] ],
			],
		],
	],
	'image' => [
		'type'   => 'group',
		'label'  => __( 'Image', 'forma-grid-gallery' ),
		'fields' => [
			'filter' => [
				'type'    => 'select',
				'label'   => __( 'Filter', 'forma-grid-gallery' ),
				'help'    => __( 'On the image at rest; its true colors come back on hover.', 'forma-grid-gallery' ),
				'options' => [
					''                                                 => __( 'Default', 'forma-grid-gallery' ),
					'none'                                             => __( 'None', 'forma-grid-gallery' ),
					'grayscale(1)'                                     => __( 'Black & white', 'forma-grid-gallery' ),
					'saturate(.55) brightness(1.04)'                   => __( 'Soft', 'forma-grid-gallery' ),
					'sepia(.3) saturate(1.15) hue-rotate(-8deg)'       => __( 'Warm', 'forma-grid-gallery' ),
					'saturate(.85) hue-rotate(12deg) brightness(1.03)' => __( 'Cool', 'forma-grid-gallery' ),
					'saturate(1.35) contrast(1.08)'                    => __( 'Vivid', 'forma-grid-gallery' ),
					'contrast(.85) brightness(1.1) saturate(.75)'      => __( 'Faded', 'forma-grid-gallery' ),
					'blur(1.5px) saturate(1.2) brightness(1.05)'       => __( 'Dreamy', 'forma-grid-gallery' ),
				],
				'style'   => [ [ 'element' => '', 'property' => '--forma-skin-polaroid--filter' ] ],
			],
		],
	],
	'text'  => [
		'type'   => 'group',
		'label'  => __( 'Text', 'forma-grid-gallery' ),
		'fields' => [
			'align'      => [
				'type'    => 'align',
				'label'   => __( 'Text align', 'forma-grid-gallery' ),
				'default' => 'center',
				'style'   => [ [ 'element' => '', 'property' => '--forma-skin-polaroid--content-x' ] ],
			],
			'text_color' => [
				'type'  => 'color',
				'label' => __( 'Text color', 'forma-grid-gallery' ),
				'style' => [
					[ 'element' => '.forma-card', 'property' => 'color' ],
					[ 'element' => '.forma-card__title', 'property' => 'color' ],
				],
			],
		],
	],
	'title' => [
		'type'   => 'group',
		'label'  => __( 'Title', 'forma-grid-gallery' ),
		'fields' => [
			'title_size' => [
				'type'  => 'dimension',
				'label' => __( 'Title size', 'forma-grid-gallery' ),
				'units' => [ 'px', 'rem', 'em' ],
				'min'   => 8,
				'max'   => 80,
				'style' => [ [ 'element' => '', 'property' => '--forma-skin-polaroid--title-font-size' ] ],
			],
			'title_tag'  => [
				'type'    => 'select',
				'label'   => __( 'Title tag', 'forma-grid-gallery' ),
				'default' => 'h3',
				'options' => [
					'h2'  => 'H2',
					'h3'  => 'H3',
					'h4'  => 'H4',
					'h5'  => 'H5',
					'h6'  => 'H6',
					'p'   => 'p',
					'div' => 'div',
				],
			],
		],
	],
	'show'  => [
		'type'   => 'group',
		'label'  => __( 'Show', 'forma-grid-gallery' ),
		'fields' => [
			'date' => [
				'type'    => 'toggle',
				'label'   => __( 'Show the date', 'forma-grid-gallery' ),
				'default' => true,
			],
		],
	],
];
