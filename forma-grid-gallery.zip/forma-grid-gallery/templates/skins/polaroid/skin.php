<?php
/**
 * Forma card style, Polaroid: a white instant-photo frame with the title under the image, set at a slight angle that straightens on hover.
 *
 * Inside the card Forma prints; variables as skins/default/skin.php (Forma's templates).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

// The skin's settings (settings.php): the title's tag, the parts to leave out
$forma_title_tag = $options['title_tag'] ?? 'h3';
$forma_show_date = $options['date'] ?? true;
?>
<div class="forma__media forma-card__media">
	<?php forma_item_part( 'image', $item ); ?>
	<?php forma_item_part( 'video', $item ); ?>
</div>
<div class="forma-card__body">
	<?php forma_item_part( 'title', $item, [ 'link_class' => 'forma-card__link', 'tag' => $forma_title_tag ] ); ?>
	<?php if ( $forma_show_date ) : ?>
		<?php forma_item_part( 'date', $item ); ?>
	<?php endif; ?>
</div>
