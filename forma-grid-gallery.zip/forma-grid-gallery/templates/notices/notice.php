<?php
/**
 * A note for editors above the grid (e.g. the skin's file is missing), never shown to visitors
 *
 * Variables: $message, $config.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class="forma__notice"><?php echo esc_html( $message ); ?></p>
