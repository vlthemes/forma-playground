<?php
/**
 * Nothing matches the query (or the filter / search)
 *
 * Variables: $message (text, also changed with the forma_empty_message filter), $config.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class="forma__empty"><?php echo esc_html( $message ); ?></p>
