<?php
/**
 * A note for editors where a block or widget shows a part the layout has turned off, never shown to visitors
 *
 * Variables: $part (filter, search, sort or pagination), $title (what is off), $message (how to turn it on).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class="forma__notice"><span><strong><?php echo esc_html( $title ); ?>.</strong> <?php echo esc_html( $message ); ?></span></p>
