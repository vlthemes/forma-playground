<?php
/**
 * Item part: the tags as a list
 *
 * Variables: $item, $class (of the list), $item_class (of each tag), $limit (3 by default, 0 = all).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $item['tags'] ) ) {
	return;
}

$forma_limit = $limit ?? 3;
$forma_tags  = $forma_limit ? array_slice( $item['tags'], 0, $forma_limit ) : $item['tags'];
?>
<ul class="<?php echo esc_attr( $class ?? 'forma-card__tags' ); ?>">
	<?php foreach ( $forma_tags as $forma_tag ) : ?>
		<li<?php echo !empty( $item_class ) ? ' class="' . esc_attr( $item_class ) . '"' : ''; ?>>
			<?php echo esc_html( $forma_tag['name'] ); ?>
		</li>
	<?php endforeach; ?>
</ul>
