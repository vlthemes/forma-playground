<?php
/**
 * Item part: the excerpt (a post's excerpt, an image's caption or description)
 *
 * Variables: $item, $class, $words (cut to this many words, 0 = all).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( '' === (string) $item['excerpt'] ) {
	return;
}

$forma_excerpt = !empty( $words ) ? wp_trim_words( $item['excerpt'], (int) $words ) : $item['excerpt'];
?>
<p class="<?php echo esc_attr( $class ?? 'forma-card__excerpt' ); ?>">
	<?php echo esc_html( $forma_excerpt ); ?>
</p>
