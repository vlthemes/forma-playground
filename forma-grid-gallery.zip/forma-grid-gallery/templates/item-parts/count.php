<?php
/**
 * Item part: how many items a category has (Categories & tags source)
 *
 * Variables: $item, $class.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $item['count'] ) ) {
	return;
}

/* translators: %s: number of items in a category */
$forma_count = sprintf( _n( '%s item', '%s items', $item['count'], 'forma-grid-gallery' ), number_format_i18n( $item['count'] ) );
?>
<span class="<?php echo esc_attr( $class ?? 'forma-card__count' ); ?>">
	<?php echo esc_html( $forma_count ); ?>
</span>
