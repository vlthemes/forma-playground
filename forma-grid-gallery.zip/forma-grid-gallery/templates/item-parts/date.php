<?php
/**
 * Item part: the publish date, the year by default
 *
 * Variables: $item, $class, $format (a PHP date format, e.g. 'F j, Y'; '' = the year).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $item['datetime'] ) ) {
	return;
}

$forma_date = !empty( $format ) && $item['object'] instanceof WP_Post ? get_the_date( $format, $item['object'] ) : $item['year'];
?>
<time
	class="<?php echo esc_attr( $class ?? 'forma-card__date' ); ?>"
	datetime="<?php echo esc_attr( $item['datetime'] ); ?>"
>
	<?php echo esc_html( $forma_date ); ?>
</time>
