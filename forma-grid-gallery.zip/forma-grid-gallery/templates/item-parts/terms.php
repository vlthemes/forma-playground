<?php
/**
 * Item part: the categories (the terms of the layout's filter taxonomy), each a link to its archive
 *
 * Variables: $item, $class, $separator (', ' by default), $links (false: plain names).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $item['terms'] ) ) {
	return;
}

$forma_links = $links ?? true;
$forma_terms = array_map(
	fn( $term ) => $forma_links && $term['url']
		? '<a href="' . esc_url( $term['url'] ) . '">' . esc_html( $term['name'] ) . '</a>'
		: esc_html( $term['name'] ),
	$item['terms']
);
?>
<span class="<?php echo esc_attr( $class ?? 'forma-card__terms' ); ?>">
	<?php echo implode( esc_html( $separator ?? ', ' ), $forma_terms ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?>
</span>
