<?php
/**
 * Item part: the image at the layout's size (forma_item_image changes it), or the placeholder
 *
 * Variables: $item.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $item['image'] ) ) {
	return;
}

echo wp_kses( $item['image'], 'forma_image' );
