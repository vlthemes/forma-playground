<?php
/**
 * Item part: the title, the item's link around it (forma_link_start())
 *
 * Variables: $item, $class (of the heading), $tag (h3 by default), $link_class (of the link).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( '' === (string) $item['title'] ) {
	return;
}

$forma_tag = tag_escape( $tag ?? 'h3' );
?>
<<?php echo $forma_tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- tag_escape() ?> class="<?php echo esc_attr( $class ?? 'forma-card__title' ); ?>">
	<?php
	if ( $item['url'] ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside
		echo forma_link_start( $item, $link_class ?? '' ) . esc_html( $item['title'] ) . forma_link_end( $item );
	} else {
		echo esc_html( $item['title'] );
	}
	?>
</<?php echo $forma_tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- tag_escape() ?>>
