<?php
/**
 * End of an item's link (pairs with link-start.php). Skins: forma_link_end( $item ).
 *
 * Variables: $item (url).
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

echo empty( $item['url'] ) ? '</div>' : '</a>';
