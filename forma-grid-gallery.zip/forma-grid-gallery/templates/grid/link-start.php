<?php
/**
 * Start of an item's link, or a <div> when it has none. Skins use forma_link_start( $item, $class ).
 *
 * Variables: $item (url, url_target, url_rel, aria_label), $class.
 *
 * @package VLT\Forma
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $item['url'] ) ) {
	echo '<div' . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' ) . '>';
	return;
}
?>
<a
	href="<?php echo esc_url( $item['url'] ); ?>"
	<?php if ( $class ) : ?>
		class="<?php echo esc_attr( $class ); ?>"
	<?php endif; ?>
	<?php if ( !empty( $item['url_target'] ) ) : ?>
		target="<?php echo esc_attr( $item['url_target'] ); ?>"
	<?php endif; ?>
	<?php if ( !empty( $item['url_rel'] ) ) : ?>
		rel="<?php echo esc_attr( $item['url_rel'] ); ?>"
	<?php endif; ?>
	<?php if ( !empty( $item['aria_label'] ) ) : ?>
		aria-label="<?php echo esc_attr( $item['aria_label'] ); ?>"
	<?php endif; ?>
>
