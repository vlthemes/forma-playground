<?php

namespace VLT\Forma\Layouts;

use VLT\Forma\Core\Config;
use VLT\Forma\Front\SkinManager;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Layout type registered by the theme
 *
 *     add_filter( 'forma_layouts_styles', fn( $types ) => $types + [ 'carousel' => 'Carousel' ] );
 *
 *     your-theme/forma/layouts/carousel/layout.php (+ style.css, script.js)
 *
 * layout.php has "Name:" and "Description:" headers and returns its definition:
 *
 *     return [
 *         'settings'     => [
 *             'row_height' => [ 'type' => 'number', 'label' => 'Row height', 'default' => 240, 'min' => 80, 'max' => 600, 'unit' => 'px', 'responsive' => true ],
 *             'captions'   => [ 'type' => 'toggle', 'label' => 'Captions', 'default' => true ],
 *         ],
 *         'fields'       => [                                        // the shared Columns & gaps fields
 *             'columns' => false,                                    // hidden
 *             'gap_y'   => [ 'disabled' => true ],                   // shown, locked
 *             'gap_x'   => [ 'label' => 'Spacing', 'help' => '', 'max' => 100 ],
 *         ],
 *         'item_classes' => fn( $index, $config ) => [],
 *         'css'          => fn( $config, $scope, $breakpoints ) => '',
 *     ];
 *
 * Setting types: number, select, toggle, text. Each setting is available as --forma-{key} on the grid, and to
 * script.js as data-forma → layoutSettings.
 */
class ThemeLayout extends Layout {
	const TYPES = [ 'number', 'select', 'toggle', 'text' ];

	// Shared fields a definition can change, with the range Config keeps them in
	const FIELDS = [
		'columns' => [ 1, 12 ],
		'gap_x'   => [ 0, 200 ],
		'gap_y'   => [ 0, 200 ],
	];

	/**
	 * ID
	 *
	 * @var string
	 */
	private $id;

	/**
	 * Label
	 *
	 * @var string
	 */
	private $label;

	/**
	 * Description
	 *
	 * @var string
	 */
	private $description;

	/**
	 * Definition returned by layout.php
	 *
	 * @var array
	 */
	private $definition;

	/**
	 * Constructor
	 *
	 * @param string $id    Layout type ID (registered with forma_layouts_styles)
	 * @param string $label Label
	 */
	public function __construct( $id, $label ) {
		$file = SkinManager::locate( $id, 'template', 'layouts' );

		$this->id          = $id;
		$this->label       = $label;
		// "Description:" header of layout.php
		$this->description = $file ? (string) get_file_data( $file[0], [ 'description' => 'Description' ] )['description'] : '';

		$definition = $file ? ( static fn() => include $file[0] )() : [];

		$this->definition = is_array( $definition ) ? $definition : [];
	}

	/**
	 * Get ID
	 *
	 * @return string
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Get label
	 *
	 * @return string
	 */
	public function get_label() {
		return $this->label;
	}

	/**
	 * Get description
	 *
	 * @return string
	 */
	public function get_description() {
		return $this->description;
	}

	/**
	 * Whether the type lays items out in columns (the editor's Columns field)
	 *
	 * @return bool
	 */
	public function uses_columns() {
		return false !== ( $this->fields()['columns'] ?? true );
	}

	/**
	 * Changes to the shared fields (FIELDS): false hides one, an array sets its label, help, min, max or disabled
	 *
	 * @return array [ key => false|array ]
	 */
	public function fields() {
		$fields = [];

		foreach ( self::FIELDS as $key => [ $min, $max ] ) {
			$field = $this->definition['fields'][ $key ] ?? null;

			if ( false === $field ) {
				$fields[ $key ] = false;
				continue;
			}

			if ( !is_array( $field ) ) {
				continue;
			}

			$fields[ $key ] = array_filter(
				[
					'label'    => isset( $field['label'] ) ? (string) $field['label'] : null,
					'help'     => isset( $field['help'] ) ? (string) $field['help'] : null,
					'min'      => isset( $field['min'] ) ? max( $min, min( $max, (int) $field['min'] ) ) : null,
					'max'      => isset( $field['max'] ) ? max( $min, min( $max, (int) $field['max'] ) ) : null,
					'disabled' => !empty( $field['disabled'] ) ?: null,
				],
				fn( $value ) => null !== $value
			);
		}

		return $fields;
	}

	/**
	 * Valid settings of the definition
	 *
	 * @return array [ key => normalized setting ]
	 */
	public function settings() {
		$settings = [];

		foreach ( (array) ( $this->definition['settings'] ?? [] ) as $key => $setting ) {
			$key = sanitize_key( $key );

			if ( !$key || !is_array( $setting ) || !in_array( $setting['type'] ?? '', self::TYPES, true ) ) {
				continue;
			}

			$type    = $setting['type'];
			$options = 'select' === $type ? array_map( 'strval', (array) ( $setting['options'] ?? [] ) ) : [];

			if ( 'select' === $type && !$options ) {
				continue;
			}

			$normalized = [
				'type'       => $type,
				'label'      => (string) ( $setting['label'] ?? $key ),
				'help'       => (string) ( $setting['help'] ?? '' ),
				'responsive' => !empty( $setting['responsive'] ),
				'min'        => isset( $setting['min'] ) ? (float) $setting['min'] : null,
				'max'        => isset( $setting['max'] ) ? (float) $setting['max'] : null,
				'step'       => isset( $setting['step'] ) ? (float) $setting['step'] : 1,
				'unit'       => preg_replace( '/[^a-z%]/', '', strtolower( (string) ( $setting['unit'] ?? '' ) ) ),
				'options'    => $options,
			];

			// The type's own fallback: number → min (or 0), select → first option
			$fallback = match ( $type ) {
				'number' => $normalized['min'] ?? 0.0,
				'toggle' => false,
				'select' => (string) array_key_first( $options ),
				default  => '',
			};

			$default = $setting['default'] ?? null;

			if ( $normalized['responsive'] ) {
				$desktop = self::clean( $normalized, is_array( $default ) ? ( $default['desktop'] ?? null ) : $default, $fallback );
				$default = [];

				foreach ( Config::DEVICES as $device ) {
					$default[ $device ] = self::clean( $normalized, is_array( $setting['default'] ?? null ) ? ( $setting['default'][ $device ] ?? null ) : null, $desktop );
				}
			} else {
				$default = self::clean( $normalized, $default, $fallback );
			}

			$settings[ $key ] = [ 'default' => $default ] + $normalized;
		}

		return $settings;
	}

	/**
	 * Default settings
	 *
	 * @return array
	 */
	public function defaults() {
		return wp_list_pluck( $this->settings(), 'default' );
	}

	/**
	 * Validate settings
	 *
	 * @param array $settings Raw settings
	 *
	 * @return array
	 */
	public function sanitize( array $settings ) {
		$clean = [];

		foreach ( $this->settings() as $key => $setting ) {
			$value = $settings[ $key ] ?? null;

			if ( !$setting['responsive'] ) {
				$clean[ $key ] = self::clean( $setting, $value, $setting['default'] );
				continue;
			}

			// One value (older configs, or a type that became responsive) applies to every device
			foreach ( Config::DEVICES as $device ) {
				$clean[ $key ][ $device ] = self::clean( $setting, is_array( $value ) ? ( $value[ $device ] ?? null ) : $value, $setting['default'][ $device ] );
			}
		}

		return $clean;
	}

	/**
	 * One validated value of a setting
	 *
	 * @param array $setting  Normalized setting
	 * @param mixed $value    Raw value (null = missing)
	 * @param mixed $fallback Used when the value is missing or invalid
	 *
	 * @return mixed
	 */
	private static function clean( array $setting, $value, $fallback ) {
		if ( null === $value ) {
			return $fallback;
		}

		return match ( $setting['type'] ) {
			'number' => is_numeric( $value ) ? min( $setting['max'] ?? PHP_FLOAT_MAX, max( $setting['min'] ?? -PHP_FLOAT_MAX, (float) $value ) ) : $fallback,
			'toggle' => (bool) $value,
			'select' => isset( $setting['options'][ (string) $value ] ) ? (string) $value : $fallback,
			default  => mb_substr( sanitize_text_field( (string) $value ), 0, 200 ),
		};
	}

	/**
	 * Values of the layout settings
	 *
	 * @param array $config Layout config
	 *
	 * @return array [ key => value | [ desktop, tablet, mobile ] ]
	 */
	public function script_settings( array $config ) {
		return $this->sanitize( (array) ( $config['layout'][ $this->id ] ?? [] ) );
	}

	/**
	 * Extra classes of the item at a position
	 *
	 * @param int   $index  Position
	 * @param array $config Layout config
	 *
	 * @return array
	 */
	public function item_classes( $index, array $config ) {
		$callback = $this->definition['item_classes'] ?? null;

		return is_callable( $callback ) ? array_map( 'sanitize_html_class', (array) $callback( $index, $config ) ) : [];
	}

	/**
	 * Settings as CSS variables, then the definition's own CSS
	 *
	 * @param array  $config      Layout config
	 * @param string $scope       Scope selector
	 * @param array  $breakpoints Breakpoints
	 *
	 * @return string
	 */
	public function css( array $config, $scope, array $breakpoints ) {
		$values = $this->script_settings( $config );
		$rules  = array_fill_keys( Config::DEVICES, '' );

		foreach ( $this->settings() as $key => $setting ) {
			$name = '--forma-' . str_replace( '_', '-', $key ) . ':';

			if ( !$setting['responsive'] ) {
				$rules['desktop'] .= $name . self::css_value( $setting, $values[ $key ] ) . ';';
				continue;
			}

			// Smaller devices only where they differ from the wider one
			$wider = null;

			foreach ( Config::DEVICES as $device ) {
				$value = self::css_value( $setting, $values[ $key ][ $device ] );

				if ( $value !== $wider ) {
					$rules[ $device ] .= $name . $value . ';';
				}

				$wider = $value;
			}
		}

		$css = $rules['desktop'] ? $scope . '{' . $rules['desktop'] . '}' : '';

		foreach ( array_keys( $breakpoints ) as $device ) {
			if ( $rules[ $device ] && !empty( $breakpoints[ $device ] ) ) {
				$css .= '@media (max-width:' . (int) $breakpoints[ $device ] . 'px){' . $scope . '{' . $rules[ $device ] . '}}';
			}
		}

		$callback = $this->definition['css'] ?? null;

		return $css . ( is_callable( $callback ) ? (string) $callback( $config, $scope, $breakpoints ) : '' );
	}

	/**
	 * A value as CSS: number with its unit, toggle 1 / 0, text that can't break out of the declaration
	 *
	 * @param array $setting Normalized setting
	 * @param mixed $value   Value
	 *
	 * @return string
	 */
	private static function css_value( array $setting, $value ) {
		return match ( $setting['type'] ) {
			'number' => ( floor( $value ) == $value ? (int) $value : $value ) . $setting['unit'], // phpcs:ignore Universal.Operators.StrictComparisons
			'toggle' => $value ? '1' : '0',
			default  => preg_replace( '/[^\w\s#%.,()+-]/u', '', (string) $value ),
		};
	}

	/**
	 * The theme's style.css and script.js of the type
	 *
	 * @param array $config Config
	 */
	public function enqueue( array $config ) {
		SkinManager::enqueue( $this->id, 'layouts' );
	}

	/**
	 * Editor data: description, changes to the shared fields and the settings
	 *
	 * @return array
	 */
	public function editor_data() {
		$options = fn( array $list ) => array_map( fn( $value, $label ) => [ 'value' => (string) $value, 'label' => $label ], array_keys( $list ), $list );

		return [
			'description' => $this->description,
			'fields'      => (object) $this->fields(),
			'settings'    => array_map( fn( $setting ) => [ 'options' => $options( $setting['options'] ) ] + $setting, $this->settings() ),
		];
	}
}
