<?php

namespace VLT\Forma\Layouts\Freeform;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Freeform pattern parser
 *
 * A pattern is a list of cells on a 12-column grid. Each cell is the place of one item: it takes `slot` columns of
 * the row, the item inside it is `width` of them wide and sits where `align` says. Cells fill the rows in order, a
 * new row starts when the next cell doesn't fit.
 *
 * Grammar (whitespace around cells is ignored):
 *
 *     pattern := cell ( ";" cell )* [ ";" ]
 *     cell    := slot "/" width [ " " align ]
 *     slot    := integer 1–12
 *     width   := integer 1–slot
 *     align   := vertical horizontal: t (top), m (middle), b (bottom) + l (left), c (center), r (right); default tl
 *
 * Example: "6/3 mr;6/4 tl;12/6 mc" (a half with the item 3 columns wide, middle right; a half with it 4 wide, top
 * left; the whole row with it 6 wide, in the middle)
 */
class FreeformParser {
	const COLUMNS = 12;

	const VERTICAL = [
		't' => 'start',
		'm' => 'center',
		'b' => 'end',
	];

	const HORIZONTAL = [
		'l' => 'start',
		'c' => 'center',
		'r' => 'end',
	];

	/**
	 * Parse a pattern
	 *
	 * @param string $pattern Pattern
	 *
	 * @return array|\WP_Error [ 'columns' => 12, 'tiles' => [ [ 'slot', 'width', 'align', 'justify' ] ] ]
	 */
	public static function parse( $pattern ) {
		$cells = array_filter( array_map( 'trim', explode( ';', strtolower( (string) $pattern ) ) ), 'strlen' );
		$tiles = [];

		if ( !$cells ) {
			return new \WP_Error( 'freeform_syntax', __( 'Use the format SLOT/WIDTH ALIGN;... e.g. 6/3 mr;6/4 tl.', 'forma-grid-gallery' ) );
		}

		foreach ( array_values( $cells ) as $i => $cell ) {
			if ( !preg_match( '/^(\d+)\s*\/\s*(\d+)(?:\s+([tmb])([lcr]))?$/', $cell, $match ) ) {
				/* translators: %d: cell number */
				return new \WP_Error( 'freeform_cell', sprintf( __( 'Cell %d: use SLOT/WIDTH and an optional alignment, e.g. 6/3 mr.', 'forma-grid-gallery' ), $i + 1 ) );
			}

			$slot  = (int) $match[1];
			$width = (int) $match[2];

			if ( $slot < 1 || $slot > self::COLUMNS || $width < 1 || $width > $slot ) {
				/* translators: 1: cell number, 2: columns */
				return new \WP_Error( 'freeform_size', sprintf( __( 'Cell %1$d: the slot is 1 to %2$d columns, the width 1 to the slot.', 'forma-grid-gallery' ), $i + 1, self::COLUMNS ) );
			}

			$tiles[] = [
				'slot'    => $slot,
				'width'   => $width,
				'align'   => self::VERTICAL[ $match[3] ?? 't' ] ?? 'start',
				'justify' => self::HORIZONTAL[ $match[4] ?? 'l' ] ?? 'start',
			];
		}

		return [
			'columns' => self::COLUMNS,
			'tiles'   => $tiles,
		];
	}
}
