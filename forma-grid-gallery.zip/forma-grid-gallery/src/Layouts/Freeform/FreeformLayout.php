<?php

namespace VLT\Forma\Layouts\Freeform;

use VLT\Forma\Layouts\Image;
use VLT\Forma\Layouts\Layout;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Freeform: each item sits in its own cell of a 12-column row, narrower than the cell and aligned in it, so it
 * looks scattered while keeping the gaps. The pattern repeats; mobile stacks.
 *
 *     add_filter( 'forma_freeform_patterns', fn( $patterns ) => $patterns + [
 *         'my-pattern' => [
 *             'label'          => 'My pattern',
 *             'pattern'        => '6/3 mr;6/4 tl;12/6 mc',
 *             'pattern_tablet' => '12/8 tl;12/8 tr',   // optional, per device
 *         ],
 *     ] );
 *
 * Pattern syntax: see FreeformParser.
 */
class FreeformLayout extends Layout {
	const POSITION = 45;

	const DEFAULT_PATTERN = 'scattered';

	// Pattern keys of the devices; a device without one uses the wider device's, mobile stacks
	const KEYS = [
		'desktop'          => 'pattern',
		'tablet_landscape' => 'pattern_tablet_landscape',
		'tablet'           => 'pattern_tablet',
		'mobile'           => 'pattern_mobile',
	];

	// One item under another, the whole width
	const STACK = '12/12';

	/**
	 * Parsed patterns cache
	 *
	 * @var array|null
	 */
	private $patterns = null;

	/**
	 * Get ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'freeform';
	}

	/**
	 * Get label
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Freeform', 'forma-grid-gallery' );
	}

	/**
	 * Available patterns, parsed per device
	 *
	 * @return array [ key => [ 'label', 'devices' => [ device => [ 'columns', 'tiles' ] ] ] ]
	 */
	public function get_patterns() {
		if ( null !== $this->patterns ) {
			return $this->patterns;
		}

		$built_in = [
			self::DEFAULT_PATTERN => [
				'label'          => __( 'Scattered collage', 'forma-grid-gallery' ),
				'pattern'        => '6/4 tl;6/3 br;12/6 mc;4/3 tr;8/5 bl;7/4 mr;5/4 tl',
				'pattern_tablet' => '6/5 tl;6/4 br;12/8 mc;7/6 bl;5/4 tr',
			],
			'zigzag'              => [
				'label'          => __( 'Zigzag', 'forma-grid-gallery' ),
				'pattern'        => '12/5 tl;12/4 tr;12/6 tc',
				'pattern_tablet' => '12/7 tl;12/6 tr;12/8 tc',
				'pattern_mobile' => '12/10 tl;12/10 tr',
			],
			'magazine'            => [
				'label'          => __( 'Magazine spread', 'forma-grid-gallery' ),
				'pattern'        => '8/7 tl;4/3 br;4/4 tl;8/5 mr;12/8 mc',
				'pattern_tablet' => '8/7 tl;4/4 br;12/8 mc',
			],
		];

		$this->patterns = [];

		foreach ( (array) apply_filters( 'forma_freeform_patterns', $built_in ) as $key => $pattern ) {
			$key    = sanitize_key( $key );
			$parsed = $key ? self::parse_devices( (array) $pattern ) : null;

			if ( !is_array( $parsed ) ) {
				_doing_it_wrong(
					'forma_freeform_patterns',
					/* translators: 1: pattern key, 2: error */
					esc_html( sprintf( __( 'Freeform pattern "%1$s" is skipped: %2$s', 'forma-grid-gallery' ), $key, is_wp_error( $parsed ) ? $parsed->get_error_message() : __( 'invalid key', 'forma-grid-gallery' ) ) ),
					'1.0.0'
				);
				continue;
			}

			$this->patterns[ $key ] = [
				'label'   => (string) ( $pattern['label'] ?? $key ),
				'devices' => $parsed,
			];
		}

		// The default can't be filtered away
		$this->patterns[ self::DEFAULT_PATTERN ] ??= [
			'label'   => $built_in[ self::DEFAULT_PATTERN ]['label'],
			'devices' => self::parse_devices( $built_in[ self::DEFAULT_PATTERN ] ),
		];

		return $this->patterns;
	}

	/**
	 * Parse a pattern's devices: the desktop one is required, a device without one takes the wider device's, mobile
	 * without one stacks
	 *
	 * @param array $pattern [ 'pattern' => …, 'pattern_tablet_landscape' => …, 'pattern_tablet' => …, 'pattern_mobile' => … ]
	 *
	 * @return array|\WP_Error [ device => parsed ]
	 */
	private static function parse_devices( array $pattern ) {
		$devices  = [];
		$previous = null;

		foreach ( self::KEYS as $device => $key ) {
			$source = $pattern[ $key ] ?? ( 'mobile' === $device ? self::STACK : null );

			if ( null === $source ) {
				if ( !$previous ) {
					return new \WP_Error( 'freeform_desktop', __( 'The desktop pattern is missing.', 'forma-grid-gallery' ) );
				}

				$devices[ $device ] = $previous;
				continue;
			}

			$parsed = FreeformParser::parse( $source );

			if ( is_wp_error( $parsed ) ) {
				return $parsed;
			}

			$devices[ $device ] = $previous = $parsed;
		}

		return $devices;
	}

	/**
	 * Defaults: the pattern, and the image ratio and fit (Image), the image's own ratio first
	 *
	 * @return array
	 */
	public function defaults() {
		return [ 'pattern' => self::DEFAULT_PATTERN, 'ratio' => 'auto' ] + Image::defaults();
	}

	/**
	 * Sanitize
	 *
	 * @param array $settings Settings
	 *
	 * @return array
	 */
	public function sanitize( array $settings ) {
		$pattern = (string) ( $settings['pattern'] ?? '' );

		return [ 'pattern' => isset( $this->get_patterns()[ $pattern ] ) ? $pattern : self::DEFAULT_PATTERN ] + Image::sanitize( $settings );
	}

	/**
	 * Pattern of a layout
	 *
	 * @param array $config Config
	 *
	 * @return array [ 'label', 'devices' ]
	 */
	public function get_pattern( array $config ) {
		$patterns = $this->get_patterns();

		return $patterns[ $config['layout']['freeform']['pattern'] ] ?? $patterns[ self::DEFAULT_PATTERN ];
	}

	/**
	 * Parsed pattern of each device
	 *
	 * @param array $config Config
	 *
	 * @return array [ device => parsed ]
	 */
	public function devices( array $config ) {
		return $this->get_pattern( $config )['devices'];
	}

	/**
	 * Item classes: its cell in the pattern of each device
	 *
	 * @param int   $index  Index
	 * @param array $config Config
	 *
	 * @return array
	 */
	public function item_classes( $index, array $config ) {
		$classes = [];

		foreach ( $this->devices( $config ) as $device => $pattern ) {
			$classes[] = 'forma__item--' . self::prefix( $device ) . ( $index % count( $pattern['tiles'] ) );
		}

		return $classes;
	}

	/**
	 * CSS: the image ratio and fit, the cells of each device
	 *
	 * @param array  $config      Config
	 * @param string $scope       Scope
	 * @param array  $breakpoints Breakpoints
	 *
	 * @return string
	 */
	public function css( array $config, $scope, array $breakpoints ) {
		$devices = $this->devices( $config );
		$css     = Image::css( $config['layout']['freeform'], $scope, $breakpoints ) . $this->rules( $devices['desktop'], 'desktop', $scope );

		foreach ( $breakpoints as $device => $max_width ) {
			$css .= sprintf( '@media (max-width:%dpx){%s}', $max_width, $this->rules( $devices[ $device ], $device, $scope ) );
		}

		return $css;
	}

	/**
	 * CSS of one device. Items wrap in a flex row with margins from their alignment, so nothing overflows on narrow
	 * screens the way fixed gaps of a 12-column grid would.
	 *
	 * @param array  $pattern Parsed pattern
	 * @param string $device  Device
	 * @param string $scope   Scope
	 *
	 * @return string
	 */
	private function rules( array $pattern, $device, $scope ) {
		$prefix = self::prefix( $device );
		$css    = '';

		// One column and the gap after it; the end margin gives half a pixel, so rounding never wraps a full row
		$step  = sprintf( '((100%% - %1$d * var(--forma-gap-x)) / %2$d + var(--forma-gap-x))', $pattern['columns'] - 1, $pattern['columns'] );
		$share = [
			'start'  => 0,
			'center' => .5,
			'end'    => 1,
		];

		foreach ( $pattern['tiles'] as $i => $tile ) {
			$free  = $tile['slot'] - $tile['width'];
			$start = $free * $share[ $tile['justify'] ];

			$css .= sprintf(
				'%1$s .forma__item--%2$s%3$d{width:calc(%4$s * %5$d - var(--forma-gap-x));margin-inline:calc(%4$s * %6$s) calc(%4$s * %7$s - .5px);align-self:%8$s}',
				$scope,
				$prefix,
				$i,
				$step,
				$tile['width'],
				$start,
				$free - $start,
				$tile['align']
			);
		}

		return $css;
	}

	/**
	 * Class prefix of a device
	 *
	 * @param string $device Device
	 *
	 * @return string
	 */
	private static function prefix( $device ) {
		return [
			'desktop'          => 'free-',
			'tablet_landscape' => 'free-l',
			'tablet'           => 'free-t',
			'mobile'           => 'free-m',
		][ $device ];
	}

	/**
	 * Editor data: the patterns for the picker
	 *
	 * @return array
	 */
	public function editor_data() {
		$list = [];

		foreach ( $this->get_patterns() as $key => $pattern ) {
			$list[] = [
				'value'   => $key,
				'label'   => $pattern['label'],
				'devices' => $pattern['devices'],
			];
		}

		return [ 'patterns' => $list ];
	}

	/**
	 * List detail: the pattern
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function summary( array $config ) {
		return $this->get_pattern( $config )['label'];
	}

	/**
	 * Uses columns: no, the pattern's 12-column grid
	 *
	 * @return bool
	 */
	public function uses_columns() {
		return false;
	}

	/**
	 * Sketch: the desktop pattern's items in their cells
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function sketch( array $config ) {
		$pattern = $this->get_pattern( $config )['devices']['desktop'];
		$cells   = '';

		foreach ( $pattern['tiles'] as $tile ) {
			$cells .= sprintf( '<span style="grid-column:span %d;width:%s%%;align-self:%s;justify-self:%s"></span>', $tile['slot'], round( $tile['width'] / $tile['slot'] * 100, 2 ), $tile['align'], $tile['justify'] );
		}

		return self::sketch_html( $cells, sprintf( 'grid-template-columns:repeat(%d,1fr)', $pattern['columns'] ), 'is-freeform' );
	}
}
