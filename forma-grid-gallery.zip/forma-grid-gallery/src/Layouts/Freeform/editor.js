/**
 * Freeform: one pattern for the layout, with its own arrangement per device; each item in a cell of a 12-column
 * row, narrower than it and aligned in it. The picker sketches the patterns for the device being edited.
 */
import { __ } from '@wordpress/i18n';
import { PatternGroup } from '../../../assets/src/editor/components/patterns.js';
import ImageSettings from '../../../assets/src/editor/components/image-settings.js';

const patterns = () => window.formaEditor.layoutData.freeform?.patterns || [];

/**
 * Sketch of a pattern: each item at its width and place in its cell
 */
function FreeformSketch( { pattern } ) {
	return (
		<span className="forma-editor__sketch forma-editor__sketch--freeform" style={ { gridTemplateColumns: `repeat(${ pattern.columns }, 1fr)` } } aria-hidden="true">
			{ pattern.tiles.map( ( tile, i ) => (
				<span
					key={ i }
					style={ {
						gridColumn: `span ${ tile.slot }`,
						width: `${ ( tile.width / tile.slot ) * 100 }%`,
						alignSelf: tile.align,
						justifySelf: tile.justify,
					} }
				/>
			) ) }
		</span>
	);
}

export default {
	id: 'freeform',
	Settings: ( { settings, update } ) => <ImageSettings type="freeform" values={ settings } update={ update } />,
	// The one pattern key (as desktop's), sketched as on this device
	Device: ( { settings, device, update } ) => (
		<PatternGroup
			type="freeform"
			patterns={ patterns().map( ( pattern ) => ( { ...pattern, ...pattern.devices[ device ] } ) ) }
			settings={ settings }
			device="desktop"
			update={ update }
			Sketch={ FreeformSketch }
			label={ __( 'Freeform pattern', 'forma-grid-gallery' ) }
		/>
	),
	// The pattern's 12-column grid; the gaps are the least distance between items
	fields: () => ( { columns: false } ),
};
