<?php

namespace VLT\Forma\Layouts;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Image ratio and fit for Grid, Slider and Freeform, per device ('' = the wider device's)
 */
class Image {
	/**
	 * Image ratios
	 *
	 * @var array [ value => CSS aspect-ratio ]
	 */
	const RATIOS = [
		'auto' => 'auto',
		'1:1'  => '1 / 1',
		'4:3'  => '4 / 3',
		'3:2'  => '3 / 2',
		'16:9' => '16 / 9',
		'3:4'  => '3 / 4',
		'2:3'  => '2 / 3',
	];

	/**
	 * The ratios to choose from: RATIOS and an add-on's (forma_image_ratios)
	 *
	 * @return array [ value => CSS aspect-ratio ]
	 */
	public static function choices() {
		return (array) apply_filters( 'forma_image_ratios', self::RATIOS );
	}

	/**
	 * Ratio keys of the devices below desktop
	 */
	const DEVICE_KEYS = [
		'tablet_landscape' => 'ratio_tablet_landscape',
		'tablet'           => 'ratio_tablet',
		'mobile'           => 'ratio_mobile',
	];

	/**
	 * Defaults
	 *
	 * @return array
	 */
	public static function defaults() {
		return [
			'ratio'                  => '4:3',
			'ratio_tablet_landscape' => '',
			'ratio_tablet'           => '',
			'ratio_mobile'           => '',
			'fit'                    => 'cover',
		];
	}

	/**
	 * Image ratio and fit settings
	 *
	 * @param array $settings Settings
	 *
	 * @return array [ ratio, ratio_{device} ('' = as the wider device), fit ]
	 */
	public static function sanitize( array $settings ) {
		$ratios = self::choices();
		$clean  = [ 'ratio' => isset( $ratios[ $settings['ratio'] ?? '' ] ) ? $settings['ratio'] : '4:3' ];

		foreach ( self::DEVICE_KEYS as $key ) {
			$clean[ $key ] = isset( $ratios[ $settings[ $key ] ?? '' ] ) ? $settings[ $key ] : '';
		}

		return $clean + [
			'fit' => in_array( $settings['fit'] ?? '', [ 'cover', 'contain' ], true ) ? $settings['fit'] : 'cover',
		];
	}

	/**
	 * Ratios that apply: desktop's, then each device that sets its own
	 *
	 * @param array $settings Sanitized settings (sanitize())
	 *
	 * @return array [ device => ratio key ]
	 */
	public static function ratios( array $settings ) {
		$ratios = [ 'desktop' => $settings['ratio'] ];

		foreach ( self::DEVICE_KEYS as $device => $key ) {
			if ( '' !== ( $settings[ $key ] ?? '' ) ) {
				$ratios[ $device ] = $settings[ $key ];
			}
		}

		return $ratios;
	}

	/**
	 * CSS of the image ratio and fit: the desktop's on the scope, the other devices' below their breakpoints
	 *
	 * @param array  $settings    Sanitized settings (sanitize())
	 * @param string $scope       Scope selector
	 * @param array  $breakpoints Breakpoints [ device => max width ]
	 * @param array  $values      CSS aspect-ratio of ratios over choices(), e.g. one the layout sets itself
	 *
	 * @return string
	 */
	public static function css( array $settings, $scope, array $breakpoints, array $values = [] ) {
		$values = $values + self::choices();
		$value  = fn( $ratio ) => $values[ $ratio ] ?? 'auto';
		$css    = '';

		foreach ( self::ratios( $settings ) as $device => $ratio ) {
			$css .= 'desktop' === $device
				? sprintf( '%s{--forma-ratio:%s;--forma-fit:%s}', $scope, $value( $ratio ), $settings['fit'] )
				: sprintf( '@media (max-width:%dpx){%s{--forma-ratio:%s}}', $breakpoints[ $device ], $scope, $value( $ratio ) );
		}

		return $css;
	}
}
