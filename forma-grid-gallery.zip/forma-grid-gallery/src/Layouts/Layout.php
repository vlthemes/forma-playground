<?php

namespace VLT\Forma\Layouts;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base of a layout type: what a type does not need to change
 *
 * A new type extends it and sets its ID, label, settings and CSS; the rest is a plain column grid.
 */
abstract class Layout implements LayoutInterface {
	/**
	 * Place in the list of types (LayoutRegistry)
	 */
	const POSITION = 100;

	/**
	 * Defaults
	 *
	 * @return array
	 */
	public function defaults() {
		return [];
	}

	/**
	 * Sanitize
	 *
	 * @param array $settings Settings
	 *
	 * @return array
	 */
	public function sanitize( array $settings ) {
		return [];
	}

	/**
	 * Grid classes
	 *
	 * @param array $config Config
	 *
	 * @return array
	 */
	public function classes( array $config ) {
		return [];
	}

	/**
	 * Item classes
	 *
	 * @param int   $index  Index
	 * @param array $config Config
	 *
	 * @return array
	 */
	public function item_classes( $index, array $config ) {
		return [];
	}

	/**
	 * Item style
	 *
	 * @param int   $index  Index
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function item_style( $index, array $config ) {
		return '';
	}

	/**
	 * CSS
	 *
	 * @param array  $config      Config
	 * @param string $scope       Scope
	 * @param array  $breakpoints Breakpoints
	 *
	 * @return string
	 */
	public function css( array $config, $scope, array $breakpoints ) {
		return '';
	}

	/**
	 * Script settings: the type's settings
	 *
	 * @param array $config Config
	 *
	 * @return array
	 */
	public function script_settings( array $config ) {
		return $config['layout'][ $this->get_id() ] ?? [];
	}

	/**
	 * Front-end assets
	 *
	 * @param array $config Config
	 */
	public function enqueue( array $config ) {
	}

	/**
	 * Uses columns
	 *
	 * @return bool
	 */
	public function uses_columns() {
		return true;
	}

	/**
	 * Editor data
	 *
	 * @return array
	 */
	public function editor_data() {
		return [];
	}

	/**
	 * List detail
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function summary( array $config ) {
		return '';
	}

	/**
	 * Columns per device
	 *
	 * @param array $config Config
	 *
	 * @return array
	 */
	public function columns( array $config ) {
		return $config['responsive']['columns'];
	}

	/**
	 * Sketch: two rows of the desktop columns (two to four)
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function sketch( array $config ) {
		$columns = min( 4, max( 1, (int) $config['responsive']['columns']['desktop'] ?: 3 ) );

		return self::sketch_html( str_repeat( '<span></span>', $columns * 2 ), sprintf( 'grid-template-columns:repeat(%d,1fr);grid-auto-rows:1fr;height:100%%', $columns ) );
	}

	/**
	 * Sketch markup around its cells
	 *
	 * @param string $cells Cells (escaped)
	 * @param string $style Style of the cells box
	 * @param string $class Modifier class, e.g. is-metro
	 *
	 * @return string
	 */
	protected static function sketch_html( $cells, $style = '', $class = '' ) {
		return sprintf(
			'<span class="forma-list__sketch%s" aria-hidden="true"><span class="forma-list__cells"%s>%s</span></span>',
			$class ? ' ' . esc_attr( $class ) : '',
			$style ? ' style="' . esc_attr( $style ) . '"' : '',
			$cells
		);
	}
}
