<?php

namespace VLT\Forma\Layouts;

use VLT\Forma\Front\SkinManager;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Available layout types. Themes add folders (layouts/{Name}/layout.php, see ThemeLayout); built-in IDs can't be taken.
 *
 *     add_filter( 'forma_layouts', fn( $layouts ) => $layouts + [ 'my' => new MyLayout() ] );
 */
class LayoutRegistry {
	/**
	 * Layouts cache
	 *
	 * @var LayoutInterface[]|null
	 */
	private static $layouts = null;

	/**
	 * Get all layouts
	 *
	 * @return LayoutInterface[] [ id => layout ]
	 */
	public static function all() {
		if ( null !== self::$layouts ) {
			return self::$layouts;
		}

		$layouts = self::discover();

		// Theme layout types: registered with forma_layouts_styles, files in layouts/{id}/layout.php
		foreach ( SkinManager::styles( 'layouts' ) as $id => $label ) {
			if ( !isset( $layouts[ $id ] ) && SkinManager::locate( $id, 'template', 'layouts' ) ) {
				$layouts[ $id ] = new ThemeLayout( $id, $label );
			}
		}

		$layouts = array_filter( (array) apply_filters( 'forma_layouts', $layouts ), fn( $layout ) => $layout instanceof LayoutInterface );

		// Theme folders are only known once the theme is set up
		if ( did_action( 'after_setup_theme' ) ) {
			self::$layouts = $layouts;
		}

		return $layouts;
	}

	/**
	 * Get a layout
	 *
	 * @param string $id Layout ID
	 *
	 * @return LayoutInterface|null
	 */
	public static function get( $id ) {
		return self::all()[ $id ] ?? null;
	}

	/**
	 * The layout types of the plugin: every Layouts/{Name}/{Name}Layout.php, in their POSITION order
	 *
	 * @return array [ id => LayoutInterface ]
	 */
	private static function discover() {
		$found = [];

		foreach ( glob( __DIR__ . '/*/*Layout.php' ) ?: [] as $file ) {
			$name  = basename( dirname( $file ) );
			$class = __NAMESPACE__ . '\\' . $name . '\\' . $name . 'Layout';

			if ( basename( $file ) === $name . 'Layout.php' && is_subclass_of( $class, Layout::class ) && !( new \ReflectionClass( $class ) )->isAbstract() ) {
				$found[] = new $class();
			}
		}

		usort( $found, fn( $a, $b ) => $a::POSITION <=> $b::POSITION );

		$layouts = [];

		foreach ( $found as $layout ) {
			$layouts[ $layout->get_id() ] = $layout;
		}

		return $layouts;
	}
}
