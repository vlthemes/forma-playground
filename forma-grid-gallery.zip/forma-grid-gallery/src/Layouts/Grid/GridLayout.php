<?php

namespace VLT\Forma\Layouts\Grid;

use VLT\Forma\Layouts\Image;
use VLT\Forma\Layouts\Layout;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Grid: equal cells, columns per breakpoint (shared responsive settings)
 *
 * Image ratio and fit are handed to the theme's skin as CSS variables (Image); the card markup itself is the theme's.
 */
class GridLayout extends Layout {
	const POSITION = 10;

	/**
	 * Get ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'grid';
	}

	/**
	 * Get label
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Grid', 'forma-grid-gallery' );
	}

	/**
	 * Defaults
	 *
	 * @return array
	 */
	public function defaults() {
		return Image::defaults();
	}

	/**
	 * Sanitize
	 *
	 * @param array $settings Settings
	 *
	 * @return array
	 */
	public function sanitize( array $settings ) {
		return Image::sanitize( $settings );
	}

	/**
	 * CSS
	 *
	 * @param array  $config      Config
	 * @param string $scope       Scope
	 * @param array  $breakpoints Breakpoints
	 *
	 * @return string
	 */
	public function css( array $config, $scope, array $breakpoints ) {
		return Image::css( $config['layout']['grid'], $scope, $breakpoints );
	}

	/**
	 * List detail: the image ratio
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function summary( array $config ) {
		return 'auto' === $config['layout']['grid']['ratio'] ? __( 'original ratio', 'forma-grid-gallery' ) : $config['layout']['grid']['ratio'];
	}
}
