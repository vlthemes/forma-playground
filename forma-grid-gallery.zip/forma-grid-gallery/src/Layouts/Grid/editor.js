/**
 * Grid: the image ratio and fit
 */
import ImageSettings from '../../../assets/src/editor/components/image-settings.js';

export default {
	id: 'grid',
	Settings: ( { settings, update } ) => <ImageSettings type="grid" values={ settings } update={ update } />,
};
