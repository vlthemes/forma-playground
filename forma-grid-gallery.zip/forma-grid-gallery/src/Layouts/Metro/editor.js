/**
 * Metro: a pattern per device; a device with its own pattern uses that pattern's columns
 */
import { __ } from '@wordpress/i18n';
import { PatternGroup, ownColumns } from '../../../assets/src/editor/components/patterns.js';
import Group from '../../../assets/src/editor/group.js';
import { Select } from '../../../assets/src/editor/components/controls.js';

const patterns = () => window.formaEditor.layoutData.metro?.patterns || [];

/**
 * Pattern sketch at real proportions (container query units, as on the site)
 */
function MetroSketch( { pattern } ) {
	// Area of one round of the pattern, in column widths squared (a tile's rows are 1/100 of a column width): repeated
	// until it is as tall as it is wide, more than the card shows, so it fills the card
	const area = pattern.tiles.reduce( ( sum, tile ) => sum + ( tile.width * tile.rows ) / 100, 0 );
	const repeat = Math.max( 2, Math.ceil( ( pattern.columns * pattern.columns ) / Math.max( area, .01 ) ) + 1 );
	const tiles = Array.from( { length: repeat }, () => pattern.tiles ).flat();
	const columns = pattern.columns;

	return (
		<span
			className="forma-editor__sketch"
			style={ {
				gridTemplateColumns: `repeat(${ columns }, 1fr)`,
				gridAutoRows: `calc(100cqw / ${ columns } / 100)`,
			} }
			aria-hidden="true"
		>
			{ tiles.map( ( tile, i ) => (
				<span key={ i } style={ { gridColumn: `span ${ tile.width }`, gridRow: `span ${ tile.rows }` } } />
			) ) }
		</span>
	);
}

export default {
	id: 'metro',
	description: __( 'Wide, tall and small tiles in a pattern that repeats down the grid. Pick a pattern for each device; smaller devices take the wider one\'s until they have their own.', 'forma-grid-gallery' ),
	Settings: () => (
		<Group title={ __( 'Settings', 'forma-grid-gallery' ) }>
			<Select
				label={ __( 'Tile size', 'forma-grid-gallery' ) }
				help={ __( 'Image: the image is the tile, the card\'s text goes under it. Whole card: the card fills the tile, the image takes the height its text leaves.', 'forma-grid-gallery' ) }
				path="layout.metro.tile"
				options={ [
					{ value: 'image', label: __( 'Image', 'forma-grid-gallery' ) },
					{ value: 'card', label: __( 'Whole card', 'forma-grid-gallery' ) },
				] }
			/>
		</Group>
	),
	Device: ( { settings, device, update } ) => (
		<PatternGroup type="metro" patterns={ patterns() } settings={ settings } device={ device } update={ update } Sketch={ MetroSketch } label={ __( 'Metro pattern', 'forma-grid-gallery' ) } />
	),
	fields: ( layout, device ) => {
		const columns = ownColumns( patterns(), layout.metro, device );

		return columns ? { columns: { fixed: columns, disabled: true, help: __( 'Set by the Metro pattern.', 'forma-grid-gallery' ) } } : {};
	},
};
