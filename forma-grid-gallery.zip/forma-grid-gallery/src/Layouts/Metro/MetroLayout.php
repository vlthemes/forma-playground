<?php

namespace VLT\Forma\Layouts\Metro;

use VLT\Forma\Core\Config;
use VLT\Forma\Layouts\Layout;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Metro: a repeating pattern of differently sized tiles. No "dense" packing, so items stay in query order.
 *
 *     add_filter( 'forma_metro_patterns', fn( $patterns ) => $patterns + [
 *         'my-pattern' => [ 'label' => 'My pattern', 'pattern' => '4|2,2;1,1;1,1;2,1' ],
 *     ] );
 *
 * Pattern syntax: see MetroParser.
 */
class MetroLayout extends Layout {
	const POSITION = 20;

	const DEFAULT_PATTERN = 'classic';

	/**
	 * Parsed patterns cache
	 *
	 * @var array|null
	 */
	private $patterns = null;

	/**
	 * Get ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'metro';
	}

	/**
	 * Get label
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Metro', 'forma-grid-gallery' );
	}

	/**
	 * Available patterns, parsed
	 *
	 * @return array [ key => [ 'label', 'pattern', 'columns', 'tiles' ] ]
	 */
	public function get_patterns() {
		if ( null !== $this->patterns ) {
			return $this->patterns;
		}

		$patterns = (array) apply_filters( 'forma_metro_patterns', [
			'classic'     => [
				'label'   => __( 'Classic: wide + two stacked', 'forma-grid-gallery' ),
				'pattern' => '3|2,1;1,.5;1,.5',
			],
			'mosaic'      => [
				'label'   => __( 'Mosaic: big square + four', 'forma-grid-gallery' ),
				'pattern' => '4|2,2;1,1;1,1;1,1;1,1',
			],
			'tall'        => [
				'label'   => __( 'Tall + wide', 'forma-grid-gallery' ),
				'pattern' => '3|1,2;2,1;1,1;1,1',
			],
			'bricks'      => [
				'label'   => __( 'Bricks', 'forma-grid-gallery' ),
				'pattern' => '4|2,1;1,1;1,1;1,1;1,1;2,1',
			],
			'feature'     => [
				'label'   => __( 'Feature row + two', 'forma-grid-gallery' ),
				'pattern' => '2|2,1;1,1;1,1',
			],
			'bento'       => [
				'label'   => __( 'Bento: big square in the middle', 'forma-grid-gallery' ),
				'pattern' => '3|1,1;2,2;1,1;2,1;1,1',
			],
			'bento-4'     => [
				'label'   => __( 'Bento, four columns', 'forma-grid-gallery' ),
				'pattern' => '4|1,1;1,1;2,2;1,1;1,1;2,2;1,1;1,1;1,1;1,1',
			],
			'magazine'    => [
				'label'   => __( 'Magazine: big and wide, alternating', 'forma-grid-gallery' ),
				'pattern' => '4|2,2;2,1;2,1;2,1;2,2;2,1',
			],
			'editorial'   => [
				'label'   => __( 'Editorial: tall in the middle, wide below', 'forma-grid-gallery' ),
				'pattern' => '3|1,1;1,2;1,1;1,1;1,1;1,1;2,1',
			],
			'staggered'   => [
				'label'   => __( 'Staggered: tall and short', 'forma-grid-gallery' ),
				'pattern' => '3|1,1.4;1,1;1,1.4;1,1;1,1.4;1,1',
			],
			'staggered-2' => [
				'label'   => __( 'Staggered, two columns', 'forma-grid-gallery' ),
				'pattern' => '2|1,1.4;1,1;1,1;1,1.4',
			],
		] );

		$this->patterns = [];

		foreach ( $patterns as $key => $pattern ) {
			$key    = sanitize_key( $key );
			$parsed = $key ? MetroParser::parse( $pattern['pattern'] ?? '' ) : null;

			if ( !is_array( $parsed ) ) {
				_doing_it_wrong(
					'forma_metro_patterns',
					/* translators: 1: pattern key, 2: error */
					esc_html( sprintf( __( 'Metro pattern "%1$s" is skipped: %2$s', 'forma-grid-gallery' ), $key, is_wp_error( $parsed ) ? $parsed->get_error_message() : __( 'invalid key', 'forma-grid-gallery' ) ) ),
					'1.0.0'
				);
				continue;
			}

			$this->patterns[ $key ] = [
				'label'   => (string) ( $pattern['label'] ?? $key ),
				'pattern' => $pattern['pattern'],
			] + $parsed;
		}

		// The default can't be filtered away
		$this->patterns[ self::DEFAULT_PATTERN ] ??= [
			'label'   => __( 'Classic: wide + two stacked', 'forma-grid-gallery' ),
			'pattern' => '3|2,1;1,.5;1,.5',
		] + MetroParser::parse( '3|2,1;1,.5;1,.5' );

		return $this->patterns;
	}

	/**
	 * Defaults; the empty patterns of the smaller devices inherit
	 *
	 * @return array
	 */
	public function defaults() {
		return [
			'pattern'                  => self::DEFAULT_PATTERN,
			'pattern_tablet_landscape' => '',
			'pattern_tablet'           => '',
			'pattern_mobile'           => '',
			// What the tile sizes: the image (the card's text under it) or the whole card
			'tile'                     => 'image',
		];
	}

	/**
	 * Sanitize
	 *
	 * @param array $settings Settings
	 *
	 * @return array
	 */
	public function sanitize( array $settings ) {
		$patterns = $this->get_patterns();
		$key      = fn( $name, $fallback ) => isset( $patterns[ (string) ( $settings[ $name ] ?? '' ) ] ) ? (string) $settings[ $name ] : $fallback;

		return [
			'pattern'                  => $key( 'pattern', self::DEFAULT_PATTERN ),
			'pattern_tablet_landscape' => $key( 'pattern_tablet_landscape', '' ),
			'pattern_tablet'           => $key( 'pattern_tablet', '' ),
			'pattern_mobile'           => $key( 'pattern_mobile', '' ),
			'tile'                     => 'card' === ( $settings['tile'] ?? '' ) ? 'card' : 'image',
		];
	}

	/**
	 * Parsed desktop pattern of a layout
	 *
	 * @param array $config Config
	 *
	 * @return array [ 'columns', 'tiles', … ]
	 */
	public function get_pattern( array $config ) {
		$patterns = $this->get_patterns();

		return $patterns[ $config['layout']['metro']['pattern'] ] ?? $patterns[ self::DEFAULT_PATTERN ];
	}

	/**
	 * Pattern and columns per device. Without its own pattern a device narrows the wider one's.
	 *
	 * @param array $config Config
	 *
	 * @return array [ device (Config::DEVICES) => [ 'pattern' => parsed, 'columns' => int, 'own' => bool ] ]
	 */
	public function devices( array $config ) {
		$patterns = $this->get_patterns();
		$settings = $config['layout']['metro'];
		$desktop  = $this->get_pattern( $config );
		$devices  = [
			'desktop' => [
				'pattern' => $desktop,
				'columns' => $desktop['columns'],
				'own'     => true,
			],
		];

		$previous = $devices['desktop'];

		$limits = Config::inherit( $config['responsive']['columns'] );

		foreach ( array_slice( Config::DEVICES, 1 ) as $device ) {
			$own = $settings[ 'pattern_' . $device ] ?? '';

			$devices[ $device ] = isset( $patterns[ $own ] )
				? [
					'pattern' => $patterns[ $own ],
					'columns' => $patterns[ $own ]['columns'],
					'own'     => true,
				]
				: [
					'pattern' => $previous['pattern'],
					'columns' => min( $previous['columns'], $limits[ $device ] ),
					'own'     => false,
				];

			$previous = $devices[ $device ];
		}

		return $devices;
	}

	/**
	 * Grid classes: the whole card as the tile
	 *
	 * @param array $config Config
	 *
	 * @return array
	 */
	public function classes( array $config ) {
		return 'card' === ( $config['layout']['metro']['tile'] ?? '' ) ? [ 'forma--metro-card' ] : [];
	}

	/**
	 * Item classes: the item's tile on each device (patterns may have different lengths)
	 *
	 * @param int   $index  Index
	 * @param array $config Config
	 *
	 * @return array
	 */
	public function item_classes( $index, array $config ) {
		$classes = [];

		foreach ( $this->devices( $config ) as $device => $use ) {
			$classes[] = 'forma__item--' . self::prefix( $device ) . ( $index % count( $use['pattern']['tiles'] ) );
		}

		return $classes;
	}

	/**
	 * Columns and tile spans per device
	 *
	 * @param array  $config      Config
	 * @param string $scope       Scope
	 * @param array  $breakpoints Breakpoints
	 *
	 * @return string
	 */
	public function css( array $config, $scope, array $breakpoints ) {
		$devices = $this->devices( $config );
		$css     = $this->rules( $devices['desktop'], 'desktop', $scope );

		foreach ( $breakpoints as $device => $max_width ) {
			$css .= sprintf( '@media (max-width:%dpx){%s}', $max_width, $this->rules( $devices[ $device ], $device, $scope ) );
		}

		return $css;
	}

	/**
	 * Column count and tile spans of one device
	 *
	 * @param array  $use    [ 'pattern', 'columns' ]
	 * @param string $device Device
	 * @param string $scope  Scope
	 *
	 * @return string
	 */
	private function rules( array $use, $device, $scope ) {
		$css = sprintf( '%s .forma__items{--forma-cols:%d}', $scope, $use['columns'] );

		foreach ( $use['pattern']['tiles'] as $i => $tile ) {
			$css .= sprintf( '%s .forma__item--%s%d{grid-column:span %d;grid-row:span %d;--forma-tile-rows:%d}', $scope, self::prefix( $device ), $i, min( $tile['width'], $use['columns'] ), $tile['rows'], $tile['rows'] );
		}

		return $css;
	}

	/**
	 * Tile class prefix: tile-3, tile-l3, tile-t3, tile-m3
	 *
	 * @param string $device Device
	 *
	 * @return string
	 */
	private static function prefix( $device ) {
		return [
			'desktop'          => 'tile-',
			'tablet_landscape' => 'tile-l',
			'tablet'           => 'tile-t',
			'mobile'           => 'tile-m',
		][ $device ];
	}

	/**
	 * Editor data: the patterns for the picker
	 *
	 * @return array
	 */
	public function editor_data() {
		$list = [];

		foreach ( $this->get_patterns() as $key => $pattern ) {
			$list[] = [
				'value'   => $key,
				'label'   => $pattern['label'],
				'columns' => $pattern['columns'],
				'tiles'   => $pattern['tiles'],
			];
		}

		return [ 'patterns' => $list ];
	}

	/**
	 * List detail: the desktop pattern
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function summary( array $config ) {
		return $this->get_pattern( $config )['label'];
	}

	/**
	 * Columns per device: the patterns' (see devices())
	 *
	 * @param array $config Config
	 *
	 * @return array
	 */
	public function columns( array $config ) {
		return array_map( fn( $use ) => $use['columns'], $this->devices( $config ) );
	}

	/**
	 * Sketch: the desktop pattern, repeated until it is as tall as it is wide (more than the box shows), so it fills
	 * the box; the gaps are the tiles' borders, the same across and down (grid-list.scss)
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function sketch( array $config ) {
		$pattern = $this->get_pattern( $config );
		$columns = $pattern['columns'];
		// Area of one round, in column widths squared (a tile's rows are 1/100 of a column width)
		$area    = array_sum( array_map( fn( $tile ) => $tile['width'] * $tile['rows'] / 100, $pattern['tiles'] ) );
		$repeat  = max( 2, (int) ceil( $columns * $columns / max( $area, .01 ) ) + 1 );
		$cells   = '';

		for ( $r = 0; $r < $repeat; $r++ ) {
			foreach ( $pattern['tiles'] as $tile ) {
				$cells .= sprintf( '<span style="grid-column:span %d;grid-row:span %d"></span>', $tile['width'], $tile['rows'] );
			}
		}

		return self::sketch_html( $cells, sprintf( 'grid-template-columns:repeat(%1$d,1fr);grid-auto-rows:calc(100cqw / %1$d / 100)', $columns ), 'is-metro' );
	}
}
