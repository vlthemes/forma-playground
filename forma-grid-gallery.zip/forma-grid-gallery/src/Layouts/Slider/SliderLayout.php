<?php

namespace VLT\Forma\Layouts\Slider;

use VLT\Forma\Core\Assets;
use VLT\Forma\Layouts\Image;
use VLT\Forma\Layouts\Layout;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Slider (Swiper, grid-slider.js). Uses the theme's "swiper" when one is registered, else the plugin's copy.
 * Columns are the slides in view; item height can be auto, fixed or a share of the slide width.
 */
class SliderLayout extends Layout {
	const POSITION = 50;

	/**
	 * Get ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'slider';
	}

	/**
	 * Get label
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Slider', 'forma-grid-gallery' );
	}

	/**
	 * Defaults
	 *
	 * @return array
	 */
	public function defaults() {
		return Image::defaults() + [
			'arrows'             => true,
			'dots'               => true,
			'loop'               => false,
			'centered'           => false,
			'effect'             => 'slide',
			'free_scroll'        => false,
			'free_scroll_sticky' => false,
			'height'             => 'dynamic',
			'height_static'      => 300,
			'height_dynamic'     => 80,
			'min_height'         => '',
			'autoplay'           => false,
			'pause_on_hover'     => false,
			'delay'              => 5000,
			'speed'              => 500,
		];
	}

	/**
	 * Sanitize
	 *
	 * @param array $settings Settings
	 *
	 * @return array
	 */
	public function sanitize( array $settings ) {
		$defaults = $this->defaults();
		$number   = fn( $key, $min, $max ) => min( $max, max( $min, (int) ( $settings[ $key ] ?? $defaults[ $key ] ) ) );

		$toggle   = fn( $key ) => (bool) ( $settings[ $key ] ?? $defaults[ $key ] );

		return Image::sanitize( $settings ) + [
			'arrows'             => $toggle( 'arrows' ),
			'dots'               => $toggle( 'dots' ),
			'loop'               => $toggle( 'loop' ),
			'centered'           => $toggle( 'centered' ),
			'effect'             => in_array( $settings['effect'] ?? '', [ 'slide', 'coverflow', 'fade' ], true ) ? $settings['effect'] : $defaults['effect'],
			'free_scroll'        => $toggle( 'free_scroll' ),
			'free_scroll_sticky' => $toggle( 'free_scroll_sticky' ),
			'height'             => in_array( $settings['height'] ?? '', [ 'auto', 'static', 'dynamic' ], true ) ? $settings['height'] : $defaults['height'],
			'height_static'      => $number( 'height_static', 30, 800 ),
			'height_dynamic'     => $number( 'height_dynamic', 10, 300 ),
			'min_height'         => self::length( $settings['min_height'] ?? '' ),
			'autoplay'           => $toggle( 'autoplay' ),
			'pause_on_hover'     => $toggle( 'pause_on_hover' ),
			'delay'              => $number( 'delay', 1000, 30000 ),
			'speed'              => $number( 'speed', 100, 3000 ),
		];
	}


	/**
	 * CSS
	 *
	 * @param array  $config      Config
	 * @param string $scope       Scope
	 * @param array  $breakpoints Breakpoints
	 *
	 * @return string
	 */
	public function css( array $config, $scope, array $breakpoints ) {
		$settings = $config['layout']['slider'];
		$css      = Image::css( $settings, $scope, $breakpoints );

		// Fade shows one slide at a time; auto columns: slides as wide as their content, as many as fit
		if ( 'fade' === $settings['effect'] ) {
			$css .= sprintf( '%s .forma__item{width:100%%}', $scope );
		} elseif ( in_array( 'auto', $config['responsive']['columns'], true ) ) {
			$css .= self::auto_widths( $config['responsive']['columns'], $scope, $breakpoints );
		}

		if ( 'auto' === $settings['height'] ) {
			return $css;
		}

		// Dynamic: the height is a share of the slide width, as a ratio
		$height = 'static' === $settings['height']
			? sprintf( 'height:%dpx;aspect-ratio:auto', $settings['height_static'] )
			: sprintf( 'aspect-ratio:100/%d', $settings['height_dynamic'] );

		if ( '' !== $settings['min_height'] ) {
			$height .= ';min-height:' . $settings['min_height'];
		}

		return $css . sprintf( '%s .forma__media{%s}', $scope, $height );
	}

	/**
	 * Swiper and the script that sets it up
	 *
	 * @param array $config Config
	 */
	public function enqueue( array $config ) {
		Assets::enqueue( 'forma-slider' );
	}

	/**
	 * List detail: the effect
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function summary( array $config ) {
		return [
			'slide'     => __( 'slide', 'forma-grid-gallery' ),
			'coverflow' => __( 'coverflow', 'forma-grid-gallery' ),
			'fade'      => __( 'fade', 'forma-grid-gallery' ),
		][ $config['layout']['slider']['effect'] ] ?? '';
	}

	/**
	 * Sketch: one row of slides, the last one cut
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function sketch( array $config ) {
		$columns = (int) $config['responsive']['columns']['desktop'] ?: 3;
		$columns = 'fade' === $config['layout']['slider']['effect'] ? 1 : min( 4, max( 1, $columns ) );

		return self::sketch_html( str_repeat( '<span></span>', $columns + 1 ), sprintf( 'grid-template-columns:repeat(%d,1fr) .4fr;height:100%%', $columns ), 'is-slider' );
	}

	/**
	 * Slide widths of the devices with auto columns, and back to the columns on the ones without
	 *
	 * @param array  $columns     Columns per device (resolved)
	 * @param string $scope       Scope
	 * @param array  $breakpoints [ device => max width ]
	 *
	 * @return string
	 */
	private static function auto_widths( array $columns, $scope, array $breakpoints ) {
		$rules = fn( $auto ) => $auto
			? sprintf( '%1$s .forma__item{width:auto}%1$s .forma__media img{width:auto;max-width:none}', $scope )
			: sprintf( '%1$s .forma__item{width:calc((100%% - (var(--forma-cols) - 1) * var(--forma-gap-x)) / var(--forma-cols))}%1$s .forma__media img{width:100%%;max-width:100%%}', $scope );

		$css = $rules( 'auto' === $columns['desktop'] );

		foreach ( $breakpoints as $device => $max_width ) {
			$css .= sprintf( '@media (max-width:%dpx){%s}', $max_width, $rules( 'auto' === $columns[ $device ] ) );
		}

		return $css;
	}

	/**
	 * A CSS length (number and unit) or clamp() / min() / max() / calc() of lengths, '' otherwise
	 *
	 * @param string $value Value
	 *
	 * @return string
	 */
	private static function length( $value ) {
		$value = strtolower( trim( (string) $value ) );

		return preg_match( '/^\d+(\.\d+)?(px|vh|svh|dvh|lvh|vw|vmin|vmax|em|rem|%)$/', $value ) || preg_match( '/^(clamp|min|max|calc)\([a-z0-9%.,+*\/\s()-]+\)$/', $value ) ? $value : '';
	}
}
