/**
 * Slider: effect and motion, navigation, autoplay, the image and the items height; slides in view are the columns
 * (Auto: as wide as their content), the space between them the horizontal gap
 */
import { __ } from '@wordpress/i18n';
import Group from '../../../assets/src/editor/group.js';
import ImageSettings from '../../../assets/src/editor/components/image-settings.js';
import { Select, Toggle } from '../../../assets/src/editor/components/controls.js';
import ValueControl from '../../../assets/src/editor/components/value-control.js';

/**
 * Slider: effect and motion, navigation, autoplay; slides in view and the space between them are the columns and gap
 */
function SliderSettings( { slider } ) {

	return (
		<>
			<Group title={ __( 'Slider', 'forma-grid-gallery' ) }>
				<div className="forma-editor__row is-2">
					<Select
					label={ __( 'Effect', 'forma-grid-gallery' ) }
					help={ __( 'Coverflow turns the slides around the one in the middle; fade shows one slide at a time.', 'forma-grid-gallery' ) }
					path="layout.slider.effect"
					options={ [
						{ value: 'slide', label: __( 'Slide', 'forma-grid-gallery' ) },
						{ value: 'coverflow', label: __( 'Coverflow', 'forma-grid-gallery' ) },
						{ value: 'fade', label: __( 'Fade', 'forma-grid-gallery' ) },
					] }
					__nextHasNoMarginBottom
					/>
					<ValueControl numeric units={ [ 'ms', 's' ] } min={ 100 } max={ 3000 } step={ 50 } label={ __( 'Speed', 'forma-grid-gallery' ) } path="layout.slider.speed" />
				</div>
				{ 'slide' === slider.effect && (
					<Toggle label={ __( 'Centered slides', 'forma-grid-gallery' ) } path="layout.slider.centered" />
				) }
				<Toggle label={ __( 'Loop', 'forma-grid-gallery' ) } help={ __( 'After the last slide comes the first one.', 'forma-grid-gallery' ) } path="layout.slider.loop" />
			</Group>

			<Group title={ __( 'Navigation', 'forma-grid-gallery' ) }>
				<div className="forma-editor__row is-2">
					<Toggle label={ __( 'Arrows', 'forma-grid-gallery' ) } path="layout.slider.arrows" />
					<Toggle label={ __( 'Dots', 'forma-grid-gallery' ) } path="layout.slider.dots" />
				</div>
				<Toggle label={ __( 'Free scroll', 'forma-grid-gallery' ) } help={ __( 'Slides do not snap to positions.', 'forma-grid-gallery' ) } path="layout.slider.free_scroll" />
				{ slider.free_scroll && (
					<Toggle label={ __( 'Free scroll sticky', 'forma-grid-gallery' ) } help={ __( 'Snaps to the nearest slide when the movement ends.', 'forma-grid-gallery' ) } path="layout.slider.free_scroll_sticky" />
				) }
			</Group>

			<Group title={ __( 'Autoplay', 'forma-grid-gallery' ) }>
				<Toggle label={ __( 'Autoplay', 'forma-grid-gallery' ) } path="layout.slider.autoplay" />
				{ slider.autoplay && (
					<>
					<ValueControl numeric units={ [ 'ms', 's' ] } min={ 1000 } max={ 30000 } step={ 500 } label={ __( 'Delay', 'forma-grid-gallery' ) } path="layout.slider.delay" />
					<Toggle label={ __( 'Pause on mouse over', 'forma-grid-gallery' ) } path="layout.slider.pause_on_hover" />
					</>
				) }
			</Group>
		</>
	);
}

/**
 * Slider items height: the image ratio (auto), a fixed one or a share of the slide width, with a minimal height
 */
function SliderHeight( { slider } ) {
	return (
		<Group title={ __( 'Items height', 'forma-grid-gallery' ) }>
			<Select
				label={ __( 'Sizing', 'forma-grid-gallery' ) }
				help={ { auto: __( 'Uses the image ratio.', 'forma-grid-gallery' ), static: __( 'A fixed height.', 'forma-grid-gallery' ), dynamic: __( 'A share of the slide width, so the height scales with the screen.', 'forma-grid-gallery' ) }[ slider.height ] }
				path="layout.slider.height"
				options={ [
					{ value: 'auto', label: __( 'Auto', 'forma-grid-gallery' ) },
					{ value: 'static', label: __( 'Static (px)', 'forma-grid-gallery' ) },
					{ value: 'dynamic', label: __( 'Dynamic (%)', 'forma-grid-gallery' ) },
				] }
			/>
			{ 'auto' !== slider.height && (
				<div className="forma-editor__row">
					{ /* A key each: switching Sizing builds a new field with its own unit */ }
					{ 'static' === slider.height ? (
						<ValueControl key="static" numeric units={ [ 'px' ] } min={ 30 } max={ 800 } step={ 10 } label={ __( 'Height', 'forma-grid-gallery' ) } path="layout.slider.height_static" />
					) : (
						<ValueControl key="dynamic" numeric units={ [ '%' ] } min={ 10 } max={ 300 } step={ 5 } label={ __( 'Height', 'forma-grid-gallery' ) } path="layout.slider.height_dynamic" />
					) }
					<ValueControl label={ __( 'Minimal height', 'forma-grid-gallery' ) } help={ __( '100vh makes a full-screen slider. Heights in vh do not show in the editor preview.', 'forma-grid-gallery' ) } path="layout.slider.min_height" units={ [ 'px', 'vh', 'svh', 'dvh', 'vw', '%', 'em', 'rem' ] } functions={ [ 'clamp', 'min', 'max', 'calc' ] } min={ 0 } placeholder="300" />
				</div>
			) }
		</Group>
	);
}

export default {
	id: 'slider',
	Settings: ( { settings, update } ) => (
		<>
			<SliderSettings slider={ settings } />
			{ /* The static and dynamic heights take the ratio's place */ }
			<ImageSettings type="slider" values={ settings } update={ update } ratioDisabled={ 'auto' !== settings.height } />
			<SliderHeight slider={ settings } />
		</>
	),
	fields: ( layout ) => ( {
		// One row
		gap_y: { disabled: true },
		// Fade shows one slide; Auto is Swiper's slidesPerView 'auto'
		columns: 'fade' === layout.slider?.effect ? false : { auto: true },
	} ),
};
