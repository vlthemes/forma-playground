/**
 * Justified: the last row; per device the row height (rows decide, not columns)
 */
import { __ } from '@wordpress/i18n';
import Group from '../../../assets/src/editor/group.js';
import { DeviceNumber } from '../../../assets/src/editor/components/device-fields.js';
import { DEVICES } from '../../../assets/src/editor/device.js';
import { Toggle } from '../../../assets/src/editor/components/controls.js';

/**
 * Justified row height of one device (one number saved by older configs applies to every device)
 */
function JustifiedRowHeight( { justified, device, update } ) {
	const raw = justified?.row_height;
	const heights = raw && 'object' === typeof raw ? raw : Object.fromEntries( DEVICES.map( ( item ) => [ item.value, raw ?? null ] ) );

	return (
		<Group title={ __( 'Row height', 'forma-grid-gallery' ) }>
			<DeviceNumber
				label={ __( 'Height', 'forma-grid-gallery' ) }
				path="layout.justified.row_height"
				help={ __( 'Every row has this height; items keep their image proportions.', 'forma-grid-gallery' ) }
				values={ { desktop: 260, ...heights } }
				device={ device }
				min={ 60 }
				max={ 800 }
				fallback={ 260 }
				onChange={ ( next ) => update( 'layout.justified.row_height', next ) }
			/>
		</Group>
	);
}

export default {
	id: 'justified',
	Settings: ( { settings, update } ) => (
		<Group title={ __( 'Settings', 'forma-grid-gallery' ) }>
			<Toggle
				label={ __( 'Stretch the last row', 'forma-grid-gallery' ) }
				help={ __( 'Off: the last row keeps the row height and starts on the left.', 'forma-grid-gallery' ) }
				checked={ !! settings?.stretch_last }
				onChange={ ( value ) => update( 'layout.justified.stretch_last', value ) }
				__nextHasNoMarginBottom
			/>
		</Group>
	),
	Device: ( { settings, device, update } ) => <JustifiedRowHeight justified={ settings } device={ device } update={ update } />,
	fields: () => ( { columns: false } ),
};
