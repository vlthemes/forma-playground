<?php

namespace VLT\Forma\Layouts\Justified;

use VLT\Forma\Core\Config;
use VLT\Forma\Layouts\Layout;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Justified: rows of one height with images in their own proportions, CSS only. Each item carries its ratio
 * (--vlt-ratio), so rows are laid out before images load.
 */
class JustifiedLayout extends Layout {
	const POSITION = 40;

	const MIN_HEIGHT = 60;
	const MAX_HEIGHT = 800;

	/**
	 * Get ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'justified';
	}

	/**
	 * Get label
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Justified', 'forma-grid-gallery' );
	}

	/**
	 * Defaults
	 *
	 * @return array
	 */
	public function defaults() {
		return [
			// Tablet landscape null: the desktop's height
			'row_height'   => [
				'desktop'          => 260,
				'tablet_landscape' => null,
				'tablet'           => 200,
				'mobile'           => 150,
			],
			'stretch_last' => false,
		];
	}

	/**
	 * Sanitize, one number (older configs) applies to every device
	 *
	 * @param array $settings Settings
	 *
	 * @return array
	 */
	public function sanitize( array $settings ) {
		$defaults = $this->defaults();
		$raw      = $settings['row_height'] ?? null;
		$heights  = [];

		foreach ( Config::DEVICES as $device ) {
			$value              = is_array( $raw ) ? ( $raw[ $device ] ?? null ) : $raw;
			$heights[ $device ] = is_numeric( $value ) ? max( self::MIN_HEIGHT, min( self::MAX_HEIGHT, (int) $value ) ) : $defaults['row_height'][ $device ];
		}

		return [
			'row_height'   => $heights,
			'stretch_last' => !empty( $settings['stretch_last'] ),
		];
	}

	/**
	 * Row heights per device
	 *
	 * @param array $config Layout config
	 *
	 * @return array [ device => px ] (Config::DEVICES), every device filled
	 */
	public function row_heights( array $config ) {
		return Config::inherit( $this->sanitize( (array) ( $config['layout']['justified'] ?? [] ) )['row_height'] );
	}

	/**
	 * Row height per device and the last-row behavior as variables
	 *
	 * @param array  $config      Config
	 * @param string $scope       Scope
	 * @param array  $breakpoints Breakpoints
	 *
	 * @return string
	 */
	public function css( array $config, $scope, array $breakpoints ) {
		$heights = $this->row_heights( $config );
		$stretch = $this->sanitize( (array) ( $config['layout']['justified'] ?? [] ) )['stretch_last'];
		$css     = $scope . '{--forma-row-height:' . $heights['desktop'] . 'px;--forma-stretch-last:' . ( $stretch ? 1 : 0 ) . '}';
		$wider   = $heights['desktop'];

		foreach ( array_keys( $breakpoints ) as $device ) {
			if ( $heights[ $device ] !== $wider && !empty( $breakpoints[ $device ] ) ) {
				$css .= '@media (max-width:' . (int) $breakpoints[ $device ] . 'px){' . $scope . '{--forma-row-height:' . $heights[ $device ] . 'px}}';
			}

			$wider = $heights[ $device ];
		}

		return $css;
	}

	/**
	 * Rows: the row height decides, not columns
	 *
	 * @return bool
	 */
	public function uses_columns() {
		return false;
	}

	/**
	 * List detail: the row heights
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function summary( array $config ) {
		/* translators: %s: row heights per device, widest first, e.g. "260 / 260 / 200 / 150" */
		return sprintf( __( 'rows %spx', 'forma-grid-gallery' ), implode( ' / ', $this->row_heights( $config ) ) );
	}

	/**
	 * Sketch: rows of different widths
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function sketch( array $config ) {
		$cells = '';

		foreach ( [ [ 3, 2, 2 ], [ 2, 4 ], [ 2, 3, 2 ] ] as $row ) {
			$cells .= '<span class="is-row">';

			foreach ( $row as $grow ) {
				$cells .= '<i style="flex-grow:' . (int) $grow . '"></i>';
			}

			$cells .= '</span>';
		}

		return self::sketch_html( $cells, '', 'is-justified' );
	}
}
