<?php

namespace VLT\Forma\Layouts;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Grid layout type. A layout only places items (settings, item classes, CSS); querying and rendering are shared.
 * One folder per type, Layouts/{Name}/{Name}Layout.php plus {Name}/editor.js. More through forma_layouts.
 */
interface LayoutInterface {
	/**
	 * Unique ID (stored in configs, used in the .forma--layout-{id} class)
	 *
	 * @return string
	 */
	public function get_id();

	/**
	 * Label for the editor
	 *
	 * @return string
	 */
	public function get_label();

	/**
	 * Default settings
	 *
	 * @return array
	 */
	public function defaults();

	/**
	 * Validate settings
	 *
	 * @param array $settings Raw settings
	 *
	 * @return array
	 */
	public function sanitize( array $settings );

	/**
	 * Extra classes of the item at a position
	 *
	 * @param int   $index  0-based position in the whole result (continues across pages)
	 * @param array $config Layout config
	 *
	 * @return array
	 */
	public function item_classes( $index, array $config );

	/**
	 * Inline style of the item at a position (CSS variables), '' for none
	 *
	 * @param int   $index  0-based position in the whole result (continues across pages)
	 * @param array $config Layout config
	 *
	 * @return string
	 */
	public function item_style( $index, array $config );

	/**
	 * Layout-specific CSS of one layout (printed once per page)
	 *
	 * @param array  $config      Layout config
	 * @param string $scope       Scope selector, e.g. .forma--123
	 * @param array  $breakpoints [ 'tablet_landscape' => px, 'tablet' => px, 'mobile' => px ] max-widths, widest first
	 *
	 * @return string
	 */
	public function css( array $config, $scope, array $breakpoints );

	/**
	 * Settings the grid's scripts read (data-forma → layoutSettings)
	 *
	 * @param array $config Layout config
	 *
	 * @return array
	 */
	public function script_settings( array $config );

	/**
	 * Front-end assets of a grid of this type (Assets::enqueue())
	 *
	 * @param array $config Layout config
	 */
	public function enqueue( array $config );

	/**
	 * Whether items sit in the responsive columns (the editor's Columns field, the list summary)
	 *
	 * @return bool
	 */
	public function uses_columns();

	/**
	 * Data the type's editor UI reads from window.formaEditor.layoutData[ id ]
	 *
	 * @return array
	 */
	public function editor_data();

	/**
	 * Detail for the Forma Layouts list, e.g. "4:3" or a pattern name
	 *
	 * @param array $config Layout config
	 *
	 * @return string
	 */
	public function summary( array $config );

	/**
	 * Columns per device for the Forma Layouts list
	 *
	 * @param array $config Layout config
	 *
	 * @return array [ device => columns ]
	 */
	public function columns( array $config );

	/**
	 * Thumbnail sketch for the Forma Layouts list (escaped HTML)
	 *
	 * @param array $config Layout config
	 *
	 * @return string
	 */
	public function sketch( array $config );
}
