/**
 * Masonry: columns and gaps only
 */
import { __ } from '@wordpress/i18n';

export default {
	id: 'masonry',
	description: __( 'Each item goes under the shortest column, so the order runs across the row, and items loaded later never move the ones above. Columns and gaps are set per device below.', 'forma-grid-gallery' ),
};
