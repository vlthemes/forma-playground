<?php

namespace VLT\Forma\Layouts\Masonry;

use VLT\Forma\Layouts\Layout;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Masonry: grid.js puts each item under the shortest column, so items loaded later never move the ones above.
 */
class MasonryLayout extends Layout {
	const POSITION = 30;

	/**
	 * Get ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'masonry';
	}

	/**
	 * Get label
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Masonry', 'forma-grid-gallery' );
	}

	/**
	 * Sketch: columns of uneven cells
	 *
	 * @param array $config Config
	 *
	 * @return string
	 */
	public function sketch( array $config ) {
		$columns = min( 4, max( 2, (int) $config['responsive']['columns']['desktop'] ) );

		return self::sketch_html( str_repeat( '<span class="is-col"><i></i><i></i></span>', $columns ), sprintf( 'grid-template-columns:repeat(%d,1fr)', $columns ), 'is-masonry' );
	}
}
