<?php

namespace VLT\Forma;

use VLT\Forma\Admin\Settings;
use VLT\Forma\Admin\Welcome;
use VLT\Forma\Core\Assets;
use VLT\Forma\Core\Forma;
use VLT\Forma\Core\Roles;
use VLT\Forma\Core\Upgrade;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin bootstrap, shared by the free plugin and Pro. Only one of them runs at a time.
 */
class Plugin {
	const VERSION = '1.0.0';

	const FREE = 'free';
	const PRO  = 'pro';

	// Main file of each edition, relative to the plugins directory
	const FREE_BASENAME = 'forma-grid-gallery/forma-grid-gallery.php';
	const PRO_BASENAME  = 'forma-grid-gallery-pro/forma-grid-gallery-pro.php';

	/**
	 * Edition running
	 *
	 * @var string
	 */
	private static $edition = self::FREE;

	/**
	 * Start the plugin
	 *
	 * @param string $file    Main plugin file
	 * @param string $edition self::FREE or self::PRO
	 */
	public static function boot( $file, $edition ) {
		self::$edition = $edition;

		define( 'FORMA_VERSION', self::VERSION );
		define( 'FORMA_FILE', $file );
		define( 'FORMA_PATH', plugin_dir_path( $file ) );
		define( 'FORMA_URL', plugin_dir_url( $file ) );

		// The functions for themes, there from the start (a theme's functions.php may check for them)
		require_once __DIR__ . '/functions.php';

		register_activation_hook( $file, [ __CLASS__, 'activate' ] );

		// On init, not earlier: the settings and the portfolio use translated strings
		add_action( 'init', [ __CLASS__, 'start' ], 0 );
	}

	/**
	 * Whether Pro runs
	 *
	 * @return bool
	 */
	public static function is_pro() {
		return self::PRO === self::$edition;
	}

	/**
	 * Start the parts
	 */
	public static function start() {
		Assets::init();
		Upgrade::init();
		// The portfolio first: it is the default grid source and its menu holds the grid pages
		Portfolio\Portfolio::instance();
		Forma::instance();
	}

	/**
	 * Activation: the welcome page, the roles' capabilities
	 */
	public static function activate() {
		Welcome::activate();
		Roles::sync( Settings::get( 'roles' ) );
	}
}
