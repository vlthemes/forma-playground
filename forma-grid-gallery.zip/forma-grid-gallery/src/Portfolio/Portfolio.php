<?php

namespace VLT\Forma\Portfolio;

use VLT\Forma\Admin\ListTable;
use VLT\Forma\Admin\Settings;
use VLT\Forma\Core\Forma;
use VLT\Forma\Core\Roles;
use VLT\Forma\Integrations\Seo;
use VLT\Forma\Sources\SourceRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Portfolio post type with its own categories and tags. Uses the common names (portfolio, portfolio_category,
 * portfolio_tag); when the theme or another plugin registers "portfolio", theirs is kept (conflict()).
 */
class Portfolio {
	const POST_TYPE = 'portfolio';
	const CATEGORY  = 'portfolio_category';
	const TAG       = 'portfolio_tag';

	/**
	 * Settings the rewrite rules were last flushed for
	 */
	const REWRITE_OPTION = 'forma_portfolio_rewrite';

	/**
	 * Instance
	 *
	 * @var Portfolio|null
	 */
	private static $instance = null;

	/**
	 * The category or tag of the request the archive page shows: a WP_Term, false for the portfolio's own address,
	 * null when the archive page isn't shown
	 *
	 * @var \WP_Term|false|null
	 */
	private static $archive = null;

	/**
	 * Get instance
	 *
	 * @return Portfolio
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Settings → Portfolio → Archive page: the theme's archive, or a published page
	 *
	 * @return array [ '' | page ID => title ]
	 */
	public static function archive_options() {
		$options = [ '' => __( "Your theme's archive", 'forma-grid-gallery' ) ];

		foreach ( get_pages( [ 'post_status' => 'publish', 'sort_column' => 'post_title' ] ) as $page ) {
			$options[ (string) $page->ID ] = get_the_title( $page ) ?: '#' . $page->ID;
		}

		return $options;
	}

	/**
	 * The portfolio's address and its category and tag pages show the archive page instead: the theme renders it as
	 * any page, with whatever it was built with, and its grids keep to the category or tag (scope())
	 *
	 * @param array $vars Query vars of the request
	 *
	 * @return array
	 */
	public static function archive_request( array $vars ) {
		$page = (int) ( Settings::get( 'portfolio' )['archive_page'] ?? 0 );

		if ( !$page || is_admin() || isset( $vars['feed'] ) || 'publish' !== get_post_status( $page ) ) {
			return $vars;
		}

		$term = false;

		foreach ( [ self::CATEGORY, self::TAG ] as $taxonomy ) {
			if ( !empty( $vars[ $taxonomy ] ) ) {
				// A child category comes as parent/child
				$term = get_term_by( 'slug', basename( (string) $vars[ $taxonomy ] ), $taxonomy );

				if ( !$term ) {
					return $vars;
				}
			}
		}

		$archive = self::POST_TYPE === ( $vars['post_type'] ?? '' ) && empty( $vars[ self::POST_TYPE ] ) && empty( $vars['name'] );

		if ( !$term && !$archive ) {
			return $vars;
		}

		self::$archive = $term;

		add_filter( 'redirect_canonical', '__return_false' );
		add_filter( 'forma_initial_term', [ __CLASS__, 'initial_term' ], 5, 2 );
		add_filter( 'forma_filter_url', [ __CLASS__, 'filter_url' ], 10, 3 );
		add_filter( 'forma_shortcode_config', [ __CLASS__, 'scope' ] );

		if ( $term ) {
			add_filter( 'the_title', [ __CLASS__, 'archive_title' ], 10, 2 );
			add_filter( 'document_title_parts', [ __CLASS__, 'document_title' ] );
			Seo::term( $term );
		}

		return [ 'page_id' => $page ];
	}

	/**
	 * The archive page's label in the Pages list, as WordPress marks the front page and the posts page
	 *
	 * @param array    $states Post states
	 * @param \WP_Post $post   Post
	 *
	 * @return array
	 */
	public static function post_state( $states, $post ) {
		if ( 'page' === $post->post_type && (int) ( Settings::get( 'portfolio' )['archive_page'] ?? 0 ) === $post->ID && self::active() ) {
			$states['forma_portfolio'] = __( 'Portfolio Page', 'forma-grid-gallery' );
		}

		return $states;
	}

	/**
	 * On a category or tag page: a grid filtered by that taxonomy starts on the term, so "All" still leads to the rest
	 *
	 * @param int   $term   Term
	 * @param array $config Layout config
	 *
	 * @return int
	 */
	public static function initial_term( $term, array $config ) {
		return self::$archive && $config['filters']['taxonomy'] === self::$archive->taxonomy ? (int) self::$archive->term_id : $term;
	}

	/**
	 * On the archive page: a filter by portfolio categories or tags links to their pages, "All" to the portfolio's
	 *
	 * @param string $url    Filtered address
	 * @param int    $term   Term ID, 0 = all
	 * @param array  $config Layout config
	 *
	 * @return string
	 */
	public static function filter_url( $url, $term, array $config ) {
		if ( !in_array( $config['filters']['taxonomy'], [ self::CATEGORY, self::TAG ], true ) ) {
			return $url;
		}

		$link = $term ? get_term_link( $term, $config['filters']['taxonomy'] ) : get_post_type_archive_link( self::POST_TYPE );

		return $link && !is_wp_error( $link ) ? $link : $url;
	}

	/**
	 * On a category or tag page: a grid of a source with that taxonomy, without a filter of it, shows only the term's
	 * items (query.scope keeps it to them when it loads more)
	 *
	 * @param array $config Layout config
	 *
	 * @return array
	 */
	public static function scope( array $config ) {
		$term = self::$archive;

		if ( !$term || ( $config['filters']['enabled'] && $config['filters']['taxonomy'] === $term->taxonomy )
			|| !isset( SourceRegistry::get( $config['query']['source'] )?->get_taxonomies()[ $term->taxonomy ] ) ) {
			return $config;
		}

		$config['query']['taxonomies'][ $term->taxonomy ] = [ (int) $term->term_id ];
		$config['query']['scope']                        = $term->taxonomy . ':' . $term->term_id;

		return $config;
	}

	/**
	 * The archive page's title on a category or tag page: the term's
	 *
	 * @param string $title Title
	 * @param int    $id    Post ID
	 *
	 * @return string
	 */
	public static function archive_title( $title, $id = 0 ) {
		return (int) $id === get_queried_object_id() ? esc_html( self::$archive->name ) : $title;
	}

	/**
	 * The document title on a category or tag page: the term's
	 *
	 * @param array $parts Title parts
	 *
	 * @return array
	 */
	public static function document_title( array $parts ) {
		$parts['title'] = self::$archive->name;

		return $parts;
	}

	/**
	 * Whether the portfolio is on (default yes)
	 *
	 * @return bool
	 */
	public static function enabled() {
		return (bool) ( Settings::get( 'portfolio' )['enabled'] ?? true );
	}

	/**
	 * Whether the portfolio is on and is this plugin's (no other "portfolio" took the name)
	 *
	 * @return bool
	 */
	public static function active() {
		return self::enabled() && !self::conflict();
	}

	/**
	 * Whether the theme or another plugin registers the "portfolio" post type (known once post types are registered)
	 *
	 * @return bool
	 */
	public static function conflict() {
		$object = get_post_type_object( self::POST_TYPE );

		return $object && empty( $object->forma );
	}

	/**
	 * Admin menu slug of the portfolio
	 *
	 * @return string
	 */
	public static function menu() {
		return 'edit.php?post_type=' . self::POST_TYPE;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		// After the post types: turning the portfolio off drops its addresses too
		add_action( 'init', [ __CLASS__, 'flush_rewrite' ], 99 );

		if ( !self::enabled() ) {
			return;
		}

		add_action( 'init', [ __CLASS__, 'register' ] );
		add_filter( 'request', [ __CLASS__, 'archive_request' ] );
		add_filter( 'display_post_states', [ __CLASS__, 'post_state' ], 10, 2 );
		// Also while another plugin has "portfolio": its tab says what to do then
		Migration::init();
	}

	/**
	 * Rewrite rules rebuilt once after the Portfolio settings change
	 */
	public static function flush_rewrite() {
		$version = md5( (string) wp_json_encode( Settings::get( 'portfolio' ) ) );

		if ( get_option( self::REWRITE_OPTION ) !== $version ) {
			flush_rewrite_rules( false );
			update_option( self::REWRITE_OPTION, $version );
		}
	}

	/**
	 * Admin menu: no "Add New Portfolio Item" (the items list has its Add button)
	 */
	public static function menu_items() {
		remove_submenu_page( self::menu(), 'post-new.php?post_type=' . self::POST_TYPE );
	}

	/**
	 * Items list: the featured image before the title
	 *
	 * @param array $columns Columns
	 *
	 * @return array
	 */
	public static function add_column( array $columns ) {
		$result = [];

		foreach ( $columns as $key => $label ) {
			if ( 'title' === $key ) {
				$result['forma_thumb'] = '<span class="screen-reader-text">' . esc_html__( 'Image', 'forma-grid-gallery' ) . '</span>';
			}

			$result[ $key ] = $label;
		}

		return $result;
	}

	/**
	 * Image column: the thumbnail, linked to the editor
	 *
	 * @param string $column  Column
	 * @param int    $post_id Post ID
	 */
	public static function render_column( $column, $post_id ) {
		if ( 'forma_thumb' !== $column ) {
			return;
		}

		$image = wp_kses_post( get_the_post_thumbnail( $post_id, 'thumbnail', [ 'alt' => '' ] ) );
		$image = $image ?: '<span class="vlt-list-thumb__empty" aria-hidden="true"></span>';
		$link  = current_user_can( 'edit_post', $post_id ) ? get_edit_post_link( $post_id ) : '';

		if ( $link ) {
			printf( '<a class="vlt-list-thumb" href="%s" tabindex="-1">%s</a>', esc_url( $link ), $image ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $image is escaped above
		} else {
			printf( '<span class="vlt-list-thumb">%s</span>', $image ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $image is escaped above
		}
	}

	/**
	 * Register the post type and taxonomies
	 */
	public static function register() {
		// The theme or another plugin has it: theirs stays
		if ( post_type_exists( self::POST_TYPE ) ) {
			return;
		}

		$settings = Settings::get( 'portfolio' );

		register_post_type( self::POST_TYPE, [
			// Marks the registration as this plugin's (conflict())
			'forma'           => true,
			'labels'          => [
				'name'               => esc_html__( 'Portfolio', 'forma-grid-gallery' ),
				'singular_name'      => esc_html__( 'Portfolio Item', 'forma-grid-gallery' ),
				// The top-level menu holds the grid pages too
				'menu_name'          => esc_html__( 'Forma', 'forma-grid-gallery' ),
				'all_items'          => esc_html__( 'Portfolio Items', 'forma-grid-gallery' ),
				'add_new'            => esc_html__( 'Add New', 'forma-grid-gallery' ),
				'add_new_item'       => esc_html__( 'Add New Portfolio Item', 'forma-grid-gallery' ),
				'edit_item'          => esc_html__( 'Edit Portfolio Item', 'forma-grid-gallery' ),
				'new_item'           => esc_html__( 'New Portfolio Item', 'forma-grid-gallery' ),
				'view_item'          => esc_html__( 'View Portfolio Item', 'forma-grid-gallery' ),
				'search_items'       => esc_html__( 'Search Portfolio Items', 'forma-grid-gallery' ),
				'not_found'          => esc_html__( 'No portfolio items found', 'forma-grid-gallery' ),
				'not_found_in_trash' => esc_html__( 'No portfolio items found in trash', 'forma-grid-gallery' ),
			],
			'public'          => true,
			'show_in_rest'    => true,
			'has_archive'     => true,
			'menu_icon'       => Forma::menu_icon(),
			'menu_position'   => 21,
			'supports'        => [ 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'revisions', 'custom-fields', 'post-formats' ],
			'rewrite'         => [ 'slug' => $settings['item_base'] ],
			// edit_portfolio_items…, given to roles in Settings → Roles
			'capability_type' => [ 'portfolio_item', 'portfolio_items' ],
			'map_meta_cap'    => true,
		] );

		register_taxonomy( self::CATEGORY, self::POST_TYPE, [
			'labels'            => [
				'name'          => esc_html__( 'Portfolio Categories', 'forma-grid-gallery' ),
				'singular_name' => esc_html__( 'Portfolio Category', 'forma-grid-gallery' ),
				'menu_name'     => esc_html__( 'Categories', 'forma-grid-gallery' ),
			],
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => [ 'slug' => $settings['category_base'] ],
			'capabilities'      => self::term_caps(),
		] );

		register_taxonomy( self::TAG, self::POST_TYPE, [
			'labels'            => [
				'name'          => esc_html__( 'Portfolio Tags', 'forma-grid-gallery' ),
				'singular_name' => esc_html__( 'Portfolio Tag', 'forma-grid-gallery' ),
				'menu_name'     => esc_html__( 'Tags', 'forma-grid-gallery' ),
			],
			'hierarchical'      => false,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => [ 'slug' => $settings['tag_base'] ],
			'capabilities'      => self::term_caps(),
		] );

		// Screens of this portfolio only
		add_action( 'admin_menu', [ __CLASS__, 'menu_items' ], 999 );
		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', [ __CLASS__, 'add_column' ] );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', [ __CLASS__, 'render_column' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', fn() => self::active() && ListTable::screen( 'edit-' . self::POST_TYPE ) );
		Views::init();
	}

	/**
	 * Who may manage and assign the portfolio's categories and tags: whoever may edit portfolio items
	 *
	 * @return array
	 */
	private static function term_caps() {
		return array_fill_keys( [ 'manage_terms', 'edit_terms', 'delete_terms', 'assign_terms' ], Roles::PORTFOLIO );
	}
}
