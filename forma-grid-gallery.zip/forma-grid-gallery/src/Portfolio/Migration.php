<?php

namespace VLT\Forma\Portfolio;

use VLT\Forma\Admin\Settings;
use VLT\Forma\Core\PostTypes;
use VLT\Forma\Core\Roles;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Moves another plugin's items into the portfolio, in place: IDs, content, meta, images and comments stay, so
 * layouts picking items by ID keep working. Terms merge by slug; undo() puts everything back.
 * Their grids and galleries aren't converted.
 *
 *     wp forma-portfolio migrate --from=project [--map=project_category:category,project_tag:tag] [--dry-run]
 *     wp forma-portfolio migrate --undo
 *
 * Direct queries: WordPress has no API to move posts and terms between types in bulk.
 */
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
class Migration {
	const MARK   = '_forma_migrated_from';
	const ACTION = 'forma_portfolio_migrate';
	const TAB    = 'migration';

	/**
	 * Post types never offered: WordPress' own, ours, and other plugins' layouts
	 */
	const SKIP_TYPES = [ 'post', 'page', 'attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_block', 'wp_template', 'wp_template_part', 'wp_global_styles', 'wp_navigation', 'wp_font_family', 'wp_font_face', Portfolio::POST_TYPE, PostTypes::LAYOUT ];

	/**
	 * Taxonomies that belong to other content too
	 */
	const SHARED_TAXONOMIES = [ 'category', 'post_tag', 'post_format', 'nav_menu', 'link_category', 'wp_theme', 'wp_template_part_area', 'wp_pattern_category', Portfolio::CATEGORY, Portfolio::TAG ];

	/**
	 * Init (with the portfolio on)
	 */
	public static function init() {
		add_filter( 'forma_settings_tabs', [ __CLASS__, 'tab' ] );
		add_action( 'admin_post_' . self::ACTION, [ __CLASS__, 'handle' ] );

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'forma-portfolio migrate', [ __CLASS__, 'cli' ] );
		}
	}

	/**
	 * Settings tab
	 *
	 * @param array $tabs Tabs
	 *
	 * @return array
	 */
	public static function tab( array $tabs ) {
		$tabs[ self::TAB ] = [
			'label'  => __( 'Migration', 'forma-grid-gallery' ),
			'icon'   => 'migrate',
			'render' => [ __CLASS__, 'render' ],
		];

		return $tabs;
	}

	/**
	 * Our taxonomy per target name of the form and the CLI
	 *
	 * @return array
	 */
	private static function targets() {
		return [
			'category' => Portfolio::CATEGORY,
			'tag'      => Portfolio::TAG,
		];
	}

	/**
	 * Post types with items in the database, registered or not
	 *
	 * @return array [ post_type => [ 'label' => string, 'posts' => int ] ]
	 */
	public static function sources() {
		global $wpdb;

		$rows    = $wpdb->get_results( "SELECT post_type, COUNT(*) AS posts FROM {$wpdb->posts} WHERE post_status NOT IN ('auto-draft', 'inherit') GROUP BY post_type ORDER BY post_type" );
		$sources = [];

		foreach ( $rows as $row ) {
			$object = get_post_type_object( $row->post_type );

			// Registered types that aren't public or searchable are some plugin's internal data or templates
			if ( in_array( $row->post_type, self::SKIP_TYPES, true ) || ( $object && ( !$object->public || $object->exclude_from_search ) ) ) {
				continue;
			}

			$sources[ $row->post_type ] = [
				'label' => $object ? $object->labels->name : $row->post_type,
				'posts' => (int) $row->posts,
			];
		}

		return $sources;
	}

	/**
	 * Taxonomies of a post type: its registered ones and those its items have terms of
	 *
	 * @param string $from Post type
	 *
	 * @return array [ taxonomy => [ 'label', 'terms' => int, 'shared' => bool, 'target' => category|tag|'' ] ]
	 */
	public static function taxonomies( $from ) {
		global $wpdb;

		$names = array_merge( get_object_taxonomies( $from ), $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT tt.taxonomy FROM {$wpdb->term_relationships} tr JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id JOIN {$wpdb->posts} p ON p.ID = tr.object_id WHERE p.post_type = %s",
			$from
		) ) );

		$list = [];

		foreach ( array_unique( $names ) as $taxonomy ) {
			$object = get_taxonomy( $taxonomy );
			$shared = in_array( $taxonomy, self::SHARED_TAXONOMIES, true )
				|| ( $object && array_diff( $object->object_type, [ $from ] ) )
				|| $wpdb->get_var( $wpdb->prepare(
					"SELECT 1 FROM {$wpdb->term_relationships} tr JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id JOIN {$wpdb->posts} p ON p.ID = tr.object_id WHERE tt.taxonomy = %s AND p.post_type <> %s LIMIT 1",
					$taxonomy,
					$from
				) );

			// Unregistered: tags by name, the rest as categories. A registered one that isn't public is the plugin's
			// internal data (e.g. WooCommerce's product type): kept unless asked
			$tags   = $object ? !$object->hierarchical : false !== strpos( $taxonomy, 'tag' );
			$target = $object && !$object->public ? '' : ( $tags ? 'tag' : 'category' );

			$list[ $taxonomy ] = [
				'label'  => $object ? $object->labels->name : $taxonomy,
				'terms'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s", $taxonomy ) ),
				'shared' => (bool) $shared,
				'target' => $target,
			];
		}

		return $list;
	}

	/**
	 * Taxonomies to move and where to: the asked targets ('' = keep), the guessed ones for the rest
	 *
	 * @param string $from  Post type
	 * @param array  $asked [ taxonomy => category|tag|'' ]
	 *
	 * @return array [ taxonomy => our taxonomy ]
	 */
	public static function map( $from, array $asked = [] ) {
		$map = [];

		foreach ( self::taxonomies( $from ) as $taxonomy => $info ) {
			$target = isset( $asked[ $taxonomy ] ) ? sanitize_key( $asked[ $taxonomy ] ) : $info['target'];

			if ( !$info['shared'] && isset( self::targets()[ $target ] ) ) {
				$map[ $taxonomy ] = self::targets()[ $target ];
			}
		}

		return $map;
	}

	/**
	 * Convert
	 *
	 * @param string $from    Post type
	 * @param array  $map     [ taxonomy => our taxonomy ] (see map())
	 * @param bool   $dry_run Only count
	 *
	 * @return array [ 'posts' => int, 'terms' => int, 'merged' => int, 'renamed' => int, 'menu_items' => int ]
	 */
	public static function run( $from, array $map, $dry_run = false ) {
		global $wpdb;

		$result = [
			'posts'      => 0,
			'terms'      => 0,
			'merged'     => 0,
			'renamed'    => 0,
			'menu_items' => 0,
		];

		if ( !isset( self::sources()[ $from ] ) ) {
			return $result;
		}

		// Terms first: post counts are recounted at the end
		foreach ( $map as $source => $to ) {
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT tt.term_taxonomy_id, tt.term_id, t.slug FROM {$wpdb->term_taxonomy} tt JOIN {$wpdb->terms} t ON t.term_id = tt.term_id WHERE tt.taxonomy = %s",
				$source
			) );

			foreach ( $rows as $row ) {
				$existing = $wpdb->get_row( $wpdb->prepare(
					"SELECT tt.term_taxonomy_id, tt.term_id FROM {$wpdb->term_taxonomy} tt JOIN {$wpdb->terms} t ON t.term_id = tt.term_id WHERE tt.taxonomy = %s AND t.slug = %s",
					$to,
					$row->slug
				) );

				++$result[ $existing ? 'merged' : 'terms' ];

				if ( $dry_run ) {
					continue;
				}

				if ( $existing ) {
					// Same slug in ours: give its items the existing term, re-parent its children, drop it
					$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->term_relationships} (object_id, term_taxonomy_id, term_order) SELECT object_id, %d, term_order FROM {$wpdb->term_relationships} WHERE term_taxonomy_id = %d", $existing->term_taxonomy_id, $row->term_taxonomy_id ) );
					$wpdb->delete( $wpdb->term_relationships, [ 'term_taxonomy_id' => $row->term_taxonomy_id ] );
					$wpdb->delete( $wpdb->term_taxonomy, [ 'term_taxonomy_id' => $row->term_taxonomy_id ] );

					// Children already moved or still waiting
					foreach ( [ $source, $to ] as $taxonomy ) {
						$wpdb->update( $wpdb->term_taxonomy, [ 'parent' => $existing->term_id ], [ 'parent' => $row->term_id, 'taxonomy' => $taxonomy ] );
					}

					$result['menu_items'] += self::menu_items( 'taxonomy', $source, $to, (int) $row->term_id, (int) $existing->term_id );
					continue;
				}

				$wpdb->update( $wpdb->term_taxonomy, [ 'taxonomy' => $to ], [ 'term_taxonomy_id' => $row->term_taxonomy_id ] );
				update_term_meta( (int) $row->term_id, self::MARK, $source );
			}

			if ( !$dry_run ) {
				// Moved terms keep their IDs, so parents and the other menu items only change the taxonomy
				$result['menu_items'] += self::menu_items( 'taxonomy', $source, $to );
			}
		}

		$ids             = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_status <> 'auto-draft'", $from ) ) );
		$result['posts'] = count( $ids );

		if ( $dry_run ) {
			$result['renamed'] = self::slug_conflicts( $ids, true );

			return $result;
		}

		foreach ( $ids as $id ) {
			update_post_meta( $id, self::MARK, $from );
		}

		if ( $ids ) {
			$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->posts} SET post_type = %s WHERE post_type = %s", Portfolio::POST_TYPE, $from ) );
		}

		$result['renamed']     = self::slug_conflicts( $ids );
		$result['menu_items'] += self::menu_items( 'post_type', $from, Portfolio::POST_TYPE );
		$result['menu_items'] += self::menu_items( 'post_type_archive', $from, Portfolio::POST_TYPE );

		self::refresh( $ids, array_keys( $map ) );

		return $result;
	}

	/**
	 * Put every converted post and term back where it came from
	 *
	 * @return array [ 'posts' => int, 'terms' => int ]
	 */
	public static function undo() {
		global $wpdb;

		$posts = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s", self::MARK ) );
		$types = [];

		foreach ( $posts as $post ) {
			set_post_type( (int) $post->post_id, $post->meta_value );
			delete_post_meta( (int) $post->post_id, self::MARK );

			$types[ $post->meta_value ][] = (int) $post->post_id;
		}

		foreach ( $types as $type => $ids ) {
			self::menu_items( 'post_type', Portfolio::POST_TYPE, $type, 0, 0, $ids );
		}

		$terms = $wpdb->get_results( $wpdb->prepare( "SELECT term_id, meta_value FROM {$wpdb->termmeta} WHERE meta_key = %s", self::MARK ) );

		foreach ( $terms as $term ) {
			$to = $wpdb->get_var( $wpdb->prepare( "SELECT taxonomy FROM {$wpdb->term_taxonomy} WHERE term_id = %d", $term->term_id ) );

			if ( in_array( $to, self::targets(), true ) ) {
				$wpdb->update( $wpdb->term_taxonomy, [ 'taxonomy' => $term->meta_value ], [ 'term_id' => $term->term_id, 'taxonomy' => $to ] );
				self::menu_items( 'taxonomy', $to, $term->meta_value, (int) $term->term_id );
			}

			delete_term_meta( (int) $term->term_id, self::MARK );
		}

		self::refresh( array_merge( [], ...array_values( $types ) ), array_unique( wp_list_pluck( $terms, 'meta_value' ) ) );

		return [
			'posts' => count( $posts ),
			'terms' => count( $terms ),
		];
	}

	/**
	 * Give converted posts a unique slug where one of our items already uses it
	 *
	 * @param array $ids     Converted post IDs
	 * @param bool  $dry_run Only count
	 *
	 * @return int
	 */
	private static function slug_conflicts( array $ids, $dry_run = false ) {
		global $wpdb;

		if ( !$ids ) {
			return 0;
		}

		$in = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $in is a list of %d placeholders
		$clashes = $wpdb->get_results( $wpdb->prepare(
			"SELECT p.ID, p.post_name, p.post_status, p.post_parent FROM {$wpdb->posts} p
			WHERE p.ID IN ({$in}) AND p.post_name <> '' AND EXISTS (
				SELECT 1 FROM {$wpdb->posts} o WHERE o.post_type = %s AND o.post_name = p.post_name AND o.ID NOT IN ({$in})
			)",
			array_merge( $ids, [ Portfolio::POST_TYPE ], $ids )
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( !$dry_run ) {
			foreach ( $clashes as $post ) {
				$wpdb->update( $wpdb->posts, [ 'post_name' => wp_unique_post_slug( $post->post_name, $post->ID, $post->post_status, Portfolio::POST_TYPE, $post->post_parent ) ], [ 'ID' => $post->ID ] );
			}
		}

		return count( $clashes );
	}

	/**
	 * Point nav menu items at the new post type / taxonomy
	 *
	 * @param string $type    _menu_item_type: taxonomy | post_type | post_type_archive
	 * @param string $from    Old object
	 * @param string $to      New object
	 * @param int    $term    Only items of this term (0 = all of $from)
	 * @param int    $term_to New term ID for $term (merged term), 0 = same
	 * @param array  $posts   Only items of these posts
	 *
	 * @return int Updated items
	 */
	private static function menu_items( $type, $from, $to, $term = 0, $term_to = 0, array $posts = [] ) {
		global $wpdb;

		$items = array_map( 'intval', $wpdb->get_col( $wpdb->prepare(
			"SELECT o.post_id FROM {$wpdb->postmeta} o JOIN {$wpdb->postmeta} t ON t.post_id = o.post_id AND t.meta_key = '_menu_item_type' AND t.meta_value = %s WHERE o.meta_key = '_menu_item_object' AND o.meta_value = %s",
			$type,
			$from
		) ) );

		foreach ( $items as $i => $item ) {
			$object_id = (int) get_post_meta( $item, '_menu_item_object_id', true );

			if ( ( $term && $object_id !== $term ) || ( $posts && !in_array( $object_id, $posts, true ) ) ) {
				unset( $items[ $i ] );
				continue;
			}

			update_post_meta( $item, '_menu_item_object', $to );

			if ( $term_to ) {
				update_post_meta( $item, '_menu_item_object_id', $term_to );
			}
		}

		return count( $items );
	}

	/**
	 * Caches, term counts and permalinks after a change
	 *
	 * @param array $ids        Changed post IDs
	 * @param array $taxonomies The other plugin's taxonomies that changed
	 */
	private static function refresh( array $ids, array $taxonomies ) {
		foreach ( $ids as $id ) {
			clean_post_cache( $id );
		}

		wp_cache_flush();

		foreach ( array_merge( $taxonomies, array_values( self::targets() ) ) as $taxonomy ) {
			if ( taxonomy_exists( $taxonomy ) ) {
				$terms = get_terms( [
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
					'fields'     => 'tt_ids',
				] );

				wp_update_term_count_now( is_array( $terms ) ? $terms : [], $taxonomy );
			}
		}

		flush_rewrite_rules( false );
	}

	/**
	 * Why nothing can be converted now: another plugin or the theme has "portfolio" ('' = it can)
	 *
	 * Converted items would become that plugin's; its own items are "portfolio" posts already.
	 *
	 * @return string
	 */
	private static function blocked() {
		return Portfolio::conflict()
			? __( 'Your theme or another plugin registers the "portfolio" post type, so Forma\'s Portfolio is off. Its items are portfolio posts already: turn that plugin off (or switch the theme) and Forma\'s Portfolio shows them, with no migration. Items of other post types can be converted here once it is off.', 'forma-grid-gallery' )
			: '';
	}

	/**
	 * Tab content: the post type to move, where its taxonomies go, what changes, and the buttons
	 */
	public static function render() {
		global $wpdb;

		if ( !current_user_can( Roles::SETTINGS ) ) {
			return;
		}

		if ( self::blocked() ) {
			?>
			<div class="vlt-settings-page__head">
				<h2><?php esc_html_e( 'Migration', 'forma-grid-gallery' ); ?></h2>
			</div>
			<p class="vlt-settings-page__note is-warning"><?php echo esc_html( self::blocked() ); ?></p>
			<?php
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only choices of the page
		$sources = self::sources();
		$from    = sanitize_key( wp_unslash( $_GET['from'] ?? '' ) );
		// The only post type found is chosen for you
		$from    = isset( $sources[ $from ] ) ? $from : ( 1 === count( $sources ) ? (string) array_key_first( $sources ) : '' );
		$asked   = array_map( 'sanitize_key', (array) wp_unslash( $_GET['map'] ?? [] ) );
		$done    = sanitize_key( wp_unslash( $_GET['done'] ?? '' ) );
		// The settings page's own query args, kept by the form below
		$keep = array_filter( array_map( fn( $key ) => sanitize_key( wp_unslash( $_GET[ $key ] ?? '' ) ), [ 'post_type' => 'post_type', 'page' => 'page' ] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$taxonomies = $from ? self::taxonomies( $from ) : [];
		$map        = $from ? self::map( $from, $asked ) : [];
		$plan       = $from ? self::run( $from, $map, true ) : null;
		$migrated   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s", self::MARK ) );
		$report     = get_transient( self::ACTION . '_' . get_current_user_id() );
		$shared     = wp_list_pluck( array_filter( $taxonomies, fn( $info ) => $info['shared'] ), 'label' );
		$target     = fn( $taxonomy ) => array_search( $map[ $taxonomy ] ?? '', self::targets(), true ) ?: '';

		$button = function ( $mode, $label, $class ) use ( $from, $map, $target ) {
			?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
				<input type="hidden" name="mode" value="<?php echo esc_attr( $mode ); ?>">
				<input type="hidden" name="from" value="<?php echo esc_attr( $from ); ?>">
				<?php foreach ( array_keys( $map ) as $taxonomy ) : ?>
					<input type="hidden" name="map[<?php echo esc_attr( $taxonomy ); ?>]" value="<?php echo esc_attr( $target( $taxonomy ) ); ?>">
				<?php endforeach; ?>
				<?php wp_nonce_field( self::ACTION ); ?>
				<button type="submit" class="vlt-settings-page__button <?php echo esc_attr( $class ); ?>"><?php echo esc_html( $label ); ?></button>
			</form>
			<?php
		};
		?>
		<div class="vlt-settings-page__head">
			<h2><?php esc_html_e( 'Migration', 'forma-grid-gallery' ); ?></h2>
			<p><?php esc_html_e( 'Moves the items of another portfolio plugin, with their categories and tags, into the portfolio. Items keep their IDs, content, featured images and custom fields; nothing is copied. Post types of plugins you have turned off are listed too: their items are still in the database.', 'forma-grid-gallery' ); ?></p>
		</div>

		<?php if ( $done && is_array( $report ) ) : ?>
			<p class="vlt-settings-page__note is-success">
				<?php
				echo esc_html( 'undo' === $done
					/* translators: 1: posts, 2: terms */
					? sprintf( __( 'Restored %1$d items and %2$d terms to their plugins.', 'forma-grid-gallery' ), $report['posts'], $report['terms'] )
					/* translators: 1: posts, 2: terms, 3: merged terms, 4: renamed slugs, 5: menu items */
					: sprintf( __( 'Converted %1$d items and %2$d terms (%3$d merged into existing terms), %4$d slugs made unique, %5$d menu items updated.', 'forma-grid-gallery' ), $report['posts'], $report['terms'], $report['merged'], $report['renamed'], $report['menu_items'] ) );
				?>
			</p>
		<?php endif; ?>

		<?php if ( $sources ) : ?>
			<?php // GET: choosing only reloads the numbers; the hidden fields keep the settings page ?>
			<form method="get" action="#<?php echo esc_attr( self::TAB ); ?>">
				<?php foreach ( $keep as $key => $value ) : ?>
					<input type="hidden" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>">
				<?php endforeach; ?>

				<div class="vlt-settings-page__block">
					<div class="vlt-settings-page__block-head">
						<h3><?php esc_html_e( 'Move from', 'forma-grid-gallery' ); ?></h3>
					</div>
					<div class="vlt-settings-page__inline">
						<select class="vlt-settings-page__input" name="from" aria-label="<?php esc_attr_e( 'Post type', 'forma-grid-gallery' ); ?>">
							<option value=""><?php esc_html_e( 'Choose a post type', 'forma-grid-gallery' ); ?></option>
							<?php foreach ( $sources as $type => $source ) : ?>
								<option value="<?php echo esc_attr( $type ); ?>" <?php selected( $from, $type ); ?>>
									<?php
									/* translators: 1: post type name, 2: post type key, 3: number of items */
									echo esc_html( sprintf( __( '%1$s (%2$s, %3$d items)', 'forma-grid-gallery' ), $source['label'], $type, $source['posts'] ) );
									?>
								</option>
							<?php endforeach; ?>
						</select>
						<button type="submit" class="vlt-settings-page__button"><?php esc_html_e( 'Check', 'forma-grid-gallery' ); ?></button>
					</div>
				</div>

				<?php if ( $from ) : ?>
					<div class="vlt-settings-page__block">
						<div class="vlt-settings-page__block-head">
							<h3><?php esc_html_e( 'Categories and tags', 'forma-grid-gallery' ); ?></h3>
						</div>
						<?php if ( count( $taxonomies ) > count( $shared ) ) : ?>
							<div class="vlt-settings-page__grid">
								<?php
								foreach ( $taxonomies as $taxonomy => $info ) :
									if ( $info['shared'] ) {
										continue;
									}
									?>
									<div class="vlt-settings-page__field">
										<label for="vlt-migration-<?php echo esc_attr( $taxonomy ); ?>">
											<?php
											/* translators: 1: taxonomy name, 2: number of terms */
											echo esc_html( sprintf( __( '%1$s (%2$d terms)', 'forma-grid-gallery' ), $info['label'], $info['terms'] ) );
											?>
										</label>
										<select class="vlt-settings-page__input" id="vlt-migration-<?php echo esc_attr( $taxonomy ); ?>" name="map[<?php echo esc_attr( $taxonomy ); ?>]">
											<option value="category" <?php selected( $target( $taxonomy ), 'category' ); ?>><?php esc_html_e( 'Portfolio categories', 'forma-grid-gallery' ); ?></option>
											<option value="tag" <?php selected( $target( $taxonomy ), 'tag' ); ?>><?php esc_html_e( 'Portfolio tags', 'forma-grid-gallery' ); ?></option>
											<option value="" <?php selected( $target( $taxonomy ), '' ); ?>><?php esc_html_e( 'Don\'t move', 'forma-grid-gallery' ); ?></option>
										</select>
									</div>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					</div>

					<p class="vlt-settings-page__note">
						<?php
						echo esc_html( count( $taxonomies ) > count( $shared )
							? __( 'After a change press Check to update the numbers below.', 'forma-grid-gallery' )
							: __( 'This post type has no categories or tags of its own.', 'forma-grid-gallery' ) );
						?>
					</p>

					<?php if ( $shared ) : ?>
						<p class="vlt-settings-page__note">
							<?php
							/* translators: %s: list of taxonomy names */
							echo esc_html( sprintf( __( 'Other content uses these too, so they stay as they are: %s.', 'forma-grid-gallery' ), implode( ', ', $shared ) ) );
							?>
						</p>
					<?php endif; ?>
				<?php endif; ?>
			</form>
		<?php endif; ?>

		<?php if ( $plan ) : ?>
			<div class="vlt-settings-page__block">
				<div class="vlt-settings-page__block-head">
					<h3><?php esc_html_e( 'What changes', 'forma-grid-gallery' ); ?></h3>
				</div>
				<ul class="vlt-settings-page__list">
					<li><?php esc_html_e( 'Items moved', 'forma-grid-gallery' ); ?> <strong><?php echo esc_html( number_format_i18n( $plan['posts'] ) ); ?></strong></li>
					<li><?php esc_html_e( 'Terms moved', 'forma-grid-gallery' ); ?> <strong><?php echo esc_html( number_format_i18n( $plan['terms'] ) ); ?></strong></li>
					<li><?php esc_html_e( 'Terms merged into existing ones (same slug)', 'forma-grid-gallery' ); ?> <strong><?php echo esc_html( number_format_i18n( $plan['merged'] ) ); ?></strong></li>
					<li><?php esc_html_e( 'Slugs already used by portfolio items (renamed)', 'forma-grid-gallery' ); ?> <strong><?php echo esc_html( number_format_i18n( $plan['renamed'] ) ); ?></strong></li>
				</ul>
			</div>

			<p class="vlt-settings-page__note"><?php esc_html_e( 'The other plugin\'s grids and galleries are not converted: rebuild them as Forma Layouts. Fields only that plugin understood are kept but not used.', 'forma-grid-gallery' ); ?></p>
			<p class="vlt-settings-page__note is-warning"><?php esc_html_e( 'Back up the database first. Old item links change to the portfolio addresses.', 'forma-grid-gallery' ); ?></p>
		<?php elseif ( !$sources ) : ?>
			<p class="vlt-settings-page__note is-success"><?php esc_html_e( 'No items of other plugins found: nothing to convert.', 'forma-grid-gallery' ); ?></p>
		<?php endif; ?>

		<?php if ( $migrated || ( $plan && ( $plan['posts'] || $plan['terms'] || $plan['merged'] ) ) ) : ?>
			<div class="vlt-settings-page__save">
				<span>
					<?php
					echo esc_html( $migrated
						/* translators: %d: number of converted items */
						? sprintf( __( '%d items converted so far, can be undone.', 'forma-grid-gallery' ), $migrated )
						: __( 'Converts in place, can be undone.', 'forma-grid-gallery' ) );
					?>
				</span>
				<div class="vlt-settings-page__actions">
					<?php
					if ( $migrated ) {
						$button( 'undo', __( 'Undo conversion', 'forma-grid-gallery' ), '' );
					}

					if ( $plan && ( $plan['posts'] || $plan['terms'] || $plan['merged'] ) ) {
						$button( 'run', __( 'Convert now', 'forma-grid-gallery' ), 'is-primary' );
					}
					?>
				</div>
			</div>
		<?php endif; ?>
		<?php
	}

	/**
	 * Admin form handler
	 */
	public static function handle() {
		if ( !current_user_can( Roles::SETTINGS ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'forma-grid-gallery' ), 403 );
		}

		check_admin_referer( self::ACTION );

		if ( self::blocked() ) {
			wp_die( esc_html( self::blocked() ), 409 );
		}

		$mode = 'undo' === sanitize_key( wp_unslash( $_POST['mode'] ?? '' ) ) ? 'undo' : 'run';
		$from = sanitize_key( wp_unslash( $_POST['from'] ?? '' ) );

		if ( 'undo' === $mode ) {
			$report = self::undo();
		} else {
			$asked = array_map( 'sanitize_key', (array) wp_unslash( $_POST['map'] ?? [] ) );
			$asked += array_fill_keys( array_keys( self::taxonomies( $from ) ), '' );
			$report = self::run( $from, self::map( $from, $asked ) );
		}

		set_transient( self::ACTION . '_' . get_current_user_id(), $report, MINUTE_IN_SECONDS );

		// Back to the settings tab (opened by the #hash), without the choices of the converted type
		$back = remove_query_arg( [ 'done', 'from', 'map' ], wp_get_referer() ?: admin_url( 'admin.php?page=' . Settings::PAGE ) );

		wp_safe_redirect( add_query_arg( 'done', $mode, $back ) . '#' . self::TAB );
		exit;
	}

	/**
	 * WP-CLI: move another plugin's items into the portfolio
	 *
	 * ## OPTIONS
	 *
	 * [--from=<post_type>]
	 * : Post type to convert. Without it, lists the post types found.
	 *
	 * [--map=<taxonomies>]
	 * : Where its taxonomies go, e.g. project_category:category,project_tag:tag (none = keep). Unlisted ones are guessed.
	 *
	 * [--dry-run]
	 * : Only show what would change.
	 *
	 * [--undo]
	 * : Put every converted item back.
	 *
	 * @param array $args       Positional args
	 * @param array $assoc_args Flags
	 */
	public static function cli( $args, $assoc_args ) {
		if ( self::blocked() ) {
			\WP_CLI::error( self::blocked() );
		}

		if ( !empty( $assoc_args['undo'] ) ) {
			$report = self::undo();
			\WP_CLI::success( sprintf( 'Restored %d items and %d terms.', $report['posts'], $report['terms'] ) );
			return;
		}

		$from = sanitize_key( $assoc_args['from'] ?? '' );

		if ( !isset( self::sources()[ $from ] ) ) {
			foreach ( self::sources() as $type => $source ) {
				\WP_CLI::log( sprintf( '%s: %s, %d items', $type, $source['label'], $source['posts'] ) );
			}

			\WP_CLI::error( $from ? "No items of \"{$from}\" to convert." : 'Pass --from=<post_type>.' );
		}

		$asked = [];

		foreach ( array_filter( explode( ',', (string) ( $assoc_args['map'] ?? '' ) ) ) as $pair ) {
			[ $taxonomy, $target ] = array_pad( explode( ':', $pair, 2 ), 2, '' );
			$asked[ $taxonomy ]    = 'none' === $target ? '' : $target;
		}

		$map    = self::map( $from, $asked );
		$dry    = !empty( $assoc_args['dry-run'] );
		$report = self::run( $from, $map, $dry );

		foreach ( $map as $taxonomy => $to ) {
			\WP_CLI::log( "{$taxonomy} → {$to}" );
		}

		$summary = sprintf( '%d items, %d terms (%d merged), %d slugs renamed', $report['posts'], $report['terms'], $report['merged'], $report['renamed'] );

		\WP_CLI::success( $dry ? "Would convert {$summary}." : "Converted {$summary}, {$report['menu_items']} menu items." );
	}
}
