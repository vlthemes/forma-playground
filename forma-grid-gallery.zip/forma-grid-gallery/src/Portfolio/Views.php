<?php

namespace VLT\Forma\Portfolio;

use VLT\Forma\Admin\Settings;
use VLT\Forma\Api\Rest;
use VLT\Forma\Core\Assets;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Views of portfolio items: counted on their pages, shown in the items list, an order for layouts and visitors
 *
 *     POST /forma/v1/views/{id}  one view of a published item; public
 */
class Views {
	const META = '_forma_views';

	/**
	 * Init (with the portfolio on)
	 */
	public static function init() {
		if ( !Settings::get( 'portfolio' )['views'] ) {
			return;
		}

		add_action( 'rest_api_init', [ __CLASS__, 'route' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_filter( 'forma_orderby_options', [ __CLASS__, 'orderby' ], 10, 2 );
		add_filter( 'forma_query_args', [ __CLASS__, 'query_args' ], 10, 2 );
		add_filter( 'manage_' . Portfolio::POST_TYPE . '_posts_columns', [ __CLASS__, 'add_column' ] );
		add_action( 'manage_' . Portfolio::POST_TYPE . '_posts_custom_column', [ __CLASS__, 'render_column' ], 10, 2 );
		add_filter( 'manage_edit-' . Portfolio::POST_TYPE . '_sortable_columns', [ __CLASS__, 'sortable' ] );
		add_action( 'pre_get_posts', [ __CLASS__, 'sort_list' ] );
	}

	/**
	 * Register the route
	 */
	public static function route() {
		register_rest_route( Rest::NAMESPACE, '/views/(?P<id>\d+)', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => [ __CLASS__, 'count' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'id' => [ 'type' => 'integer', 'required' => true ],
			],
		] );
	}

	/**
	 * One more view of a published portfolio item
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function count( \WP_REST_Request $request ) {
		$id = (int) $request['id'];

		if ( Portfolio::POST_TYPE !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) ) {
			return new \WP_Error( 'forma_not_found', __( 'No such item.', 'forma-grid-gallery' ), [ 'status' => 404 ] );
		}

		$views = self::get( $id ) + 1;
		update_post_meta( $id, self::META, $views );

		return rest_ensure_response( [ 'views' => $views ] );
	}

	/**
	 * Views of an item
	 *
	 * @param int $id Post ID
	 *
	 * @return int
	 */
	public static function get( $id ) {
		return (int) get_post_meta( $id, self::META, true );
	}

	/**
	 * The counting script on an item's page; its editors' visits don't count
	 */
	public static function enqueue() {
		if ( !is_singular( Portfolio::POST_TYPE ) || is_preview() || current_user_can( 'edit_post', get_queried_object_id() ) ) {
			return;
		}

		Assets::enqueue( 'forma-views' );
		Assets::data( 'forma-views', 'formaViews', [
			'url' => rest_url( Rest::NAMESPACE . '/views/' . get_queried_object_id() ),
			'id'  => get_queried_object_id(),
		] );
	}

	/**
	 * "Views" among the portfolio's orders
	 *
	 * @param array  $options [ orderby => label ]
	 * @param string $source  Source ID
	 *
	 * @return array
	 */
	public static function orderby( array $options, $source ) {
		return Portfolio::POST_TYPE === $source ? $options + [ 'views' => __( 'Views', 'forma-grid-gallery' ) ] : $options;
	}

	/**
	 * Order by views. Items never viewed count as 0; ties go newest first
	 *
	 * @param array $query_args WP_Query args
	 * @param array $query      Query config
	 *
	 * @return array
	 */
	public static function query_args( array $query_args, array $query ) {
		if ( 'views' !== $query['orderby'] ) {
			return $query_args;
		}

		$query_args['meta_query']          = (array) ( $query_args['meta_query'] ?? [] ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		$query_args['meta_query']['views'] = [
			'relation'     => 'OR',
			'forma_views'  => [
				'key'  => self::META,
				'type' => 'NUMERIC',
			],
			'forma_unseen' => [
				'key'     => self::META,
				'compare' => 'NOT EXISTS',
			],
		];
		$query_args['orderby']             = [
			'forma_views' => $query['order'],
			'date'        => 'DESC',
		];

		return $query_args;
	}

	/**
	 * Items list: a Views column before the date
	 *
	 * @param array $columns Columns
	 *
	 * @return array
	 */
	public static function add_column( array $columns ) {
		$date = $columns['date'] ?? null;
		unset( $columns['date'] );

		$columns['forma_views'] = __( 'Views', 'forma-grid-gallery' );

		return null === $date ? $columns : $columns + [ 'date' => $date ];
	}

	/**
	 * Views column
	 *
	 * @param string $column  Column
	 * @param int    $post_id Post ID
	 */
	public static function render_column( $column, $post_id ) {
		if ( 'forma_views' === $column ) {
			echo esc_html( number_format_i18n( self::get( $post_id ) ) );
		}
	}

	/**
	 * Views column sorts the list
	 *
	 * @param array $columns Sortable columns
	 *
	 * @return array
	 */
	public static function sortable( array $columns ) {
		return $columns + [ 'forma_views' => [ 'forma_views', true ] ];
	}

	/**
	 * Items list sorted by views
	 *
	 * @param \WP_Query $query Query
	 */
	public static function sort_list( $query ) {
		if ( !is_admin() || !$query->is_main_query() || 'forma_views' !== $query->get( 'orderby' ) ) {
			return;
		}

		$query->set( 'meta_query', self::query_args( [], [ 'orderby' => 'views', 'order' => $query->get( 'order' ) ?: 'DESC' ] )['meta_query'] );
		$query->set( 'orderby', [ 'forma_views' => $query->get( 'order' ) ?: 'DESC', 'date' => 'DESC' ] );
	}
}
