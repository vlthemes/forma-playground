<?php

namespace VLT\Forma\Front;

use VLT\Forma\Admin\Settings;
use VLT\Forma\Core\Assets;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PhotoSwipe lightbox driven by markup: data-forma-lightbox="{group}" opens its group. One delegated handler,
 * so items loaded later need nothing.
 */
class Lightbox {
	const HANDLE = 'forma-lightbox';

	/**
	 * Unique gallery groups per page
	 *
	 * @var int
	 */
	private static $galleries = 0;

	/**
	 * Init
	 */
	public static function init() {
		// Settings labels are translated: read them on init
		add_action( 'init', [ __CLASS__, 'register' ] );
	}

	/**
	 * WordPress galleries and images
	 */
	public static function register() {
		if ( !self::enabled() || !self::settings()['wp'] ) {
			return;
		}

		add_filter( 'render_block_core/gallery', fn( $html ) => self::process_links( $html, 'wp-gallery-' . ( ++self::$galleries ), true ), 20 );
		add_filter( 'render_block_core/image', fn( $html ) => self::process_links( $html, 'wp-content' ), 20 );
		add_filter( 'do_shortcode_tag', fn( $html, $tag ) => 'gallery' === $tag ? self::process_links( $html, 'wp-gallery-' . ( ++self::$galleries ), true ) : $html, 20, 2 );
		add_filter( 'the_content', fn( $html ) => self::process_links( $html, 'wp-content' ), 20 );
	}

	/**
	 * Settings
	 *
	 * @return array [ enabled, wp, captions, arrows, zoom, counter, share ]
	 */
	public static function settings() {
		return Settings::get( 'lightbox' ) + [
			'enabled'  => true,
			'wp'       => false,
			'captions' => true,
			'arrows'   => true,
			'zoom'     => true,
			'counter'  => true,
			'share'    => true,
		];
	}

	/**
	 * Whether the lightbox is on
	 *
	 * @return bool
	 */
	public static function enabled() {
		return (bool) apply_filters( 'forma_lightbox_enabled', self::settings()['enabled'] );
	}

	/**
	 * Lightbox attributes of an image
	 *
	 * @param string $group      Group: elements of one group form one gallery
	 * @param int    $image_id   Attachment ID (0 = use $src)
	 * @param string $caption    Caption (plain text)
	 * @param string $src        Image URL when there is no attachment
	 *
	 * @return array Attributes, [] when the lightbox is off or there is no image
	 */
	public static function attributes( $group, $image_id, $caption = '', $src = '' ) {
		if ( !self::enabled() ) {
			return [];
		}

		$full = $image_id ? wp_get_attachment_image_src( $image_id, 'full' ) : null;
		$src  = $full ? $full[0] : $src;

		if ( !$src ) {
			return [];
		}

		self::enqueue();

		return array_filter( [
			'data-forma-lightbox'         => $group,
			'data-forma-lightbox-src'     => $src,
			'data-forma-lightbox-meta'    => implode( '|', self::meta( $image_id ) ),
			// Empty sizes are read by the script
			'data-forma-lightbox-width'   => $full ? (int) $full[1] : '',
			'data-forma-lightbox-height'  => $full ? (int) $full[2] : '',
			'data-forma-lightbox-srcset'  => $image_id ? (string) wp_get_attachment_image_srcset( $image_id, 'full' ) : '',
			'data-forma-lightbox-caption' => self::settings()['captions'] ? wp_strip_all_tags( $caption ) : '',
		], fn( $value ) => '' !== $value && false !== $value );
	}

	/**
	 * Full-size image data for lightbox/item-data.php
	 *
	 * @param int $image_id Attachment ID
	 *
	 * @return array|null [ src, srcset, width, height, captions (bool: show captions), meta ], null when the lightbox is off
	 */
	public static function image( $image_id ) {
		$full = self::enabled() && $image_id ? wp_get_attachment_image_src( $image_id, 'full' ) : null;

		if ( !$full ) {
			return null;
		}

		self::enqueue();

		return [
			'src'      => $full[0],
			'srcset'   => (string) wp_get_attachment_image_srcset( $image_id, 'full' ),
			'width'    => (int) $full[1],
			'height'   => (int) $full[2],
			'captions' => (bool) self::settings()['captions'],
			'meta'     => self::meta( $image_id ),
		];
	}

	/**
	 * Short lines shown under an image's caption, e.g. Forma Pro's camera details (forma_lightbox_meta)
	 *
	 * @param int $image_id Attachment ID (0 = none)
	 *
	 * @return string[] Plain text
	 */
	public static function meta( $image_id ) {
		return $image_id ? array_values( array_filter( array_map( 'strval', (array) apply_filters( 'forma_lightbox_meta', [], (int) $image_id ) ) ) ) : [];
	}

	/**
	 * Attributes as an HTML string
	 *
	 * @param array $attributes Attributes
	 *
	 * @return string
	 */
	public static function attributes_html( array $attributes ) {
		$html = '';

		foreach ( $attributes as $name => $value ) {
			$html .= ' ' . esc_attr( $name ) . '="' . ( in_array( $name, [ 'data-forma-lightbox-src', 'data-forma-lightbox-poster' ], true ) ? esc_url( $value ) : esc_attr( $value ) ) . '"';
		}

		return $html;
	}

	/**
	 * Add lightbox attributes to links to image files
	 *
	 * @param string $html  HTML
	 * @param string $group Group
	 * @param bool   $force Regroup links already processed (a gallery takes over its images' group)
	 *
	 * @return string
	 */
	public static function process_links( $html, $group, $force = false ) {
		if ( !is_string( $html ) || false === stripos( $html, '<a' ) || is_admin() || is_feed() ) {
			return $html;
		}

		return (string) preg_replace_callback(
			// LazyLoad may put a <noscript> before the <img>
			'#<a(\s[^>]*?href=(["\'])([^"\']+\.(?:jpe?g|png|gif|webp|avif))(?:\?[^"\']*)?\2[^>]*)>(\s*(?:<noscript>.*?</noscript>\s*)?<img[^>]*>)#is',
			function ( $matches ) use ( $group, $force ) {
				[ $tag, $attributes, , $href, $img ] = $matches;

				if ( preg_match( '#\sdata-forma-lightbox(?:-\w+)?=#', $attributes ) ) {
					return $force ? preg_replace( '#data-forma-lightbox=(["\'])[^"\']*\1#', 'data-forma-lightbox="' . esc_attr( $group ) . '"', $tag, 1 ) : $tag;
				}

				// Another lightbox handles it
				if ( preg_match( '#\sdata-(?:fancybox|lightbox|pswp)|\srel=(["\'])[^"\']*lightbox#i', $attributes ) ) {
					return $tag;
				}

				$image_id = preg_match( '/wp-image-(\d+)/', $img, $id ) ? (int) $id[1] : 0;
				$caption  = $image_id ? (string) wp_get_attachment_caption( $image_id ) : '';

				// Use the attachment only when the link points to its file
				if ( $image_id && false === strpos( $href, pathinfo( (string) get_attached_file( $image_id ), PATHINFO_FILENAME ) ) ) {
					$image_id = 0;
				}

				$lightbox = self::attributes( $group, $image_id, $caption ?: ( preg_match( '/\salt=(["\'])([^"\']*)\1/', $img, $alt ) ? $alt[2] : '' ), $href );

				return $lightbox ? '<a' . $attributes . self::attributes_html( $lightbox ) . '>' . $img : $tag;
			},
			$html
		);
	}

	/**
	 * Enqueue PhotoSwipe and the handler
	 */
	public static function enqueue() {
		if ( wp_script_is( self::HANDLE, 'enqueued' ) ) {
			return;
		}

		Assets::enqueue( 'forma-photoswipe', self::HANDLE );

		// The theme styles the lightbox itself (forma_default_styles): PhotoSwipe's own CSS only
		if ( !SkinManager::default_styles( 'lightbox' ) ) {
			wp_dequeue_style( self::HANDLE );
		}
	}

	/**
	 * Data of the handler (window.formaLightbox)
	 *
	 * @return array
	 */
	public static function script_data() {
		$settings = self::settings();

		return [
			// The buttons shown (Settings → Lightbox)
			'ui'    => [
				'arrows'   => (bool) $settings['arrows'],
				'zoom'     => (bool) $settings['zoom'],
				'counter'  => (bool) $settings['counter'],
				'share'    => (bool) $settings['share'],
			],
			// Line icons of the buttons (templates/icons/lightbox-*.svg, stroked in lightbox.scss)
			'icons' => array_map( fn( $name ) => SkinManager::icon( 'lightbox-' . $name, 'pswp__icn' ), [
				'arrow-left'  => 'arrow-left',
				'arrow-right' => 'arrow-right',
				'zoom'        => 'zoom',
				'close'       => 'close',
				'share'       => 'share',
			] ),
			'i18n'  => [
				'close'    => __( 'Close', 'forma-grid-gallery' ),
				'zoom'     => __( 'Zoom', 'forma-grid-gallery' ),
				'prev'     => __( 'Previous', 'forma-grid-gallery' ),
				'next'     => __( 'Next', 'forma-grid-gallery' ),
				'error'    => __( 'The image could not be loaded.', 'forma-grid-gallery' ),
				'share'    => __( 'Share', 'forma-grid-gallery' ),
				'more'     => __( 'Share via…', 'forma-grid-gallery' ),
				'copy'     => __( 'Copy link', 'forma-grid-gallery' ),
				'copied'   => __( 'Link copied', 'forma-grid-gallery' ),
				'download' => __( 'Download', 'forma-grid-gallery' ),
			],
		];
	}
}
