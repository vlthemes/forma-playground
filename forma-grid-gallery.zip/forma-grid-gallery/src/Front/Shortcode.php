<?php

namespace VLT\Forma\Front;

use VLT\Forma\Core\Config;
use VLT\Forma\Core\Roles;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Layout shortcode: the grid, or one of its controls anywhere on the page
 *
 *     [forma_grid id="123"]
 *     [forma_grid id="123" show="filter"]   filter, search, sort or pagination; instance="2" targets the second grid
 */
class Shortcode {
	const TAG = 'forma_grid';

	/**
	 * What it shows: the grid or a control
	 */
	const PARTS = [ 'grid', 'filter', 'search', 'sort', 'pagination' ];

	/**
	 * Init
	 */
	public static function init() {
		add_shortcode( self::TAG, [ __CLASS__, 'render' ] );

		// Grids in the post content get their styles in <head> instead of late in the footer
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_early' ], 20 );
	}

	/**
	 * [forma_grid]: also what the block and the page builders' elements print
	 *
	 * @param array|string $atts Attributes: id, show, instance
	 *
	 * @return string
	 */
	public static function render( $atts ) {
		$atts   = shortcode_atts( [ 'id' => 0, 'show' => 'grid', 'instance' => 1 ], $atts, self::TAG );
		$config = self::config( $atts );

		if ( !is_array( $config ) ) {
			return $config;
		}

		$show = in_array( $atts['show'], self::PARTS, true ) ? $atts['show'] : 'grid';

		return 'grid' === $show ? Renderer::render( $config ) : call_user_func( [ Renderer::class, 'render_' . $show ], $config, max( 1, absint( $atts['instance'] ) ) );
	}

	/**
	 * Config of the layout in the attributes, or the "not found" output
	 *
	 * @param array $atts Attributes
	 *
	 * @return array|string Config, or a notice for editors / empty string
	 */
	private static function config( array $atts ) {
		$config = Config::get( $atts['id'] );

		// The grid as this page shows it (Portfolio: a category's archive page keeps to the category)
		if ( $config ) {
			return (array) apply_filters( 'forma_shortcode_config', $config, $atts );
		}

		return current_user_can( Roles::LAYOUTS )
			/* translators: %d: grid layout ID */
			? '<p class="forma__notice">' . esc_html( sprintf( __( 'Grid layout #%d not found or not published.', 'forma-grid-gallery' ), absint( $atts['id'] ) ) ) . '</p>'
			: '';
	}

	/**
	 * Enqueue assets of grids found in the current post's content
	 */
	public static function enqueue_early() {
		$post = is_singular() ? get_post() : null;
		if ( !$post || !has_shortcode( $post->post_content, self::TAG ) ) {
			return;
		}

		preg_match_all( '/' . get_shortcode_regex( [ self::TAG ] ) . '/', $post->post_content, $matches );

		foreach ( $matches[3] as $atts ) {
			$config = Config::get( shortcode_parse_atts( $atts )['id'] ?? 0 );

			if ( $config ) {
				Renderer::enqueue( $config );
			}
		}
	}
}
