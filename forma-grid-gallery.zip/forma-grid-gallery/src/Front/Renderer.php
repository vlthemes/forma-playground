<?php

namespace VLT\Forma\Front;

use VLT\Forma\Admin\Controls;
use VLT\Forma\Admin\Preview;
use VLT\Forma\Admin\Settings;
use VLT\Forma\Api\Rest;
use VLT\Forma\Core\Animations;
use VLT\Forma\Core\Assets;
use VLT\Forma\Core\Config;
use VLT\Forma\Core\ImageSizes;
use VLT\Forma\Core\Placeholder;
use VLT\Forma\Core\PostTypes;
use VLT\Forma\Layouts\LayoutRegistry;
use VLT\Forma\Sources\SourceRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Grid markup for the shortcodes and AJAX; all HTML comes from templates (SkinManager)
 *
 * Search, filter, sort and pagination are separate pieces bound to the n-th grid of their layout on the page.
 */
class Renderer {
	/**
	 * @var int
	 */
	private static $instances = 0;

	/**
	 * Layouts whose CSS is printed
	 *
	 * @var array
	 */
	private static $printed = [];

	/**
	 * First page's result per layout ( page, max_pages, total ), for pagination rendered apart from the grid
	 *
	 * @var array
	 */
	private static $results = [];

	/**
	 * Grids rendered per layout
	 *
	 * @var array
	 */
	private static $layout_instances = [];

	/**
	 * Items the grids of this page show so far, for the grids below that leave them out (query.skip_shown)
	 *
	 * @var int[]
	 */
	private static $shown = [];

	/**
	 * Init
	 */
	public static function init() {
		// Before the footer scripts are printed, after every grid of the page
		add_action( 'wp_footer', [ __CLASS__, 'admin_bar' ], 5 );
		add_filter( 'wp_kses_allowed_html', [ __CLASS__, 'image_tags' ], 10, 2 );
	}

	/**
	 * The "forma_image" kses context of item-parts/image.php: an image as WordPress and image plugins print it, with
	 * its srcset, sizes and loading attributes, which wp_kses_post() would strip
	 *
	 * @param array  $tags    Allowed tags
	 * @param string $context Context
	 *
	 * @return array
	 */
	public static function image_tags( $tags, $context ) {
		if ( 'forma_image' !== $context ) {
			return $tags;
		}

		$common = [
			'class'   => true,
			'id'      => true,
			'style'   => true,
			'title'   => true,
			'width'   => true,
			'height'  => true,
			'srcset'  => true,
			'sizes'   => true,
			// Lazy-loading and CDN plugins keep their URLs in data-src, data-srcset…
			'data-*'  => true,
		];

		return [
			'img'     => $common + [
				'src'           => true,
				'alt'           => true,
				'loading'       => true,
				'decoding'      => true,
				'fetchpriority' => true,
			],
			'picture' => [ 'class' => true ],
			'source'  => $common + [
				'type'  => true,
				'media' => true,
			],
			'noscript' => [],
		];
	}

	/**
	 * Admin bar menu of the layouts this page shows, linked to their editor
	 */
	public static function admin_bar() {
		if ( !self::$layout_instances || !is_admin_bar_showing() ) {
			return;
		}

		$items = [];

		foreach ( array_keys( self::$layout_instances ) as $id ) {
			// No link when the user can't edit the layout
			$link = get_edit_post_link( $id, 'raw' );

			if ( $link ) {
				$items[] = [
					'title' => get_the_title( $id ) ?: sprintf( '#%d', $id ),
					'url'   => $link,
				];
			}
		}

		if ( !$items ) {
			return;
		}

		Assets::enqueue( 'forma-admin-bar' );
		Assets::data( 'forma-admin-bar', 'formaAdminBar', [
			'label' => __( 'Forma', 'forma-grid-gallery' ),
			'items' => $items,
		] );
	}

	/**
	 * Data of the front-end script (window.formaGrid)
	 *
	 * @return array
	 */
	public static function script_data() {
		return [
			// GET {restUrl}{layout}/items (Rest::items()); the logged-in send a nonce to see the drafts they may edit
			'restUrl' => Rest::url( '/layouts/' ),
			'nonce'   => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
			'i18n'    => [
				'error'    => __( 'Could not load items. Please try again.', 'forma-grid-gallery' ),
				// Slider arrows
				'previous' => __( 'Previous', 'forma-grid-gallery' ),
				'next'     => __( 'Next', 'forma-grid-gallery' ),
			],
			// The slider's arrows (grid-slider.js builds them): icons/arrow-*.svg, a theme's copy first
			'icons'   => [
				'previous' => forma_icon( 'arrow-left' ),
				'next'     => forma_icon( 'arrow-right' ),
			],
		];
	}

	/**
	 * Enqueue a layout's assets
	 *
	 * @param array $config Layout config
	 */
	public static function enqueue( array $config ) {
		Assets::enqueue( 'forma' );
		SkinManager::enqueue( $config['skin'] );

		LayoutRegistry::get( $config['layout']['type'] )?->enqueue( $config );

		do_action( 'forma_enqueue', $config );
	}

	/**
	 * Assets of every published layout: page builders' editors, which render an element through AJAX where the
	 * styles its layout enqueues never reach the page
	 */
	public static function enqueue_published() {
		foreach ( get_posts( [ 'post_type' => PostTypes::LAYOUT, 'post_status' => 'publish', 'numberposts' => -1, 'fields' => 'ids' ] ) as $id ) {
			$config = Config::get( $id );

			if ( $config ) {
				self::enqueue( $config );
				// Its own CSS too: Elementor builds the widget's HTML in the editor's request, not the preview's
				self::styles( $config );
			}
		}
	}

	/**
	 * Item data every skin can rely on (empty values when the source has none). Pro adds video and audio.
	 *
	 * @param array                          $item   Normalized item
	 * @param array                          $config Layout config
	 * @param Sources\SourceInterface|null $source Source
	 *
	 * @return array
	 */
	private static function prepare( array $item, array $config, $source ) {
		$item += [
			'post_type'      => '',
			'format'         => '',
			'video'          => '',
			'audio'          => '',
			'author'         => [ 'name' => '', 'url' => '', 'avatar' => '' ],
			'comments_count' => 0,
			'comments_url'   => '',
			'count'          => 0,
		];

		$taxonomies = $source ? array_keys( $source->get_taxonomies() ) : [];
		$taxonomy   = $config['filters']['taxonomy'] ?: (string) ( $taxonomies[0] ?? '' );
		$list       = fn( $name ) => array_map(
			fn( $term ) => [
				'id'       => (int) $term->term_id,
				'name'     => $term->name,
				'slug'     => $term->slug,
				// Media labels are no real taxonomy and have no page
				'url'      => taxonomy_exists( $term->taxonomy ) ? (string) get_term_link( $term ) : '',
				'taxonomy' => $term->taxonomy,
			],
			$source && $name ? $source->get_item_terms( $item, $name ) : []
		);

		// Tags: the first taxonomy without levels other than the terms' one (Portfolio Tags, post tags)
		$tags = current( array_filter( $taxonomies, fn( $name ) => $name !== $taxonomy && taxonomy_exists( $name ) && !is_taxonomy_hierarchical( $name ) ) );
		$post = $item['object'] instanceof \WP_Post ? $item['object'] : null;

		$item['terms']    = $list( $taxonomy );
		$item['tags']     = $tags ? $list( $tags ) : [];
		$item['year']     = $post ? get_the_date( 'Y', $post ) : '';
		$item['datetime'] = $post ? get_the_date( 'c', $post ) : '';

		// No image of its own (or one whose file is gone): the placeholder of Settings → Images, never opened in the
		// lightbox
		$item['placeholder'] = false;

		if ( !$item['image_id'] || !wp_attachment_is_image( $item['image_id'] ) ) {
			$item['image_id']    = Placeholder::id();
			$item['placeholder'] = (bool) $item['image_id'];
		}

		$item = (array) apply_filters( 'forma_item_data', $item, $config, $source );

		// The <img> at the layout's size, ready for the skins (item-parts/image.php): built once here, so a plugin or
		// theme changes it in one place (forma_item_image)
		$item['image'] = (string) apply_filters( 'forma_item_image', $item['image_id'] ? wp_get_attachment_image( $item['image_id'], ImageSizes::for_layout( $config ) ) : '', $item, $config );

		return $item;
	}

	/**
	 * Apply the click action (url, target, rel, aria-label). Lightbox links point to the
	 * image file so they work without JS.
	 *
	 * @param array $item   Normalized item
	 * @param array $config Layout config
	 *
	 * @return array [ item, item wrapper attributes, lightbox data HTML ]
	 */
	private static function click( array $item, array $config ) {
		$click = $config['click'];

		$item['url_target']      = '';
		$item['url_rel']         = '';
		$item['aria_label']      = $item['title'];

		if ( 'none' === $click['action'] ) {
			$item['url'] = '';

			return [ $item, '', '' ];
		}

		$lightbox = 'lightbox' === $click['action'] && $item['image_id'] && !$item['placeholder'] && !self::own_link( $item, $config ) && class_exists( '\VLT\Forma\Front\Lightbox' );

		if ( !$lightbox ) {
			if ( 'open' === $click['action'] ) {
				$item['url_target'] = $click['target'];
				$item['url_rel']    = trim( $click['rel'] . ( '_blank' === $click['target'] ? ' noopener' : '' ) );
			}

			return [ $item, '', '' ];
		}

		$image = Lightbox::image( $item['image_id'] );

		if ( !$image ) {
			return [ $item, '', '' ];
		}

		// The item's own page, for the lightbox's Share
		$link        = $item['url'];
		$item['url'] = $image['src'];
		$data        = SkinManager::render_template( 'lightbox/item-data.php', $image + [
			'link'        => $link,
			'title'       => $image['captions'] ? self::lightbox_text( $click['title'], $item ) : '',
			'description' => $image['captions'] ? self::lightbox_text( $click['description'], $item ) : '',
			'item'        => $item,
		] );

		return [ $item, ' data-forma-lightbox="grid"', $data ];
	}

	/**
	 * A text of the lightbox caption, from the source the layout picked (click.title, click.description): the item's
	 * own title or excerpt, or a field of its image in the Media Library
	 *
	 * @param string $source item, excerpt, image_title, image_caption, image_description, image_alt or none
	 * @param array  $item   Item
	 *
	 * @return string Plain text
	 */
	private static function lightbox_text( $source, array $item ) {
		$image = $item['image_id'] ? get_post( $item['image_id'] ) : null;

		switch ( $source ) {
			case 'item':
				return $item['title'];
			case 'excerpt':
				return $item['excerpt'];
			case 'image_title':
				return $image ? get_the_title( $image ) : '';
			case 'image_caption':
				return $image ? wp_strip_all_tags( (string) wp_get_attachment_caption( $image->ID ) ) : '';
			case 'image_description':
				return $image ? wp_strip_all_tags( $image->post_content ) : '';
			case 'image_alt':
				return $image ? (string) get_post_meta( $image->ID, '_wp_attachment_image_alt', true ) : '';
			default:
				return '';
		}
	}

	/**
	 * Whether an image of the Media source has a link of its own in this layout (it keeps it over the lightbox)
	 *
	 * @param array $item   Item
	 * @param array $config Layout config
	 *
	 * @return bool
	 */
	public static function own_link( array $item, array $config ) {
		return 'media' === $config['query']['source'] && !empty( $config['query']['image_data'][ $item['id'] ]['link'] );
	}

	/**
	 * Opening tag of an item's link for skins: <a>, or <div> when the item has no link
	 *
	 * @param array  $item  Item
	 * @param string $class Class
	 *
	 * @return string
	 */
	public static function link_start( array $item, $class = '' ) {
		return SkinManager::render_template( 'grid/link-start.php', [
			'item'  => $item,
			'class' => (string) $class,
		] );
	}

	/**
	 * Closing tag for link_start()
	 *
	 * @param array $item Item
	 *
	 * @return string
	 */
	public static function link_end( array $item ) {
		return SkinManager::render_template( 'grid/link-end.php', [ 'item' => $item ] );
	}

	/**
	 * Image aspect ratio as --vlt-ratio
	 *
	 * @param int $image_id Attachment ID
	 *
	 * @return string ";--vlt-ratio:N" or ''
	 */
	private static function ratio_style( $image_id ) {
		$meta = $image_id ? wp_get_attachment_metadata( $image_id ) : null;

		if ( empty( $meta['width'] ) || empty( $meta['height'] ) ) {
			return '';
		}

		return ';--vlt-ratio:' . round( $meta['width'] / $meta['height'], 4 );
	}

	/**
	 * Max widths, widest first
	 *
	 * @return array [ 'tablet_landscape' => int, 'tablet' => int, 'mobile' => int ] max-widths, widest first
	 */
	public static function breakpoints() {
		$breakpoints = (array) apply_filters( 'forma_breakpoints', Settings::get( 'breakpoints' ) );

		return [
			'tablet_landscape' => absint( $breakpoints['tablet_landscape'] ?? 1200 ),
			'tablet'           => absint( $breakpoints['tablet'] ?? 1024 ),
			'mobile'           => absint( $breakpoints['mobile'] ?? 767 ),
		];
	}

	/**
	 * Render a grid
	 *
	 * @param array $config  Layout config
	 * @param bool  $preview Editor preview
	 *
	 * @return string
	 */
	public static function render( array $config, $preview = false ) {
		self::enqueue( $config );

		// Keeps the same shuffle across pages
		$seed   = 'rand' === $config['query']['orderby'] ? wp_rand( 1, 999999 ) : 0;
		$skip   = $config['query']['skip_shown'] ? self::$shown : [];
		$term   = self::initial_term( $config );
		$sort   = self::initial_sort( $config );
		$result = QueryBuilder::run( $config, self::initial_page( $config ), $term, $seed, '', $skip, $sort );

		// A page past the end (fewer items since the link was made): the first
		if ( !$result['items'] && $result['page'] > 1 ) {
			$result = QueryBuilder::run( $config, 1, $term, $seed, '', $skip, $sort );
		}

		self::$results[ $config['id'] ] = array_intersect_key( $result, array_flip( [ 'page', 'max_pages', 'total' ] ) );
		// Posts and images only: term IDs would match unrelated posts
		self::$shown                      = array_values( array_unique( array_merge( self::$shown, array_column( array_filter( $result['items'], fn( $item ) => 'term' !== $item['type'] ), 'id' ) ) ) );

		$attributes = apply_filters( 'forma_container_attributes', [
			'id'                      => 'forma-' . $config['id'] . '-' . ( ++self::$instances ),
			'class'                   => implode( ' ', array_filter( [
				'forma',
				'forma--' . $config['id'],
				'forma--layout-' . $config['layout']['type'],
				...( LayoutRegistry::get( $config['layout']['type'] )?->classes( $config ) ?? [] ),
				$config['skin'] ? 'forma--skin-' . $config['skin'] : '',
				...Controls::classes( $config ),
			] ) ),
			'data-forma'           => wp_json_encode( [
				'layout'         => $config['id'],
				'page'           => $result['page'],
				'maxPages'       => $result['max_pages'],
				'seed'           => $seed,
				'term'           => $term,
				'sort'           => $sort,
				// A category or tag page's grid stays within its term when it loads more (Portfolio::scope())
				'scope'          => (string) ( $config['query']['scope'] ?? '' ),
				'layoutSettings' => LayoutRegistry::get( $config['layout']['type'] )?->script_settings( $config ) ?? [],
				// Its filter, search and pages leave out the same items
				'skip'           => $skip,
			] ),
			'data-forma-layout'    => $config['id'],
			'data-forma-lightbox-scope' => '',
		], $config );

		$instance = self::$layout_instances[ $config['id'] ] = ( self::$layout_instances[ $config['id'] ] ?? 0 ) + 1;

		// The grid's markup is the plugin's (its classes and attributes drive the layout and the script); only what is
		// inside each card and control comes from templates
		$grid = '<div' . self::attributes( $attributes ) . '>'
			. ( $preview ? '' : self::notice( $config ) )
			. '<div class="forma__items" aria-live="polite">' . ( $preview ? self::preview_items( $config, $result ) : self::render_items( $config, $result ) ) . '</div>'
			. '</div>';

		if ( $config['display']['attach_controls'] ) {
			$controls = [
				'search'  => self::render_search( $config, $instance ),
				'filters' => self::render_filter( $config, $instance ),
				'sort'    => self::render_sort( $config, $instance ),
			];

			$shown  = array_keys( array_filter( $controls, fn( $html ) => '' !== $html ) );
			$places = self::places( $config, $shown );
			$grid   = self::group( self::toolbar( $places['desktop'], $controls ), $grid, self::render_pagination( $config, $instance ), self::toolbar_media( $places ) );
		}

		return self::styles( $config ) . $grid;
	}

	/**
	 * Last preview: 'ok', 'empty' or 'no-skin'
	 *
	 * @var string
	 */
	public static $preview_state = 'ok';

	/**
	 * Preview items, or placeholders when the skin template is missing
	 *
	 * @param array $config Layout config
	 * @param array $result Query result
	 *
	 * @return string
	 */
	private static function preview_items( array $config, array $result ) {
		$has_skin = (bool) SkinManager::locate( $config['skin'], 'template' );

		self::$preview_state = !$result['items'] ? 'empty' : ( $has_skin ? 'ok' : 'no-skin' );

		if ( 'no-skin' !== self::$preview_state ) {
			return self::render_items( $config, $result );
		}

		$layout = LayoutRegistry::get( $config['layout']['type'] );
		$count  = $config['query']['per_page'] > 0 ? min( 12, max( 6, $config['query']['per_page'] ) ) : 9;
		$html   = '';

		for ( $i = 0; $i < $count; $i++ ) {
			// Mixed ratios so Justified shows its shape
			$html .= self::item( $config, null, $i, [ 'forma__item' ], '--vlt-i:' . $i . ';--vlt-ratio:' . [ 1.5, 0.75, 1.33, 1, 1.78 ][ $i % 5 ], '', SkinManager::render_template( 'preview/placeholder.php', [
				'index'  => $i,
				'config' => $config,
			] ), $layout );
		}

		return $html;
	}

	/**
	 * @param array $config Layout config
	 * @param array $result QueryBuilder::run() result
	 *
	 * @return string
	 */
	public static function render_items( array $config, array $result ) {
		if ( !$result['items'] ) {
			$settings = Settings::get( 'messages' );

			if ( !$settings['empty'] ) {
				return '';
			}

			return SkinManager::render_template( 'notices/empty.php', [
				'message' => (string) apply_filters( 'forma_empty_message', $settings['empty_text'] ?: __( 'No items found.', 'forma-grid-gallery' ), $config ),
				'config'  => $config,
			] );
		}

		$layout  = LayoutRegistry::get( $config['layout']['type'] );
		$options = Controls::values( $config );
		$html    = '';
		$batch   = 0;
		// The skin that renders (a missing one falls back to the default), for the card's --style-{id}
		$skin    = SkinManager::locate( $config['skin'], 'template' ) ? ( sanitize_key( $config['skin'] ) ?: 'default' ) : 'default';

		// Restored by hand after the items: wp_reset_postdata() alone misses it when the grid is not in the main loop
		$page_post = $GLOBALS['post'] ?? null;

		foreach ( $result['items'] as $i => $item ) {
			$index  = $result['start'] + $i;
			$number = $index + 1;

			/**
			 * Cells of their own before an item, e.g. a banner between the items
			 *
			 * @param array $cells  [ 'count' => cells before items 1…n-1 (the layout's tile spans count them),
			 *                      'cells' => [ [ 'content' => HTML, 'class' => string ], … ] right before item n ]
			 * @param int   $number Item number, 1-based
			 * @param array $config Layout config
			 */
			$cells  = (array) apply_filters( 'forma_cells', [ 'count' => 0, 'cells' => [] ], $number, $config );
			$visual = $index + (int) ( $cells['count'] ?? 0 );

			foreach ( (array) ( $cells['cells'] ?? [] ) as $cell ) {
				$html .= self::item( $config, null, $visual++, array_filter( [ 'forma__item', 'forma__item--cell', (string) ( $cell['class'] ?? '' ) ] ), '--vlt-i:' . (int) $batch++, '', (string) ( $cell['content'] ?? '' ), $layout );
			}

			// [ item, wrapper attributes, lightbox data HTML ]
			[ $item, $click, $popup ] = apply_filters( 'forma_item_click', self::click( self::prepare( $item, $config, $result['source'] ), $config ), $config );

			// A post item is the current post while its skin runs: template tags (post_class(), get_post_format(),
			// get_field() without an ID) and the_post hooks (WooCommerce's global $product) see it
			$is_post = 'post' === $item['type'] && $item['object'] instanceof \WP_Post;

			if ( $is_post ) {
				$GLOBALS['post'] = $item['object']; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				setup_postdata( $item['object'] );
			}

			$content = SkinManager::render( $config['skin'], [
				'item'       => $item,
				'index'      => $index,
				'config'     => $config,
				'source'     => $result['source'],
				'image_size' => ImageSizes::for_layout( $config ),
				'options'    => $options,
			] );

			if ( $is_post ) {
				wp_reset_postdata();
			}

			// The card's own element is the plugin's: its classes stay whatever a skin prints inside
			$content = '<article class="' . esc_attr( 'forma-card' . ( $item['url'] ? ' forma-card--link' : '' ) . ( $item['image_id'] ? '' : ' forma-card--empty' ) . ' forma-card--style-' . $skin ) . '">' . $content . '</article>';

			// The plugin's own parts of the item next to the card
			$content .= (string) apply_filters( 'forma_item_append', '', $item, $config );

			$classes = (array) apply_filters( 'forma_item_classes', $item['placeholder'] ? [ 'forma__item', 'forma__item--placeholder' ] : [ 'forma__item' ], $item, $config );

			// --vlt-i: position in this batch, for entrance animations
			$html .= apply_filters(
				'forma_item_html',
				self::item( $config, $item, $index, $classes, '--vlt-i:' . (int) $batch++ . self::ratio_style( $item['image_id'] ), $click, $content . $popup, $layout, $visual ),
				$item,
				$config,
				$index,
			);
		}

		$GLOBALS['post'] = $page_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

		return $html;
	}

	/**
	 * @param array                        $config     Layout config
	 * @param array|null                   $item       Item, null for cells and placeholders
	 * @param int                          $index      Position in the whole result
	 * @param array                        $classes    Classes
	 * @param string                       $style      Inline style
	 * @param string                       $attributes Escaped attributes
	 * @param string                       $content    Content
	 * @param Layouts\LayoutInterface|null $layout     Layout type
	 * @param int|null                     $visual     Position for the layout, $index when null
	 *
	 * @return string
	 */
	private static function item( array $config, $item, $index, array $classes, $style, $attributes, $content, $layout, $visual = null ) {
		$classes = array_merge( $classes, $layout ? $layout->item_classes( $visual ?? $index, $config ) : [] );
		$extra   = $layout ? $layout->item_style( $visual ?? $index, $config ) : '';
		$style   = $extra ? rtrim( $style, '; ' ) . ( '' !== $style ? ';' : '' ) . $extra : $style;

		return '<div class="' . esc_attr( implode( ' ', $classes ) ) . '" style="' . esc_attr( $style ) . '"' . $attributes . '>' . $content . '</div>';
	}

	/**
	 * Filter of a layout ([forma_grid show="filter"])
	 *
	 * @param array $config   Layout config
	 * @param int   $instance Grid of this layout it controls, 1-based
	 *
	 * @return string
	 */
	public static function render_filter( array $config, $instance = 1 ) {
		$list = QueryBuilder::filter_terms( $config );

		if ( !$list ) {
			return '';
		}

		self::enqueue( $config );

		$filters = $config['filters'];
		$source  = SourceRegistry::get( $config['query']['source'] );
		$label   = $source ? $source->get_taxonomies()[ $filters['taxonomy'] ] ?? __( 'Filter', 'forma-grid-gallery' ) : __( 'Filter', 'forma-grid-gallery' );
		$terms   = [
			[
				'id'     => 0,
				'name'   => $filters['all_label'] ?: __( 'All', 'forma-grid-gallery' ),
				'count'  => null,
				'active' => true,
			],
		];

		foreach ( $list as $term ) {
			$terms[] = [
				'id'     => $term->term_id,
				'name'   => $term->name,
				'count'  => $filters['show_count'] ? (int) $term->count : null,
				'active' => false,
			];
		}

		// The term the grid starts with (initial_term()) is the active one
		$current = self::initial_term( $config );

		if ( $current ) {
			$terms = array_map( fn( $term ) => [ 'active' => $term['id'] === $current ] + $term, $terms );
		}

		// What the script needs on each chip; a template prints it and adds its own classes after
		$terms = array_map( fn( $term ) => $term + [
			// The count as printed ('' without counts), the name with it for a dropdown
			'count_label' => null !== $term['count'] ? number_format_i18n( $term['count'] ) : '',
			'label'       => $term['name'] . ( null !== $term['count'] ? ' (' . number_format_i18n( $term['count'] ) . ')' : '' ),
			'url'         => FilterLink::url( $config, $term['id'] ),
			'class'       => 'forma-filter__link' . ( $term['active'] ? ' is-active' : '' ),
			'attributes'  => self::attributes( [ 'data-forma-term' => $term['id'] ] + ( $term['active'] ? [ 'aria-current' => 'true' ] : [] ) ),
		], $terms );

		SkinManager::enqueue( $filters['template'], 'filters' );

		$html = self::control( 'div', 'forma-filter forma-filter--align-' . self::zone( $config, 'filters' ), self::attributes( [
			'role'       => 'group',
			'aria-label' => $label,
		] ) . self::link( $config, $instance ), $filters['template'], 'filters', [
			'terms'  => $terms,
			'label'  => $label,
			'config' => $config,
		] );

		return (string) apply_filters( 'forma_filter_html', $html, $terms, $config );
	}

	/**
	 * Term a grid starts filtered by, 0 = all; forma_initial_term sets it (FilterLink: the filter in the page address)
	 *
	 * @param array $config Layout config
	 *
	 * @return int
	 */
	public static function initial_term( array $config ) {
		$term = $config['filters']['enabled'] ? (int) apply_filters( 'forma_initial_term', 0, $config ) : 0;

		return $term && QueryBuilder::is_valid_term( $config, $term ) ? $term : 0;
	}

	/**
	 * Page a paginated grid starts on, 1-based; forma_initial_page sets it (the page in the page address, FilterLink)
	 *
	 * @param array $config Layout config
	 *
	 * @return int
	 */
	public static function initial_page( array $config ) {
		return 'none' !== $config['pagination']['type'] ? max( 1, (int) apply_filters( 'forma_initial_page', 1, $config ) ) : 1;
	}

	/**
	 * Visitor's order a grid starts with, '' = the layout's own; forma_initial_sort sets it (FilterLink: the sort in the
	 * page address), one of the layout's sort options
	 *
	 * @param array $config Layout config
	 *
	 * @return string Key of QueryBuilder::SORTS or ''
	 */
	public static function initial_sort( array $config ) {
		$sort = $config['sort']['enabled'] ? (string) apply_filters( 'forma_initial_sort', '', $config ) : '';

		return in_array( $sort, $config['sort']['options'], true ) ? $sort : '';
	}

	/**
	 * Search of a layout ([forma_grid show="search"])
	 *
	 * @param array $config   Layout config
	 * @param int   $instance Grid of this layout it controls
	 *
	 * @return string
	 */
	public static function render_search( array $config, $instance = 1 ) {
		if ( !$config['search']['enabled'] ) {
			return '';
		}

		self::enqueue( $config );

		$search = $config['search'];

		SkinManager::enqueue( $search['template'], 'search' );

		$html = self::control( 'div', 'forma-search forma-search--align-' . self::zone( $config, 'search' ), self::link( $config, $instance ), $search['template'], 'search', [
			'placeholder' => $search['placeholder'] ?: __( 'Search…', 'forma-grid-gallery' ),
			'label'       => __( 'Search', 'forma-grid-gallery' ),
			'config'      => $config,
		] );

		return (string) apply_filters( 'forma_search_html', $html, $config );
	}

	/**
	 * Sort select of a layout ([forma_grid show="sort"])
	 *
	 * @param array $config   Layout config
	 * @param int   $instance Grid of this layout it controls
	 *
	 * @return string
	 */
	public static function render_sort( array $config, $instance = 1 ) {
		$sort = $config['sort'];

		if ( !$sort['enabled'] || !$sort['options'] ) {
			return '';
		}

		self::enqueue( $config );

		SkinManager::enqueue( $sort['template'], 'sort' );

		$labels  = QueryBuilder::sorts( SourceRegistry::get( $config['query']['source'] ) );
		$own     = QueryBuilder::sort_key( $config['query'] );
		// The order the grid starts with (initial_sort()), else its own
		$current = self::initial_sort( $config ) ?: $own;
		$options = [];

		// The layout's own order comes first when the list doesn't have it
		if ( !in_array( $own, $sort['options'], true ) ) {
			$options[] = [
				'value'  => '',
				'label'  => $sort['default_label'] ?: __( 'Default order', 'forma-grid-gallery' ),
				'active' => $current === $own,
			];
		}

		foreach ( $sort['options'] as $key ) {
			$options[] = [
				'value'  => $key,
				'label'  => $labels[ $key ],
				'active' => $key === $current,
			];
		}

		$label = __( 'Sort by', 'forma-grid-gallery' );
		$html  = self::control( 'div', 'forma-sort forma-sort--align-' . self::zone( $config, 'sort' ), self::attributes( [
			'role'       => 'group',
			'aria-label' => $label,
		] ) . self::link( $config, $instance ), $sort['template'], 'sort', [
			'options' => $options,
			'label'   => $label,
			'config'  => $config,
		] );

		return (string) apply_filters( 'forma_sort_html', $html, $options, $config );
	}

	/**
	 * Pagination of a layout ([forma_grid show="pagination"]); the wrapper is printed even when empty for AJAX
	 *
	 * @param array $config   Layout config
	 * @param int   $instance Grid of this layout it controls
	 *
	 * @return string
	 */
	public static function render_pagination( array $config, $instance = 1 ) {
		if ( 'none' === $config['pagination']['type'] ) {
			return '';
		}

		self::enqueue( $config );

		SkinManager::enqueue( $config['pagination']['template'], 'pagination' );

		// Placed before the grid or without it
		if ( !isset( self::$results[ $config['id'] ] ) ) {
			self::$results[ $config['id'] ] = array_intersect_key( QueryBuilder::run( $config, self::initial_page( $config ), self::initial_term( $config ), 0, '', self::$shown, self::initial_sort( $config ) ), array_flip( [ 'page', 'max_pages', 'total' ] ) );
		}

		return self::pagination_html( $config, self::$results[ $config['id'] ], $instance );
	}

	/**
	 * Pagination of a page, its wrapper included; also returned by AJAX, which takes the place of the old one with it
	 * (the script keeps the old one's data-forma-for and data-forma-instance)
	 *
	 * @param array $config   Layout config
	 * @param array $result   QueryBuilder::run() result ( page, max_pages, total )
	 * @param int   $instance Grid of this layout it controls
	 *
	 * @return string
	 */
	public static function pagination_html( array $config, array $result, $instance = 1 ) {
		$page     = $result['page'];
		$max      = $result['max_pages'];
		$total    = $result['total'];
		$per_page = $config['query']['per_page'];
		// Items of this page (numbers), or loaded so far (Load More: pages 1 to this one)
		$to = -1 === $per_page ? $total : min( $page * $per_page, $total );
		$type = $config['pagination']['type'];
		$from = $total ? ( -1 === $per_page ? 1 : ( $page - 1 ) * $per_page + 1 ) : 0;

		$data = [
			'type'      => $type,
			'page'      => $page,
			'max_pages' => $max,
			// Page numbers: prev, the numbers and gaps, next
			'items'     => 'numbers' === $type ? self::page_items( $page, $max ) : [],
			// Load More: the button
			'more'      => 'numbers' !== $type ? self::more_item( $config, $page, $max ) : [],
			'total'     => $total,
			'from'      => $from,
			'to'        => $to,
			// Share shown, 0–1: a theme can draw a bar from it (--forma-progress on .forma-pagination__count)
			'progress'  => $total ? round( $to / $total, 4 ) : 0,
			// "5–6 of 14" (page numbers) or "Showing 6 of 14 items", its numbers in spans
			'count'     => self::count_html( $type, $total, $from, $to ),
			// Every item shown and the layout hides the pagination then
			'ended'     => $page >= $max && $config['pagination']['hide_end'],
		];

		$class      = 'forma-pagination forma-pagination--align-' . $config['pagination']['align'];
		$attributes = self::attributes( [ 'aria-label' => __( 'Pagination', 'forma-grid-gallery' ) ] ) . self::link( $config, $instance );

		// A single page shows nothing, nor the end when the layout hides it: an empty wrapper, for AJAX to fill
		if ( $max < 2 || $data['ended'] ) {
			return (string) apply_filters( 'forma_pagination_html', '<nav class="' . esc_attr( $class ) . '"' . $attributes . '></nav>', $data, $config );
		}

		$html = self::control( 'nav', $class, $attributes, $config['pagination']['template'], 'pagination', [
			'data'   => $data,
			'config' => $config,
		], self::pagination_types()[ $data['type'] ] ?? 'numbers.php' );

		return (string) apply_filters( 'forma_pagination_html', $html, $data, $config );
	}

	/**
	 * Pagination types and their template, one per type so each can be overridden on its own; an add-on adds a type
	 * of the Load More kind (its button) with forma_pagination_types
	 *
	 * @return array [ type => template file ]
	 */
	public static function pagination_types() {
		return array_map( 'sanitize_file_name', (array) apply_filters( 'forma_pagination_types', [
			'numbers'  => 'numbers.php',
			'loadmore' => 'load-more.php',
		] ) );
	}

	/**
	 * The pagination's count, ready to print: "5–6 of 14" for page numbers, "Showing 6 of 14 items" for Load More
	 *
	 * @param string $type  Pagination type
	 * @param int    $total All items
	 * @param int    $from  First item shown
	 * @param int    $to    Last item shown (Load More: items loaded)
	 *
	 * @return string HTML
	 */
	private static function count_html( $type, $total, $from, $to ) {
		$span = fn( $part, $number ) => '<span class="forma-pagination__count-' . $part . '">' . esc_html( number_format_i18n( $number ) ) . '</span>';

		if ( 'numbers' === $type ) {
			/* translators: 1: first item shown, 2: last item shown, 3: all items */
			return sprintf( esc_html__( '%1$s–%2$s of %3$s', 'forma-grid-gallery' ), $span( 'from', $from ), $span( 'to', $to ), $span( 'total', $total ) );
		}

		/* translators: 1: items shown, 2: all items */
		return sprintf( esc_html( _n( 'Showing %1$s of %2$s item', 'Showing %1$s of %2$s items', $total, 'forma-grid-gallery' ) ), $span( 'to', $to ), $span( 'total', $total ) );
	}

	/**
	 * Page numbers for the template: the classes, link and attributes the script needs come with each, the template
	 * adds its own classes after them
	 *
	 * @param int $page Current page
	 * @param int $max  Max pages
	 *
	 * @return array [ [ type (prev | page | gap | next), class, url ('' = a span), label, attributes ], … ]
	 */
	private static function page_items( $page, $max ) {
		$step = function ( $type, $number ) use ( $max ) {
			$exists = $number >= 1 && $number <= $max;

			return [
				'type'       => $type,
				'class'      => 'forma-pagination__link forma-pagination__link--step forma-pagination__link--' . $type . ( $exists ? '' : ' is-disabled' ),
				'url'        => $exists ? FilterLink::page_url( $number ) : '',
				'label'      => 'prev' === $type ? __( 'Prev', 'forma-grid-gallery' ) : __( 'Next', 'forma-grid-gallery' ),
				'attributes' => self::attributes( $exists ? [
					'data-forma-page' => $number,
					'rel'             => $type,
					'aria-label'      => 'prev' === $type ? __( 'Previous page', 'forma-grid-gallery' ) : __( 'Next page', 'forma-grid-gallery' ),
				] : [ 'aria-hidden' => 'true' ] ),
			];
		};

		$items = [ $step( 'prev', $page - 1 ) ];

		foreach ( self::page_list( $page, $max ) as $number ) {
			if ( null === $number ) {
				$items[] = [
					'type'       => 'gap',
					'class'      => 'forma-pagination__gap',
					'url'        => '',
					'label'      => '…',
					'attributes' => self::attributes( [ 'aria-hidden' => 'true' ] ),
				];
			} else {
				$items[] = [
					'type'       => 'page',
					'class'      => 'forma-pagination__link' . ( $number === $page ? ' is-current' : '' ),
					'url'        => $number === $page ? '' : FilterLink::page_url( $number ),
					'label'      => number_format_i18n( $number ),
					'attributes' => self::attributes( $number === $page ? [ 'aria-current' => 'page' ] : [
						'data-forma-page' => $number,
						/* translators: %s: page number */
						'aria-label'      => sprintf( __( 'Page %s', 'forma-grid-gallery' ), number_format_i18n( $number ) ),
					] ),
				];
			}
		}

		$items[] = $step( 'next', $page + 1 );

		return $items;
	}

	/**
	 * Load More button for the template, as page_items(): a link to the next page, or a disabled button once
	 * everything is in
	 *
	 * @param array $config Layout config
	 * @param int   $page   Current page
	 * @param int   $max    Max pages
	 *
	 * @return array [ class, url ('' when everything is loaded), label, loading, end, attributes ]
	 */
	private static function more_item( array $config, $page, $max ) {
		$pagination = $config['pagination'];
		$ended      = $page >= $max;

		$more = [
			'class'      => 'forma-pagination__more' . ( $ended ? ' forma-pagination__more--done' : '' ),
			'url'        => $ended ? '' : FilterLink::page_url( $page + 1 ),
			'label'      => $pagination['load_more_label'] ?: __( 'Load More', 'forma-grid-gallery' ),
			'loading'    => $pagination['loading_label'] ?: __( 'Loading…', 'forma-grid-gallery' ),
			'end'        => $pagination['no_more_label'] ?: __( 'No more items', 'forma-grid-gallery' ),
			// The script loads the next page on it
			'attributes' => $ended ? '' : self::attributes( [ 'data-forma-more' => '' ] ),
		];

		/**
		 * The button of a pagination type of the Load More kind (see pagination_types())
		 *
		 * @param array $more   [ class, url, label, loading, end, attributes (escaped) ]
		 * @param array $config Layout config
		 * @param bool  $ended  Everything is loaded
		 */
		return (array) apply_filters( 'forma_pagination_more', $more, $config, $ended );
	}

	/**
	 * Page numbers to show: first, last, current ±1; null marks a gap
	 *
	 * @param int $page Current page
	 * @param int $max  Max pages
	 *
	 * @return array
	 */
	private static function page_list( $page, $max ) {
		$pages = array_unique( array_filter( [ 1, $page - 1, $page, $page + 1, $max ], fn( $p ) => $p >= 1 && $p <= $max ) );
		sort( $pages );

		$list = [];
		$prev = 0;

		foreach ( $pages as $p ) {
			if ( $p - $prev === 2 ) {
				$list[] = $p - 1;
			} elseif ( $p - $prev > 2 ) {
				$list[] = null;
			}

			$list[] = $p;
			$prev   = $p;
		}

		return $list;
	}

	/**
	 * Places of the shown controls on every device: a device without any placed takes the wider one's; a control
	 * without a place goes on row 1, the filter in the center when it is alone, else on the left, the others right
	 *
	 * @param array $config Layout config
	 * @param array $shown  Controls shown (Config::TOOLBAR_CONTROLS)
	 *
	 * @return array [ device => [ place => controls ] ]
	 */
	private static function places( array $config, array $shown ) {
		$devices = [];
		$base    = [];

		foreach ( Config::DEVICES as $device ) {
			$own = (array) ( $config[ Config::toolbar_key( $device ) ] ?? [] );

			if ( array_filter( $own ) ) {
				$base = $own;
			}

			$places = array_fill_keys( Config::TOOLBAR_PLACES, [] );

			foreach ( Config::TOOLBAR_PLACES as $place ) {
				$places[ $place ] = array_values( array_intersect( (array) ( $base[ $place ] ?? [] ), $shown ) );
			}

			foreach ( array_diff( $shown, array_merge( ...array_values( $places ) ) ) as $control ) {
				$places[ 'filters' !== $control ? '1-right' : ( 1 === count( $shown ) ? '1-center' : '1-left' ) ][] = $control;
			}

			$devices[ $device ] = $places;
		}

		return $devices;
	}

	/**
	 * Rows of the toolbar above the grid: each control in its row and zone, in its order there
	 *
	 * @param array $places   [ place => controls ] (places())
	 * @param array $controls [ control => HTML ]
	 *
	 * @return array [ [ class, zones => [ [ class, html ], … ] ], … ], rows and zones without a control left out
	 */
	private static function toolbar( array $places, array $controls ) {
		$rows = [];

		foreach ( $places as $place => $list ) {
			[ $row, $zone ] = explode( '-', $place );

			foreach ( $list as $control ) {
				$rows[ $row ][ $zone ] = ( $rows[ $row ][ $zone ] ?? '' ) . $controls[ $control ];
			}
		}

		// Each row with its classes (the zones it holds) and its zones with theirs
		return array_map( fn( $zones ) => [
			'class' => 'forma-toolbar' . implode( '', array_map( fn( $zone ) => ' forma-toolbar--' . $zone, array_keys( $zones ) ) ),
			'zones' => array_map( fn( $zone, $html ) => [
				'class' => 'forma-toolbar__zone forma-toolbar__zone--' . $zone,
				'html'  => $html,
			], array_keys( $zones ), $zones ),
		], array_values( $rows ) );
	}

	/**
	 * Places of each device by its width range, for grid.js to move the controls into; '' when every device has the
	 * desktop's
	 *
	 * @param array $devices [ device => places ] (places())
	 *
	 * @return string JSON [ [ media query, places ], … ]
	 */
	private static function toolbar_media( array $devices ) {
		if ( 1 === count( array_unique( array_map( 'wp_json_encode', $devices ) ) ) ) {
			return '';
		}

		$breakpoints = self::breakpoints();
		$ranges      = [
			'desktop'          => sprintf( '(min-width:%dpx)', $breakpoints['tablet_landscape'] + 1 ),
			'tablet_landscape' => sprintf( '(min-width:%dpx) and (max-width:%dpx)', $breakpoints['tablet'] + 1, $breakpoints['tablet_landscape'] ),
			'tablet'           => sprintf( '(min-width:%dpx) and (max-width:%dpx)', $breakpoints['mobile'] + 1, $breakpoints['tablet'] ),
			'mobile'           => sprintf( '(max-width:%dpx)', $breakpoints['mobile'] ),
		];

		return (string) wp_json_encode( array_map( fn( $device ) => [ $ranges[ $device ], array_filter( $devices[ $device ] ) ], array_keys( $devices ) ) );
	}

	/**
	 * A control: its element is the plugin's (classes, role, the attributes that link it to its grid, the style's
	 * --style-{id}), the template of its style prints what is inside
	 *
	 * @param string $tag        div or nav
	 * @param string $class      Base classes
	 * @param string $attributes Escaped attributes
	 * @param string $style      Style ID
	 * @param string $kind       filters, search, sort or pagination
	 * @param array  $vars       Template variables
	 * @param string $file       Template file of the style ('' = the kind's)
	 *
	 * @return string
	 */
	private static function control( $tag, $class, $attributes, $style, $kind, array $vars, $file = '' ) {
		// The style that renders (a missing one falls back to the default)
		$id    = SkinManager::locate_file( SkinManager::path( $style, $kind, $file ) ) ? ( sanitize_key( (string) $style ) ?: 'default' ) : 'default';
		$block = 'filters' === $kind ? 'filter' : $kind;

		return '<' . $tag . ' class="' . esc_attr( $class . ' forma-' . $block . '--style-' . $id ) . '"' . $attributes . '>'
			. SkinManager::render( $style, $vars, $kind, $file )
			. '</' . $tag . '>';
	}

	/**
	 * A grid with its controls (Shortcodes → "Output search, filter, sort and pagination with the grid"): the toolbar
	 * rows above, the pagination below
	 *
	 * @param array  $toolbar Rows (toolbar())
	 * @param string $grid    Grid HTML
	 * @param string $footer  Pagination HTML, '' = none
	 * @param string $media   Places per device (toolbar_media()), '' = the same on every device
	 *
	 * @return string
	 */
	private static function group( array $toolbar, $grid, $footer, $media = '' ) {
		$header = '';

		foreach ( $toolbar as $row ) {
			$zones = '';

			foreach ( $row['zones'] as $zone ) {
				$zones .= '<div class="' . esc_attr( $zone['class'] ) . '">' . $zone['html'] . '</div>';
			}

			$header .= '<div class="' . esc_attr( $row['class'] ) . '">' . $zones . '</div>';
		}

		return '<div class="forma-group">'
			. ( $header ? '<div class="forma-group__header"' . ( $media ? ' data-forma-toolbar="' . esc_attr( $media ) . '"' : '' ) . '>' . $header . '</div>' : '' )
			. $grid
			. ( $footer ? '<div class="forma-group__footer">' . $footer . '</div>' : '' )
			. '</div>';
	}

	/**
	 * Zone of a control in the toolbar, its alignment where it stands alone
	 *
	 * @param array  $config  Layout config
	 * @param string $control search | filters | sort
	 *
	 * @return string left | center | right
	 */
	private static function zone( array $config, $control ) {
		$enabled = array_values( array_filter( Config::TOOLBAR_CONTROLS, fn( $item ) => !empty( $config[ $item ]['enabled'] ) ) );

		foreach ( self::places( $config, $enabled )['desktop'] as $place => $list ) {
			if ( in_array( $control, $list, true ) ) {
				return explode( '-', $place )[1];
			}
		}

		return 'left';
	}


	/**
	 * Attributes linking a control to its grid
	 *
	 * @param array $config   Layout config
	 * @param int   $instance Grid instance
	 *
	 * @return string
	 */
	private static function link( array $config, $instance ) {
		return self::attributes( [
			'data-forma-for'      => $config['id'],
			'data-forma-instance' => max( 1, (int) $instance ),
		] );
	}

	/**
	 * Build an attribute string
	 *
	 * @param array $attributes Attributes
	 *
	 * @return string
	 */
	private static function attributes( array $attributes ) {
		$html = '';

		foreach ( $attributes as $name => $value ) {
			$html .= ' ' . esc_attr( $name ) . '="' . esc_attr( $value ) . '"';
		}

		return $html;
	}

	/**
	 * Layout CSS, once per layout per page, as an inline style of the forma-{id} handle
	 *
	 * @param array $config Layout config
	 *
	 * @return string The style tag when the page can no longer print it, otherwise ''
	 */
	public static function styles( array $config ) {
		if ( isset( self::$printed[ $config['id'] ] ) ) {
			return '';
		}

		self::$printed[ $config['id'] ] = true;

		$scope       = '.forma--' . $config['id'];
		$responsive  = $config['responsive'];
		$breakpoints = self::breakpoints();
		$vars        = fn( $device ) => sprintf(
			'--forma-cols:%s;--forma-gap-x:%dpx;--forma-gap-y:%dpx',
			'auto' === $responsive['columns'][ $device ] ? 'auto' : (int) $responsive['columns'][ $device ],
			$responsive['gap_x'][ $device ],
			$responsive['gap_y'][ $device ],
		);

		$css = $scope . '{' . $vars( 'desktop' ) . '}';

		foreach ( $breakpoints as $device => $max_width ) {
			$css .= sprintf( '@media (max-width:%dpx){%s{%s}}', $max_width, $scope, $vars( $device ) );
		}

		// Read by scrollIntoView() when page numbers bring the grid back into view
		if ( $config['pagination']['scroll_offset'] ) {
			$css .= sprintf( '%s{scroll-margin-top:%dpx}', $scope, $config['pagination']['scroll_offset'] );
		}

		$layout = LayoutRegistry::get( $config['layout']['type'] );
		$css   .= $layout ? $layout->css( $config, $scope, $breakpoints ) : '';
		// In the preview, between markers: the editor swaps the theme controls' CSS live (live-css.js), no reload
		$css   .= Preview::active() ? '/*forma-controls*/' . Controls::css( $config, $scope, $breakpoints ) . '/*/forma-controls*/' : Controls::css( $config, $scope, $breakpoints );
		$css   .= Animations::css( $config, $scope );
		$css    = (string) apply_filters( 'forma_layout_css', $css, $config, $scope, $breakpoints );
		// Last, so it wins over the layout's own rules; the preview passes the unsaved CSS
		$css   .= CssScoper::scope( $config['custom_css'] ?? (string) get_post_meta( $config['id'] ?? 0, PostTypes::META_CSS, true ), $scope );

		$handle = 'forma-' . $config['id'];

		wp_register_style( $handle, false, [ 'forma' ], FORMA_VERSION );
		wp_add_inline_style( $handle, $css );

		// Before the footer the page prints it (in <head>, or with the late styles); an AJAX / REST render has no page
		if ( !did_action( 'wp_print_footer_scripts' ) && !wp_doing_ajax() && !wp_is_serving_rest_request() ) {
			wp_enqueue_style( $handle );

			return '';
		}

		ob_start();
		wp_print_styles( $handle );

		return ob_get_clean();
	}

	/**
	 * Notice for editors when the skin template is missing
	 *
	 * @param array $config Layout config
	 *
	 * @return string
	 */
	private static function notice( array $config ) {
		if ( SkinManager::locate( $config['skin'], 'template' ) || !current_user_can( 'edit_theme_options' ) ) {
			return '';
		}

		return SkinManager::render_template( 'notices/notice.php', [
			/* translators: %s: template path */
			'message' => sprintf( __( 'Forma: the skin template %s is missing.', 'forma-grid-gallery' ), SkinManager::path( $config['skin'] ) ),
			'config'  => $config,
		] );
	}

	/**
	 * Notice for editors where a block or widget shows a part the layout has turned off
	 *
	 * @param string $part filter, search, sort or pagination
	 *
	 * @return string
	 */
	public static function part_off( $part ) {
		$parts = [
			'filter'     => __( 'The filter is off', 'forma-grid-gallery' ),
			'search'     => __( 'The search is off', 'forma-grid-gallery' ),
			'sort'       => __( 'The sorting is off', 'forma-grid-gallery' ),
			'pagination' => __( 'The pagination is off', 'forma-grid-gallery' ),
		];

		return SkinManager::render_template( 'notices/part-off.php', [
			'part'    => $part,
			'title'   => $parts[ $part ] ?? $parts['filter'],
			'message' => __( 'Turn it on in this Grid Layout to show it here. Visitors see nothing in its place.', 'forma-grid-gallery' ),
		] );
	}
}
