<?php

namespace VLT\Forma\Front;

use VLT\Forma\Core\IdList;
use VLT\Forma\Layouts\LayoutRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Forma templates. Any file in templates/ can be overridden at your-theme/forma/{path}.
 *
 *     skins/       one folder per card style: skin.php (+ style.css, script.js)
 *     item-parts/  pieces skins print with forma_item_part()
 *     controls/    filters/ pagination/ search/ sort/, one folder per style
 *     grid/ lightbox/ notices/ preview/ icons/ layouts/
 *
 * Structural markup (grid, items, card <article>, control elements) is printed by Renderer, so a template can't
 * lose it. A theme's copy of a built-in template doesn't get the plugin's style.css.
 *
 *     add_filter( 'forma_filters_styles', fn( $styles ) => $styles + [ 'pills' => 'Pills' ] );
 *     add_filter( 'forma_skins_styles', fn( $styles ) => $styles + [ 'work-1' => [ 'label' => 'Style 1', 'group' => 'Work' ] ] );
 *     add_filter( 'forma_default_styles', '__return_false' );   // drop the plugin's own look
 *     add_filter( 'forma_exclude_styles', fn( $ids, $kind ) => 'skins' === $kind ? [ 'default', 'fade' ] : $ids, 10, 2 );
 */
class SkinManager {
	/**
	 * Folder => template file (pagination: one file per type, the renderer names it; numbers.php is the main one)
	 */
	const KINDS = [
		'skins'      => 'skin.php',
		'filters'    => 'filter.php',
		'pagination' => 'numbers.php',
		'search'     => 'search.php',
		'sort'       => 'sort.php',
		'layouts'    => 'layout.php',
	];

	/**
	 * Styles that ship with the plugin, listed before the theme's: [ kind => [ id, … ] ]
	 */
	const BUILT_IN = [
		'skins'      => [ 'default', 'fade', 'overlay', 'caption', 'minimal', 'magazine', 'polaroid', 'glass', 'mono' ],
		'filters'    => [ 'default', 'dropdown' ],
		'pagination' => [ 'default' ],
		'sort'       => [ 'default', 'dropdown' ],
	];

	/**
	 * Built-in style a new layout starts with, when it isn't "default"
	 */
	const BUILT_IN_DEFAULT = [
		'sort' => 'dropdown',
	];

	/**
	 * Folder of a kind in templates/ (and in your-theme/forma/), when it isn't the kind itself
	 */
	const FOLDERS = [
		'filters'    => 'controls/filters',
		'pagination' => 'controls/pagination',
		'search'     => 'controls/search',
		'sort'       => 'controls/sort',
	];

	/**
	 * Optional files next to a style's template
	 */
	const FILES = [
		'style'  => 'style.css',
		'script' => 'script.js',
	];

	/**
	 * Child theme, parent theme, plugin
	 *
	 * @return array [ [ path, url ], … ]
	 */
	public static function roots() {
		$relative = 'forma/';
		$roots    = [ [ trailingslashit( get_stylesheet_directory() ) . $relative, trailingslashit( get_stylesheet_directory_uri() ) . $relative ] ];

		if ( get_template_directory() !== get_stylesheet_directory() ) {
			$roots[] = [ trailingslashit( get_template_directory() ) . $relative, trailingslashit( get_template_directory_uri() ) . $relative ];
		}

		$roots[] = [ FORMA_PATH . 'templates/', FORMA_URL . 'templates/' ];

		return $roots;
	}

	/**
	 * Locate a file in the templates tree
	 *
	 * @param string $relative Path, e.g. controls/filters/default/filter.php
	 *
	 * @return array|null [ path, url ]
	 */
	public static function locate_file( $relative ) {
		// No way out of the tree
		if ( !preg_match( '#^[a-z0-9_-]+(?:/[a-z0-9_-]+)*\.(?:php|css|js|svg)$#', $relative ) ) {
			return null;
		}

		$found = null;

		foreach ( self::roots() as [ $path, $url ] ) {
			if ( is_file( $path . $relative ) ) {
				$found = [ $path . $relative, $url . $relative ];
				break;
			}
		}

		// [ path, url ]
		$found = apply_filters( 'forma_template', $found, $relative );

		return is_array( $found ) && !empty( $found[0] ) && is_file( $found[0] ) ? $found : null;
	}

	/**
	 * Render a template
	 *
	 * @param string $relative Path, e.g. notices/empty.php
	 * @param array  $vars     Variables
	 *
	 * @return string
	 */
	public static function render_template( $relative, array $vars ) {
		$template = self::locate_file( $relative );

		if ( !$template ) {
			return '';
		}

		$vars = (array) apply_filters( 'forma_template_vars', $vars, $relative );

		ob_start();

		( static function ( $__template, $__vars ) {
			extract( $__vars, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
			include $__template;
		} )( $template[0], $vars );

		return (string) ob_get_clean();
	}

	/**
	 * An icon of templates/icons/, the theme's copy first
	 *
	 * @param string $name  File name without .svg, e.g. arrow-left
	 * @param string $class Class added to the <svg>
	 *
	 * @return string SVG markup, hidden from screen readers ('' when there is no such icon)
	 */
	public static function icon( $name, $class = '' ) {
		static $cache = [];

		$key = $name . '|' . $class;

		if ( !isset( $cache[ $key ] ) ) {
			$file = self::locate_file( 'icons/' . sanitize_key( $name ) . '.svg' );
			$svg  = $file ? trim( (string) file_get_contents( $file[0] ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file
			$svg  = preg_replace( '#^.*?(?=<svg[\s>])#s', '', $svg );

			if ( $svg ) {
				$svg = preg_replace( '#^<svg#', '<svg aria-hidden="true" focusable="false"' . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' ), $svg );
			}

			$cache[ $key ] = (string) apply_filters( 'forma_icon', $svg, $name, $class );
		}

		return $cache[ $key ];
	}

	/**
	 * Registered styles of a kind
	 *
	 * @param string $kind Kind (key of KINDS)
	 *
	 * @return array [ id => label ] ('' is not listed: it is the default of filters, search, sort and pagination)
	 */
	public static function styles( $kind = 'skins' ) {
		return wp_list_pluck( self::registered( $kind ), 'label' );
	}

	/**
	 * Registered styles of a kind with their group: a style is registered with its label, or with
	 * [ 'label' => …, 'group' => … ] to be listed under that group in the editor; a card style made for given layout
	 * types only adds 'layouts' => [ 'list' ] (offered there alone, see fits())
	 *
	 * @param string $kind Kind (key of KINDS)
	 *
	 * @return array [ id => [ 'label' => string, 'group' => string, 'layouts' => string[] ] ]
	 */
	public static function registered( $kind = 'skins' ) {
		if ( !isset( self::KINDS[ $kind ] ) ) {
			return [];
		}

		$clean = [];

		foreach ( (array) apply_filters( 'forma_' . $kind . '_styles', [] ) as $id => $style ) {
			$id    = sanitize_key( $id );
			$style = is_array( $style ) ? $style : [ 'label' => $style ];

			if ( $id ) {
				$clean[ $id ] = [
					'label'   => wp_strip_all_tags( (string) ( $style['label'] ?? '' ) ) ?: ucfirst( $id ),
					'group'   => wp_strip_all_tags( (string) ( $style['group'] ?? '' ) ),
					'layouts' => array_values( array_filter( array_map( 'sanitize_key', (array) ( $style['layouts'] ?? [] ) ) ) ),
				];
			}
		}

		// The built-in styles first, next to the theme's (a theme may register one to rename it), in groups
		$clean = array_map( fn( $style ) => [ 'group' => $style['group'] ?: __( 'Theme', 'forma-grid-gallery' ) ] + $style, $clean );

		$clean = array_merge( self::built_in( $kind ), $clean );

		// Narrowed by ID: forma_include_styles keeps only these (in this order), forma_exclude_styles drops these
		return IdList::apply(
			$clean,
			(array) apply_filters( 'forma_include_styles', [], $kind ),
			(array) apply_filters( 'forma_exclude_styles', [], $kind )
		);
	}

	/**
	 * A card style fits a layout type: one made for given types fits those; any other fits the types that don't take
	 * only marked styles (a type's editor_data() 'marked_skins')
	 *
	 * @param string $id     Card style ID
	 * @param string $layout Layout type ID
	 *
	 * @return bool
	 */
	public static function fits( $id, $layout ) {
		$layouts = self::registered()[ $id ]['layouts'] ?? [];

		return $layouts ? in_array( $layout, $layouts, true ) : empty( LayoutRegistry::get( $layout )?->editor_data()['marked_skins'] );
	}

	/**
	 * The card style for a layout type: the one chosen when it fits, else the first that does
	 *
	 * @param string $id     Card style ID
	 * @param string $layout Layout type ID
	 *
	 * @return string
	 */
	public static function for_layout( $id, $layout ) {
		if ( self::fits( $id, $layout ) ) {
			return $id;
		}

		foreach ( array_keys( self::registered() ) as $other ) {
			if ( self::fits( (string) $other, $layout ) ) {
				return (string) $other;
			}
		}

		return $id;
	}

	/**
	 * Style a new layout starts with: the theme's first one; without theme styles the built-in default ('' for search
	 * and pagination)
	 *
	 * @param string $kind Kind
	 *
	 * @return string
	 */
	public static function default_style( $kind = 'skins' ) {
		$ids = array_keys( self::styles( $kind ) );

		// The theme's first, else the built-in default
		if ( self::built_in( $kind ) ) {
			return (string) ( array_values( array_diff( $ids, array_keys( self::built_in( $kind ) ) ) )[0] ?? self::BUILT_IN_DEFAULT[ $kind ] ?? 'default' );
		}

		return (string) ( $ids[0] ?? '' );
	}

	/**
	 * Whether a style is one the plugin ships ('' = the default)
	 *
	 * @param string $id   Style ID
	 * @param string $kind Kind
	 *
	 * @return bool
	 */
	public static function is_built_in( $id, $kind ) {
		$id = (string) $id ?: 'default';

		return 'default' === $id || isset( self::built_in( $kind )[ $id ] );
	}

	/**
	 * The styles the plugin ships for a kind; an add-on adds its own with forma_built_in_styles, a label or
	 * [ 'label', 'group', 'layouts' ] each (layouts: the layout types a card style is made for, see fits())
	 *
	 * @param string $kind Kind
	 *
	 * @return array [ id => [ 'label' => string, 'group' => string, 'layouts' => string[] ] ]
	 */
	public static function built_in( $kind ) {
		$labels = [
			'default'  => __( 'Default', 'forma-grid-gallery' ),
			'dropdown' => __( 'Dropdown', 'forma-grid-gallery' ),
			'fade'     => __( 'Fade', 'forma-grid-gallery' ),
			'overlay'  => __( 'Overlay', 'forma-grid-gallery' ),
			'caption'  => __( 'Caption', 'forma-grid-gallery' ),
			'minimal'  => __( 'Minimal', 'forma-grid-gallery' ),
			'magazine' => __( 'Magazine', 'forma-grid-gallery' ),
			'polaroid' => __( 'Polaroid', 'forma-grid-gallery' ),
			'glass'    => __( 'Glass', 'forma-grid-gallery' ),
			'mono'     => __( 'Mono', 'forma-grid-gallery' ),
		];
		$styles = [];

		foreach ( self::BUILT_IN[ $kind ] ?? [] as $id ) {
			$styles[ $id ] = $labels[ $id ];
		}

		$built = [];

		foreach ( (array) apply_filters( 'forma_built_in_styles', $styles, $kind ) as $id => $style ) {
			$style        = is_array( $style ) ? $style : [ 'label' => $style ];
			$built[ $id ] = [
				'label'   => (string) ( $style['label'] ?? $id ),
				'group'   => (string) ( $style['group'] ?? '' ) ?: __( 'Forma', 'forma-grid-gallery' ),
				'layouts' => array_values( (array) ( $style['layouts'] ?? [] ) ),
			];
		}

		return $built;
	}

	/**
	 * A built-in style the theme hasn't overridden: the plugin's template, so its markup takes the plugin's look.
	 * A theme's copy has its own classes and its look is the theme's
	 *
	 * @param string $id   Style ID ('' = the kind's default)
	 * @param string $kind Kind
	 *
	 * @return bool
	 */
	public static function is_plugin_style( $id, $kind ) {
		$template = self::locate( $id, 'template', $kind );

		return self::is_built_in( $id, $kind ) && $template && self::is_plugin_file( $template[0] );
	}

	/**
	 * Path of a style's template
	 *
	 * @param string $id   Style ID ('' = the kind's default)
	 * @param string $kind Kind
	 * @param string $file Template file of the style ('' = the kind's)
	 *
	 * @return string
	 */
	public static function path( $id, $kind = 'skins', $file = '' ) {
		$file = $file ?: ( self::KINDS[ $kind ] ?? 'skin.php' );

		// Every style in a folder of its own, the built-in one in default/
		return ( self::FOLDERS[ $kind ] ?? $kind ) . '/' . ( sanitize_key( (string) $id ) ?: 'default' ) . '/' . $file;
	}

	/**
	 * Locate a file of a style
	 *
	 * @param string $id   Style ID
	 * @param string $key  'template', or a key of FILES
	 * @param string $kind Kind
	 *
	 * @return array|null [ path, url ]
	 */
	public static function locate( $id, $key, $kind = 'skins' ) {
		$template = self::path( $id, $kind );

		if ( 'template' === $key ) {
			return self::locate_file( $template );
		}

		return isset( self::FILES[ $key ] ) ? self::locate_file( dirname( $template ) . '/' . self::FILES[ $key ] ) : null;
	}

	/**
	 * Enqueue a style's style.css and script.js
	 *
	 * @param string $id   Style ID ('' = the kind's default)
	 * @param string $kind Kind
	 */
	public static function enqueue( $id, $kind = 'skins' ) {
		$handle = 'forma-' . $kind . '-' . ( sanitize_key( (string) $id ) ?: 'default' );
		$style  = self::locate( $id, 'style', $kind );
		$script = self::locate( $id, 'script', $kind );

		// The plugin's style.css styles the plugin's template only: not under a theme's copy of it, nor when turned off
		if ( $style && self::is_plugin_file( $style[0] ) && ( !self::default_styles( $kind, (string) $id ) || !self::is_plugin_style( $id, $kind ) ) ) {
			$style = null;
		}

		if ( $style ) {
			wp_enqueue_style( $handle, $style[1], [ 'forma' ], (string) filemtime( $style[0] ) );
		}

		if ( $script ) {
			wp_enqueue_script( $handle, $script[1], [ 'forma' ], (string) filemtime( $script[0] ), true );
		}
	}

	/**
	 * Whether the plugin's own look loads (forma_default_styles); a theme returns false to style it all itself
	 *
	 * @param string $kind Kind (skins, filters, search, sort, pagination) or lightbox
	 * @param string $id   Style ID ('' for the lightbox)
	 *
	 * @return bool
	 */
	public static function default_styles( $kind, $id = '' ) {
		return (bool) apply_filters( 'forma_default_styles', true, $kind, $id );
	}

	/**
	 * Whether a file is the plugin's own, not a theme's copy
	 *
	 * @param string $path File path
	 *
	 * @return bool
	 */
	private static function is_plugin_file( $path ) {
		return 0 === strpos( wp_normalize_path( $path ), wp_normalize_path( FORMA_PATH ) );
	}

	/**
	 * Render a style, falling back to the default template
	 *
	 * @param string $id   Style ID
	 * @param array  $vars Variables
	 * @param string $kind Kind
	 * @param string $file Template file of the style ('' = the kind's)
	 *
	 * @return string
	 */
	public static function render( $id, array $vars, $kind = 'skins', $file = '' ) {
		$path = self::path( $id, $kind, $file );

		if ( !self::locate_file( $path ) && 'layouts' !== $kind ) {
			$path = self::path( '', $kind, $file );
		}

		return self::render_template( $path, $vars );
	}
}
