<?php

namespace VLT\Forma\Front;

use VLT\Forma\Sources\SourceRegistry;
use VLT\Forma\Sources\VirtualTermsInterface;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Runs a layout's query for one page
 *
 * query.offset skips the first N items once; pages are counted from what is left.
 */
class QueryBuilder {
	/**
	 * Orders a visitor can pick (the layout's sort select): key => [ orderby, order ]
	 */
	const SORTS = [
		'date-desc'          => [ 'date', 'DESC' ],
		'date-asc'           => [ 'date', 'ASC' ],
		'title-asc'          => [ 'title', 'ASC' ],
		'title-desc'         => [ 'title', 'DESC' ],
		'modified-desc'      => [ 'modified', 'DESC' ],
		'comment_count-desc' => [ 'comment_count', 'DESC' ],
		'views-desc'         => [ 'views', 'DESC' ],
		'menu_order-asc'     => [ 'menu_order', 'ASC' ],
		'rand'               => [ 'rand', 'DESC' ],
	];

	/**
	 * Run the query
	 *
	 * @param array  $config Layout config
	 * @param int    $page   Page (1-based), forced to 1 without pagination
	 * @param int    $term   Front-end filter term ID (0 = all); validate with is_valid_term() first
	 * @param int    $seed   Random order seed
	 * @param string $search Front-end search words ('' = none; ignored when the layout has no search)
	 * @param array  $not_in Item IDs left out: what the grids above on the page show (query.skip_shown)
	 * @param string $sort   Visitor's order, a key of SORTS ('' or one the layout doesn't offer = the layout's own)
	 *
	 * @return array [ 'items', 'source', 'page', 'max_pages', 'total', 'start' ]
	 */
	public static function run( array $config, $page = 1, $term = 0, $seed = 0, $search = '', array $not_in = [], $sort = '' ) {
		if ( $config['sort']['enabled'] && in_array( $sort, $config['sort']['options'], true ) ) {
			[ $config['query']['orderby'], $config['query']['order'] ] = self::SORTS[ $sort ];
		}

		$source    = SourceRegistry::get( $config['query']['source'] );
		$per_page  = $config['query']['per_page'];
		$offset    = $config['query']['offset'];
		$all       = -1 === $per_page;
		$paginated = !$all && 'none' !== $config['pagination']['type'];
		$page      = $paginated ? max( 1, (int) $page ) : 1;
		$start     = $all ? 0 : ( $page - 1 ) * $per_page;

		$args = [
			'limit'  => $per_page, // -1 = no limit
			'skip'   => $offset + $start,
			'filter' => $term ? [
				'taxonomy' => $config['filters']['taxonomy'],
				'term'     => (int) $term,
			] : null,
			'seed'   => (int) $seed,
			'count'  => $paginated,
			'search' => $config['search']['enabled'] ? self::search_words( $search ) : '',
			'not_in' => $config['query']['skip_shown'] ? array_map( 'absint', $not_in ) : [],
		];

		$result = $source ? $source->fetch( $config['query'], $args ) : [
			'items' => [],
			'total' => 0,
		];

		// WP_Query doesn't count when the page is past the end
		if ( $source && $paginated && !$result['items'] && $start > 0 ) {
			$result['total'] = $source->fetch( $config['query'], [ 'limit' => 1, 'skip' => 0 ] + $args )['total'];
		}

		$total = $paginated ? max( 0, $result['total'] - $offset ) : count( $result['items'] );

		return [
			'items'     => $result['items'],
			'source'    => $source,
			'page'      => $page,
			'max_pages' => $paginated ? max( 1, (int) ceil( $total / $per_page ) ) : 1,
			'total'     => $total,
			'start'     => $start,
		];
	}

	/**
	 * Front-end search words: plain text, at most 100 characters
	 *
	 * @param string $search Raw
	 *
	 * @return string
	 */
	public static function search_words( $search ) {
		return mb_substr( trim( sanitize_text_field( (string) $search ) ), 0, 100 );
	}

	/**
	 * Labels of the orders a source can be sorted by
	 *
	 * @param Sources\SourceInterface|null $source Source
	 *
	 * @return array [ key of SORTS => label ]
	 */
	public static function sorts( $source ) {
		$labels = [
			'date-desc'          => __( 'Newest', 'forma-grid-gallery' ),
			'date-asc'           => __( 'Oldest', 'forma-grid-gallery' ),
			'title-asc'          => __( 'Title: A to Z', 'forma-grid-gallery' ),
			'title-desc'         => __( 'Title: Z to A', 'forma-grid-gallery' ),
			'modified-desc'      => __( 'Recently updated', 'forma-grid-gallery' ),
			'comment_count-desc' => __( 'Most commented', 'forma-grid-gallery' ),
			'views-desc'         => __( 'Most viewed', 'forma-grid-gallery' ),
			'menu_order-asc'     => __( 'Menu order', 'forma-grid-gallery' ),
			'rand'               => __( 'Random', 'forma-grid-gallery' ),
		];

		$orderby = $source ? array_keys( $source->get_orderby_options() ) : [];

		return array_filter( $labels, fn( $key ) => in_array( self::SORTS[ $key ][0], $orderby, true ), ARRAY_FILTER_USE_KEY );
	}

	/**
	 * Key of SORTS that matches the layout's own order ('' = none)
	 *
	 * @param array $query Query config
	 *
	 * @return string
	 */
	public static function sort_key( array $query ) {
		foreach ( self::SORTS as $key => [ $orderby, $order ] ) {
			if ( $orderby === $query['orderby'] && ( 'rand' === $orderby || $order === $query['order'] ) ) {
				return $key;
			}
		}

		return '';
	}

	/**
	 * Terms shown in the front-end filter
	 *
	 * The configured query terms of the filter taxonomy limit the list (with their children); otherwise all non-empty terms.
	 *
	 * @param array $config Layout config
	 *
	 * @return \WP_Term[]
	 */
	public static function filter_terms( array $config ) {
		if ( !$config['filters']['enabled'] ) {
			return [];
		}

		$virtual = self::virtual_terms( $config );

		if ( null !== $virtual ) {
			return $virtual;
		}

		$taxonomy = $config['filters']['taxonomy'];
		$args     = [
			'taxonomy'   => $taxonomy,
			'hide_empty' => true,
		];

		$allowed = self::allowed_terms( $config );

		if ( null !== $allowed ) {
			$args['include'] = $allowed ?: [ 0 ];
		}

		$terms = get_terms( apply_filters( 'forma_filter_terms_args', $args, $config ) );

		return is_array( $terms ) ? $terms : [];
	}

	/**
	 * Whether a term may be used as the front-end filter of this layout
	 *
	 * @param array $config Layout config
	 * @param int   $term   Term ID
	 *
	 * @return bool
	 */
	public static function is_valid_term( array $config, $term ) {
		$term = (int) $term;

		if ( !$config['filters']['enabled'] || $term < 1 ) {
			return false;
		}

		$virtual = self::virtual_terms( $config );

		if ( null !== $virtual ) {
			return in_array( $term, array_map( 'intval', wp_list_pluck( $virtual, 'term_id' ) ), true );
		}

		if ( !term_exists( $term, $config['filters']['taxonomy'] ) ) {
			return false;
		}

		$allowed = self::allowed_terms( $config );

		return null === $allowed || in_array( $term, $allowed, true );
	}

	/**
	 * Terms of the filter taxonomy when the source keeps them itself (VirtualTermsInterface)
	 *
	 * @param array $config Layout config
	 *
	 * @return \WP_Term[]|null Null for a WordPress taxonomy
	 */
	private static function virtual_terms( array $config ) {
		$source = SourceRegistry::get( $config['query']['source'] );

		return $source instanceof VirtualTermsInterface ? $source->get_virtual_terms( $config['query'], $config['filters']['taxonomy'] ) : null;
	}

	/**
	 * Terms of the filter taxonomy the query is restricted to, with their descendants
	 *
	 * @param array $config Layout config
	 *
	 * @return array|null Term IDs, or null when the query doesn't restrict this taxonomy
	 */
	private static function allowed_terms( array $config ) {
		$taxonomy = $config['filters']['taxonomy'];

		if ( empty( $config['query']['taxonomies'][ $taxonomy ] ) ) {
			return null;
		}

		$allowed = $config['query']['taxonomies'][ $taxonomy ];

		foreach ( $config['query']['taxonomies'][ $taxonomy ] as $term_id ) {
			$children = get_term_children( $term_id, $taxonomy );
			$allowed  = array_merge( $allowed, is_array( $children ) ? $children : [] );
		}

		return array_values( array_unique( array_map( 'intval', $allowed ) ) );
	}
}
