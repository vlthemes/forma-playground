<?php

namespace VLT\Forma\Front;

use VLT\Forma\Admin\Settings;
use VLT\Forma\Core\Assets;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filter, sort and page in the page address (Settings → Filter & Sort)
 *
 * ?filter=branding&sort=title-asc opens the grid filtered and sorted; the filter chips link there so crawlers
 * reach every view. ?grid-page=3 opens that page and only comes from the page links (not "page": WordPress uses it).
 */
class FilterLink {
	/**
	 * The settings tab and the front end
	 */
	public static function init() {
		add_filter( 'forma_settings_sections', [ __CLASS__, 'section' ] );

		add_filter( 'forma_initial_term', [ __CLASS__, 'term' ], 10, 2 );
		add_filter( 'forma_initial_page', [ __CLASS__, 'page' ] );
		add_filter( 'forma_container_attributes', [ __CLASS__, 'attributes' ], 10, 2 );

		if ( !empty( Settings::get( 'filters' )['sort_url'] ) ) {
			add_filter( 'forma_initial_sort', [ __CLASS__, 'sort' ] );
		}
	}

	/**
	 * Filter & Sort tab, before Lightbox
	 *
	 * @param array $sections Settings sections
	 *
	 * @return array
	 */
	public static function section( array $sections ) {
		$section = [
			'filters' => [
				'tab'         => __( 'Filter & Sort', 'forma-grid-gallery' ),
				'icon'        => 'filter',
				'title'       => __( 'Filter & Sort', 'forma-grid-gallery' ),
				'description' => __( 'The filter and the order visitors pick in the page address, so the view can be shared, bookmarked and found by search engines; the browser\'s Back button goes to the one before.', 'forma-grid-gallery' ),
				'fields'      => [
					'url'        => [
						'type'    => 'toggle',
						'label'   => __( 'Show the filter in the page address', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'Picking a filter adds it to the address: ?filter=branding. Off, the address stays as it is; the filters still link to their filtered views, so search engines find them.', 'forma-grid-gallery' ),
					],
					'param'      => [
						'type'    => 'slug',
						'label'   => __( 'Filter parameter', 'forma-grid-gallery' ),
						'default' => 'filter',
						'help'    => __( 'The name in the address of the filters\' links: ?filter=branding. Change it when another plugin uses it too. Grids filtered by the same taxonomy on one page share it.', 'forma-grid-gallery' ),
					],
					'sort_url'   => [
						'type'    => 'toggle',
						'label'   => __( 'Show the sort in the page address', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'Picking an order adds it to the address: ?sort=title-asc. The layout\'s own order leaves it out.', 'forma-grid-gallery' ),
					],
					'sort_param' => [
						'type'    => 'slug',
						'show_if' => 'sort_url',
						'label'   => __( 'Sort parameter', 'forma-grid-gallery' ),
						'default' => 'sort',
						'help'    => __( 'The name in the address. Change it when another plugin uses it too.', 'forma-grid-gallery' ),
					],
					'page_param' => [
						'type'    => 'slug',
						'label'   => __( 'Page parameter', 'forma-grid-gallery' ),
						'default' => 'grid-page',
						'help'    => __( 'Page numbers and Load More link to each page, ?grid-page=2, so search engines reach every item; the address bar doesn\'t show it. The name in the address: change it when another plugin uses it too. Paginated grids on one page share it.', 'forma-grid-gallery' ),
					],
				],
			],
		];
		$at      = array_search( 'lightbox', array_keys( $sections ), true );

		return false === $at ? $sections + $section : array_slice( $sections, 0, $at, true ) + $section + array_slice( $sections, $at, null, true );
	}

	/**
	 * The term the address asks for
	 *
	 * @param int   $term   Term ID, 0 = all
	 * @param array $config Layout config
	 *
	 * @return int
	 */
	public static function term( $term, array $config ) {
		$slugs = self::slugs( $config );
		$asked = self::asked( self::param( 'param', 'filter' ) );

		return $slugs && '' !== $asked ? (int) array_search( $asked, $slugs, true ) : $term;
	}

	/**
	 * The order the address asks for (Forma keeps it only when the layout offers it)
	 *
	 * @param string $sort Key of QueryBuilder::SORTS, '' = the layout's own
	 *
	 * @return string
	 */
	public static function sort( $sort ) {
		$asked = self::asked( self::param( 'sort_param', 'sort' ) );

		return isset( QueryBuilder::SORTS[ $asked ] ) ? $asked : $sort;
	}

	/**
	 * The page the address asks for
	 *
	 * @param int $page Page, 1-based
	 *
	 * @return int
	 */
	public static function page( $page ) {
		return absint( self::asked( self::param( 'page_param', 'grid-page' ) ) ) ?: $page;
	}

	/**
	 * Address of a page of the grid, for the pagination's links (the script keeps them up to date after AJAX, which
	 * has no page address of its own)
	 *
	 * @param int $page Page, 1-based
	 *
	 * @return string
	 */
	public static function page_url( $page ) {
		$param = self::param( 'page_param', 'grid-page' );

		return $page > 1 ? add_query_arg( $param, (int) $page ) : remove_query_arg( $param );
	}

	/**
	 * Address of the page filtered by a term, for the filter's links
	 *
	 * @param array $config Layout config
	 * @param int   $term   Term ID, 0 = all
	 *
	 * @return string
	 */
	public static function url( array $config, $term ) {
		$param = self::param( 'param', 'filter' );
		$slug  = self::slugs( $config )[ $term ] ?? '';
		// A filter starts on its first page
		$url   = remove_query_arg( self::param( 'page_param', 'grid-page' ) );
		$url   = $slug ? add_query_arg( $param, $slug, $url ) : remove_query_arg( $param, $url );

		// E.g. the portfolio's archive page: its category and tag pages
		return (string) apply_filters( 'forma_filter_url', $url, (int) $term, $config );
	}

	/**
	 * Parameters and filter slugs for the script (data-forma-link)
	 *
	 * @param array $attributes Grid attributes
	 * @param array $config     Layout config
	 *
	 * @return array
	 */
	public static function attributes( array $attributes, array $config ) {
		$settings = Settings::get( 'filters' );
		// The filter's links lead to its views either way; the toggle is the address bar only
		$slugs    = !empty( $settings['url'] ) ? self::slugs( $config ) : [];
		$sort     = !empty( $settings['sort_url'] ) && $config['sort']['enabled'] && $config['sort']['options'];
		$link     = array_filter( [
			'param'     => $slugs ? self::param( 'param', 'filter' ) : '',
			'slugs'     => $slugs ? (object) $slugs : null,
			'sortParam' => $sort ? self::param( 'sort_param', 'sort' ) : '',
			'pageParam' => 'none' !== $config['pagination']['type'] ? self::param( 'page_param', 'grid-page' ) : '',
		] );

		if ( $link ) {
			$attributes['data-forma-link'] = wp_json_encode( $link );

			Assets::enqueue( 'forma-filter-link' );
		}

		return $attributes;
	}

	/**
	 * Slugs of a layout's filter terms
	 *
	 * @param array $config Layout config
	 *
	 * @return array [ term ID => slug ], empty without a filter
	 */
	private static function slugs( array $config ) {
		static $slugs = [];

		if ( !$config['filters']['enabled'] ) {
			return [];
		}

		$key = md5( (string) wp_json_encode( [ $config['query'], $config['filters'] ] ) );

		if ( !isset( $slugs[ $key ] ) ) {
			$slugs[ $key ] = [];

			foreach ( QueryBuilder::filter_terms( $config ) as $term ) {
				$slugs[ $key ][ (int) $term->term_id ] = $term->slug;
			}
		}

		return $slugs[ $key ];
	}

	/**
	 * Name of a parameter (Settings → Filter & Sort)
	 *
	 * @param string $field    Field
	 * @param string $fallback Default
	 *
	 * @return string
	 */
	private static function param( $field, $fallback ) {
		return ( Settings::get( 'filters' )[ $field ] ?? '' ) ?: $fallback;
	}

	/**
	 * Value of a parameter in the address, as a slug
	 *
	 * @param string $param Parameter
	 *
	 * @return string
	 */
	private static function asked( $param ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a public view of the page, read only
		return isset( $_GET[ $param ] ) ? sanitize_title( wp_unslash( (string) $_GET[ $param ] ) ) : '';
	}
}
