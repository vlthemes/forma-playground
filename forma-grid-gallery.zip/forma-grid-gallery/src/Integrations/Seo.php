<?php

namespace VLT\Forma\Integrations;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Portfolio category and tag pages served through the archive page get the term's canonical, title and description,
 * so search engines don't see them as copies (WordPress, Yoast, Rank Math, AIOSEO)
 */
class Seo {
	/**
	 * The term of the request
	 *
	 * @var \WP_Term|null
	 */
	private static $term = null;

	/**
	 * The request shows a term through the archive page
	 *
	 * @param \WP_Term $term Category or tag
	 */
	public static function term( \WP_Term $term ) {
		self::$term = $term;

		add_filter( 'get_canonical_url', [ __CLASS__, 'core_canonical' ], 10, 2 );

		if ( function_exists( 'YoastSEO' ) ) {
			add_filter( 'wpseo_title', fn( $value ) => self::yoast( 'title', $value ) );
			add_filter( 'wpseo_metadesc', fn( $value ) => self::yoast( 'description', $value ) );
			add_filter( 'wpseo_canonical', fn( $value ) => self::yoast( 'canonical', $value ) );
			add_filter( 'wpseo_opengraph_url', fn( $value ) => self::yoast( 'canonical', $value ) );
			add_filter( 'wpseo_opengraph_title', fn( $value ) => self::yoast( 'open_graph_title', $value ) );
			add_filter( 'wpseo_opengraph_desc', fn( $value ) => self::yoast( 'open_graph_description', $value ) );
			add_filter( 'wpseo_schema_webpage', [ __CLASS__, 'yoast_webpage' ] );
			add_filter( 'wpseo_schema_breadcrumb', [ __CLASS__, 'yoast_breadcrumb' ] );
		}

		if ( class_exists( '\RankMath\Paper\Paper' ) ) {
			add_filter( 'rank_math/frontend/title', fn( $value ) => self::rank_math( 'title', $value ) );
			add_filter( 'rank_math/frontend/description', fn( $value ) => self::rank_math( 'description', $value ) );
			// og:url is the canonical
			add_filter( 'rank_math/frontend/canonical', fn() => \RankMath\Term::get_meta( 'canonical_url', self::$term, self::$term->taxonomy ) ?: self::link() );
		}

		if ( function_exists( 'aioseo' ) ) {
			add_filter( 'aioseo_title', fn( $value ) => self::aioseo( 'title', $value ) );
			add_filter( 'aioseo_description', fn( $value ) => self::aioseo( 'description', $value ) );
			add_filter( 'aioseo_canonical_url', [ __CLASS__, 'link' ] );
			add_filter( 'aioseo_facebook_tags', [ __CLASS__, 'aioseo_facebook' ] );
			add_filter( 'aioseo_schema_output', [ __CLASS__, 'aioseo_schema' ] );
		}
	}

	/**
	 * Address of the term's page
	 *
	 * @return string
	 */
	public static function link() {
		$link = get_term_link( self::$term );

		return is_wp_error( $link ) ? '' : $link;
	}

	/**
	 * WordPress' canonical of the archive page (printed without an SEO plugin)
	 *
	 * @param string   $url  Canonical URL
	 * @param \WP_Post $post Post
	 *
	 * @return string
	 */
	public static function core_canonical( $url, $post ) {
		return $post->ID === get_queried_object_id() ? self::link() : $url;
	}

	/**
	 * A value Yoast SEO has for the term's archive
	 *
	 * @param string $key   Meta key: title, description, canonical, open_graph_title…
	 * @param mixed  $value The page's
	 *
	 * @return mixed
	 */
	private static function yoast( $key, $value ) {
		static $meta = null;

		$meta ??= YoastSEO()->meta->for_term( self::$term->term_id );

		return $meta && $meta->{$key} ? $meta->{$key} : $value;
	}

	/**
	 * Yoast SEO's WebPage schema: the term's collection page
	 *
	 * @param array $piece Schema piece
	 *
	 * @return array
	 */
	public static function yoast_webpage( array $piece ) {
		$url = self::yoast( 'canonical', self::link() );

		$piece['@type'] = 'CollectionPage';
		$piece['@id']   = $url;
		$piece['url']   = $url;
		$piece['name']  = self::yoast( 'title', $piece['name'] ?? '' );

		if ( isset( $piece['breadcrumb']['@id'] ) ) {
			$piece['breadcrumb']['@id'] = $url . '#breadcrumb';
		}

		unset( $piece['potentialAction'], $piece['datePublished'], $piece['dateModified'] );

		return $piece;
	}

	/**
	 * Yoast SEO's breadcrumb schema: on the term's address, ending with the term
	 *
	 * @param array $piece Schema piece
	 *
	 * @return array
	 */
	public static function yoast_breadcrumb( array $piece ) {
		$url = self::yoast( 'canonical', self::link() );

		$piece['@id'] = $url . '#breadcrumb';

		if ( !empty( $piece['itemListElement'] ) ) {
			$last = array_key_last( $piece['itemListElement'] );

			$piece['itemListElement'][ $last ]['name'] = self::$term->name;
		}

		return $piece;
	}

	/**
	 * A value Rank Math has for the term's archive (as its taxonomy page does it)
	 *
	 * @param string $key   title or description
	 * @param string $value The page's
	 *
	 * @return string
	 */
	private static function rank_math( $key, $value ) {
		$own = \RankMath\Term::get_meta( $key, self::$term, self::$term->taxonomy );

		return '' !== $own ? $own : ( \RankMath\Paper\Paper::get_from_options( 'tax_' . self::$term->taxonomy . '_' . $key, self::$term ) ?: $value );
	}

	/**
	 * A value All in One SEO has for the term's archive
	 *
	 * @param string $key   title or description
	 * @param string $value The page's
	 *
	 * @return string
	 */
	private static function aioseo( $key, $value ) {
		static $values = [];

		if ( !array_key_exists( $key, $values ) ) {
			// It runs its own aioseo_title / aioseo_description on the term's value: this answers that one with it
			$values[ $key ] = $value;
			$values[ $key ] = 'title' === $key ? aioseo()->meta->title->getTermTitle( self::$term ) : aioseo()->meta->description->getTermDescription( self::$term );
		}

		return $values[ $key ] ?: $value;
	}

	/**
	 * All in One SEO's Open Graph tags: the term's
	 *
	 * @param array $tags Tags
	 *
	 * @return array
	 */
	public static function aioseo_facebook( array $tags ) {
		$tags['og:url']         = self::link();
		$tags['og:title']       = self::aioseo( 'title', $tags['og:title'] ?? '' );
		$tags['og:description'] = self::aioseo( 'description', $tags['og:description'] ?? '' );

		return $tags;
	}

	/**
	 * All in One SEO's schema: the term's collection page and breadcrumb, on its address
	 *
	 * @param array $graphs Schema pieces
	 *
	 * @return array
	 */
	public static function aioseo_schema( $graphs ) {
		// The addresses as they are inside JSON strings: their @ids are the page's address with a #fragment
		$page = substr( (string) wp_json_encode( get_permalink( get_queried_object_id() ) ), 1, -1 );
		$url  = substr( (string) wp_json_encode( self::link() ), 1, -1 );

		foreach ( (array) $graphs as $key => $piece ) {
			if ( !in_array( $piece['@type'] ?? '', [ 'WebPage', 'CollectionPage', 'BreadcrumbList' ], true ) ) {
				continue;
			}

			$piece = json_decode( str_replace( $page, $url, (string) wp_json_encode( $piece ) ), true ) ?: $piece;

			if ( 'BreadcrumbList' !== $piece['@type'] ) {
				$piece['@type'] = 'CollectionPage';
				$piece['name']  = self::aioseo( 'title', $piece['name'] ?? '' );
			}

			$graphs[ $key ] = $piece;
		}

		return $graphs;
	}
}
