<?php

namespace VLT\Forma\Integrations\Elementor;

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widget_Base;
use VLT\Forma\Core\PostTypes;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Front\Shortcode;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor widget: a saved Grid Layout, or one of its parts (filter, search, sort, pagination)
 *
 * Prints the layout's shortcode, with the part it shows.
 */
class FormaWidget extends Widget_Base {
	/**
	 * Widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return Integration::WIDGET;
	}

	/**
	 * Widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'Forma', 'forma-grid-gallery' );
	}

	/**
	 * Widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'forma-widget-icon forma-label';
	}

	/**
	 * Widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Search keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'grid', 'portfolio', 'gallery', 'masonry', 'filter', 'layout' ];
	}

	/**
	 * Scripts the widget needs
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return [ 'forma-elementor' ];
	}

	/**
	 * Styles the widget needs
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return [ 'forma' ];
	}

	/**
	 * Controls
	 */
	protected function register_controls() {
		$this->start_controls_section( 'section_layout', [ 'label' => __( 'Grid Layout', 'forma-grid-gallery' ) ] );

		$this->add_control( 'grid_layout', [
			'label'   => __( 'Grid Layout', 'forma-grid-gallery' ),
			'type'    => Controls_Manager::SELECT,
			'options' => [ '' => __( 'Choose a layout', 'forma-grid-gallery' ) ] + PostTypes::layouts(),
			'default' => '',
		] );

		$this->add_control( 'grid_part', [
			'label'   => __( 'Show', 'forma-grid-gallery' ),
			'type'    => Controls_Manager::SELECT,
			'options' => [
				'grid'       => __( 'Grid', 'forma-grid-gallery' ),
				'filter'     => __( 'Filter', 'forma-grid-gallery' ),
				'search'     => __( 'Search', 'forma-grid-gallery' ),
				'sort'       => __( 'Sorting', 'forma-grid-gallery' ),
				'pagination' => __( 'Pagination', 'forma-grid-gallery' ),
			],
			'default' => 'grid',
		] );

		$this->add_control( 'grid_instance', [
			'label'       => __( 'Grid on the page', 'forma-grid-gallery' ),
			'description' => __( 'With this layout on the page more than once: which of its grids this part controls (1 = the first).', 'forma-grid-gallery' ),
			'type'        => Controls_Manager::NUMBER,
			'min'         => 1,
			'max'         => 20,
			'default'     => 1,
			'condition'   => [ 'grid_part!' => 'grid' ],
		] );

		$this->add_control( 'grid_note', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => sprintf(
				/* translators: %s: link to the Forma Layouts list */
				__( 'The layout\'s content, look and parts are set in %s. A filter, search, sorting or pagination shows only when the layout has it turned on.', 'forma-grid-gallery' ),
				'<a href="' . esc_url( admin_url( 'edit.php?post_type=' . PostTypes::LAYOUT ) ) . '" target="_blank">' . esc_html__( 'Forma Layouts', 'forma-grid-gallery' ) . '</a>'
			),
			'content_classes' => 'elementor-descriptor',
		] );

		$this->end_controls_section();
	}

	/**
	 * Output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$part     = in_array( $settings['grid_part'], Shortcode::PARTS, true ) ? $settings['grid_part'] : 'grid';
		$editor   = Plugin::$instance->editor->is_edit_mode();

		if ( !$settings['grid_layout'] ) {
			if ( $editor ) {
				echo '<p class="forma__notice">' . esc_html__( 'Choose a grid layout in the widget settings.', 'forma-grid-gallery' ) . '</p>';
			}

			return;
		}

		$html = Shortcode::render( [
			'id'       => absint( $settings['grid_layout'] ),
			'show'     => $part,
			'instance' => absint( $settings['grid_instance'] ?? 1 ),
		] );

		if ( '' === trim( $html ) && $editor ) {
			$html = Renderer::part_off( $part );
		}

		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rendered templates
	}
}
