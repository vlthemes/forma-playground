<?php

namespace VLT\Forma\Integrations\Elementor;

use VLT\Forma\Core\Assets;
use VLT\Forma\Core\Config;
use VLT\Forma\Front\Renderer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor: the Forma widget, loaded only when Elementor registers its widgets
 */
class Integration {
	// The widget's name (FormaWidget), also what Admin looks for in Elementor data
	const WIDGET = 'forma';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/editor/after_enqueue_styles', [ __CLASS__, 'enqueue_editor_style' ] );
		// The editor renders a widget through AJAX, where the styles its layout enqueues never reach the page
		add_action( 'elementor/preview/enqueue_styles', [ Renderer::class, 'enqueue_published' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_early' ], 20 );
	}

	/**
	 * Assets of the layouts the page's widgets show, in <head> rather than late in the footer
	 */
	public static function enqueue_early() {
		$data = is_singular() ? get_post_meta( get_queried_object_id(), '_elementor_data', true ) : '';

		if ( !is_string( $data ) || false === strpos( $data, '"' . self::WIDGET . '"' ) ) {
			return;
		}

		foreach ( array_unique( self::layouts( (array) json_decode( $data, true ) ) ) as $id ) {
			$config = Config::get( $id );

			if ( $config ) {
				Renderer::enqueue( $config );
			}
		}
	}

	/**
	 * Layouts of the Forma widgets in Elementor elements, nested ones included
	 *
	 * @param array $elements Elementor elements
	 *
	 * @return int[] Layout IDs
	 */
	public static function layouts( array $elements ) {
		$layouts = [];

		foreach ( $elements as $element ) {
			if ( self::WIDGET === ( $element['widgetType'] ?? '' ) && !empty( $element['settings']['grid_layout'] ) ) {
				$layouts[] = (int) $element['settings']['grid_layout'];
			}

			if ( !empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$layouts = array_merge( $layouts, self::layouts( $element['elements'] ) );
			}
		}

		return $layouts;
	}

	/**
	 * The widget's badge in the editor panel
	 */
	public static function enqueue_editor_style() {
		Assets::enqueue( 'forma-elementor-editor' );
	}

	/**
	 * Register the widget
	 *
	 * @param \Elementor\Widgets_Manager $widgets Widgets manager
	 */
	public static function register_widget( $widgets ) {
		$widgets->register( new FormaWidget() );
	}
}
