<?php

namespace VLT\Forma\Integrations;

use VLT\Forma\Admin\Admin;
use VLT\Forma\Admin\Preview;
use VLT\Forma\Core\Assets;
use VLT\Forma\Core\Config;
use VLT\Forma\Core\PostTypes;
use VLT\Forma\Core\Roles;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Front\Shortcode;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Grid Layout block: a saved layout's grid or one of its controls, rendered by the shortcode
 *
 *     forma/grid   { layout, show: grid | filter | search | sort | pagination, instance }
 */
class Blocks {
	const CATEGORY = 'forma';
	const NAME     = 'forma/grid';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'init', [ __CLASS__, 'register' ] );
		add_filter( 'block_categories_all', [ __CLASS__, 'category' ] );
		add_action( 'enqueue_block_editor_assets', [ __CLASS__, 'enqueue_editor' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_early' ], 20 );
	}

	/**
	 * Register the block
	 */
	public static function register() {
		register_block_type( self::NAME, [
			'api_version'          => 3,
			'title'                => __( 'Grid Layout', 'forma-grid-gallery' ),
			'description'          => __( 'A saved Grid Layout: portfolio, gallery or posts grid, or its filter, search, sort or pagination anywhere on the page.', 'forma-grid-gallery' ),
			'category'             => self::CATEGORY,
			'keywords'             => [ 'portfolio', 'gallery', 'grid', 'masonry', 'filter', 'forma' ],
			'attributes'           => [
				'layout'   => [ 'type' => 'integer', 'default' => 0 ],
				'show'     => [ 'type' => 'string', 'enum' => Shortcode::PARTS, 'default' => 'grid' ],
				// Which grid of that layout on the page the control drives (shortcodes' instance)
				'instance' => [ 'type' => 'integer', 'default' => 1 ],
			],
			'supports'             => [
				'html'  => false,
				'align' => [ 'wide', 'full' ],
			],
			// The canvas is an iframe: WordPress copies only a block's own editor styles into it
			'editor_style_handles' => [ 'forma-blocks' ],
			'render_callback'      => [ __CLASS__, 'render' ],
		] );
	}

	/**
	 * The block's markup: the shortcode's, in the block wrapper (alignment, the block's own classes)
	 *
	 * @param array $attributes Block attributes
	 *
	 * @return string
	 */
	public static function render( $attributes ) {
		$html = (string) Shortcode::render( [
			'id'       => (int) ( $attributes['layout'] ?? 0 ),
			'show'     => (string) ( $attributes['show'] ?? 'grid' ),
			'instance' => (int) ( $attributes['instance'] ?? 1 ),
		] );

		return '' === $html ? '' : '<div ' . get_block_wrapper_attributes() . '>' . $html . '</div>';
	}

	/**
	 * The editor part, wherever posts are edited but in the Grid Layout editor itself
	 */
	public static function enqueue_editor() {
		if ( !Admin::is_layout_screen() ) {
			Assets::enqueue( 'forma-blocks' );
		}
	}

	/**
	 * The block's place in the inserter
	 *
	 * @param array $categories Block categories
	 *
	 * @return array
	 */
	public static function category( array $categories ) {
		return array_merge( $categories, [
			[
				'slug'  => self::CATEGORY,
				'title' => __( 'Forma', 'forma-grid-gallery' ),
			],
		] );
	}

	/**
	 * Assets of the layouts the post's blocks show, in <head> rather than late in the footer
	 */
	public static function enqueue_early() {
		$post = is_singular() ? get_post() : null;

		if ( !$post || false === strpos( $post->post_content, '<!-- wp:' . self::NAME . ' ' ) ) {
			return;
		}

		foreach ( self::layouts( parse_blocks( $post->post_content ) ) as $layout ) {
			$config = Config::get( $layout );

			if ( $config ) {
				Renderer::enqueue( $config );
			}
		}
	}

	/**
	 * Layouts of the plugin's blocks, inner blocks too (the grid's assets serve its controls as well)
	 *
	 * @param array $blocks Parsed blocks
	 *
	 * @return int[]
	 */
	private static function layouts( array $blocks ) {
		$layouts = [];

		foreach ( $blocks as $block ) {
			if ( self::NAME === $block['blockName'] && !empty( $block['attrs']['layout'] ) ) {
				$layouts[] = (int) $block['attrs']['layout'];
			}

			$layouts = array_merge( $layouts, self::layouts( $block['innerBlocks'] ?? [] ) );
		}

		return array_values( array_unique( $layouts ) );
	}

	/**
	 * Data of the editor script (window.formaBlocks)
	 *
	 * @return array
	 */
	public static function script_data() {
		return [
			'postType'   => PostTypes::LAYOUT,
			'previewUrl' => Preview::url(),
			'nonce'      => wp_create_nonce( Preview::NONCE ),
			'newUrl'     => admin_url( 'post-new.php?post_type=' . PostTypes::LAYOUT ),
			'listUrl'    => admin_url( 'edit.php?post_type=' . PostTypes::LAYOUT ),
			'canEdit'    => current_user_can( Roles::LAYOUTS ),
		];
	}
}
