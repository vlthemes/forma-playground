<?php

namespace VLT\Forma\Integrations\WPBakery;

use VLT\Forma\Core\PostTypes;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Front\Shortcode;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPBakery element. It stays the shortcode, so pages keep working without WPBakery.
 */
class Integration {
	/**
	 * Init
	 */
	public static function init() {
		add_action( 'vc_before_init', [ __CLASS__, 'map' ] );
		// The front-end editor renders a new element through AJAX, where the styles its layout enqueues never reach the page
		add_action( 'vc_load_iframe_jscss', [ Renderer::class, 'enqueue_published' ] );
		add_filter( 'vc_shortcode_output', [ __CLASS__, 'notice' ], 10, 4 );
	}

	/**
	 * In the front-end editor, the notes the Elementor widget shows: no layout picked yet, or a part the layout has
	 * turned off (it prints nothing then)
	 *
	 * @param string $output    Element output
	 * @param object $shortcode WPBakery shortcode object
	 * @param array  $atts      Attributes
	 * @param string $tag       Shortcode
	 *
	 * @return string
	 */
	public static function notice( $output, $shortcode, $atts, $tag ) {
		if ( Shortcode::TAG !== $tag || !function_exists( 'vc_is_page_editable' ) || !vc_is_page_editable() ) {
			return $output;
		}

		if ( empty( $atts['id'] ) ) {
			return '<p class="forma__notice">' . esc_html__( 'Choose a grid layout in the element settings.', 'forma-grid-gallery' ) . '</p>';
		}

		$show = $atts['show'] ?? 'grid';

		return '' === trim( (string) $output ) && 'grid' !== $show && in_array( $show, Shortcode::PARTS, true ) ? Renderer::part_off( $show ) : $output;
	}

	/**
	 * The element
	 */
	public static function map() {
		// A field of text only, like Elementor's RAW_HTML: no input, so nothing is saved in the shortcode
		vc_add_shortcode_param( 'forma_note', fn( $settings ) => '<div class="vc_description">' . wp_kses_post( $settings['text'] ?? '' ) . '</div>' );

		vc_map( [
			'name'        => __( 'Forma', 'forma-grid-gallery' ),
			'base'        => Shortcode::TAG,
			'description' => __( 'A saved Grid Layout, or its filter, search, sorting or pagination.', 'forma-grid-gallery' ),
			'category'    => __( 'Content', 'forma-grid-gallery' ),
			'icon'        => FORMA_URL . 'assets/icons/logo.svg',
			'params'      => [
				[
					'type'        => 'dropdown',
					'heading'     => __( 'Grid Layout', 'forma-grid-gallery' ),
					'param_name'  => 'id',
					'value'       => self::layouts(),
					'admin_label' => true,
				],
				[
					'type'        => 'dropdown',
					'heading'     => __( 'Show', 'forma-grid-gallery' ),
					'param_name'  => 'show',
					'value'       => [
						__( 'Grid', 'forma-grid-gallery' )       => 'grid',
						__( 'Filter', 'forma-grid-gallery' )     => 'filter',
						__( 'Search', 'forma-grid-gallery' )     => 'search',
						__( 'Sorting', 'forma-grid-gallery' )    => 'sort',
						__( 'Pagination', 'forma-grid-gallery' ) => 'pagination',
					],
					'std'         => 'grid',
					'admin_label' => true,
				],
				[
					'type'        => 'textfield',
					'heading'     => __( 'Grid on the page', 'forma-grid-gallery' ),
					'param_name'  => 'instance',
					'value'       => '1',
					'description' => __( 'With this layout on the page more than once: which of its grids this part controls (1 = the first).', 'forma-grid-gallery' ),
					'dependency'  => [ 'element' => 'show', 'value_not_equal_to' => 'grid' ],
				],
				[
					'type'       => 'forma_note',
					'param_name' => 'note',
					'text'       => sprintf(
						/* translators: %s: link to the Forma Layouts list */
						__( 'The layout\'s content, look and parts are set in %s. A filter, search, sorting or pagination shows only when the layout has it turned on.', 'forma-grid-gallery' ),
						'<a href="' . esc_url( admin_url( 'edit.php?post_type=' . PostTypes::LAYOUT ) ) . '" target="_blank">' . esc_html__( 'Forma Layouts', 'forma-grid-gallery' ) . '</a>'
					),
				],
			],
		] );
	}

	/**
	 * Published layouts for the dropdown
	 *
	 * @return array [ title => id ] (WPBakery's order)
	 */
	private static function layouts() {
		$layouts = [ __( 'Choose a layout', 'forma-grid-gallery' ) => '' ];

		foreach ( PostTypes::layouts() as $id => $title ) {
			// Same titles would overwrite each other as keys
			$layouts[ $title . ' (#' . $id . ')' ] = (string) $id;
		}

		return $layouts;
	}
}
