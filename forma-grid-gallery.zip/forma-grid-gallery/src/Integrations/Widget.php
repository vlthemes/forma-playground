<?php

namespace VLT\Forma\Integrations;

use VLT\Forma\Core\Assets;
use VLT\Forma\Core\Config;
use VLT\Forma\Core\PostTypes;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Front\Shortcode;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sidebar widget: a saved Grid Layout, or one of its parts (filter, search, sort, pagination), as the Elementor widget
 *
 * Prints the layout's shortcode, with the part it shows.
 */
class Widget extends \WP_Widget {
	// The widget's id base; its settings are in the option widget_{ID}
	const ID = 'forma';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'widgets_init', fn() => register_widget( self::class ) );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_early' ], 20 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin' ] );
		add_action( 'customize_controls_enqueue_scripts', fn() => Assets::enqueue( 'forma-admin-widget' ) );
	}

	/**
	 * The form's look and the logo by the widget's name, on the Widgets screen
	 *
	 * @param string $hook Admin page
	 */
	public static function enqueue_admin( $hook ) {
		if ( 'widgets.php' === $hook ) {
			Assets::enqueue( 'forma-admin-widget' );
		}
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct( self::ID, __( 'Forma', 'forma-grid-gallery' ), [
			'description'                 => __( 'A saved Grid Layout, or its filter, search, sorting or pagination.', 'forma-grid-gallery' ),
			'customize_selective_refresh' => true,
		] );
	}

	/**
	 * Assets of the layouts the active widgets show, in <head> rather than late in the footer
	 */
	public static function enqueue_early() {
		if ( !is_active_widget( false, false, self::ID ) ) {
			return;
		}

		// Each saved widget that sits in an active sidebar (is_active_widget() with its ID)
		foreach ( (array) get_option( 'widget_' . self::ID, [] ) as $number => $settings ) {
			if ( !is_int( $number ) || empty( $settings['layout'] ) || !is_active_widget( false, self::ID . '-' . $number, self::ID ) ) {
				continue;
			}

			$config = Config::get( (int) $settings['layout'] );

			if ( $config ) {
				Renderer::enqueue( $config );
			}
		}
	}

	/**
	 * Output
	 *
	 * @param array $args     Sidebar arguments
	 * @param array $instance Widget settings
	 */
	public function widget( $args, $instance ) {
		$instance = $this->defaults( $instance );

		if ( !$instance['layout'] ) {
			return;
		}

		$html = Shortcode::render( [
			'id'       => $instance['layout'],
			'show'     => $instance['show'],
			'instance' => $instance['instance'],
		] );

		// A part the layout has turned off prints nothing: no empty box in the sidebar either
		if ( '' === trim( $html ) ) {
			return;
		}

		$title = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );

		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- the theme's sidebar markup, rendered templates
		echo $args['before_widget'];

		if ( '' !== $title ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
		}

		echo $html;
		echo $args['after_widget'];
		// phpcs:enable
	}

	/**
	 * Settings form
	 *
	 * @param array $instance Widget settings
	 *
	 * @return string
	 */
	public function form( $instance ) {
		$instance = $this->defaults( $instance );
		$layouts  = PostTypes::layouts();
		$parts    = [
			'grid'       => __( 'Grid', 'forma-grid-gallery' ),
			'filter'     => __( 'Filter', 'forma-grid-gallery' ),
			'search'     => __( 'Search', 'forma-grid-gallery' ),
			'sort'       => __( 'Sorting', 'forma-grid-gallery' ),
			'pagination' => __( 'Pagination', 'forma-grid-gallery' ),
		];
		?>
		<div class="forma-widget">
			<p class="forma-widget__field">
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'forma-grid-gallery' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" placeholder="<?php esc_attr_e( 'No title', 'forma-grid-gallery' ); ?>">
			</p>

			<p class="forma-widget__field">
				<span class="forma-widget__label">
					<label for="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>"><?php esc_html_e( 'Grid Layout', 'forma-grid-gallery' ); ?></label>
					<?php if ( $instance['layout'] && current_user_can( 'edit_post', $instance['layout'] ) ) : ?>
						<a href="<?php echo esc_url( (string) get_edit_post_link( $instance['layout'] ) ); ?>" target="_blank"><?php esc_html_e( 'Edit layout', 'forma-grid-gallery' ); ?></a>
					<?php endif; ?>
				</span>
				<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'layout' ) ); ?>">
					<option value=""><?php esc_html_e( 'Choose a layout', 'forma-grid-gallery' ); ?></option>
					<?php foreach ( $layouts as $id => $title ) : ?>
						<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $instance['layout'], $id ); ?>><?php echo esc_html( $title ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>

			<fieldset class="forma-widget__field">
				<legend class="forma-widget__label"><?php esc_html_e( 'Show', 'forma-grid-gallery' ); ?></legend>
				<span class="forma-widget__parts">
					<?php foreach ( $parts as $part => $label ) : ?>
						<label class="forma-widget__part">
							<input type="radio" name="<?php echo esc_attr( $this->get_field_name( 'show' ) ); ?>" value="<?php echo esc_attr( $part ); ?>" <?php checked( $instance['show'], $part ); ?>>
							<span><?php echo esc_html( $label ); ?></span>
						</label>
					<?php endforeach; ?>
				</span>
			</fieldset>

			<p class="forma-widget__field forma-widget__instance">
				<label for="<?php echo esc_attr( $this->get_field_id( 'instance' ) ); ?>"><?php esc_html_e( 'Grid on the page', 'forma-grid-gallery' ); ?></label>
				<input class="small-text" id="<?php echo esc_attr( $this->get_field_id( 'instance' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'instance' ) ); ?>" type="number" min="1" max="20" step="1" value="<?php echo esc_attr( $instance['instance'] ); ?>">
				<small><?php esc_html_e( 'With this layout on the page more than once: which of its grids this part controls (1 = the first).', 'forma-grid-gallery' ); ?></small>
			</p>

			<p class="forma-widget__note">
				<?php
				printf(
					/* translators: %s: link to the Forma Layouts list */
					esc_html__( 'The layout\'s content, look and parts are set in %s. A filter, search, sorting or pagination shows only when the layout has it turned on.', 'forma-grid-gallery' ),
					'<a href="' . esc_url( admin_url( 'edit.php?post_type=' . PostTypes::LAYOUT ) ) . '" target="_blank">' . esc_html__( 'Forma Layouts', 'forma-grid-gallery' ) . '</a>'
				);
				?>
			</p>
		</div>
		<?php

		return '';
	}

	/**
	 * Save the settings
	 *
	 * @param array $new_instance New settings
	 * @param array $old_instance Old settings
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		return $this->defaults( [
			'title'    => sanitize_text_field( $new_instance['title'] ?? '' ),
			'layout'   => $new_instance['layout'] ?? 0,
			'show'     => $new_instance['show'] ?? 'grid',
			'instance' => $new_instance['instance'] ?? 1,
		] );
	}

	/**
	 * Settings with their defaults, checked
	 *
	 * @param array $instance Widget settings
	 *
	 * @return array
	 */
	private function defaults( $instance ) {
		$show = $instance['show'] ?? 'grid';

		return [
			'title'    => (string) ( $instance['title'] ?? '' ),
			'layout'   => absint( $instance['layout'] ?? 0 ),
			'show'     => in_array( $show, Shortcode::PARTS, true ) ? $show : 'grid',
			'instance' => min( 20, max( 1, absint( $instance['instance'] ?? 1 ) ) ),
		];
	}
}
