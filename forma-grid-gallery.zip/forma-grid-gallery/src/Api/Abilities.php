<?php

namespace VLT\Forma\Api;

use VLT\Forma\Core\Animations;
use VLT\Forma\Core\Config;
use VLT\Forma\Core\PostTypes;
use VLT\Forma\Core\Roles;
use VLT\Forma\Front\QueryBuilder;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Front\Shortcode;
use VLT\Forma\Front\SkinManager;
use VLT\Forma\Layouts\LayoutRegistry;
use VLT\Forma\Portfolio\Portfolio;
use VLT\Forma\Sources\SourceRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abilities for AI assistants (WordPress 6.9+ Abilities API)
 *
 *     forma/get-options            allowed values and defaults of a layout's settings
 *     forma/list-layouts           Forma Layouts with their shortcode
 *     forma/get-layout             one layout's settings
 *     forma/create-layout          a new layout
 *     forma/update-layout          changes to a layout
 *     forma/list-portfolio-items   portfolio items
 *     forma/create-portfolio-item  a new portfolio item
 *
 * Settings go through Config::sanitize(); the user's role decides what's allowed.
 */
class Abilities {
	const CATEGORY = 'forma';

	/**
	 * Init, where WordPress has the Abilities API
	 */
	public static function init() {
		if ( !function_exists( 'wp_register_ability' ) ) {
			return;
		}

		add_action( 'wp_abilities_api_categories_init', [ __CLASS__, 'category' ] );
		add_action( 'wp_abilities_api_init', [ __CLASS__, 'register' ] );
	}

	/**
	 * The abilities' category
	 */
	public static function category() {
		// WordPress 6.9+, as the whole Abilities API (init() checks it): here too, for the plugin's 6.5 minimum
		if ( !function_exists( 'wp_register_ability_category' ) ) {
			return;
		}

		wp_register_ability_category( self::CATEGORY, [
			'label'       => __( 'Forma', 'forma-grid-gallery' ),
			'description' => __( 'Forma Layouts (galleries and portfolio grids) and portfolio items.', 'forma-grid-gallery' ),
		] );
	}

	/**
	 * Register the abilities
	 */
	public static function register() {
		$can_layouts = fn() => current_user_can( Roles::LAYOUTS );
		$layout      = [
			'type'       => 'object',
			'properties' => [
				'id'        => [ 'type' => 'integer' ],
				'title'     => [ 'type' => 'string' ],
				'status'    => [ 'type' => 'string' ],
				'shortcode' => [ 'type' => 'string' ],
				'edit_url'  => [ 'type' => 'string' ],
				'config'    => [ 'type' => 'object' ],
			],
		];
		$config_help = __( 'Layout settings, the shape of "defaults" from forma/get-options; give only what differs. Unknown keys and values are dropped.', 'forma-grid-gallery' );

		self::add( 'get-options', [
			'label'               => __( 'Get Grid Layout options', 'forma-grid-gallery' ),
			'description'         => __( 'Lists the values a Grid Layout\'s settings take (layout types, content sources with their taxonomies and orders, skins, filter / search / sort / pagination styles, animations) and the default settings, to build valid settings for forma/create-layout.', 'forma-grid-gallery' ),
			'output_schema'       => [ 'type' => 'object' ],
			'execute_callback'    => [ __CLASS__, 'options' ],
			'permission_callback' => $can_layouts,
		], true );

		self::add( 'list-layouts', [
			'label'               => __( 'List Forma Layouts', 'forma-grid-gallery' ),
			'description'         => __( 'Lists the Forma Layouts (saved grids) with their status, layout type, content source and shortcode.', 'forma-grid-gallery' ),
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [
					'search' => [ 'type' => 'string', 'description' => __( 'Words in the title.', 'forma-grid-gallery' ) ],
				],
			],
			'output_schema'       => [ 'type' => 'array', 'items' => $layout ],
			'execute_callback'    => [ __CLASS__, 'list_layouts' ],
			'permission_callback' => $can_layouts,
		], true );

		self::add( 'get-layout', [
			'label'               => __( 'Get a Forma Layout', 'forma-grid-gallery' ),
			'description'         => __( 'Gets one Forma Layout with all its settings and its shortcode.', 'forma-grid-gallery' ),
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [ 'id' => [ 'type' => 'integer', 'description' => __( 'Layout ID.', 'forma-grid-gallery' ) ] ],
				'required'   => [ 'id' ],
			],
			'output_schema'       => $layout,
			'execute_callback'    => [ __CLASS__, 'get_layout' ],
			'permission_callback' => fn( $input ) => current_user_can( 'edit_post', (int) ( $input['id'] ?? 0 ) ),
		], true );

		self::add( 'create-layout', [
			'label'               => __( 'Create a Forma Layout', 'forma-grid-gallery' ),
			'description'         => __( 'Creates a Forma Layout (a saved grid, gallery or portfolio) from settings, and returns its shortcode to put on a page. A draft unless status is "publish".', 'forma-grid-gallery' ),
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [
					'title'  => [ 'type' => 'string' ],
					'config' => [ 'type' => 'object', 'description' => $config_help ],
					'status' => [ 'type' => 'string', 'enum' => [ 'draft', 'publish' ], 'default' => 'draft' ],
				],
				'required'   => [ 'title' ],
			],
			'output_schema'       => $layout,
			'execute_callback'    => [ __CLASS__, 'create_layout' ],
			'permission_callback' => fn( $input ) => current_user_can( Roles::LAYOUTS ) && ( 'publish' !== ( $input['status'] ?? '' ) || current_user_can( 'publish_forma_layouts' ) ),
		] );

		self::add( 'update-layout', [
			'label'               => __( 'Update a Forma Layout', 'forma-grid-gallery' ),
			'description'         => __( 'Changes a Forma Layout: its title, status, and settings merged into the saved ones (lists are replaced as a whole).', 'forma-grid-gallery' ),
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [
					'id'     => [ 'type' => 'integer' ],
					'title'  => [ 'type' => 'string' ],
					'config' => [ 'type' => 'object', 'description' => $config_help ],
					'status' => [ 'type' => 'string', 'enum' => [ 'draft', 'publish' ] ],
				],
				'required'   => [ 'id' ],
			],
			'output_schema'       => $layout,
			'execute_callback'    => [ __CLASS__, 'update_layout' ],
			'permission_callback' => fn( $input ) => current_user_can( 'edit_post', (int) ( $input['id'] ?? 0 ) ) && ( 'publish' !== ( $input['status'] ?? '' ) || current_user_can( 'publish_forma_layouts' ) ),
		], false, true );

		// Forma's portfolio only, not another plugin's "portfolio" (known once post types are registered: checked on use)
		self::add( 'list-portfolio-items', [
			'label'               => __( 'List portfolio items', 'forma-grid-gallery' ),
			'description'         => __( 'Lists portfolio items (projects) with their categories, tags and featured image.', 'forma-grid-gallery' ),
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [
					'search'   => [ 'type' => 'string' ],
					'category' => [ 'type' => 'string', 'description' => __( 'Category slug.', 'forma-grid-gallery' ) ],
					'per_page' => [ 'type' => 'integer', 'minimum' => 1, 'maximum' => 100, 'default' => 20 ],
				],
			],
			'output_schema'       => [ 'type' => 'array', 'items' => [ 'type' => 'object' ] ],
			'execute_callback'    => [ __CLASS__, 'list_items' ],
			'permission_callback' => fn() => Portfolio::active() && current_user_can( Roles::PORTFOLIO ),
		], true );

		self::add( 'create-portfolio-item', [
			'label'               => __( 'Create a portfolio item', 'forma-grid-gallery' ),
			'description'         => __( 'Creates a portfolio item (a project) with its text, categories and tags (by name, created when missing) and a featured image from the Media Library. A draft unless status is "publish".', 'forma-grid-gallery' ),
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [
					'title'      => [ 'type' => 'string' ],
					'content'    => [ 'type' => 'string' ],
					'excerpt'    => [ 'type' => 'string' ],
					'status'     => [ 'type' => 'string', 'enum' => [ 'draft', 'publish' ], 'default' => 'draft' ],
					'categories' => [ 'type' => 'array', 'items' => [ 'type' => 'string' ] ],
					'tags'       => [ 'type' => 'array', 'items' => [ 'type' => 'string' ] ],
					'image_id'   => [ 'type' => 'integer', 'description' => __( 'Media Library image for its featured image.', 'forma-grid-gallery' ) ],
				],
				'required'   => [ 'title' ],
			],
			'output_schema'       => [ 'type' => 'object' ],
			'execute_callback'    => [ __CLASS__, 'create_item' ],
			'permission_callback' => fn( $input ) => Portfolio::active() && current_user_can( Roles::PORTFOLIO ) && ( 'publish' !== ( $input['status'] ?? '' ) || current_user_can( 'publish_portfolio_items' ) ),
		] );
	}

	/**
	 * Register one ability, open to REST, MCP and AI clients
	 *
	 * @param string $name       Name without the namespace
	 * @param array  $args       Arguments
	 * @param bool   $readonly   It changes nothing
	 * @param bool   $idempotent Running it again with the same input changes nothing more
	 */
	private static function add( $name, array $args, $readonly = false, $idempotent = false ) {
		wp_register_ability( self::CATEGORY . '/' . $name, $args + [
			'category' => self::CATEGORY,
			'meta'     => [
				'annotations' => [
					'readonly'    => $readonly,
					'destructive' => false,
					'idempotent'  => $readonly || $idempotent,
				],
				'public'      => true,
			],
		] );
	}

	/**
	 * forma/get-options
	 *
	 * @return array
	 */
	public static function options() {
		$labels = fn( array $list ) => array_map( fn( $value, $label ) => [ 'value' => (string) $value, 'label' => $label ], array_keys( $list ), $list );
		$styles = [];

		foreach ( array_keys( SkinManager::KINDS ) as $kind ) {
			$styles[ $kind ] = array_keys( SkinManager::styles( $kind ) );
		}

		return [
			'layout_types'     => $labels( array_map( fn( $layout ) => $layout->get_label(), LayoutRegistry::all() ) ),
			'sources'          => array_values( array_map( fn( $source ) => [
				'value'      => $source->get_id(),
				'label'      => $source->get_label(),
				'taxonomies' => $labels( $source->get_taxonomies() ),
				'orderby'    => array_keys( $source->get_orderby_options() ),
			], SourceRegistry::all() ) ),
			'styles'           => $styles,
			'animations'       => array_column( Animations::editor_data(), 'value' ),
			'pagination_types' => array_merge( [ 'none' ], array_keys( Renderer::pagination_types() ) ),
			'visitor_sorts'    => array_keys( QueryBuilder::SORTS ),
			'click_actions'    => [ 'open', 'lightbox', 'none' ],
			'defaults'         => Config::defaults(),
		];
	}

	/**
	 * forma/list-layouts
	 *
	 * @param array|null $input Input
	 *
	 * @return array
	 */
	public static function list_layouts( $input = null ) {
		$posts = get_posts( [
			'post_type'      => PostTypes::LAYOUT,
			'post_status'    => [ 'publish', 'draft', 'pending', 'private' ],
			'posts_per_page' => 100,
			's'              => (string) ( $input['search'] ?? '' ),
		] );

		return array_values( array_map( fn( $post ) => self::layout( $post, false ), array_filter( $posts, fn( $post ) => current_user_can( 'edit_post', $post->ID ) ) ) );
	}

	/**
	 * forma/get-layout
	 *
	 * @param array $input Input
	 *
	 * @return array|\WP_Error
	 */
	public static function get_layout( $input ) {
		$post = get_post( (int) $input['id'] );

		return $post && PostTypes::LAYOUT === $post->post_type ? self::layout( $post, true ) : self::not_found();
	}

	/**
	 * forma/create-layout
	 *
	 * @param array $input Input
	 *
	 * @return array|\WP_Error
	 */
	public static function create_layout( $input ) {
		$id = wp_insert_post( [
			'post_type'    => PostTypes::LAYOUT,
			'post_title'   => sanitize_text_field( (string) $input['title'] ),
			// The editor's template, which only new layouts opened in the editor get: its preview
			'post_content' => '<!-- wp:forma/grid-settings /-->',
			'post_status'  => 'publish' === ( $input['status'] ?? '' ) ? 'publish' : 'draft',
		], true );

		if ( is_wp_error( $id ) ) {
			return $id;
		}

		self::save( $id, Config::merge( Config::defaults(), (array) ( $input['config'] ?? [] ) ) );

		return self::layout( get_post( $id ), true );
	}

	/**
	 * forma/update-layout
	 *
	 * @param array $input Input
	 *
	 * @return array|\WP_Error
	 */
	public static function update_layout( $input ) {
		$post = get_post( (int) $input['id'] );

		if ( !$post || PostTypes::LAYOUT !== $post->post_type ) {
			return self::not_found();
		}

		$changes = array_filter( [
			'ID'          => $post->ID,
			'post_title'  => isset( $input['title'] ) ? sanitize_text_field( (string) $input['title'] ) : null,
			'post_status' => isset( $input['status'] ) ? ( 'publish' === $input['status'] ? 'publish' : 'draft' ) : null,
		], fn( $value ) => null !== $value );

		if ( count( $changes ) > 1 ) {
			$updated = wp_update_post( $changes, true );

			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
		}

		if ( !empty( $input['config'] ) ) {
			self::save( $post->ID, Config::merge( self::config( $post->ID ), (array) $input['config'] ) );
		}

		return self::layout( get_post( $post->ID ), true );
	}

	/**
	 * forma/list-portfolio-items
	 *
	 * @param array|null $input Input
	 *
	 * @return array
	 */
	public static function list_items( $input = null ) {
		$args = [
			'post_type'      => Portfolio::POST_TYPE,
			'post_status'    => [ 'publish', 'draft', 'pending', 'private' ],
			'posts_per_page' => min( 100, max( 1, (int) ( $input['per_page'] ?? 20 ) ) ),
			's'              => (string) ( $input['search'] ?? '' ),
		];

		if ( !empty( $input['category'] ) ) {
			$args['tax_query'] = [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				[
					'taxonomy' => Portfolio::CATEGORY,
					'field'    => 'slug',
					'terms'    => sanitize_title( (string) $input['category'] ),
				],
			];
		}

		$names = fn( $post, $taxonomy ) => wp_list_pluck( (array) ( get_the_terms( $post, $taxonomy ) ?: [] ), 'name' );

		return array_values( array_map( fn( $post ) => [
			'id'         => $post->ID,
			'title'      => get_the_title( $post ),
			'status'     => $post->post_status,
			'url'        => (string) get_permalink( $post ),
			'categories' => $names( $post, Portfolio::CATEGORY ),
			'tags'       => $names( $post, Portfolio::TAG ),
			'image_id'   => (int) get_post_thumbnail_id( $post ),
		], array_filter( get_posts( $args ), fn( $post ) => current_user_can( 'edit_post', $post->ID ) ) ) );
	}

	/**
	 * forma/create-portfolio-item
	 *
	 * @param array $input Input
	 *
	 * @return array|\WP_Error
	 */
	public static function create_item( $input ) {
		$id = wp_insert_post( [
			'post_type'    => Portfolio::POST_TYPE,
			'post_title'   => sanitize_text_field( (string) $input['title'] ),
			'post_content' => wp_kses_post( (string) ( $input['content'] ?? '' ) ),
			'post_excerpt' => sanitize_textarea_field( (string) ( $input['excerpt'] ?? '' ) ),
			'post_status'  => 'publish' === ( $input['status'] ?? '' ) ? 'publish' : 'draft',
		], true );

		if ( is_wp_error( $id ) ) {
			return $id;
		}

		foreach ( [ 'categories' => Portfolio::CATEGORY, 'tags' => Portfolio::TAG ] as $key => $taxonomy ) {
			$names = array_filter( array_map( fn( $name ) => sanitize_text_field( (string) $name ), (array) ( $input[ $key ] ?? [] ) ) );

			if ( $names ) {
				wp_set_object_terms( $id, $names, $taxonomy );
			}
		}

		$image = (int) ( $input['image_id'] ?? 0 );

		if ( $image && wp_attachment_is_image( $image ) ) {
			set_post_thumbnail( $id, $image );
		}

		return [
			'id'       => $id,
			'url'      => (string) get_permalink( $id ),
			'edit_url' => (string) get_edit_post_link( $id, 'raw' ),
		];
	}

	/**
	 * A layout as the abilities return it
	 *
	 * @param \WP_Post $post        Layout
	 * @param bool     $with_config With all its settings
	 *
	 * @return array
	 */
	private static function layout( \WP_Post $post, $with_config ) {
		$config = self::config( $post->ID );

		return array_filter( [
			'id'        => $post->ID,
			'title'     => get_the_title( $post ),
			'status'    => $post->post_status,
			'type'      => $config['layout']['type'],
			'source'    => $config['query']['source'],
			'shortcode' => sprintf( '[%s id="%d"]', Shortcode::TAG, $post->ID ),
			'edit_url'  => (string) get_edit_post_link( $post->ID, 'raw' ),
			'config'    => $with_config ? $config : null,
		], fn( $value ) => null !== $value );
	}

	/**
	 * Saved settings of a layout
	 *
	 * @param int $id Layout ID
	 *
	 * @return array
	 */
	private static function config( $id ) {
		return Config::sanitize( get_post_meta( $id, PostTypes::META_CONFIG, true ) );
	}

	/**
	 * Save settings (sanitized by the meta's own callback, Config::sanitize_meta())
	 *
	 * @param int   $id     Layout ID
	 * @param array $config Settings
	 */
	private static function save( $id, array $config ) {
		update_post_meta( $id, PostTypes::META_CONFIG, wp_slash( (string) wp_json_encode( $config ) ) );
	}

	/**
	 * @return \WP_Error
	 */
	private static function not_found() {
		return new \WP_Error( 'forma_not_found', __( 'Grid layout not found.', 'forma-grid-gallery' ), [ 'status' => 404 ] );
	}
}
