<?php

namespace VLT\Forma\Api;

use VLT\Forma\Core\Config;
use VLT\Forma\Core\Roles;
use VLT\Forma\Front\QueryBuilder;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Sources;
use VLT\Forma\Sources\PostTypeSource;
use VLT\Forma\Sources\SourceRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST routes (forma/v1)
 *
 *     GET /layouts/{id}/items  a page of a layout's items; public. GET with no nonce for visitors, so page caches
 *                              can keep the answers (a nonce would be cached with the page).
 *     GET /terms               editor: terms of a taxonomy
 *     GET /posts               editor: posts of a source
 *
 * Editor routes need Roles::LAYOUTS.
 */
class Rest {
	const NAMESPACE = 'forma/v1';
	const MAX_SEED  = 999999;

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
	}

	/**
	 * Register the routes
	 */
	public static function routes() {
		register_rest_route( self::NAMESPACE, '/layouts/(?P<id>\d+)/items', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ __CLASS__, 'items' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'id'     => [ 'type' => 'integer', 'required' => true ],
				'page'   => [ 'type' => 'integer', 'default' => 1, 'minimum' => 1 ],
				'term'   => [ 'type' => 'integer', 'default' => 0, 'minimum' => 0 ],
				'seed'   => [ 'type' => 'integer', 'default' => 0, 'minimum' => 0, 'maximum' => self::MAX_SEED ],
				'search' => [ 'type' => 'string', 'default' => '' ],
				'sort'   => [ 'type' => 'string', 'default' => '' ],
				// The items the grids above showed when the page loaded (only narrows the result)
				'skip'   => [ 'type' => 'string', 'default' => '' ],
				// "taxonomy:term" of a category or tag page's grid (only narrows the result)
				'scope'  => [ 'type' => 'string', 'default' => '' ],
			],
		] );

		register_rest_route( self::NAMESPACE, '/terms', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ __CLASS__, 'terms' ],
			'permission_callback' => [ __CLASS__, 'can_edit' ],
			'args'                => [
				'taxonomy' => [ 'type' => 'string', 'required' => true ],
			],
		] );

		register_rest_route( self::NAMESPACE, '/posts', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => [ __CLASS__, 'posts' ],
			'permission_callback' => [ __CLASS__, 'can_edit' ],
			'args'                => [
				'source'  => [ 'type' => 'string', 'required' => true ],
				'include' => [ 'type' => 'string', 'default' => '' ],
				'search'  => [ 'type' => 'string', 'default' => '' ],
			],
		] );
	}

	/**
	 * Whether the current user may use the editor's routes
	 *
	 * @return bool
	 */
	public static function can_edit() {
		return current_user_can( Roles::LAYOUTS );
	}

	/**
	 * Address of a route
	 *
	 * @param string $route Route, e.g. /layouts/
	 *
	 * @return string
	 */
	public static function url( $route ) {
		return rest_url( self::NAMESPACE . $route );
	}

	/**
	 * Front end: a page of items
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function items( \WP_REST_Request $request ) {
		$config = Config::get( (int) $request['id'] );
		$page   = (int) $request['page'];
		$term   = (int) $request['term'];
		$search = QueryBuilder::search_words( $request['search'] );
		$sort   = sanitize_key( $request['sort'] );
		$skip   = array_slice( array_filter( array_map( 'absint', explode( ',', sanitize_text_field( $request['skip'] ) ) ) ), 0, 500 );

		if ( !$config ) {
			return new \WP_Error( 'forma_not_found', __( 'Grid layout not found.', 'forma-grid-gallery' ), [ 'status' => 404 ] );
		}

		if ( ( 'none' === $config['pagination']['type'] && $page > 1 ) || ( $term && !QueryBuilder::is_valid_term( $config, $term ) ) ) {
			return new \WP_Error( 'forma_invalid', __( 'Invalid request.', 'forma-grid-gallery' ), [ 'status' => 400 ] );
		}

		$config = self::scope( $config, (string) $request['scope'] );
		$result = QueryBuilder::run( $config, $page, $term, (int) $request['seed'], $search, $skip, $sort );

		return rest_ensure_response( [
			'items'      => Renderer::render_items( $config, $result ),
			'pagination' => Renderer::pagination_html( $config, $result ),
			'page'       => $result['page'],
			'maxPages'   => $result['max_pages'],
		] );
	}

	/**
	 * A category or tag page's grid kept within its term: a real term of a taxonomy the layout's source has
	 *
	 * @param array  $config Layout config
	 * @param string $scope  "taxonomy:term"
	 *
	 * @return array
	 */
	private static function scope( array $config, $scope ) {
		[ $taxonomy, $term ] = array_pad( explode( ':', $scope, 2 ), 2, '' );
		$taxonomy            = sanitize_key( $taxonomy );
		$term                = absint( $term );
		$source              = SourceRegistry::get( $config['query']['source'] );

		if ( $term && $source && isset( $source->get_taxonomies()[ $taxonomy ] ) && term_exists( $term, $taxonomy ) ) {
			$config['query']['taxonomies'][ $taxonomy ] = [ $term ];
		}

		return $config;
	}

	/**
	 * Editor: terms of a taxonomy used by a source
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function terms( \WP_REST_Request $request ) {
		$taxonomy = sanitize_key( $request['taxonomy'] );
		$known    = false;

		foreach ( SourceRegistry::all() as $source ) {
			$known = $known || isset( $source->get_taxonomies()[ $taxonomy ] ) || ( $source instanceof Sources\TermsSource && $source->get_taxonomy() === $taxonomy );
		}

		if ( !$known ) {
			return new \WP_Error( 'forma_invalid', __( 'Invalid request.', 'forma-grid-gallery' ), [ 'status' => 400 ] );
		}

		$terms = get_terms( [
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
			'number'     => 500,
		] );

		return rest_ensure_response( array_map( fn( $term ) => [
			'id'     => $term->term_id,
			'name'   => $term->name,
			'parent' => $term->parent,
		], is_array( $terms ) ? $terms : [] ) );
	}

	/**
	 * Editor: search posts of a source (for "exclude"), or resolve IDs to titles
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function posts( \WP_REST_Request $request ) {
		$source = SourceRegistry::get( sanitize_key( $request['source'] ) );

		if ( !$source instanceof PostTypeSource ) {
			return new \WP_Error( 'forma_invalid', __( 'Invalid request.', 'forma-grid-gallery' ), [ 'status' => 400 ] );
		}

		$include = array_filter( array_map( 'absint', explode( ',', sanitize_text_field( $request['include'] ) ) ) );
		$args    = [
			'post_type'      => $source->get_id(),
			'post_status'    => 'publish',
			'posts_per_page' => $include ? count( $include ) : 20,
			'orderby'        => 'title',
			'order'          => 'ASC',
		];

		if ( $include ) {
			$args['post__in'] = $include;
		} else {
			$args['s'] = sanitize_text_field( $request['search'] );
		}

		return rest_ensure_response( array_map( fn( $post ) => [
			'id'    => $post->ID,
			'title' => get_the_title( $post ) ?: '#' . $post->ID,
			// The preview of a picked post in the editor ('' = no featured image)
			'thumb' => (string) get_the_post_thumbnail_url( $post, 'thumbnail' ),
		], get_posts( $args ) ) );
	}
}
