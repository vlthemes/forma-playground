<?php
/**
 * Functions for themes and other plugins. Use these, not the classes, which may move.
 *
 * @package VLT\Forma
 */

use VLT\Forma\Core\PostTypes;
use VLT\Forma\Front\Lightbox;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Front\Shortcode;
use VLT\Forma\Front\SkinManager;
use VLT\Forma\Plugin;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A layout, as its shortcode prints it
 *
 * @param int   $id   Layout ID
 * @param array $args show (grid, filter, search, sort, pagination), instance (which grid of the layout a control drives)
 *
 * @return string HTML
 */
function forma_render( $id, array $args = [] ) {
	return Shortcode::render( [ 'id' => (int) $id ] + $args );
}

/**
 * Published layouts, for a theme's select controls
 *
 * @return array [ ID => title ]
 */
function forma_layouts() {
	$layouts = [];

	foreach ( get_posts( [ 'post_type' => PostTypes::LAYOUT, 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ] ) as $post ) {
		$layouts[ $post->ID ] = get_the_title( $post ) ?: sprintf( '#%d', $post->ID );
	}

	return $layouts;
}

/**
 * A template of templates/, the theme's copy (your-theme/forma/) first
 *
 * @param string $path Path in templates/, e.g. notices/empty.php
 * @param array  $vars Variables of the template
 *
 * @return string HTML
 */
function forma_get_template( $path, array $vars = [] ) {
	return SkinManager::render_template( $path, $vars );
}

/**
 * Print a part of an item in a skin (templates/item-parts/{name}.php, the theme's copy first)
 *
 *     forma_item_part( 'title', $item, [ 'class' => 'my-card__title', 'tag' => 'h2' ] );
 *
 * @param string $name image, title, terms, date, count, tags, excerpt or play (or a part of the theme's own)
 * @param array  $item Item of the skin
 * @param array  $args Variables of the part (class, and the ones its file lists)
 */
function forma_item_part( $name, array $item, array $args = [] ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rendered template
	echo SkinManager::render_template( 'item-parts/' . sanitize_key( $name ) . '.php', [ 'item' => $item ] + $args );
}

/**
 * An icon of templates/icons/, the theme's copy first
 *
 * @param string $name  File name without .svg
 * @param string $class Class of the <svg>
 *
 * @return string SVG markup
 */
function forma_icon( $name, $class = '' ) {
	return SkinManager::icon( $name, $class );
}

/**
 * Opening tag of an item's link in a skin: the click action's <a>, or a <div> when the item has none
 *
 * @param array  $item  Item of the skin
 * @param string $class Class of the element
 *
 * @return string HTML
 */
function forma_link_start( array $item, $class = '' ) {
	return Renderer::link_start( $item, $class );
}

/**
 * Closing tag for forma_link_start()
 *
 * @param array $item Item of the skin
 *
 * @return string HTML
 */
function forma_link_end( array $item ) {
	return Renderer::link_end( $item );
}

/**
 * Whether a style is one the plugin ships (skins Default and Fade, the default and dropdown controls)
 *
 * @param string $id   Style ID
 * @param string $kind skins, filters, search, sort or pagination
 *
 * @return bool
 */
function forma_is_built_in_style( $id, $kind = 'skins' ) {
	return SkinManager::is_built_in( $id, $kind );
}

/**
 * Lightbox attributes of an image link: elements of one group open as one gallery
 *
 * @param string $group    Group
 * @param int    $image_id Attachment ID (0 = use $src)
 * @param string $caption  Caption (plain text)
 * @param string $src      Image URL when there is no attachment
 *
 * @return array Attributes, [] when the lightbox is off ( forma_attributes() prints them)
 */
function forma_lightbox( $group, $image_id, $caption = '', $src = '' ) {
	return Lightbox::attributes( $group, (int) $image_id, $caption, $src );
}

/**
 * Lightbox attributes of a video or audio link, from an add-on that plays them (forma_lightbox_media)
 *
 * @param string $group     Group
 * @param string $url       Video page or file
 * @param string $kind      video or audio
 * @param string $caption   Caption (plain text)
 * @param int    $poster_id Image an audio file plays under
 *
 * @return array Attributes, [] when nothing plays them or the lightbox is off (the link then opens the URL)
 */
function forma_lightbox_media( $group, $url, $kind = 'video', $caption = '', $poster_id = 0 ) {
	return (array) apply_filters( 'forma_lightbox_media', [], $group, $url, $kind, $caption, (int) $poster_id );
}

/**
 * Attributes as an HTML string, escaped, with a leading space
 *
 * @param array $attributes [ name => value ]
 *
 * @return string
 */
function forma_attributes( array $attributes ) {
	return Lightbox::attributes_html( $attributes );
}

/**
 * Whether Forma Pro runs
 *
 * @return bool
 */
function forma_is_pro() {
	return Plugin::is_pro();
}
