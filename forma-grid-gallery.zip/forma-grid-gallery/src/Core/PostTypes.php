<?php

namespace VLT\Forma\Core;

use VLT\Forma\Front\CssScoper;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Saved grid layouts (forma_layout) and their meta
 *
 * Settings live in two meta keys edited by the block editor UI: the config and the custom CSS. The portfolio post type is its own module (Portfolio).
 */
class PostTypes {
	const LAYOUT = 'forma_layout';

	/**
	 * Layout config meta: JSON, see Config
	 */
	const META_CONFIG = '_forma_config';

	/**
	 * Custom CSS meta, separate so it can require edit_css
	 */
	const META_CSS = '_forma_css';

	/**
	 * Custom CSS a new layout starts with ("selector" = the grid container, see CssScoper)
	 */
	const DEFAULT_CSS = "selector {\n\n}\n";

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'init', [ __CLASS__, 'register' ] );
		add_action( 'admin_menu', [ __CLASS__, 'remove_left_menu_add_new' ], 999 );
	}

	/**
	 * Register the layout post type and meta
	 */
	public static function register() {
		register_post_type( self::LAYOUT, [
			'labels'          => [
				'name'               => esc_html__( 'Forma Layouts', 'forma-grid-gallery' ),
				'singular_name'      => esc_html__( 'Forma Layout', 'forma-grid-gallery' ),
				// The top-level menu, when the portfolio is off; under it the layouts list keeps "Forma Layouts" (all_items)
				'menu_name'          => esc_html__( 'Forma', 'forma-grid-gallery' ),
				'all_items'          => esc_html__( 'Forma Layouts', 'forma-grid-gallery' ),
				'add_new'            => esc_html__( 'Add New', 'forma-grid-gallery' ),
				'add_new_item'       => esc_html__( 'Add New Forma Layout', 'forma-grid-gallery' ),
				'edit_item'          => esc_html__( 'Edit Forma Layout', 'forma-grid-gallery' ),
				'new_item'           => esc_html__( 'New Forma Layout', 'forma-grid-gallery' ),
				'search_items'       => esc_html__( 'Search Forma Layouts', 'forma-grid-gallery' ),
				'not_found'          => esc_html__( 'No forma layouts found', 'forma-grid-gallery' ),
				'not_found_in_trash' => esc_html__( 'No forma layouts found in trash', 'forma-grid-gallery' ),
			],
			'public'          => false,
			'show_ui'         => true,
			// Under Portfolio when it's on, otherwise its own menu
			'show_in_menu'    => Forma::portfolio() ? \VLT\Forma\Portfolio\Portfolio::menu() : true,
			'menu_icon'       => Forma::menu_icon(),
			'menu_position'   => 21,
			'show_in_rest'    => true,
			// edit_forma_layouts…, given to roles in Settings → Roles
			'capability_type' => [ 'forma_layout', 'forma_layouts' ],
			'map_meta_cap'    => true,
			'supports'        => [ 'title', 'editor', 'custom-fields' ],
			// The whole settings UI is one locked block, see assets/src/editor
			'template'        => [ [ 'forma/grid-settings' ] ],
			'template_lock'   => 'all',
		] );

		register_post_meta( self::LAYOUT, self::META_CONFIG, [
			'type'              => 'string',
			'single'            => true,
			'default'           => '',
			'show_in_rest'      => true,
			'sanitize_callback' => [ Config::class, 'sanitize_meta' ],
			'auth_callback'     => [ __CLASS__, 'can_edit_layout' ],
		] );

		register_post_meta( self::LAYOUT, self::META_CSS, [
			'type'              => 'string',
			'single'            => true,
			'default'           => self::DEFAULT_CSS,
			'show_in_rest'      => true,
			'sanitize_callback' => [ CssScoper::class, 'sanitize' ],
			'auth_callback'     => [ __CLASS__, 'can_edit_css' ],
		] );
	}

	/**
	 * Meta auth: editing the layout config
	 *
	 * @param bool   $allowed  Allowed
	 * @param string $meta_key Meta key
	 * @param int    $post_id  Post ID
	 *
	 * @return bool
	 */
	public static function can_edit_layout( $allowed, $meta_key, $post_id ) {
		return current_user_can( 'edit_post', $post_id );
	}

	/**
	 * Meta auth: editing the custom CSS, same rule as WordPress' Additional CSS
	 *
	 * @param bool   $allowed  Allowed
	 * @param string $meta_key Meta key
	 * @param int    $post_id  Post ID
	 *
	 * @return bool
	 */
	public static function can_edit_css( $allowed, $meta_key, $post_id ) {
		return current_user_can( 'edit_post', $post_id ) && current_user_can( 'edit_css' );
	}

	/**
	 * Published layouts by title, for the pickers of the Elementor widget, the WPBakery element and the sidebar widget
	 *
	 * @return array [ id => title ]
	 */
	public static function layouts() {
		$layouts = [];

		foreach ( get_posts( [
			'post_type'   => self::LAYOUT,
			'post_status' => 'publish',
			'numberposts' => -1,
			'orderby'     => 'title',
			'order'       => 'ASC',
		] ) as $layout ) {
			/* translators: %d: layout ID */
			$layouts[ $layout->ID ] = $layout->post_title ?: sprintf( __( 'Layout #%d', 'forma-grid-gallery' ), $layout->ID );
		}

		return $layouts;
	}

	/**
	 * No Add New in the admin sidebar: layouts are added from the Forma Layouts screen
	 */
	public static function remove_left_menu_add_new() {
		remove_submenu_page( Forma::menu_parent(), 'post-new.php?post_type=' . self::LAYOUT );
	}

}

