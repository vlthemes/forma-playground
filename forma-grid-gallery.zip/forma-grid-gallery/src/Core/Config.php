<?php

namespace VLT\Forma\Core;

use VLT\Forma\Admin\Controls;
use VLT\Forma\Front\QueryBuilder;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Front\SkinManager;
use VLT\Forma\Layouts\LayoutRegistry;
use VLT\Forma\Sources;
use VLT\Forma\Sources\SourceRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Layout configuration, stored as JSON in post meta
 *
 * sanitize() runs on save and on load, so a removed source or skin falls back to the default.
 * A stored config carries its version ('v'); upgrade() brings an older one up to VERSION first.
 */
class Config {
	/**
	 * Version of the config's shape: raise it with a step in upgrades() whenever a stored key changes
	 */
	const VERSION = 1;

	/**
	 * Devices of the per-device settings, widest first; a device without its own value takes the wider one's
	 */
	const DEVICES = [ 'desktop', 'tablet_landscape', 'tablet', 'mobile' ];

	/**
	 * Places of the toolbar: row 1 or 2, left, center or right
	 */
	const TOOLBAR_PLACES = [ '1-left', '1-center', '1-right', '2-left', '2-center', '2-right' ];

	/**
	 * Controls the toolbar places
	 */
	const TOOLBAR_CONTROLS = [ 'search', 'filters', 'sort' ];

	/**
	 * Loaded configs, false when missing or not readable
	 *
	 * @var array
	 */
	private static $cache = [];

	/**
	 * Default configuration
	 *
	 * @return array
	 */
	public static function defaults() {
		$layout = [ 'type' => 'grid' ];

		foreach ( LayoutRegistry::all() as $id => $layout_type ) {
			$layout[ $id ] = $layout_type->defaults();
		}

		$defaults = [
			'v'                        => self::VERSION,
			'query'                    => [
				'source'       => Forma::portfolio() ?: 'post',
				'per_page'     => 9,
				'orderby'      => 'date',
				'order'        => 'DESC',
				'offset'       => 0,
				'include'      => [],
				'exclude'      => [],
				'authors'      => [],
					'taxonomies'   => [],
				'tax_relation' => 'OR',
				'search'       => '',
				'images'       => [],
				'image_data'   => [],
				// Media source: the image field each item's title and description come from (MediaSource::FIELDS)
				'media_title'       => 'title',
				'media_description' => 'caption',
				// Leave out what the grids above on the page show
				'skip_shown'   => false,
				// Terms sources: only top-level terms; leave out terms without items
				'top_level'    => false,
				'hide_empty'   => true,
			],
			'layout'                   => $layout,
			// null: the wider device's value (see inherit())
			'responsive'               => [
				'columns' => [
					'desktop'          => 3,
					'tablet_landscape' => null,
					'tablet'           => 2,
					'mobile'           => 1,
				],
				'gap_x'   => self::devices( null, 0, 200, 30 ),
				'gap_y'   => self::devices( null, 0, 200, 30 ),
			],
			'filters'                  => [
				'enabled'    => false,
				'taxonomy'   => '',
				'template'   => SkinManager::default_style( 'filters' ),
				'all_label'  => '',
				'show_count' => false,
			],
			'search'                   => [
				'enabled'     => false,
				'template'    => SkinManager::default_style( 'search' ),
				'placeholder' => '',
			],
			// Orders a visitor can pick (keys of QueryBuilder::SORTS)
			'sort'                     => [
				'enabled'       => false,
				'template'      => SkinManager::default_style( 'sort' ),
				'options'       => [ 'date-desc', 'date-asc', 'title-asc', 'title-desc' ],
				'default_label' => '',
			],
			'pagination'               => [
				'type'            => 'none',
				'template'        => SkinManager::default_style( 'pagination' ),
				'align'           => 'center',
				'load_more_label' => '',
				'loading_label'   => '',
				'no_more_label'   => '',
				// Load More: nothing left once every item is shown (no "No more items")
				'hide_end'        => false,
				// Page numbers: space kept above the grid when a page scrolls it into view (a sticky header)
				'scroll_offset'   => 0,
			],
			'display'                  => [
				'attach_controls' => true,
			],
			// Search, filter and sort in the places of the toolbar ("row-zone" => controls in order), per device. With
			// the grid the rows lay them out above it; by their own shortcodes the zone is their alignment. A control
			// with no place goes where Renderer::places() puts it; a smaller device with none placed takes the wider one's
			'toolbar'                  => array_fill_keys( self::TOOLBAR_PLACES, [] ),
			'toolbar_tablet_landscape' => array_fill_keys( self::TOOLBAR_PLACES, [] ),
			'toolbar_tablet'           => array_fill_keys( self::TOOLBAR_PLACES, [] ),
			'toolbar_mobile'           => array_fill_keys( self::TOOLBAR_PLACES, [] ),
			'animation'                => [
				'effect'       => 'fade-up',
				'duration'     => '500ms',
				'stagger'      => '60ms',
				// Way out of the old items, for effects that have one (Animations)
				'out_duration' => '300ms',
				'out_stagger'  => '30ms',
			],
			'skin'                     => SkinManager::default_style(),
			'click'                    => [
				'action'      => 'open',
				'target'      => '',
				'rel'         => '',
				// Lightbox caption: where its title and its description come from (Renderer::lightbox_text())
				'title'       => 'item',
				'description' => 'excerpt',
			],
			'extra'                    => Controls::defaults(),
		];

		// An add-on's settings, sanitized by its forma_config callback
		return (array) apply_filters( 'forma_config_defaults', $defaults );
	}

	/**
	 * Drafts and private layouts only for users who can edit them
	 *
	 * @param int $layout_id forma_layout post ID
	 *
	 * @return array|null Config with 'id' added, or null
	 */
	public static function get( $layout_id ) {
		$layout_id = absint( $layout_id );

		if ( !isset( self::$cache[ $layout_id ] ) ) {
			self::$cache[ $layout_id ] = false;
			$post                      = $layout_id ? get_post( $layout_id ) : null;

			if ( $post && PostTypes::LAYOUT === $post->post_type
				&& ( 'publish' === $post->post_status || current_user_can( 'edit_post', $layout_id ) ) ) {
				$config       = self::resolve( self::sanitize( get_post_meta( $layout_id, PostTypes::META_CONFIG, true ) ) );
				$config['id'] = $layout_id;

				self::$cache[ $layout_id ] = $config;
			}
		}

		return self::$cache[ $layout_id ] ?: null;
	}

	/**
	 * Config key of a device's toolbar places
	 *
	 * @param string $device Device (DEVICES)
	 *
	 * @return string
	 */
	public static function toolbar_key( $device ) {
		return 'desktop' === $device ? 'toolbar' : 'toolbar_' . $device;
	}

	/**
	 * Settings merged into others: keyed arrays key by key, lists replaced as a whole (included IDs, toolbar zones…)
	 *
	 * @param array $base    Settings
	 * @param array $changes Changes
	 *
	 * @return array
	 */
	public static function merge( array $base, array $changes ) {
		foreach ( $changes as $key => $value ) {
			$base[ $key ] = is_array( $value ) && !array_is_list( $value ) && is_array( $base[ $key ] ?? null ) && !array_is_list( $base[ $key ] )
				? self::merge( $base[ $key ], $value )
				: $value;
		}

		return $base;
	}

	/**
	 * Meta sanitize callback
	 *
	 * @param mixed $value JSON string from the editor
	 *
	 * @return string Normalized JSON
	 */
	public static function sanitize_meta( $value ) {
		return wp_json_encode( self::sanitize( $value ) );
	}

	/**
	 * Whitelist a configuration
	 *
	 * @param mixed $raw JSON string or array
	 *
	 * @return array
	 */
	public static function sanitize( $raw ) {
		if ( is_string( $raw ) ) {
			$raw = json_decode( $raw, true );
		}

		$raw      = self::upgrade( is_array( $raw ) ? $raw : [] );
		$defaults = self::defaults();
		$config   = [ 'v' => self::VERSION ];

		$query   = self::section( $raw, 'query' );
		$sources = SourceRegistry::all();
		$source  = isset( $sources[ $query['source'] ?? '' ] ) ? $query['source'] : $defaults['query']['source'];
		$source  = isset( $sources[ $source ] ) ? $source : (string) array_key_first( $sources );
		$object  = $sources[ $source ] ?? null;

		$taxonomies = $object ? $object->get_taxonomies() : [];
		$tax_terms  = [];

		foreach ( (array) ( $query['taxonomies'] ?? [] ) as $taxonomy => $terms ) {
			$terms = self::ids( $terms );

			if ( isset( $taxonomies[ $taxonomy ] ) && $terms ) {
				$tax_terms[ $taxonomy ] = $terms;
			}
		}

		$config['query'] = [
			'source'       => $source,
			// -1 = all items
			'per_page'     => -1 === (int) ( $query['per_page'] ?? 0 ) ? -1 : self::int( $query['per_page'] ?? null, 1, 100, $defaults['query']['per_page'] ),
			'orderby'      => self::choice( $query['orderby'] ?? '', $object ? array_keys( $object->get_orderby_options() ) : [ 'date' ], $defaults['query']['orderby'] ),
			'order'        => self::choice( $query['order'] ?? '', [ 'ASC', 'DESC' ], 'DESC' ),
			'offset'       => self::int( $query['offset'] ?? null, 0, 1000, 0 ),
			'include'      => array_slice( self::ids( $query['include'] ?? [] ), 0, 200 ),
			'exclude'      => array_slice( self::ids( $query['exclude'] ?? [] ), 0, 200 ),
			'authors'      => array_slice( self::ids( $query['authors'] ?? [] ), 0, 100 ),
			'taxonomies'   => $tax_terms,
			'tax_relation' => self::choice( $query['tax_relation'] ?? '', [ 'AND', 'OR' ], 'OR' ),
			'search'       => mb_substr( sanitize_text_field( (string) ( $query['search'] ?? '' ) ), 0, 100 ),
			'images'       => array_slice( self::ids( $query['images'] ?? [] ), 0, 500 ),
			'media_title'       => self::choice( $query['media_title'] ?? '', Sources\MediaSource::FIELDS, 'title' ),
			'media_description' => self::choice( $query['media_description'] ?? '', Sources\MediaSource::FIELDS, 'caption' ),
			'skip_shown'   => !empty( $query['skip_shown'] ),
			'top_level'    => !empty( $query['top_level'] ),
			'hide_empty'   => !isset( $query['hide_empty'] ) || !empty( $query['hide_empty'] ),
		];

		$config['query']['image_data'] = self::image_data( $query['image_data'] ?? [], $config['query']['images'] );

		// Each type keeps its settings when switching
		$layout           = self::section( $raw, 'layout' );
		$layouts          = LayoutRegistry::all();
		$config['layout'] = [ 'type' => self::choice( $layout['type'] ?? '', array_keys( $layouts ), 'grid' ) ];

		foreach ( $layouts as $id => $layout_type ) {
			$config['layout'][ $id ] = $layout_type->sanitize( is_array( $layout[ $id ] ?? null ) ? $layout[ $id ] : [] );
		}

		$responsive = self::section( $raw, 'responsive' );
		$columns    = is_array( $responsive['columns'] ?? null ) ? $responsive['columns'] : [];
		// A slider can size slides by their content width (Swiper's slidesPerView: 'auto')
		$column     = fn( $device, $fallback ) => 'slider' === $config['layout']['type'] && 'auto' === ( $columns[ $device ] ?? null )
			? 'auto'
			: self::int( $columns[ $device ] ?? null, 1, 12, $fallback );

		$config['responsive'] = [
			'columns' => [
				'desktop'          => $column( 'desktop', 3 ),
				'tablet_landscape' => $column( 'tablet_landscape', null ),
				'tablet'           => $column( 'tablet', 2 ),
				'mobile'           => $column( 'mobile', 1 ),
			],
			'gap_x'   => self::devices( $responsive['gap_x'] ?? null, 0, 200, 30 ),
			'gap_y'   => self::devices( $responsive['gap_y'] ?? null, 0, 200, 30 ),
		];

		$filters  = self::section( $raw, 'filters' );
		$taxonomy = isset( $taxonomies[ $filters['taxonomy'] ?? '' ] ) ? $filters['taxonomy'] : '';

		$config['filters'] = [
			'enabled'    => $taxonomy && !empty( $filters['enabled'] ),
			'taxonomy'   => $taxonomy,
			'template'   => self::style( $filters['template'] ?? '', 'filters' ),
			'all_label'  => sanitize_text_field( (string) ( $filters['all_label'] ?? '' ) ),
			'show_count' => !empty( $filters['show_count'] ),
		];

		$search = self::section( $raw, 'search' );

		$config['search'] = [
			'enabled'     => !empty( $search['enabled'] ),
			'template'    => self::style( $search['template'] ?? '', 'search' ),
			'placeholder' => mb_substr( sanitize_text_field( (string) ( $search['placeholder'] ?? '' ) ), 0, 100 ),
		];

		$sort = self::section( $raw, 'sort' );

		$config['sort'] = [
			'enabled'       => !empty( $sort['enabled'] ),
			'template'      => self::style( $sort['template'] ?? '', 'sort' ),
			// In the order of the list, only those the source can sort by
			'options'       => array_values( array_intersect( array_keys( QueryBuilder::sorts( $object ) ), (array) ( $sort['options'] ?? $defaults['sort']['options'] ) ) ),
			'default_label' => mb_substr( sanitize_text_field( (string) ( $sort['default_label'] ?? '' ) ), 0, 100 ),
		];

		$pagination = self::section( $raw, 'pagination' );

		$config['pagination'] = [
			'type'            => self::choice( $pagination['type'] ?? '', array_merge( [ 'none' ], array_keys( Renderer::pagination_types() ) ), 'none' ),
			'template'        => self::style( $pagination['template'] ?? '', 'pagination' ),
			'align'           => self::choice( $pagination['align'] ?? '', [ 'left', 'center', 'right' ], 'center' ),
			'load_more_label' => sanitize_text_field( (string) ( $pagination['load_more_label'] ?? '' ) ),
			'loading_label'   => sanitize_text_field( (string) ( $pagination['loading_label'] ?? '' ) ),
			'no_more_label'   => sanitize_text_field( (string) ( $pagination['no_more_label'] ?? '' ) ),
			'hide_end'        => !empty( $pagination['hide_end'] ),
			'scroll_offset'   => self::int( $pagination['scroll_offset'] ?? null, 0, 1000, 0 ),
		];

		$display           = self::section( $raw, 'display' );
		$config['display'] = [ 'attach_controls' => !isset( $display['attach_controls'] ) || !empty( $display['attach_controls'] ) ];

		// Each control once per device
		foreach ( self::DEVICES as $device ) {
			$key            = self::toolbar_key( $device );
			$places         = self::section( $raw, $key );
			$config[ $key ] = array_fill_keys( self::TOOLBAR_PLACES, [] );
			$placed         = [];

			foreach ( self::TOOLBAR_PLACES as $place ) {
				foreach ( (array) ( $places[ $place ] ?? [] ) as $control ) {
					if ( in_array( $control, self::TOOLBAR_CONTROLS, true ) && !isset( $placed[ $control ] ) ) {
						$config[ $key ][ $place ][] = $control;
						$placed[ $control ]         = true;
					}
				}
			}
		}

		$animation = self::section( $raw, 'animation' );

		$config['animation'] = [
			'effect'       => sanitize_key( $animation['effect'] ?? $defaults['animation']['effect'] ) ?: 'none',
			'duration'     => self::time( $animation['duration'] ?? null, 100, 2000, 500 ),
			'stagger'      => self::time( $animation['stagger'] ?? null, 0, 300, 60 ),
			'out_duration' => self::time( $animation['out_duration'] ?? null, 100, 1000, 300 ),
			'out_stagger'  => self::time( $animation['out_stagger'] ?? null, 0, 150, 30 ),
		];

		// Registered IDs only: the skin ID becomes part of a file path
		// One the layout type takes (a type for marked card styles only takes those, see SkinManager::fits())
		$config['skin'] = SkinManager::for_layout( self::style( $raw['skin'] ?? '', 'skins' ), $config['layout']['type'] );

		$click = self::section( $raw, 'click' );

		$config['click'] = [
			'action'      => self::choice( $click['action'] ?? '', [ 'open', 'lightbox', 'none' ], 'open' ),
			'target'      => self::choice( $click['target'] ?? '', [ '', '_blank', '_top' ], '' ),
			'rel'         => trim( (string) preg_replace( '/[^a-z\s-]+/', '', strtolower( sanitize_text_field( (string) ( $click['rel'] ?? '' ) ) ) ) ),
			'title'       => self::choice( $click['title'] ?? '', [ 'item', 'image_title', 'image_caption', 'image_alt', 'none' ], 'item' ),
			'description' => self::choice( $click['description'] ?? '', [ 'excerpt', 'image_caption', 'image_description', 'image_alt', 'none' ], 'excerpt' ),
		];

		$config['extra'] = Controls::sanitize( $raw['extra'] ?? [] );

		/**
		 * The sanitized config; an add-on adds its own settings from the raw one here (see forma_config_defaults)
		 *
		 * @param array $config Sanitized config
		 * @param array $raw    Config as sent or stored
		 */
		return apply_filters( 'forma_config', $config, $raw );
	}

	/**
	 * Number per device as saved: desktop always, the others null until they are set
	 *
	 * @param mixed $value   Raw value; one number (older configs) is the desktop's
	 * @param int   $min     Min
	 * @param int   $max     Max
	 * @param int   $desktop Desktop default
	 *
	 * @return array [ device => int|null ] (DEVICES)
	 */
	public static function devices( $value, $min, $max, $desktop ) {
		$value  = is_array( $value ) ? $value : [ 'desktop' => $value ];
		$values = [];

		foreach ( self::DEVICES as $device ) {
			$values[ $device ] = self::int( $value[ $device ] ?? null, $min, $max, 'desktop' === $device ? $desktop : null );
		}

		return $values;
	}

	/**
	 * Every device filled: an empty one takes the value of the next wider device (DEVICES order)
	 *
	 * @param array $values Values per device
	 *
	 * @return array
	 */
	public static function inherit( array $values ) {
		$wider = null;

		foreach ( self::DEVICES as $device ) {
			$values[ $device ] ??= $wider;
			$wider             = $values[ $device ];
		}

		return $values;
	}

	/**
	 * A stored config in the current shape: the steps of every version after its own, oldest first
	 *
	 * Layouts saved before versions were stored (1.0.0) are version 1. Every way in goes through sanitize() (save,
	 * load, REST, abilities, duplicates, imports), so a layout is converted on read and stored so on its next save.
	 *
	 * @param array $raw Config as sent or stored
	 *
	 * @return array
	 */
	public static function upgrade( array $raw ) {
		$version = max( 1, (int) ( $raw['v'] ?? 1 ) );

		foreach ( self::upgrades() as $to => $steps ) {
			if ( $to > $version && $to <= self::VERSION ) {
				foreach ( $steps as $step ) {
					$raw = (array) $step( $raw );
				}
			}
		}

		return $raw;
	}

	/**
	 * Steps by the version they bring a config to
	 *
	 * @return array [ version => [ callable( array $raw ): array ] ]
	 */
	private static function upgrades() {
		/**
		 * Steps of an add-on's own settings, at the version that changes them (Pro raises VERSION with the plugin)
		 *
		 * @param array $upgrades [ version => [ callable ] ]
		 */
		// The plugin's own steps join here: [ 2 => [ [ __CLASS__, 'to_2' ] ] ]
		$upgrades = (array) apply_filters( 'forma_config_upgrades', [] );
		ksort( $upgrades );

		return $upgrades;
	}

	/**
	 * Config for rendering: columns and gaps of every device filled (inherit())
	 *
	 * The saved config keeps the empty ones, so the editor knows which follow the wider device.
	 *
	 * @param array $config Sanitized config
	 *
	 * @return array
	 */
	public static function resolve( array $config ) {
		foreach ( [ 'columns', 'gap_x', 'gap_y' ] as $key ) {
			$config['responsive'][ $key ] = self::inherit( $config['responsive'][ $key ] );
		}

		return $config;
	}

	/**
	 * Get an array section
	 *
	 * @param array  $raw Raw config
	 * @param string $key Section
	 *
	 * @return array
	 */
	private static function section( $raw, $key ) {
		return is_array( $raw[ $key ] ?? null ) ? $raw[ $key ] : [];
	}

	/**
	 * Clamp an integer
	 *
	 * @param mixed $value   Value
	 * @param int   $min     Min
	 * @param int   $max     Max
	 * @param mixed $default Default when not numeric
	 *
	 * @return mixed
	 */
	private static function int( $value, $min, $max, $default ) {
		return is_numeric( $value ) ? max( $min, min( $max, (int) $value ) ) : $default;
	}

	/**
	 * A CSS time: ms or s kept between min and max (a number alone is ms), or a custom property
	 *
	 * @param mixed $value   Value
	 * @param int   $min     Min, ms
	 * @param int   $max     Max, ms
	 * @param int   $default Default, ms
	 *
	 * @return string
	 */
	private static function time( $value, $min, $max, $default ) {
		$value = strtolower( trim( (string) $value ) );

		if ( preg_match( '/^var\(--[a-z0-9_-]+(\s*,\s*[a-z0-9.\s-]+)?\)$/', $value ) ) {
			return $value;
		}

		if ( !preg_match( '/^(\d*\.?\d+)(ms|s)?$/', $value, $match ) ) {
			return $default . 'ms';
		}

		$seconds = 's' === ( $match[2] ?? '' );
		$ms      = (float) $match[1] * ( $seconds ? 1000 : 1 );

		// Seconds stay as typed while in range
		if ( $seconds && $ms >= $min && $ms <= $max ) {
			return $value;
		}

		return (int) round( max( $min, min( $max, $ms ) ) ) . 'ms';
	}

	/**
	 * Value from a whitelist
	 *
	 * @param mixed  $value   Value
	 * @param array  $allowed Allowed values
	 * @param string $default Default
	 *
	 * @return string
	 */
	private static function choice( $value, $allowed, $default ) {
		return in_array( $value, $allowed, true ) ? $value : $default;
	}

	/**
	 * A registered style; else the default one, e.g. the built-in style once the theme registers its own
	 *
	 * @param mixed  $value Value
	 * @param string $kind  Kind (SkinManager::KINDS)
	 *
	 * @return string
	 */
	private static function style( $value, $kind ) {
		return self::choice( $value, array_map( 'strval', array_keys( SkinManager::styles( $kind ) ) ), SkinManager::default_style( $kind ) );
	}

	/**
	 * Per-image overrides of the Media source
	 *
	 * @param mixed $data   Raw [ attachment ID => [ 'title', 'caption', 'link', 'labels', 'extra' (theme fields) ] ]
	 * @param array $images Selected image IDs
	 *
	 * @return array Entries without empty fields; images without overrides are left out
	 */
	private static function image_data( $data, array $images ) {
		$clean = [];

		foreach ( $images as $id ) {
			$entry = is_array( $data[ $id ] ?? null ) ? $data[ $id ] : [];
			$item  = array_filter( [
				'title'   => mb_substr( sanitize_text_field( (string) ( $entry['title'] ?? '' ) ), 0, 200 ),
				'caption' => mb_substr( sanitize_textarea_field( (string) ( $entry['caption'] ?? '' ) ), 0, 1000 ),
				'link'    => esc_url_raw( trim( (string) ( $entry['link'] ?? '' ) ) ),
				'labels'  => self::labels( $entry['labels'] ?? [] ),
				'extra'   => Controls::sanitize_image( $entry['extra'] ?? [] ),
			] );

			if ( $item ) {
				$clean[ $id ] = $item;
			}
		}

		return $clean;
	}

	/**
	 * Image labels: unique, at most 10 of 50 characters
	 *
	 * @param mixed $labels Raw labels
	 *
	 * @return array
	 */
	private static function labels( $labels ) {
		$clean = [];

		foreach ( (array) $labels as $label ) {
			$label = mb_substr( trim( sanitize_text_field( (string) $label ) ), 0, 50 );

			if ( '' !== $label ) {
				$clean[ mb_strtolower( $label ) ] ??= $label;
			}
		}

		return array_slice( array_values( $clean ), 0, 10 );
	}

	/**
	 * Unique positive integer IDs
	 *
	 * @param mixed $ids Value
	 *
	 * @return array
	 */
	private static function ids( $ids ) {
		return array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );
	}
}
