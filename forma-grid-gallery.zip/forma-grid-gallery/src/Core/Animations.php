<?php

namespace VLT\Forma\Core;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Entrance animations in pure CSS. They replay whenever items are inserted (load, filter, Load More), no script.
 * The stagger counts within each batch (--vlt-i), so loaded items don't wait behind earlier ones.
 *
 * Fade up is built in; Pro and themes add effects with forma_animations:
 *
 *     add_filter( 'forma_animations', fn( $presets ) => $presets + [
 *         'flip' => [ 'label' => 'Flip', 'from' => 'opacity:0;transform:perspective(600px) rotateX(-30deg)' ],
 *         'wipe' => [ 'label' => 'Wipe', 'from' => 'clip-path:inset(0 100% 0 0)', 'to' => 'clip-path:inset(-30%)', 'out' => true ],
 *         'pop'  => [ 'label' => 'Pop', 'keyframes' => 'my-theme-pop' ],
 *     ] );
 *
 * `to` is for what can't run back to the item's own style (a clip-path ends at a negative inset so shadows aren't cut).
 * `out`: old items leave one by one on a filter or page.
 */
class Animations {
	/**
	 * Presets cache
	 *
	 * @var array|null
	 */
	private static $presets = null;

	/**
	 * Available presets
	 *
	 * @return array [ key => [ 'label', 'from', 'to', 'out', 'ease' ] | [ 'label', 'keyframes', 'out', 'ease' ] ]
	 */
	public static function presets() {
		if ( null !== self::$presets ) {
			return self::$presets;
		}

		$presets = (array) apply_filters( 'forma_animations', [
			'fade-up' => [
				'label' => __( 'Fade up', 'forma-grid-gallery' ),
				'from'  => 'opacity:0;transform:translateY(24px)',
			],
		] );

		$list = [];

		foreach ( $presets as $key => $preset ) {
			$key = sanitize_key( $key );

			if ( !$key || 'none' === $key ) {
				continue;
			}

			// Declarations / names only: braces and markup can't break out of the generated rules
			if ( !empty( $preset['keyframes'] ) ) {
				$entry = [ 'keyframes' => preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $preset['keyframes'] ) ];
			} elseif ( !empty( $preset['from'] ) ) {
				$entry = [ 'from' => str_replace( [ '{', '}', '<', '>' ], '', (string) $preset['from'] ) ];

				if ( !empty( $preset['to'] ) ) {
					$entry['to'] = str_replace( [ '{', '}', '<', '>' ], '', (string) $preset['to'] );
				}
			} else {
				continue;
			}

			// A timing function only: a keyword or cubic-bezier() / steps() with numbers
			$ease = preg_match( '/^(ease|ease-in|ease-out|ease-in-out|linear|(cubic-bezier|steps)\([0-9.,\s-]+\))$/', (string) ( $preset['ease'] ?? '' ) ) ? $preset['ease'] : 'cubic-bezier(.2,.8,.2,1)';

			$list[ $key ] = [ 'label' => (string) ( $preset['label'] ?? $key ), 'out' => !empty( $preset['out'] ), 'ease' => $ease ] + $entry;
		}

		// Forma Pro and themes add theirs on init: don't freeze a list read before them
		if ( did_action( 'wp_loaded' ) ) {
			self::$presets = $list;
		}

		return $list;
	}

	/**
	 * Keyframes of a preset: its animation name and the @keyframes to print ('' for a theme's own keyframes)
	 *
	 * @param string $key Preset key
	 *
	 * @return array [ name, css ]
	 */
	public static function keyframes( $key ) {
		$preset = self::presets()[ $key ] ?? null;

		if ( !$preset ) {
			return [ '', '' ];
		}

		$name = $preset['keyframes'] ?? 'forma-' . $key;
		$css  = isset( $preset['from'] ) ? sprintf( '@keyframes %s{from{%s}%s}', $name, $preset['from'], isset( $preset['to'] ) ? 'to{' . $preset['to'] . '}' : '' ) : '';

		// Out one by one: the way out of the old items (an animation, not a transition: it takes over from the entrance one)
		if ( $preset['out'] ) {
			$css .= '@keyframes forma-out{from{opacity:1;transform:none}to{opacity:0;transform:scale(.94)}}';
		}

		return [ $name, $css ];
	}

	/**
	 * Animation CSS of a layout
	 *
	 * @param array  $config Layout config
	 * @param string $scope  Scope selector
	 *
	 * @return string
	 */
	public static function css( array $config, $scope ) {
		$animation = $config['animation'];
		$effect    = self::effect( $animation['effect'] );
		$preset    = self::presets()[ $effect ] ?? null;

		if ( !$preset ) {
			return '';
		}

		[ $name, $css ] = self::keyframes( $effect );

		// The old items stay until the answer arrives, then leave (is-swapping) before the new ones come in
		$out_duration = $animation['out_duration'];
		$out_stagger  = $animation['out_stagger'];

		$swap = $preset['out']
			? sprintf( '%%1$s.is-swapping .forma__items{opacity:.999;transition:opacity calc(%s + 10 * %s)}', $out_duration, $out_stagger )
				. sprintf( '%%1$s.is-swapping .forma__item{animation:forma-out %s cubic-bezier(.55,.085,.68,.53) both;animation-delay:calc(min(var(--vlt-i,0),10) * %s)}', $out_duration, $out_stagger )
			: '%1$s.is-swapping .forma__items{opacity:0;transition:opacity .2s}';

		$css .= sprintf(
			// backwards: only before and while it runs, so it lets go of transform and opacity once in (a slider's
			// coverflow and fade set them on the items)
			'%1$s .forma__item{animation:%2$s %3$s %5$s backwards;animation-delay:calc(var(--vlt-i,0) * %4$s)}'
			. '@media (prefers-reduced-motion:no-preference){%1$s.is-loading .forma__items{opacity:1}' . $swap . '}'
			. '@media (prefers-reduced-motion:reduce){%1$s .forma__item{animation:none}}',
			$scope,
			$name,
			$animation['duration'],
			$animation['stagger'],
			$preset['ease'],
		);

		return $css;
	}

	/**
	 * The effect that plays: the layout's, Fade up for one the site doesn't have, none for "none"
	 *
	 * @param string $effect Layout effect
	 *
	 * @return string Preset key or 'none'
	 */
	public static function effect( $effect ) {
		return 'none' === $effect || isset( self::presets()[ $effect ] ) ? $effect : 'fade-up';
	}

	/**
	 * Effects for the editor's Animation section (formaEditor.animations): "None", then the presets with what the
	 * demo box needs (out: a way out of the old items with its own timing; name, keyframes and ease)
	 *
	 * @return array
	 */
	public static function editor_data() {
		return array_merge(
			[ [ 'value' => 'none', 'label' => __( 'None', 'forma-grid-gallery' ) ] ],
			array_map(
				function ( $value, $preset ) {
					[ $name, $keyframes ] = self::keyframes( $value );

					return [ 'value' => (string) $value, 'label' => $preset['label'], 'out' => $preset['out'], 'name' => $name, 'keyframes' => $keyframes, 'ease' => $preset['ease'] ];
				},
				array_keys( self::presets() ),
				self::presets()
			)
		);
	}
}
