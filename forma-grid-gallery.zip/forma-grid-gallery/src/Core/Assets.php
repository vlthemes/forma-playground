<?php

namespace VLT\Forma\Core;

use VLT\Forma\Admin\Admin;
use VLT\Forma\Front\Lightbox;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Integrations\Blocks;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Every script and style of the plugin, registered once and enqueued by handle
 *
 *     'forma' => [ 'script' => 'js/grid.js', 'style' => 'css/grid.css', 'deps' => [] ]
 *     'forma-editor' => [ 'build' => 'editor', 'style_deps' => [ 'wp-components' ], 'translations' => 'forma-grid-gallery' ]
 *
 * 'data' => [ 'formaGrid', callable ] is built on first enqueue only. 'alias' => 'swiper': the handle the theme may
 * have registered the same library under, used instead; with 'shared' => true the plugin's copy takes that handle
 * when it is free, so a theme registering it later gets this one (a library that stays compatible, as GSAP 3).
 * Paths are relative to assets/.
 * More handles through forma_assets.
 */
class Assets {
	const SWIPER = '14.3.0';

	const PHOTOSWIPE = '5.4.4';

	/**
	 * Handles registered
	 *
	 * @var array|null
	 */
	private static $assets = null;

	/**
	 * Handles whose data is printed, per script registry
	 *
	 * @var array [ registry object ID . handle => true ]
	 */
	private static $data = [];

	/**
	 * The script registry the handles are in
	 *
	 * @var \WP_Scripts|null
	 */
	private static $registry = null;

	/**
	 * Init
	 */
	public static function init() {
		// After the theme's (10): the slider uses a Swiper it registered
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'register' ], 15 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'register' ], 5 );
		add_action( 'enqueue_block_assets', [ __CLASS__, 'register' ], 5 );
	}

	/**
	 * The plugin's handles
	 *
	 * @return array [ handle => asset ]
	 */
	public static function all() {
		$all = [
			// Front end
			'forma'           => [ 'script' => 'js/grid.js', 'style' => 'css/grid.css', 'data' => [ 'formaGrid', [ Renderer::class, 'script_data' ] ] ],
			'forma-swiper'         => [ 'script' => 'vendors/js/swiper.js', 'version' => self::SWIPER, 'alias' => 'swiper' ],
			'forma-slider'    => [ 'script' => 'js/grid-slider.js', 'deps' => [ 'forma', 'forma-swiper' ] ],
			'forma-filter-link' => [ 'script' => 'js/grid-filter-link.js', 'deps' => [ 'forma' ] ],
			'forma-views'       => [ 'script' => 'js/views.js' ],
			'forma-photoswipe'     => [ 'script' => 'vendors/js/photoswipe.js', 'style' => 'vendors/css/photoswipe.css', 'version' => self::PHOTOSWIPE ],
			'forma-lightbox'       => [ 'script' => 'js/lightbox.js', 'style' => 'css/lightbox.css', 'deps' => [ 'forma-photoswipe' ], 'data' => [ 'formaLightbox', [ Lightbox::class, 'script_data' ] ] ],
			'forma-admin-bar' => [ 'script' => 'js/admin-bar.js', 'style' => 'css/admin-bar.css', 'deps' => [ 'admin-bar' ] ],
			'forma-preview'   => [ 'script' => 'js/grid-preview.js', 'style' => 'css/grid-preview.css' ],
			'forma-elementor' => [ 'script' => 'js/elementor.js', 'deps' => [ 'forma', 'elementor-frontend' ] ],

			// Admin
			'forma-admin-settings'   => [ 'script' => 'js/admin-settings.js', 'style' => 'css/admin-settings.css' ],
			'forma-admin-welcome'    => [ 'style' => 'css/admin-welcome.css', 'deps' => [ 'forma-admin-settings' ] ],
			'forma-admin-list'       => [ 'style' => 'css/admin-list.css' ],
			'forma-list'             => [ 'style' => 'css/grid-list.css', 'deps' => [ 'forma-admin-list' ] ],
			'forma-elementor-editor' => [ 'style' => 'css/elementor-editor.css' ],
			'forma-admin-widget'     => [ 'style' => 'css/admin-widget.css' ],
			'forma-blocks'           => [ 'build' => 'blocks', 'translations' => 'forma-grid-gallery', 'data' => [ 'formaBlocks', [ Blocks::class, 'script_data' ] ] ],
			'forma-editor'           => [ 'build' => 'editor', 'style_deps' => [ 'wp-components' ], 'translations' => 'forma-grid-gallery', 'data' => [ 'formaEditor', [ Admin::class, 'script_data' ] ] ],
		];

		return (array) apply_filters( 'forma_assets', $all );
	}

	/**
	 * Register every handle (once per script registry)
	 */
	public static function register() {
		// The block editor collects the canvas's assets in fresh registries it swaps back after
		// (_wp_get_iframed_editor_assets()), so the handles go into each registry they are asked for in
		if ( wp_scripts() === self::$registry ) {
			return;
		}

		self::$registry = wp_scripts();
		self::$assets   = [];

		foreach ( self::all() as $handle => $asset ) {
			$asset = self::resolve( $handle, $asset );

			if ( !$asset ) {
				continue;
			}

			// false: an alias, only its dependencies
			if ( $asset['script'] || false === $asset['script'] ) {
				wp_register_script( $handle, $asset['script'], $asset['deps'], $asset['version'], true );

				if ( $asset['translations'] ) {
					wp_set_script_translations( $handle, $asset['translations'] );
				}
			}

			if ( $asset['style'] ) {
				wp_register_style( $handle, $asset['style'], $asset['style_deps'] ?? $asset['deps'], $asset['version'] );

				if ( $asset['rtl'] ) {
					wp_style_add_data( $handle, 'rtl', 'replace' );
				}
			}

			self::$assets[ $handle ] = $asset;
		}
	}

	/**
	 * Enqueue the script and style of handles
	 *
	 * @param string ...$handles Handles
	 */
	public static function enqueue( ...$handles ) {
		self::register();

		foreach ( $handles as $handle ) {
			if ( !empty( self::$assets[ $handle ]['script'] ) ) {
				wp_enqueue_script( $handle );

				$printed = spl_object_id( wp_scripts() ) . $handle;

				if ( !empty( self::$assets[ $handle ]['data'] ) && !isset( self::$data[ $printed ] ) ) {
					self::$data[ $printed ] = true;

					[ $name, $callback ] = self::$assets[ $handle ]['data'];

					self::data( $handle, $name, (array) call_user_func( $callback ) );
				}
			}

			if ( !empty( self::$assets[ $handle ]['style'] ) ) {
				wp_enqueue_style( $handle );
			}
		}
	}

	/**
	 * Enqueue only the style of a handle (enqueue_block_assets: it also reaches the editor canvas)
	 *
	 * @param string $handle Handle
	 */
	public static function enqueue_style( $handle ) {
		self::register();

		if ( !empty( self::$assets[ $handle ]['style'] ) ) {
			wp_enqueue_style( $handle );
		}
	}

	/**
	 * Data for a script, as window.{name} before it
	 *
	 * @param string $handle Handle
	 * @param string $name   Global name
	 * @param array  $data   Data
	 */
	public static function data( $handle, $name, array $data ) {
		self::register();

		wp_add_inline_script( $handle, sprintf( 'window.%s = %s;', $name, wp_json_encode( $data ) ), 'before' );
	}

	/**
	 * URL of a file in assets/
	 *
	 * @param string $path Path relative to assets/
	 *
	 * @return string
	 */
	public static function url( $path ) {
		return FORMA_URL . 'assets/' . ltrim( $path, '/' );
	}

	/**
	 * Files, dependencies and version of a handle; null when its files are missing
	 *
	 * @param string $handle Handle
	 * @param array  $asset  Asset
	 *
	 * @return array|null
	 */
	private static function resolve( $handle, array $asset ) {
		$asset += [
			'script'       => '',
			'style'        => '',
			'deps'         => [],
			'data'         => null,
			'style_deps'   => null,
			'version'      => null,
			'translations' => '',
			'rtl'          => false,
		];

		if ( !empty( $asset['build'] ) ) {
			$manifest = FORMA_PATH . 'assets/build/' . $asset['build'] . '.asset.php';

			if ( !is_file( $manifest ) ) {
				return null;
			}

			$built = require $manifest;

			$asset['script']  = 'build/' . $asset['build'] . '.js';
			$asset['style']   = is_file( FORMA_PATH . 'assets/build/' . $asset['build'] . '.css' ) ? 'build/' . $asset['build'] . '.css' : '';
			$asset['deps']    = array_merge( $built['dependencies'], $asset['deps'] );
			$asset['version'] = $built['version'];
			$asset['rtl']     = true;
			// The bundle's dependencies are scripts
			$asset['style_deps'] ??= [];
		}

		// A library the theme or a page builder registered under its usual handle (alias: swiper, gsap), not a second
		// copy that would replace theirs
		if ( !empty( $asset['alias'] ) && wp_script_is( $asset['alias'], 'registered' ) ) {
			return [ 'script' => false, 'deps' => [ $asset['alias'] ], 'version' => false ] + $asset;
		}

		$file = $asset['script'] ?: $asset['style'];

		if ( !is_file( FORMA_PATH . 'assets/' . $file ) ) {
			return null;
		}

		$asset['version'] ??= FORMA_VERSION . '.' . filemtime( FORMA_PATH . 'assets/' . $file );
		$asset['script']    = $asset['script'] ? self::url( $asset['script'] ) : '';
		$asset['style']     = $asset['style'] ? self::url( $asset['style'] ) : '';

		// The library's own handle, free yet: this copy under it, the plugin's handle its alias
		if ( !empty( $asset['shared'] ) && !empty( $asset['alias'] ) && $asset['script'] ) {
			wp_register_script( $asset['alias'], $asset['script'], $asset['deps'], $asset['version'], true );

			return [ 'script' => false, 'deps' => [ $asset['alias'] ], 'version' => false ] + $asset;
		}

		return $asset;
	}
}
