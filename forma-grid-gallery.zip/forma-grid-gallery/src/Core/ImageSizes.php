<?php

namespace VLT\Forma\Core;

use VLT\Forma\Admin\Settings;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Layout image sizes (forma_sm … forma_xl). Width only, so they keep the ratio and join the srcset.
 */
class ImageSizes {
	/**
	 * Size name => settings field
	 */
	const SIZES = [
		'forma_sm' => 'sm',
		'forma_md' => 'md',
		'forma_lg' => 'lg',
		'forma_xl' => 'xl',
	];

	/**
	 * Init
	 */
	public static function init() {
		// Forma starts on init, after the theme's own sizes
		add_action( 'init', [ __CLASS__, 'register' ] );
		add_filter( 'image_size_names_choose', [ __CLASS__, 'names' ] );
	}

	/**
	 * Labels of the sizes
	 *
	 * @return array [ field => label ]
	 */
	public static function labels() {
		return [
			'sm' => __( 'Small', 'forma-grid-gallery' ),
			'md' => __( 'Medium', 'forma-grid-gallery' ),
			'lg' => __( 'Large', 'forma-grid-gallery' ),
			'xl' => __( 'Extra Large', 'forma-grid-gallery' ),
		];
	}

	/**
	 * Register the sizes with the saved widths
	 */
	public static function register() {
		$widths = Settings::get( 'image_sizes' );

		foreach ( self::SIZES as $name => $field ) {
			if ( !empty( $widths[ $field ] ) ) {
				add_image_size( $name, (int) $widths[ $field ], 9999 );
			}
		}
	}

	/**
	 * The sizes in the media library's size choices
	 *
	 * @param array $sizes Sizes
	 *
	 * @return array
	 */
	public static function names( $sizes ) {
		$labels = self::labels();

		foreach ( self::SIZES as $name => $field ) {
			/* translators: %s: size label (Small, Medium…) */
			$sizes[ $name ] = sprintf( __( 'Portfolio %s', 'forma-grid-gallery' ), $labels[ $field ] );
		}

		return $sizes;
	}

	/**
	 * Size suited to a layout: the more columns, the smaller the image (the srcset still offers the others)
	 *
	 * @param array $config Layout config
	 *
	 * @return string Size name
	 */
	public static function for_layout( array $config ) {
		// Auto (slider): slides as wide as their content, sized like a few columns
		$columns = (int) ( $config['responsive']['columns']['desktop'] ?? 3 ) ?: 3;

		if ( 'justified' === $config['layout']['type'] ) {
			$size = 'forma_md';
		} elseif ( $columns <= 1 ) {
			$size = 'forma_xl';
		} elseif ( 2 === $columns ) {
			$size = 'forma_lg';
		} elseif ( $columns <= 4 ) {
			$size = 'forma_md';
		} else {
			$size = 'forma_sm';
		}

		return (string) apply_filters( 'forma_image_size', $size, $config );
	}
}
