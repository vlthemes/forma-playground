<?php

namespace VLT\Forma\Core;

use VLT\Forma\Admin\Settings;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Upgrades of data outside the layouts (settings, options, post meta), once per site when it updates
 *
 * The layouts themselves upgrade on read (Config::upgrade()). Pro runs its own steps under its own option, so they
 * still run on a site that used the free plugin in between.
 */
class Upgrade {
	const OPTION = 'forma_version';

	/**
	 * Init
	 */
	public static function init() {
		// After the post types and the settings are there
		add_action( 'init', fn() => self::run( self::OPTION, FORMA_VERSION, self::steps() ), 20 );
	}

	/**
	 * Steps of the plugin's data, each safe to run twice
	 *
	 * @return array [ version => callable ]
	 */
	private static function steps() {
		return [];
	}

	/**
	 * Run the steps after the version the site's data was last upgraded to, oldest first
	 *
	 * @param string $option  Option keeping that version
	 * @param string $version Version running
	 * @param array  $steps   [ version => callable ]
	 */
	public static function run( $option, $version, array $steps ) {
		$stored = get_option( $option );

		// No version stored: a new site, or one from 1.0.0, which didn't store it
		if ( false === $stored ) {
			$stored = self::used() ? '1.0.0' : $version;
		}

		if ( version_compare( $stored, $version, '>=' ) ) {
			if ( $stored !== get_option( $option ) ) {
				update_option( $option, $stored );
			}

			return;
		}

		// One request at a time
		if ( get_transient( $option . '_lock' ) ) {
			return;
		}

		set_transient( $option . '_lock', 1, MINUTE_IN_SECONDS );
		uksort( $steps, 'version_compare' );

		foreach ( $steps as $step_version => $step ) {
			if ( version_compare( $step_version, $stored, '>' ) && version_compare( $step_version, $version, '<=' ) ) {
				$step();
				// A step done stays done if a later one stops the request
				update_option( $option, (string) $step_version );
			}
		}

		update_option( $option, $version );
		delete_transient( $option . '_lock' );
	}

	/**
	 * Whether the site has Forma's data: its settings or a layout
	 *
	 * @return bool
	 */
	private static function used() {
		return false !== get_option( Settings::OPTION ) || (bool) get_posts( [
			'post_type'   => PostTypes::LAYOUT,
			'post_status' => 'any',
			'numberposts' => 1,
			'fields'      => 'ids',
		] );
	}
}
