<?php

namespace VLT\Forma\Core;

use VLT\Forma\Admin\Settings;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Access levels per role (Settings → Roles), each adding to the one before
 *
 *     portfolio  portfolio items, categories and tags
 *     layouts    + Forma Layouts
 *     settings   + plugin settings
 *
 * Capabilities are synced whenever the levels change (sync()).
 */
class Roles {
	// Primitive capabilities a post type with this capability_type maps to
	const PORTFOLIO = 'edit_portfolio_items';
	const LAYOUTS   = 'edit_forma_layouts';
	const SETTINGS  = 'manage_forma_settings';

	/**
	 * Levels the roles were last synced with
	 */
	const SYNCED = 'forma_roles_synced';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_init', [ __CLASS__, 'maybe_sync' ] );
	}

	/**
	 * The stored capabilities of a post type whose capability_type has this plural (the singular ones are mapped)
	 *
	 * @param string $plural Plural, e.g. portfolio_items
	 *
	 * @return string[]
	 */
	private static function post_caps( $plural ) {
		return [
			"edit_{$plural}",
			"edit_others_{$plural}",
			"edit_private_{$plural}",
			"edit_published_{$plural}",
			"publish_{$plural}",
			"read_private_{$plural}",
			"delete_{$plural}",
			"delete_others_{$plural}",
			"delete_private_{$plural}",
			"delete_published_{$plural}",
		];
	}

	/**
	 * Capabilities each level adds
	 *
	 * @return array [ level => capabilities ]
	 */
	public static function caps() {
		return [
			'portfolio' => self::post_caps( 'portfolio_items' ),
			'layouts'   => self::post_caps( 'forma_layouts' ),
			'settings'  => [ self::SETTINGS ],
		];
	}

	/**
	 * Levels, in order
	 *
	 * @return array [ level => label ]
	 */
	public static function levels() {
		return [
			'none'      => __( 'No access', 'forma-grid-gallery' ),
			'portfolio' => __( 'Portfolio items', 'forma-grid-gallery' ),
			'layouts'   => __( 'Portfolio items and Forma Layouts', 'forma-grid-gallery' ),
			'settings'  => __( 'Everything, settings too', 'forma-grid-gallery' ),
		];
	}

	/**
	 * Settings → Roles: a level for each role but the administrator's
	 *
	 * @return array Section
	 */
	public static function section() {
		$defaults = [
			'editor' => 'layouts',
			'author' => 'portfolio',
		];
		$fields   = [];

		foreach ( wp_roles()->get_names() as $role => $name ) {
			if ( 'administrator' === $role ) {
				continue;
			}

			$fields[ $role ] = [
				'type'    => 'select',
				'label'   => translate_user_role( $name ),
				'options' => self::levels(),
				'default' => $defaults[ $role ] ?? 'none',
			];
		}

		return [
			'tab'         => __( 'Roles', 'forma-grid-gallery' ),
			'icon'        => 'groups',
			'title'       => __( 'Roles', 'forma-grid-gallery' ),
			'description' => __( 'What each role may do: create and edit portfolio items, Forma Layouts, and change these settings. Administrators may do everything.', 'forma-grid-gallery' ),
			'columns'     => 3,
			'fields'      => $fields,
		];
	}

	/**
	 * Sync the roles when their levels changed since the last time
	 */
	public static function maybe_sync() {
		$levels = Settings::get( 'roles' );

		if ( get_option( self::SYNCED ) !== md5( (string) wp_json_encode( $levels ) ) ) {
			self::sync( $levels );
		}
	}

	/**
	 * Give each role the capabilities of its level and take the others away
	 *
	 * @param array $levels [ role => level ]
	 */
	public static function sync( array $levels ) {
		$caps  = self::caps();
		$order = array_keys( self::levels() );

		foreach ( wp_roles()->role_objects as $name => $role ) {
			$level = 'administrator' === $name ? 'settings' : ( $levels[ $name ] ?? 'none' );
			$rank  = (int) array_search( $level, $order, true );

			foreach ( $caps as $for => $list ) {
				$grant = $rank >= (int) array_search( $for, $order, true );

				foreach ( $list as $cap ) {
					if ( $grant && !$role->has_cap( $cap ) ) {
						$role->add_cap( $cap );
					} elseif ( !$grant && $role->has_cap( $cap ) ) {
						$role->remove_cap( $cap );
					}
				}
			}
		}

		update_option( self::SYNCED, md5( (string) wp_json_encode( $levels ) ) );
	}
}
