<?php

namespace VLT\Forma\Core;

use VLT\Forma\Admin\Admin;
use VLT\Forma\Admin\Preview;
use VLT\Forma\Admin\ReviewNotice;
use VLT\Forma\Admin\Settings;
use VLT\Forma\Admin\Welcome;
use VLT\Forma\Api\Abilities;
use VLT\Forma\Api\Rest;
use VLT\Forma\Front\FilterLink;
use VLT\Forma\Front\Lightbox;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Front\Shortcode;
use VLT\Forma\Integrations\Blocks;
use VLT\Forma\Integrations\Elementor;
use VLT\Forma\Integrations\WPBakery;
use VLT\Forma\Integrations\Widget;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Forma
 */
class Forma {
	/**
	 * Instance
	 *
	 * @var Forma|null
	 */
	private static $instance = null;

	/**
	 * Get instance
	 *
	 * @return Forma
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Portfolio post type, when the module is on
	 *
	 * @return string Post type, or '' without it
	 */
	public static function portfolio() {
		return class_exists( '\VLT\Forma\Portfolio\Portfolio' ) && \VLT\Forma\Portfolio\Portfolio::active() ? \VLT\Forma\Portfolio\Portfolio::POST_TYPE : '';
	}

	/**
	 * The Forma logo as an admin menu icon (assets/icons/menu.svg), in the form WordPress takes an SVG one
	 *
	 * @return string
	 */
	public static function menu_icon() {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local plugin file
		return 'data:image/svg+xml;base64,' . base64_encode( (string) file_get_contents( FORMA_PATH . 'assets/icons/menu.svg' ) );
	}

	/**
	 * Admin menu the Forma pages live in: Portfolio, or the Forma Layouts menu without it
	 *
	 * @return string
	 */
	public static function menu_parent() {
		return 'edit.php?post_type=' . ( self::portfolio() ?: PostTypes::LAYOUT );
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		PostTypes::init();
		Renderer::init();
		Shortcode::init();
		Rest::init();
		Roles::init();
		Abilities::init();
		Blocks::init();
		Admin::init();
		Settings::init();
		Welcome::init();
		ReviewNotice::init();
		Lightbox::init();
		FilterLink::init();
		ImageSizes::init();
		Placeholder::init();
		Preview::init();
		Elementor\Integration::init();
		WPBakery\Integration::init();
		Widget::init();

		// Under the portfolio when it is gone: denied before admin_init; under Forma Layouts while it is on: "Cannot load" after
		add_action( 'admin_page_access_denied', [ __CLASS__, 'redirect_moved_page' ] );
		add_action( 'admin_init', [ __CLASS__, 'redirect_moved_page' ] );
	}

	/**
	 * A Forma page opened under the menu it no longer lives in: the portfolio was switched on or off (saving
	 * that setting comes back to the old address), or an old bookmark. It goes to the page's address now.
	 */
	public static function redirect_moved_page() {
		global $pagenow;

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- only the address of a page is read
		$page = sanitize_key( wp_unslash( $_GET['page'] ?? '' ) );
		$here = $pagenow . '?post_type=' . sanitize_key( wp_unslash( $_GET['post_type'] ?? '' ) );
		// phpcs:enable

		if ( in_array( $page, [ Settings::PAGE, Welcome::PAGE ], true ) && self::menu_parent() !== $here ) {
			// After saving, WordPress adds settings-updated: the notice comes along
			$args = array_intersect_key( wp_unslash( $_GET ), [ 'settings-updated' => true ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			wp_safe_redirect( add_query_arg( [ 'page' => $page ] + array_map( 'sanitize_key', $args ), admin_url( self::menu_parent() ) ) );
			exit;
		}
	}
}
