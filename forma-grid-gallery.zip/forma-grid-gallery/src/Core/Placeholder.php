<?php

namespace VLT\Forma\Core;

use VLT\Forma\Admin\Settings;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Placeholder image for items without one (Settings → Images). Added to the Media Library once.
 */
class Placeholder {
	/**
	 * ID of the imported placeholder (0 = imported, then deleted)
	 */
	const OPTION = 'forma_placeholder';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_init', [ __CLASS__, 'maybe_import' ] );
	}

	/**
	 * Attachment ID of the placeholder, 0 when there is none
	 *
	 * @return int
	 */
	public static function id() {
		$id = (int) ( Settings::get( 'image_sizes' )['placeholder'] ?? 0 );

		return $id && wp_attachment_is_image( $id ) ? $id : 0;
	}

	/**
	 * The plugin's placeholder, the setting's default
	 *
	 * @return int
	 */
	public static function default_id() {
		return (int) get_option( self::OPTION, 0 );
	}

	/**
	 * Add the placeholder to the Media Library, once
	 */
	public static function maybe_import() {
		if ( false !== get_option( self::OPTION ) || !current_user_can( 'upload_files' ) ) {
			return;
		}

		// Stored before the import: a failed one isn't tried again on every page
		update_option( self::OPTION, 0, false );
		update_option( self::OPTION, self::import(), false );
	}

	/**
	 * Copy the placeholder into the uploads as an attachment
	 *
	 * @return int Attachment ID, 0 on failure
	 */
	private static function import() {
		$source = FORMA_PATH . 'assets/images/placeholder.png';

		if ( !is_readable( $source ) ) {
			return 0;
		}

		$upload = wp_upload_bits( 'forma-placeholder.png', null, (string) file_get_contents( $source ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file

		if ( !empty( $upload['error'] ) ) {
			return 0;
		}

		$id = wp_insert_attachment( [
			'post_title'     => __( 'Forma placeholder', 'forma-grid-gallery' ),
			'post_mime_type' => 'image/png',
			'post_status'    => 'inherit',
		], $upload['file'], 0, true );

		if ( is_wp_error( $id ) ) {
			return 0;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';

		wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
		update_post_meta( $id, '_wp_attachment_image_alt', '' );

		return (int) $id;
	}
}
