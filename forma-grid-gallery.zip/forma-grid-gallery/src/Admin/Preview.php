<?php

namespace VLT\Forma\Admin;

use VLT\Forma\Core\Assets;
use VLT\Forma\Core\Config;
use VLT\Forma\Core\PostTypes;
use VLT\Forma\Front\CssScoper;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Front\SkinManager;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Editor preview: a front-end page with the theme's assets but no header or footer
 *
 * WordPress 7.1 isolates the block editor (Document-Isolation-Policy); the frame sends the same header only then,
 * otherwise the editor couldn't read it.
 */
class Preview {
	const QUERY_VAR = 'forma_preview';

	/**
	 * Nonce action of the editor's preview frame
	 */
	const NONCE = 'forma_preview';

	/**
	 * Layout being previewed, 0 when this is not a preview request
	 *
	 * @var int
	 */
	private static $post_id = 0;

	/**
	 * Init
	 */
	public static function init() {
		// After the layouts are registered (edit_post checks one), before the admin bar and 404 handling are set up
		add_action( 'init', [ __CLASS__, 'detect' ], 11 );
		add_action( 'template_redirect', [ __CLASS__, 'maybe_render' ], 0 );
	}

	/**
	 * Whether this request is the editor's preview frame
	 *
	 * @return bool
	 */
	public static function active() {
		return (bool) self::$post_id;
	}

	/**
	 * Preview URL; the timestamp bypasses page caches
	 *
	 * @return string
	 */
	public static function url() {
		return set_url_scheme( add_query_arg( [
			self::QUERY_VAR => '1',
			't'             => time(),
		], trailingslashit( home_url( '/' ) ) ) );
	}

	/**
	 * Validate the request and turn off redirects, caches and the admin bar
	 */
	public static function detect() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- the nonce is checked right below
		if ( is_admin() || !isset( $_GET[ self::QUERY_VAR ] ) ) {
			return;
		}
		// phpcs:enable

		$post_id = absint( $_POST['post_id'] ?? 0 );

		if (
			'POST' !== sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ?? '' ) )
			|| !wp_verify_nonce( sanitize_key( wp_unslash( $_POST['nonce'] ?? '' ) ), self::NONCE )
			|| !$post_id
			|| PostTypes::LAYOUT !== get_post_type( $post_id )
			|| !current_user_can( 'edit_post', $post_id )
		) {
			return;
		}

		self::$post_id = $post_id;

		add_filter( 'show_admin_bar', '__return_false' );
		// Every image of the preview is in view, and it reloads on each change: lazy loading would only fade them in
		// again each time (WordPress's own switch, which lazy-loading plugins can follow too)
		add_filter( 'wp_lazy_loading_enabled', '__return_false' );
		add_filter( 'pre_handle_404', '__return_true' );
		add_filter( 'wp_robots', 'wp_robots_no_robots' );

		// Canonical and Yoast redirects would drop the query var
		remove_action( 'template_redirect', 'redirect_canonical' );

		add_action( 'template_redirect', function () {
			if ( class_exists( '\WPSEO_Frontend' ) ) {
				remove_action( 'template_redirect', [ \WPSEO_Frontend::get_instance(), 'clean_permalink' ], 1 );
			}
		}, -1 );

		add_action( 'wp_enqueue_scripts', function () {
			Assets::enqueue( 'forma-preview' );

			// WooCommerce geolocation reloads the page
			wp_dequeue_script( 'wc-geolocation' );
		}, 11 );

		// Rocket Loader breaks the script order
		add_filter( 'script_loader_tag', fn( $tag ) => str_replace( '<script', '<script data-cfasync="false"', $tag ) );
		add_filter( 'wp_inline_script_attributes', fn( $attributes ) => [ 'data-cfasync' => 'false' ] + $attributes );

		foreach ( [ 'DONOTCACHEPAGE', 'DONOTCACHEDB', 'DONOTMINIFY', 'DONOTCDN', 'DONOTCACHEOBJECT' ] as $constant ) {
			if ( !defined( $constant ) ) {
				define( $constant, true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals
			}
		}
	}

	/**
	 * Print the preview, or 403 for an invalid request
	 */
	public static function maybe_render() {
		// phpcs:disable WordPress.Security.NonceVerification -- checked in detect()
		if ( !isset( $_GET[ self::QUERY_VAR ] ) || is_admin() ) {
			return;
		}

		if ( !self::$post_id ) {
			wp_die( esc_html__( 'You are not allowed to preview this grid layout.', 'forma-grid-gallery' ), '', 403 );
		}

		$post_id = self::$post_id;
		// The unsaved settings of the layout editor, else the saved ones (blocks)
		$config       = isset( $_POST['config'] )
			? Config::resolve( Config::sanitize( wp_unslash( $_POST['config'] ) ) ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON, Config::sanitize() validates every field
			: Config::resolve( Config::sanitize( get_post_meta( $post_id, PostTypes::META_CONFIG, true ) ) );
		$config['id'] = $post_id;

		// The unsaved custom CSS, for users who may edit it
		if ( current_user_can( 'edit_css' ) && isset( $_POST['css'] ) ) {
			$config['custom_css'] = CssScoper::sanitize( wp_unslash( $_POST['css'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- CSS, sanitized by CssScoper
		}

		// Unsaved values of other plugins' editor panels, posted with the config (the nonce is checked in detect())
		$config = (array) apply_filters( 'forma_preview_config', $config, $post_id );

		nocache_headers();
		status_header( 200 );

		if ( !empty( $_POST['isolated'] ) && !headers_sent() ) {
			header( 'Document-Isolation-Policy: isolate-and-credentialless' );
		}
		// phpcs:enable

		// Rendered before wp_head() so its assets land in <head>. The block shows a control on its own (part)
		$part = sanitize_key( wp_unslash( $_POST['part'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification -- checked in detect()

		if ( in_array( $part, [ 'filter', 'search', 'sort', 'pagination' ], true ) ) {
			// Its styles also when the part is off: the notice is styled by them
			Renderer::enqueue( $config );

			$html  = call_user_func( [ Renderer::class, 'render_' . $part ], $config );
			$html  = '' !== trim( $html ) ? $html : Renderer::part_off( $part );
			$state = 'ok';
		} else {
			$html  = Renderer::render( $config, true );
			$state = Renderer::$preview_state;
		}

		$classes = implode( ' ', array_map( 'sanitize_html_class', (array) apply_filters( 'forma_preview_classes', [ 'forma-preview' ], $config ) ) );

		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- rendered template, escaped inside
		echo SkinManager::render_template( 'preview/page.php', [
			'html'    => $html,
			'state'   => $state,
			'classes' => $classes,
			'config'  => $config,
		] );
		// phpcs:enable
		exit;
	}
}
