<?php

namespace VLT\Forma\Admin;

use VLT\Forma\Core\Animations;
use VLT\Forma\Core\Assets;
use VLT\Forma\Core\Config;
use VLT\Forma\Core\Forma;
use VLT\Forma\Core\PostTypes;
use VLT\Forma\Front\QueryBuilder;
use VLT\Forma\Front\Renderer;
use VLT\Forma\Front\Shortcode;
use VLT\Forma\Front\SkinManager;
use VLT\Forma\Integrations\Blocks;
use VLT\Forma\Integrations\Elementor;
use VLT\Forma\Layouts;
use VLT\Forma\Layouts\LayoutRegistry;
use VLT\Forma\Plugin;
use VLT\Forma\Sources;
use VLT\Forma\Sources\SourceRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Grid Layout editor and list screen
 */
class Admin {
	/**
	 * Init
	 */
	/**
	 * admin-post action and nonce prefix
	 */
	const DUPLICATE = 'forma_duplicate';

	public static function init() {
		add_action( 'enqueue_block_editor_assets', [ __CLASS__, 'enqueue_editor' ] );
		add_action( 'enqueue_block_assets', [ __CLASS__, 'enqueue_editor_style' ] );

		add_filter( 'manage_' . PostTypes::LAYOUT . '_posts_columns', [ __CLASS__, 'add_column' ] );
		add_action( 'manage_' . PostTypes::LAYOUT . '_posts_custom_column', [ __CLASS__, 'render_column' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_list_style' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'menu_style' ] );
		add_filter( 'submenu_file', [ __CLASS__, 'submenu_file' ] );
		add_filter( 'post_row_actions', [ __CLASS__, 'row_actions' ], 10, 2 );
		add_action( 'admin_post_' . self::DUPLICATE, [ __CLASS__, 'duplicate' ] );
		add_filter( 'admin_footer_text', [ __CLASS__, 'footer_text' ], 20 );
	}

	/**
	 * Whether the current screen edits a Forma Layout
	 *
	 * @return bool
	 */
	public static function is_layout_screen() {
		$screen = is_admin() && function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		return $screen && PostTypes::LAYOUT === $screen->post_type && $screen->is_block_editor();
	}

	/**
	 * Whether the current screen is one of the plugin's: Forma Layouts, Portfolio items and their terms, Settings,
	 * Welcome
	 *
	 * @return bool
	 */
	public static function is_plugin_screen() {
		$screen = is_admin() && function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( !$screen ) {
			return false;
		}

		return in_array( $screen->post_type, array_filter( [ PostTypes::LAYOUT, Forma::portfolio() ] ), true )
			|| false !== strpos( $screen->id, Settings::PAGE )
			|| false !== strpos( $screen->id, Welcome::PAGE );
	}

	/**
	 * The admin footer of the plugin's screens: "Thank you for creating with WordPress and Forma."
	 *
	 * @param string $text WordPress's footer text
	 *
	 * @return string
	 */
	public static function footer_text( $text ) {
		if ( !self::is_plugin_screen() ) {
			return $text;
		}

		return sprintf(
			/* translators: 1: WordPress link, 2: Forma link */
			__( 'Thank you for creating with %1$s and %2$s.', 'forma-grid-gallery' ),
			'<a href="' . esc_url( __( 'https://wordpress.org/', 'forma-grid-gallery' ) ) . '">WordPress</a>',
			'<a href="' . esc_url( Settings::pro_url() ) . '" target="_blank" rel="noopener">Forma</a>'
		);
	}

	/**
	 * Enqueue the settings UI
	 */
	public static function enqueue_editor() {
		if ( self::is_layout_screen() ) {
			Assets::enqueue( 'forma-editor' );
		}
	}

	/**
	 * Editor styles; enqueue_block_assets also reaches the canvas iframe
	 */
	public static function enqueue_editor_style() {
		if ( self::is_layout_screen() ) {
			Assets::enqueue_style( 'forma-editor' );
		}
	}

	/**
	 * Data of the editor script (window.formaEditor)
	 *
	 * @return array
	 */
	public static function script_data() {
		return (array) apply_filters( 'forma_editor_data', self::editor_data() );
	}

	/**
	 * Editor data
	 *
	 * @return array
	 */
	/**
	 * WordPress's CSS code editor for the Custom CSS panel: its settings, and its files for the panel to load when it
	 * opens (CodeMirror and CSSLint are about 1 MB). False when the user turned off syntax highlighting.
	 *
	 * @return array|false
	 */
	private static function code_editor() {
		if ( 'false' === wp_get_current_user()->syntax_highlighting ) {
			return false;
		}

		$settings = wp_get_code_editor_settings( [ 'type' => 'text/css' ] );

		if ( empty( $settings['codemirror'] ) ) {
			return false;
		}

		return [
			'settings' => $settings,
			'scripts'  => self::files( wp_scripts(), [ 'code-editor', 'csslint' ] ),
			'styles'   => self::files( wp_styles(), [ 'code-editor' ] ),
		];
	}

	/**
	 * Addresses of registered scripts or styles, their dependencies first
	 *
	 * @param \WP_Dependencies $registry wp_scripts() or wp_styles()
	 * @param array            $handles  Handles
	 * @param array            $files    Found so far
	 *
	 * @return array [ handle => URL ]
	 */
	private static function files( \WP_Dependencies $registry, array $handles, array $files = [] ) {
		foreach ( $handles as $handle ) {
			$item = $registry->registered[ $handle ] ?? null;

			if ( !$item || isset( $files[ $handle ] ) ) {
				continue;
			}

			$files = self::files( $registry, $item->deps, $files );

			// An alias (jquery) has no file of its own
			if ( $item->src ) {
				$src              = preg_match( '#^(https?:)?//#', $item->src ) ? $item->src : $registry->base_url . $item->src;
				$files[ $handle ] = add_query_arg( 'ver', $item->ver ?: $registry->default_version, $src );
			}
		}

		return $files;
	}

	/**
	 * Icon of a source in the editor's picker
	 *
	 * @param string                          $id     Source ID
	 * @param Sources\SourceInterface $source Source
	 *
	 * @return string Dashicon class, or an image address
	 */
	private static function source_icon( $id, $source ) {
		if ( $source instanceof Sources\TermsSource ) {
			return is_taxonomy_hierarchical( $source->get_taxonomy() ) ? 'dashicons-category' : 'dashicons-tag';
		}

		if ( 'media' === $id ) {
			return 'dashicons-format-image';
		}

		// Its admin menu icon: a Dashicon, an SVG (data:) or an image address
		$icon = (string) ( get_post_type_object( $id )->menu_icon ?? '' );

		return '' === $icon || 'none' === $icon || 'div' === $icon ? 'dashicons-admin-post' : $icon;
	}

	private static function editor_data() {
		$options = fn( array $list ) => array_map( fn( $value, $label ) => [
			'value' => (string) $value,
			'label' => $label,
		], array_keys( $list ), $list );

		$sources = [];

		foreach ( SourceRegistry::all() as $id => $source ) {
			$sources[] = [
				'value'      => $id,
				'label'      => $source->get_label(),
				'taxonomies' => $options( $source->get_taxonomies() ),
				'orderby'    => $options( $source->get_orderby_options() ),
				'isMedia'    => 'media' === $id,
				'isPostType' => $source instanceof Sources\PostTypeSource,
				'sorts'      => $options( QueryBuilder::sorts( $source ) ),
				'hasAuthors' => $source instanceof Sources\PostTypeSource && post_type_supports( $id, 'author' ),
				// Terms grid: the taxonomy its terms come from
				'terms'      => $source instanceof Sources\TermsSource ? $source->get_taxonomy() : '',
				'icon'       => self::source_icon( $id, $source ),
			];
		}

		$layouts     = [];
		$layout_data = [];

		foreach ( LayoutRegistry::all() as $id => $layout ) {
			$layouts[ $id ]     = $layout->get_label();
			$layout_data[ $id ] = (object) $layout->editor_data();
		}

		$can_edit_css = current_user_can( 'edit_css' );

		// Styles with their group, for the pickers' sections
		$styles = fn( $kind ) => array_map( fn( $id, $style ) => [ 'value' => (string) $id ] + $style, array_keys( SkinManager::registered( $kind ) ), SkinManager::registered( $kind ) );

		return [
			'metaConfig'   => PostTypes::META_CONFIG,
			'metaCss'      => PostTypes::META_CSS,
			// What "Reset all settings" puts back
			'defaultCss'   => PostTypes::DEFAULT_CSS,
			'canEditCss'   => $can_edit_css,
			'codeEditor'   => self::code_editor(),
			// Classes listed under Custom CSS
			'cssClasses'   => array_values( (array) apply_filters( 'forma_css_classes', [
				[ 'selector' => 'selector', 'depth' => 0, 'description' => __( 'Grid container', 'forma-grid-gallery' ) ],
				[ 'selector' => 'selector .forma__items', 'depth' => 1, 'description' => __( 'Items wrapper (grid / columns)', 'forma-grid-gallery' ) ],
				[ 'selector' => 'selector .forma__item', 'depth' => 2, 'description' => __( 'Item (wraps the skin)', 'forma-grid-gallery' ) ],
				[ 'selector' => 'selector .forma__media', 'depth' => 3, 'description' => __( 'Image wrapper, when the skin uses it', 'forma-grid-gallery' ) ],
				[ 'selector' => 'selector .forma__empty', 'depth' => 2, 'description' => __( '"No items found" message', 'forma-grid-gallery' ) ],
			] ) ),
			// Meta keys the editor never sends: without edit_css the REST API would reject the CSS
			'skipMeta'     => $can_edit_css ? [] : [ PostTypes::META_CSS ],
			'defaults'     => Config::defaults(),
			'sources'      => $sources,
			// Animation section: the effects (forma_animations)
			'animations'   => Animations::editor_data(),
			'layouts'      => $options( $layouts ),
			'layoutData'   => (object) $layout_data,
			'skins'        => $styles( 'skins' ),
			'controls'     => (object) Controls::all(),
			'imageControls' => (object) Controls::image_fields(),
			'filterTemplates'     => $styles( 'filters' ),
			'paginationTemplates' => $styles( 'pagination' ),
			'searchTemplates'     => $styles( 'search' ),
			'sortTemplates'       => $styles( 'sort' ),
			'lightboxEnabled'     => class_exists( '\VLT\Forma\Front\Lightbox' ) && \VLT\Forma\Front\Lightbox::enabled(),
			'settingsUrl'         => Settings::url( 'lightbox' ),
			'ratios'       => $options( array_combine( array_keys( Layouts\Image::choices() ), array_keys( Layouts\Image::choices() ) ) ),
			'breakpoints'  => Renderer::breakpoints(),
			'shortcode'    => Shortcode::TAG,
			'previewUrl'   => Preview::url(),
			'nonce'        => wp_create_nonce( Preview::NONCE ),
			'skinsPath'    => 'forma/skins/{style}/skin.php',
			'proUrl'       => Settings::pro_url(),
			// The Media Library's edit screen of an image (the image popup's More details)
			'editMediaUrl' => admin_url( 'post.php?action=edit&post=' ),
		];
	}

	/**
	 * List screen: compact summary columns
	 *
	 * @param array $columns Columns
	 *
	 * @return array
	 */
	public static function add_column( $columns ) {
		$date = $columns['date'] ?? null;
		unset( $columns['date'] );

		$columns['forma_summary']   = esc_html__( 'Layout', 'forma-grid-gallery' );
		$columns['forma_shortcode'] = esc_html__( 'Shortcode', 'forma-grid-gallery' );
		$columns['forma_used']      = esc_html__( 'Used on', 'forma-grid-gallery' );

		if ( $date ) {
			$columns['date'] = $date;
		}

		return $columns;
	}

	/**
	 * List screen: column values
	 *
	 * @param string $column  Column
	 * @param int    $post_id Post ID
	 */
	public static function render_column( $column, $post_id ) {
		if ( 'forma_shortcode' === $column ) {
			echo ListTable::shortcode( sprintf( '[%s id="%d"]', Shortcode::TAG, absint( $post_id ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside
		}

		if ( 'forma_summary' === $column ) {
			echo self::summary( Config::resolve( Config::sanitize( get_post_meta( $post_id, PostTypes::META_CONFIG, true ) ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside
		}

		if ( 'forma_used' === $column ) {
			$used  = self::usage()[ (int) $post_id ] ?? [];
			$links = array_map(
				fn( $id ) => sprintf( '<a href="%s">%s</a>', esc_url( get_permalink( $id ) ), esc_html( get_the_title( $id ) ?: '#' . $id ) ),
				array_slice( $used, 0, 3 )
			);

			if ( count( $used ) > 3 ) {
				/* translators: %d: number of other places */
				$links[] = esc_html( sprintf( __( '+%d more', 'forma-grid-gallery' ), count( $used ) - 3 ) );
			}

			echo ListTable::note( implode( ', ', $links ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above, kses inside
		}
	}

	/**
	 * Posts that use each layout (shortcode, block or Elementor widget). Direct queries, since WordPress can't
	 * search content and meta of every post type for a text.
	 *
	 * @return array [ layout ID => [ post ID, … ] ]
	 */
	private static function usage() {
		static $usage = null;

		if ( null !== $usage ) {
			return $usage;
		}

		global $wpdb;

		$like   = '%' . $wpdb->esc_like( Shortcode::TAG ) . '%';
		$block  = '%' . $wpdb->esc_like( '<!-- wp:' . Blocks::NAME . ' ' ) . '%';
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- see the docblock
		$rows = array_merge(
			$wpdb->get_results( $wpdb->prepare( "SELECT ID AS id, post_content AS text FROM {$wpdb->posts} WHERE ( post_content LIKE %s OR post_content LIKE %s ) AND post_type NOT IN ( 'revision', %s ) AND post_status NOT IN ( 'trash', 'auto-draft', 'inherit' )", $like, $block, PostTypes::LAYOUT ) ),
			$wpdb->get_results( $wpdb->prepare( "SELECT m.post_id AS id, m.meta_value AS text FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = '_elementor_data' AND ( m.meta_value LIKE %s OR m.meta_value LIKE %s ) AND p.post_type <> 'revision' AND p.post_status NOT IN ( 'trash', 'auto-draft', 'inherit' )", $like, '%' . $wpdb->esc_like( Elementor\Integration::WIDGET ) . '%' ) )
		);
		// phpcs:enable

		$usage = [];

		foreach ( $rows as $row ) {
			// Elementor keeps the shortcode in JSON: id=\"12\"
			preg_match_all( '/\[' . preg_quote( Shortcode::TAG, '/' ) . '\s[^\]]*?\bid=\\\\?["\']?(\d+)/', $row->text, $matches );

			$layouts = $matches[1];

			// The block keeps its layout in its attributes: <!-- wp:forma/grid {"layout":12} /-->
			preg_match_all( '/<!-- wp:' . preg_quote( Blocks::NAME, '/' ) . '\s+\{[^}]*?"layout":(\d+)/', $row->text, $matches );

			$layouts = array_merge( $layouts, $matches[1] );

			// The Forma widget keeps its layout in the element's settings
			if ( false !== strpos( $row->text, '"' . Elementor\Integration::WIDGET . '"' ) ) {
				$layouts = array_merge( $layouts, Elementor\Integration::layouts( (array) json_decode( $row->text, true ) ) );
			}

			foreach ( array_unique( $layouts ) as $layout ) {
				$usage[ (int) $layout ][] = (int) $row->id;
			}
		}

		return $usage = array_map( fn( $ids ) => array_values( array_unique( $ids ) ), $usage );
	}

	/**
	 * Layout summary for the list
	 *
	 * @param array $config Layout config
	 *
	 * @return string
	 */
	private static function summary( array $config ) {
		$layout  = LayoutRegistry::get( $config['layout']['type'] );
		$source  = SourceRegistry::get( $config['query']['source'] );
		$columns = $layout ? $layout->columns( $config ) : $config['responsive']['columns'];
		$detail  = $layout ? $layout->summary( $config ) : '';

		$meta = [
			$source ? $source->get_label() : $config['query']['source'],
			-1 === $config['query']['per_page']
				? __( 'all items', 'forma-grid-gallery' )
				/* translators: %d: items per page */
				: sprintf( __( '%d per page', 'forma-grid-gallery' ), $config['query']['per_page'] ),
			/* translators: %s: columns per device, widest first, e.g. "3 / 3 / 2 / 1" */
			sprintf( __( '%s columns', 'forma-grid-gallery' ), implode( ' / ', array_map( fn( $device ) => $columns[ $device ], Config::DEVICES ) ) ),
		];

		if ( $layout && !$layout->uses_columns() ) {
			array_pop( $meta );
		}

		$badges = [];

		if ( 'lightbox' === $config['click']['action'] ) {
			$badges[] = [ __( 'Lightbox', 'forma-grid-gallery' ), '', self::icon( 'click' ) ];
		}

		if ( $config['search']['enabled'] ) {
			$badges[] = [ __( 'Search', 'forma-grid-gallery' ), '', self::icon( 'search' ) ];
		}

		if ( $config['filters']['enabled'] ) {
			$badges[] = [ __( 'Filter', 'forma-grid-gallery' ), '', self::icon( 'filter' ) ];
		}

		if ( $config['sort']['enabled'] && $config['sort']['options'] ) {
			$badges[] = [ __( 'Sorting', 'forma-grid-gallery' ), '', self::icon( 'sort' ) ];
		}

		$pages = [
			'numbers'  => __( 'Pages', 'forma-grid-gallery' ),
			'loadmore' => __( 'Load More', 'forma-grid-gallery' ),
		];

		// An add-on's pagination type gets its badge from it (forma_summary_badges)
		if ( isset( $pages[ $config['pagination']['type'] ] ) && -1 !== $config['query']['per_page'] ) {
			$badges[] = [ $pages[ $config['pagination']['type'] ], '', self::icon( 'pagination' ) ];
		}

		// [ label, class, icon SVG ]
		$badges = (array) apply_filters( 'forma_summary_badges', $badges, $config );
		$skins  = SkinManager::registered();

		$badges[] = SkinManager::locate( $config['skin'], 'template' )
			/* translators: %s: skin name */
			? [ sprintf( __( 'Skin: %s', 'forma-grid-gallery' ), isset( $skins[ $config['skin'] ] ) ? trim( $skins[ $config['skin'] ]['group'] . ' ' . $skins[ $config['skin'] ]['label'] ) : $config['skin'] ), '', self::icon( 'skin' ) ]
			: [ __( 'No skin', 'forma-grid-gallery' ), 'is-warning' ];

		return ListTable::summary( $layout ? $layout->get_label() : $config['layout']['type'], (string) $detail, [ esc_html( implode( ' · ', $meta ) ) ], $badges, $layout ? $layout->sketch( $config ) : '' );
	}

	/**
	 * Editor section icon from assets/icons
	 *
	 * @param string $name Icon name
	 *
	 * @return string SVG markup, '' when there is no such icon
	 */
	public static function icon( $name ) {
		static $cache = [];

		if ( !isset( $cache[ $name ] ) ) {
			$file           = FORMA_PATH . 'assets/icons/' . sanitize_key( $name ) . '.svg';
			$cache[ $name ] = is_file( $file ) ? str_replace( '<svg ', '<svg aria-hidden="true" focusable="false" ', trim( (string) file_get_contents( $file ) ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local plugin file
		}

		return $cache[ $name ];
	}


	/**
	 * "Duplicate" row action
	 *
	 * @param array    $actions Row actions
	 * @param \WP_Post $post    Post
	 *
	 * @return array
	 */
	public static function row_actions( $actions, $post ) {
		if ( PostTypes::LAYOUT !== $post->post_type || !self::can_duplicate( $post ) ) {
			return $actions;
		}

		$url = wp_nonce_url( admin_url( 'admin-post.php?action=' . self::DUPLICATE . '&post=' . $post->ID ), self::DUPLICATE . '_' . $post->ID );

		$actions = array_slice( $actions, 0, 1, true ) + [
			'forma_duplicate' => sprintf(
				'<a href="%s" aria-label="%s">%s</a>',
				esc_url( $url ),
				/* translators: %s: layout title */
				esc_attr( sprintf( __( 'Duplicate “%s”', 'forma-grid-gallery' ), get_the_title( $post ) ) ),
				esc_html__( 'Duplicate', 'forma-grid-gallery' )
			),
		] + $actions;

		return $actions;
	}

	/**
	 * Whether the user can copy a layout
	 *
	 * @param \WP_Post $post Layout
	 *
	 * @return bool
	 */
	private static function can_duplicate( $post ) {
		$type = get_post_type_object( PostTypes::LAYOUT );

		return $type && current_user_can( 'edit_post', $post->ID ) && current_user_can( $type->cap->create_posts );
	}

	/**
	 * Copy a layout as a draft and open it
	 */
	public static function duplicate() {
		$id   = absint( $_GET['post'] ?? 0 );
		$post = get_post( $id );

		check_admin_referer( self::DUPLICATE . '_' . $id );

		if ( !$post || PostTypes::LAYOUT !== $post->post_type || !self::can_duplicate( $post ) ) {
			wp_die( esc_html__( 'You are not allowed to duplicate this layout.', 'forma-grid-gallery' ), 403 );
		}

		$copy = wp_insert_post( wp_slash( [
			'post_type'    => PostTypes::LAYOUT,
			'post_status'  => 'draft',
			/* translators: %s: layout title */
			'post_title'   => sprintf( __( '%s (Copy)', 'forma-grid-gallery' ), $post->post_title ),
			'post_content' => $post->post_content,
		] ), true );

		if ( is_wp_error( $copy ) ) {
			wp_die( esc_html( $copy->get_error_message() ) );
		}

		// update_post_meta() unslashes, which would break the JSON
		foreach ( (array) apply_filters( 'forma_duplicate_meta', [ PostTypes::META_CONFIG, PostTypes::META_CSS ] ) as $key ) {
			if ( metadata_exists( 'post', $post->ID, $key ) ) {
				update_post_meta( $copy, $key, wp_slash( get_post_meta( $post->ID, $key, true ) ) );
			}
		}

		wp_safe_redirect( get_edit_post_link( $copy, 'raw' ) );
		exit;
	}

	/**
	 * "Add New" screens have no menu item of their own: the list of that post type is the current one
	 *
	 * @param string|null $submenu_file Current submenu item
	 *
	 * @return string|null
	 */
	public static function submenu_file( $submenu_file ) {
		$screen = get_current_screen();

		if ( $screen && 'add' === $screen->action && in_array( $screen->post_type, [ PostTypes::LAYOUT, Forma::portfolio() ], true ) ) {
			return 'edit.php?post_type=' . $screen->post_type;
		}

		return $submenu_file;
	}

	/**
	 * Menu dividers above Forma Layouts and Settings; accents that leave the current item WordPress' own look
	 */
	public static function menu_style() {
		$link      = 'a[href="edit.php?post_type=' . PostTypes::LAYOUT . '"]';
		$dividers  = [ '#adminmenu li:has(> a[href$="page=' . Settings::PAGE . '"])' ];
		$highlight = '';

		if ( Forma::portfolio() ) {
			$dividers[] = '#adminmenu li:has(> ' . $link . ')';
			$highlight  = '#adminmenu li:not(.current) > ' . $link . '{font-weight:600;}';
		}

		if ( !Plugin::is_pro() ) {
			// Exact: the Documentation link may share the start of the URL
			$highlight .= '#adminmenu li:not(.current) > a[href="' . str_replace( '"', '', untrailingslashit( Settings::pro_url() ) ) . '"],.plugins .forma-get-pro a{font-weight:600;color:#ff5a3c !important}';
		}

		wp_register_style( 'forma-menu', false, [], FORMA_VERSION );
		wp_enqueue_style( 'forma-menu' );
		wp_add_inline_style( 'forma-menu', implode( ',', $dividers ) . '{margin-top:6px;padding-top:6px;border-top:1px solid rgba(255,255,255,.12)}' . $highlight );
	}

	/**
	 * List screen styles
	 */
	public static function enqueue_list_style() {
		$screen = get_current_screen();

		ListTable::screen( 'edit-' . PostTypes::LAYOUT );

		if ( $screen && 'edit-' . PostTypes::LAYOUT === $screen->id ) {
			Assets::enqueue( 'forma-list' );
		}
	}
}
