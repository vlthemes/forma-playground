<?php

namespace VLT\Forma\Admin;

use VLT\Forma\Core\Config;
use VLT\Forma\Core\PostTypes;
use VLT\Forma\Core\Roles;
use VLT\Forma\Front\QueryBuilder;
use VLT\Forma\Portfolio\Portfolio;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A wordpress.org review, asked once per site: after a Forma Layout with items is saved, on the Forma Layouts and
 * Portfolio lists (the block editor shows no admin notices). Either answer ends it.
 */
class ReviewNotice {
	/**
	 * '' = not yet, 'due' = ask, 'done' = asked
	 */
	const OPTION = 'forma_review';
	const ACTION = 'forma_review';
	const URL    = 'https://wordpress.org/support/plugin/forma-grid-gallery/reviews/#new-post';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'rest_after_insert_' . PostTypes::LAYOUT, [ __CLASS__, 'saved' ] );
		add_action( 'admin_notices', [ __CLASS__, 'render' ] );
		add_action( 'admin_post_' . self::ACTION, [ __CLASS__, 'handle' ] );
	}

	/**
	 * A layout saved in the editor: due once it shows items
	 *
	 * @param \WP_Post $post Layout
	 */
	public static function saved( $post ) {
		if ( get_option( self::OPTION ) || 'publish' !== $post->post_status ) {
			return;
		}

		$config = Config::get( $post->ID );

		if ( $config && QueryBuilder::run( $config, 1 )['items'] ) {
			update_option( self::OPTION, 'due', false );
		}
	}

	/**
	 * The notice, on the lists of layouts and portfolio items
	 */
	public static function render() {
		$screen = get_current_screen();

		if ( 'due' !== get_option( self::OPTION ) || !current_user_can( Roles::LAYOUTS ) || !$screen || 'edit' !== $screen->base
			|| !in_array( $screen->post_type, [ PostTypes::LAYOUT, Portfolio::POST_TYPE ], true ) ) {
			return;
		}

		$link = fn( $answer ) => wp_nonce_url( add_query_arg( [ 'action' => self::ACTION, 'answer' => $answer ], admin_url( 'admin-post.php' ) ), self::ACTION );
		?>
		<div class="notice notice-info forma-review">
			<span class="forma-review__logo" aria-hidden="true"><?php echo Admin::icon( 'logo' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own SVG ?></span>
			<div class="forma-review__body">
				<span class="forma-review__stars" aria-hidden="true"><?php echo str_repeat( '<span class="dashicons dashicons-star-filled"></span>', 5 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed markup ?></span>
				<p><strong><?php esc_html_e( 'Your grid is live!', 'forma-grid-gallery' ); ?></strong></p>
				<p><?php esc_html_e( 'If Forma helps you, a review on WordPress.org helps others find it. It takes a minute.', 'forma-grid-gallery' ); ?></p>
				<p class="forma-review__actions">
					<a class="button button-primary" href="<?php echo esc_url( $link( 'review' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Leave a review', 'forma-grid-gallery' ); ?></a>
					<a class="button" href="<?php echo esc_url( $link( 'no' ) ); ?>"><?php esc_html_e( 'No, thanks', 'forma-grid-gallery' ); ?></a>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * An answer: either one ends it; "Leave a review" goes on to the review form
	 */
	public static function handle() {
		check_admin_referer( self::ACTION );

		if ( !current_user_can( Roles::LAYOUTS ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'forma-grid-gallery' ), 403 );
		}

		update_option( self::OPTION, 'done', false );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- checked above
		if ( 'review' === sanitize_key( wp_unslash( $_GET['answer'] ?? '' ) ) ) {
			wp_redirect( self::URL ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- wordpress.org
			exit;
		}

		wp_safe_redirect( wp_get_referer() ?: admin_url( 'edit.php?post_type=' . PostTypes::LAYOUT ) );
		exit;
	}
}
