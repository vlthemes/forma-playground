<?php

namespace VLT\Forma\Admin;

use VLT\Forma\Core\Forma;
use VLT\Forma\Core\ImageSizes;
use VLT\Forma\Core\Placeholder;
use VLT\Forma\Core\Roles;
use VLT\Forma\Plugin;
use VLT\Forma\Portfolio;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin settings page and the Documentation menu link
 *
 * Values: Settings::get( 'section' ). More tabs: the forma_settings_tabs filter.
 */
class Settings {
	const OPTION = 'forma_settings';
	const PAGE   = 'forma-settings';

	/**
	 * The page
	 *
	 * @var SettingsPage|null
	 */
	private static $page = null;

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 31 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'docs_link' ] );
		add_filter( 'plugin_action_links_' . plugin_basename( FORMA_FILE ), [ __CLASS__, 'action_links' ] );
		self::page();
	}

	/**
	 * The plugin's row in Plugins: Settings, and Get Pro without Pro
	 *
	 * @param array $links Action links
	 *
	 * @return array
	 */
	public static function action_links( array $links ) {
		$links = [ 'forma-settings' => '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Settings', 'forma-grid-gallery' ) . '</a>' ] + $links;

		if ( !Plugin::is_pro() ) {
			$links['forma-get-pro'] = '<a href="' . esc_url( self::pro_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'Get Pro', 'forma-grid-gallery' ) . '</a>';
		}

		return $links;
	}

	/**
	 * The settings page
	 *
	 * @return SettingsPage
	 */
	private static function page() {
		self::$page ??= new SettingsPage( [
			'option'      => self::OPTION,
			'page'        => self::PAGE,
			'parent'      => [ Forma::class, 'menu_parent' ],
			'title'       => __( 'Forma Settings', 'forma-grid-gallery' ),
			'menu_title'  => __( 'Settings', 'forma-grid-gallery' ),
			'name'        => __( 'Forma', 'forma-grid-gallery' ),
			'version'     => FORMA_VERSION,
			// The Forma mark, violet to coral as on the landing page
			'icon'        => Admin::icon( 'logo' ),
			'sections'    => [ __CLASS__, 'sections' ],
			'tabs_filter' => 'forma_settings_tabs',
			'validate'    => [ __CLASS__, 'validate' ],
			'docs_url'    => self::docs_url(),
			'support_url' => (string) apply_filters( 'forma_support_url', 'https://vlthemes.me/support-ticket/' ),
			'capability'  => Roles::SETTINGS,
		] );

		return self::$page;
	}

	/**
	 * Sections and their fields; forma_settings_sections adds more (Forma Pro: Filters)
	 *
	 * @return array
	 */
	public static function sections() {
		return (array) apply_filters( 'forma_settings_sections', [
			'portfolio'   => [
				'tab'         => __( 'Portfolio', 'forma-grid-gallery' ),
				'icon'        => 'portfolio',
				'title'       => __( 'Portfolio', 'forma-grid-gallery' ),
				'description' => __( 'Your projects as their own kind of content, with categories and tags, ready for any Forma Layout. Without it, Forma Layouts show posts, pages or media.', 'forma-grid-gallery' ),
				// The theme or another plugin has a portfolio of its own: theirs is used, this one stays off
				'notices'     => Portfolio\Portfolio::conflict() ? [
					[
						'type' => 'warning',
						'text' => __( 'Your theme or another plugin already has a Portfolio (the "portfolio" post type), so Forma\'s stays off and leaves it as it is. Forma Layouts can show its items like any other content.', 'forma-grid-gallery' ),
					],
				] : [],
				'columns'     => 3,
				'groups'      => [
					'addresses' => [
						'title'       => __( 'Addresses', 'forma-grid-gallery' ),
						'description' => __( 'The part of the link that comes before a project, category or tag name.', 'forma-grid-gallery' ),
						'show_if'     => 'enabled',
					],
				],
				'fields'      => [
					'enabled'       => [
						'type'    => 'toggle',
						'label'   => __( 'Use the portfolio', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'Off: the Portfolio menu goes away and Forma Layouts get a menu of their own. Projects are kept and come back when it is on again.', 'forma-grid-gallery' ),
					],
					'archive_page'  => [
						'type'    => 'select',
						'label'   => __( 'Archive page', 'forma-grid-gallery' ),
						'help'    => __( 'The portfolio\'s address and its category and tag pages show this page, built with blocks or any page builder. Its Forma Layouts keep to the category or tag: a filter by it starts on it, otherwise only its items show.', 'forma-grid-gallery' ),
						'options' => Portfolio\Portfolio::archive_options(),
						'default' => '',
						'show_if' => 'enabled',
					],
					'views'         => [
						'type'    => 'toggle',
						'label'   => __( 'Count views', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'Counts visits to each project\'s page. The projects list shows them in a Views column, and Forma Layouts can sort by them. Visits by people who can edit the project don\'t count.', 'forma-grid-gallery' ),
						'show_if' => 'enabled',
					],
					'item_base'     => [
						'type'    => 'slug',
						'group'   => 'addresses',
						'label'   => __( 'Project', 'forma-grid-gallery' ),
						'default' => 'portfolio',
						// Without the scheme, as the address bar shows it
						'preview' => preg_replace( '#^https?://#', '', home_url( '/%s/project-name/' ) ),
					],
					'category_base' => [
						'type'    => 'slug',
						'group'   => 'addresses',
						'label'   => __( 'Category', 'forma-grid-gallery' ),
						'default' => 'portfolio-category',
					],
					'tag_base'      => [
						'type'    => 'slug',
						'group'   => 'addresses',
						'label'   => __( 'Tag', 'forma-grid-gallery' ),
						'default' => 'portfolio-tag',
					],
				],
			],
			'breakpoints' => [
				'tab'         => __( 'Breakpoints', 'forma-grid-gallery' ),
				'icon'        => 'laptop',
				'title'       => __( 'Responsive Breakpoints', 'forma-grid-gallery' ),
				'description' => __( 'Screen widths where grids switch to their tablet and mobile columns, gaps and Metro patterns.', 'forma-grid-gallery' ),
				'fields'      => [
					'tablet_landscape' => [
						'type'    => 'number',
						'label'   => __( 'Tablet Landscape', 'forma-grid-gallery' ),
						'icon'    => Admin::icon( 'device-tablet-landscape' ),
						'help'    => __( 'Tablet landscape settings apply up to this width.', 'forma-grid-gallery' ),
						'default' => 1200,
						'min'     => 640,
						'max'     => 2560,
						'unit'    => 'px',
					],
					'tablet'           => [
						'type'    => 'number',
						'label'   => __( 'Tablet Portrait', 'forma-grid-gallery' ),
						'icon'    => Admin::icon( 'device-tablet' ),
						'help'    => __( 'Tablet portrait settings apply up to this width; must be below the landscape one.', 'forma-grid-gallery' ),
						'default' => 1024,
						'min'     => 480,
						'max'     => 2560,
						'unit'    => 'px',
					],
					'mobile'           => [
						'type'    => 'number',
						'label'   => __( 'Mobile Portrait', 'forma-grid-gallery' ),
						'icon'    => Admin::icon( 'device-mobile' ),
						'help'    => __( 'Mobile settings apply up to this width; must be below the tablet portrait one.', 'forma-grid-gallery' ),
						'default' => 767,
						'min'     => 320,
						'max'     => 2559,
						'unit'    => 'px',
					],
				],
			],
			'image_sizes' => [
				'tab'         => __( 'Images', 'forma-grid-gallery' ),
				'icon'        => 'format-image',
				'title'       => __( 'Images', 'forma-grid-gallery' ),
				'description' => __( 'The image of items that have none, and the image files WordPress makes for the grids when you upload.', 'forma-grid-gallery' ),
				'columns'     => 4,
				'groups'      => [
					'sizes' => [
						'title'       => __( 'Image sizes', 'forma-grid-gallery' ),
						'description' => __( 'Widths in px, the height follows each image. New widths apply to new uploads; regenerate thumbnails for existing images.', 'forma-grid-gallery' ),
					],
				],
				'fields'      => [
					'placeholder' => [
						'type'    => 'image',
						'label'   => __( 'Placeholder image', 'forma-grid-gallery' ),
						'help'    => __( 'Shown for items without an image of their own, such as a post with no featured image. Remove it to show none.', 'forma-grid-gallery' ),
						'default' => Placeholder::default_id(),
					],
				] + self::image_size_fields(),
			],
			'lightbox'    => [
				'tab'         => __( 'Lightbox', 'forma-grid-gallery' ),
				'icon'        => 'format-gallery',
				'title'       => __( 'Lightbox', 'forma-grid-gallery' ),
				'description' => __( 'Images open full size over the page (PhotoSwipe). Each layout turns it on with Click action → Lightbox.', 'forma-grid-gallery' ),
				'fields'      => [
					'enabled'  => [
						'type'    => 'toggle',
						'label'   => __( 'Enable lightbox', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'Off: layouts set to Lightbox open the image file instead.', 'forma-grid-gallery' ),
					],
					'wp'       => [
						'type'    => 'toggle',
						'show_if' => 'enabled',
						'label'   => __( 'Enable lightbox for WordPress native galleries and images', 'forma-grid-gallery' ),
						'default' => false,
						'help'    => __( 'Gallery and Image blocks linked to the media file. Links with their own lightbox are left alone.', 'forma-grid-gallery' ),
					],
					'captions' => [
						'type'    => 'toggle',
						'show_if' => 'enabled',
						'label'   => __( 'Show captions', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'The image caption or the item title under the image.', 'forma-grid-gallery' ),
					],
					'arrows'   => [
						'type'    => 'toggle',
						'show_if' => 'enabled',
						'label'   => __( 'Show arrows', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'Previous and next at the sides. Swipe and the arrow keys work either way.', 'forma-grid-gallery' ),
					],
					'zoom'     => [
						'type'    => 'toggle',
						'show_if' => 'enabled',
						'label'   => __( 'Show the zoom button', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'For images larger than the screen. A click on the image or a pinch zooms either way.', 'forma-grid-gallery' ),
					],
					'counter'  => [
						'type'    => 'toggle',
						'show_if' => 'enabled',
						'label'   => __( 'Show the counter', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'The number of the image and how many there are.', 'forma-grid-gallery' ),
					],
					'share'    => [
						'type'    => 'toggle',
						'show_if' => 'enabled',
						'label'   => __( 'Show the share button', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'Facebook, X, Pinterest, the device\'s share sheet, copy link and download. Grid items share their page, other images the page they are on.', 'forma-grid-gallery' ),
					],
				],
			],
			'messages'    => [
				'tab'         => __( 'Messages', 'forma-grid-gallery' ),
				'icon'        => 'format-status',
				'title'       => __( 'Messages', 'forma-grid-gallery' ),
				'description' => __( 'What a grid says when nothing matches its content, a filter or a search.', 'forma-grid-gallery' ),
				'fields'      => [
					'empty'      => [
						'type'    => 'toggle',
						'label'   => __( 'Show the "No items found" message', 'forma-grid-gallery' ),
						'default' => true,
						'help'    => __( 'Off: an empty grid shows nothing.', 'forma-grid-gallery' ),
					],
					'empty_text' => [
						'type'        => 'text',
						'label'       => __( 'Message', 'forma-grid-gallery' ),
						'default'     => '',
						'placeholder' => __( 'No items found.', 'forma-grid-gallery' ),
						'help'        => __( 'Leave empty for "No items found."', 'forma-grid-gallery' ),
						'show_if'     => 'empty',
					],
				],
			],
			'roles'       => Roles::section(),
		] );
	}

	/**
	 * Fields of the image sizes (ImageSizes)
	 *
	 * @return array
	 */
	private static function image_size_fields() {
		$defaults = [
			'sm' => 500,
			'md' => 800,
			'lg' => 1280,
			'xl' => 1920,
		];

		// The screens each width suits, with the device icons of the editor
		$icons  = [
			'sm' => Admin::icon( 'device-mobile' ),
			'md' => Admin::icon( 'device-tablet' ),
			'lg' => Admin::icon( 'device-tablet-landscape' ),
			'xl' => Admin::icon( 'device-desktop' ),
		];
		$fields = [];

		foreach ( ImageSizes::labels() as $key => $label ) {
			$fields[ $key ] = [
				'type'    => 'number',
				'label'   => $label,
				'icon'    => $icons[ $key ],
				'default' => $defaults[ $key ],
				'min'     => 100,
				'max'     => 4000,
				'unit'    => 'px',
				'group'   => 'sizes',
			];
		}

		return $fields;
	}

	/**
	 * Cross-field rule: each breakpoint stays below the wider one (tablet landscape > tablet > mobile)
	 *
	 * @param array $clean Clean value
	 *
	 * @return array
	 */
	public static function validate( array $clean ) {
		$wider = null;

		foreach ( [ 'tablet_landscape', 'tablet', 'mobile' ] as $device ) {
			if ( null !== $wider && $clean['breakpoints'][ $device ] >= $wider ) {
				$clean['breakpoints'][ $device ] = $wider - 1;
			}

			$wider = $clean['breakpoints'][ $device ];
		}

		return $clean;
	}

	/**
	 * Values of a section (saved, or the defaults)
	 *
	 * @param string $section Section
	 *
	 * @return array
	 */
	public static function get( $section ) {
		return self::page()->get( $section );
	}

	/**
	 * @return string
	 */
	public static function docs_url() {
		return (string) apply_filters( 'forma_docs_url', 'https://vlthemes.me/docs/forma/' );
	}

	/**
	 * Where Forma Pro is sold
	 *
	 * @return string
	 */
	public static function pro_url() {
		return (string) apply_filters( 'forma_pro_url', 'https://vlthemes.gumroad.com/l/forma-pro' );
	}

	/**
	 * The settings page header, for the plugin's other pages
	 *
	 * @param string $suffix Word after the name
	 */
	public static function header( $suffix ) {
		self::page()->header( $suffix );
	}

	/**
	 * Settings page URL
	 *
	 * @param string $tab Tab
	 *
	 * @return string
	 */
	public static function url( $tab = '' ) {
		$url = add_query_arg( 'page', self::PAGE, admin_url( Forma::menu_parent() ) );

		// The page opens the tab of the #hash
		return $tab ? $url . '#' . $tab : $url;
	}

	/**
	 * Menu: Documentation and, without Pro, Get Pro (external) after Settings
	 */
	public static function menu() {
		// A full URL as the slug: WordPress prints it as the link
		add_submenu_page( Forma::menu_parent(), __( 'Documentation', 'forma-grid-gallery' ), __( 'Documentation', 'forma-grid-gallery' ), 'edit_posts', self::docs_url() );

		if ( !Plugin::is_pro() ) {
			add_submenu_page( Forma::menu_parent(), __( 'Get Pro', 'forma-grid-gallery' ), __( 'Get Pro', 'forma-grid-gallery' ), 'manage_options', self::pro_url() );
		}
	}

	/**
	 * The external menu links open in a new tab everywhere
	 */
	public static function docs_link() {
		foreach ( [ self::docs_url(), self::pro_url() ] as $url ) {
			// The menu prints the URL without its trailing slash
			wp_add_inline_script( 'common', 'document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll("#adminmenu a[href^=\'' . esc_js( untrailingslashit( $url ) ) . '\']").forEach(function(a){a.target="_blank";a.rel="noopener";});});' );
		}
	}
}
