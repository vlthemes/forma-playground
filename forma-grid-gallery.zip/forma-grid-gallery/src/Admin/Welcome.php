<?php

namespace VLT\Forma\Admin;

use VLT\Forma\Core\Assets;
use VLT\Forma\Core\Forma;
use VLT\Forma\Core\PostTypes;
use VLT\Forma\Core\Roles;
use VLT\Forma\Plugin;
use VLT\Forma\Portfolio\Portfolio;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Welcome page. Opens once after activation, then stays reachable by its address without a menu item.
 */
class Welcome {
	const PAGE = 'forma-welcome';

	/**
	 * Set on activation, read on the next admin page
	 */
	const REDIRECT = 'forma_welcome_redirect';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_init', [ __CLASS__, 'redirect' ] );
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_action( 'admin_head', [ __CLASS__, 'hide' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
	}

	/**
	 * Activation hook
	 */
	public static function activate() {
		set_transient( self::REDIRECT, 1, MINUTE_IN_SECONDS );
	}

	/**
	 * Page URL
	 *
	 * @return string
	 */
	public static function url() {
		return add_query_arg( 'page', self::PAGE, admin_url( Forma::menu_parent() ) );
	}

	/**
	 * The first admin page after activation goes to the welcome page
	 */
	public static function redirect() {
		if ( !get_transient( self::REDIRECT ) ) {
			return;
		}

		delete_transient( self::REDIRECT );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only checks how the plugin was activated
		if ( wp_doing_ajax() || is_network_admin() || isset( $_GET['activate-multi'] ) || !current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_safe_redirect( self::url() );
		exit;
	}

	/**
	 * The page, in the plugin's menu so it gets its title
	 */
	public static function menu() {
		add_submenu_page( Forma::menu_parent(), __( 'Welcome to Forma', 'forma-grid-gallery' ), __( 'Welcome', 'forma-grid-gallery' ), Roles::LAYOUTS, self::PAGE, [ __CLASS__, 'page' ] );
	}

	/**
	 * No menu item: removed after the title is read
	 */
	public static function hide() {
		remove_submenu_page( Forma::menu_parent(), self::PAGE );
	}

	/**
	 * Settings styles (header, cards) and the page's own
	 *
	 * @param string $hook Admin page hook
	 */
	public static function enqueue( $hook ) {
		if ( false === strpos( $hook, self::PAGE ) ) {
			return;
		}

		Assets::enqueue( 'forma-admin-welcome' );
	}

	/**
	 * What the free plugin does
	 *
	 * @return array [ [ icon, title, text ] ]
	 */
	private static function features() {
		return [
			[ 'content', __( 'Any content', 'forma-grid-gallery' ), __( 'Projects, posts, pages, products, any post type, Media Library images, or the categories and tags themselves.', 'forma-grid-gallery' ) ],
			[ 'skin', __( 'Nine card styles', 'forma-grid-gallery' ), __( 'Default, Fade, Overlay, Caption, Minimal, Magazine, Polaroid, Glass and Mono, each with its own settings, in your theme\'s colors and fonts.', 'forma-grid-gallery' ) ],
			[ 'device-desktop', __( 'Set per device', 'forma-grid-gallery' ), __( 'Columns, gaps and the image ratio for desktop, tablets and phones, each seen in the live preview.', 'forma-grid-gallery' ) ],
			[ 'filter', __( 'Filters and search', 'forma-grid-gallery' ), __( 'Filter by category or tag and search as you type, without reloading the page; the address keeps the view to share.', 'forma-grid-gallery' ) ],
			[ 'sort', __( 'Sorting for visitors', 'forma-grid-gallery' ), __( 'Newest, A to Z, most viewed, most commented, random and more, from pills or a menu.', 'forma-grid-gallery' ) ],
			[ 'pagination', __( 'Pagination', 'forma-grid-gallery' ), __( 'Page numbers or a Load More button, both keeping the current filter and search.', 'forma-grid-gallery' ) ],
			[ 'click', __( 'Lightbox', 'forma-grid-gallery' ), __( 'Swipe, zoom, captions and a share menu, for grids and WordPress galleries alike.', 'forma-grid-gallery' ) ],
			[ 'calendar', __( 'Precise queries', 'forma-grid-gallery' ), __( 'Narrow by categories, tags, post formats (Video, Gallery…) and authors, pick or leave out items, match words, skip what a grid above already shows.', 'forma-grid-gallery' ) ],
			[ 'shortcodes', __( 'Place it anywhere', 'forma-grid-gallery' ), __( 'The Forma block, the Elementor widget, the WPBakery element or a shortcode; the filter, search and pagination apart if you like.', 'forma-grid-gallery' ) ],
			[ 'portfolio', __( 'A ready portfolio', 'forma-grid-gallery' ), __( 'Projects with categories and tags, an archive page, view counts to sort grids by, and a move from your old portfolio plugin in one click.', 'forma-grid-gallery' ) ],
			[ 'animation', __( 'Entrance animation', 'forma-grid-gallery' ), __( 'Items fade up as they come in: on load, after a filter and with Load More.', 'forma-grid-gallery' ) ],
			[ 'direction', __( 'Right to left', 'forma-grid-gallery' ), __( 'Layouts, the slider and the lightbox follow Arabic, Hebrew and other RTL languages.', 'forma-grid-gallery' ) ],
			[ 'users', __( 'Roles', 'forma-grid-gallery' ), __( 'Choose which roles add projects, build Forma Layouts or change the settings.', 'forma-grid-gallery' ) ],
			[ 'sparkles', __( 'Works with AI assistants', 'forma-grid-gallery' ), __( 'AI tools connected to your site can list, build and change Forma Layouts and projects, with your rights.', 'forma-grid-gallery' ) ],
			[ 'css', __( 'Made for themes', 'forma-grid-gallery' ), __( 'Custom CSS for one layout only, and templates your theme can restyle or replace.', 'forma-grid-gallery' ) ],
		];
	}

	/**
	 * What Forma Pro adds
	 *
	 * @return array [ [ icon, title, text ] ]
	 */
	private static function pro_features() {
		return [
			[ 'sparkles', __( 'Describe your grid', 'forma-grid-gallery' ), __( 'Describe the grid you want and the AI connected to your WordPress sets it up; you see it in the preview.', 'forma-grid-gallery' ) ],
			[ 'skin', __( 'Six animated card styles', 'forma-grid-gallery' ), __( 'Tilt, Drift, Cursor, Brush, Cube and Glide: cards that tilt, drift, paint or turn to their caption from the side the pointer comes in.', 'forma-grid-gallery' ) ],
			[ 'direction', __( 'Marquee layout', 'forma-grid-gallery' ), __( 'Items in a row that moves on by itself at a steady speed, turning round as the page scrolls up; it stops under the pointer, and visitors can drag and throw it.', 'forma-grid-gallery' ) ],
			[ 'list', __( 'List layout', 'forma-grid-gallery' ), __( 'An index of your projects in large type; each row\'s image follows the pointer, coming in with a grow, reveal, fade, slide or random effect.', 'forma-grid-gallery' ) ],
			[ 'heart', __( 'Client proofing', 'forma-grid-gallery' ), __( 'Clients pick their favorite photos from a link and send the selection; you get an email and the file names for Lightroom.', 'forma-grid-gallery' ) ],
			[ 'layout', __( 'Image tools', 'forma-grid-gallery' ), __( 'Add an image by its address, set a featured image from a URL, and crop one for a grid without touching the original.', 'forma-grid-gallery' ) ],
			[ 'toolbar', __( 'Lighter uploads', 'forma-grid-gallery' ), __( 'The sizes WordPress makes of your JPEG and PNG uploads saved as WebP or AVIF; the original stays as it was.', 'forma-grid-gallery' ) ],
			[ 'video', __( 'Video and audio', 'forma-grid-gallery' ), __( 'YouTube, Vimeo, TikTok, Instagram, Spotify, SoundCloud and more in the lightbox; your video files play in the card on hover or in view.', 'forma-grid-gallery' ) ],
			[ 'camera', __( 'Camera details', 'forma-grid-gallery' ), __( 'Camera, focal length, aperture, shutter speed and ISO under each photo.', 'forma-grid-gallery' ) ],
			[ 'animation', __( 'More animations', 'forma-grid-gallery' ), __( 'Fade, slide, zoom, blur and reveal, with the old items going out one by one.', 'forma-grid-gallery' ) ],
			[ 'filter', __( 'More control styles', 'forma-grid-gallery' ), __( 'A Line filter, Line and Orbit pagination, and infinite scroll that loads the next items as visitors reach the end.', 'forma-grid-gallery' ) ],
			[ 'inserts', __( 'Inserts', 'forma-grid-gallery' ), __( 'A banner, a form or any shortcode in a cell of its own between the items.', 'forma-grid-gallery' ) ],
			[ 'order', __( 'Drag and drop ordering', 'forma-grid-gallery' ), __( 'Put the items in your own order by dragging them in the editor.', 'forma-grid-gallery' ) ],
			[ 'content', __( 'Mixed post types', 'forma-grid-gallery' ), __( 'Projects and blog posts, or any post types, together in one grid.', 'forma-grid-gallery' ) ],
			[ 'calendar', __( 'Smarter queries', 'forma-grid-gallery' ), __( 'By date or custom field (a featured flag, a price), sorted by a custom field; leave out items without an image or sticky posts.', 'forma-grid-gallery' ) ],
			[ 'search', __( 'Faster filtering', 'forma-grid-gallery' ), __( 'Filters and pages already seen show at once, the next ones load in advance.', 'forma-grid-gallery' ) ],
			[ 'layout', __( 'Custom image ratio', 'forma-grid-gallery' ), __( 'Any width and height for the images of a grid or slider, like 21:9.', 'forma-grid-gallery' ) ],
			[ 'shield', __( 'Image protection', 'forma-grid-gallery' ), __( 'Per grid: no right-click, dragging or long-press saving on its images, no Download in its lightbox.', 'forma-grid-gallery' ) ],
		];
	}

	/**
	 * The layout types with the cells of their sketch, and whether they come with Forma Pro
	 *
	 * @return array [ id => [ label, cells, pro ] ]
	 */
	private static function layouts() {
		return [
			'grid'      => [ __( 'Grid', 'forma-grid-gallery' ), 6, false ],
			'masonry'   => [ __( 'Masonry', 'forma-grid-gallery' ), 6, false ],
			'metro'     => [ __( 'Metro', 'forma-grid-gallery' ), 3, false ],
			'justified' => [ __( 'Justified', 'forma-grid-gallery' ), 6, false ],
			'slider'    => [ __( 'Slider', 'forma-grid-gallery' ), 3, false ],
			'marquee'   => [ __( 'Marquee', 'forma-grid-gallery' ), 4, true ],
			'freeform'  => [ __( 'Freeform', 'forma-grid-gallery' ), 4, false ],
			'list'      => [ __( 'List', 'forma-grid-gallery' ), 5, true ],
		];
	}

	/**
	 * Feature cards
	 *
	 * @param array $features [ [ icon, title, text ] ]
	 */
	private static function cards( array $features ) {
		?>
		<ul class="vlt-welcome__features">
			<?php foreach ( $features as [ $icon, $title, $text ] ) : ?>
				<li class="vlt-welcome__feature">
					<span class="vlt-welcome__icon" aria-hidden="true"><?php echo Admin::icon( $icon ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own SVG ?></span>
					<div>
						<strong><?php echo esc_html( $title ); ?></strong>
						<p><?php echo esc_html( $text ); ?></p>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}

	/**
	 * Published and draft posts of a post type
	 *
	 * @param string $post_type Post type
	 *
	 * @return int
	 */
	private static function count( $post_type ) {
		$counts = wp_count_posts( $post_type );

		return (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 );
	}

	/**
	 * The page
	 */
	public static function page() {
		$has_pro   = Plugin::is_pro();
		// Pro's own word on its license (Pro\License): the card's badge, text and button
		$pro       = $has_pro ? (array) apply_filters( 'forma_welcome_pro', [ 'status' => 'active', 'badge' => __( 'Active', 'forma-grid-gallery' ), 'text' => '', 'action' => null ] ) : [];
		$portfolio = Portfolio::active();
		$projects  = $portfolio ? self::count( Portfolio::POST_TYPE ) : 0;
		$layouts   = self::count( PostTypes::LAYOUT );
		$list      = admin_url( 'edit.php?post_type=' . PostTypes::LAYOUT );
		$new       = admin_url( 'post-new.php?post_type=' . PostTypes::LAYOUT );
		$steps     = [
			[
				'done'   => !$portfolio || $projects > 0,
				'title'  => __( 'Add your work', 'forma-grid-gallery' ),
				'text'   => $portfolio
					/* translators: %s: number of projects */
					? ( $projects ? sprintf( _n( '%s project so far. Grids can also show posts, pages or Media Library images.', '%s projects so far. Grids can also show posts, pages or Media Library images.', $projects, 'forma-grid-gallery' ), number_format_i18n( $projects ) ) : __( 'Projects with a featured image, a category and a few tags. Grids can also show posts, pages or Media Library images.', 'forma-grid-gallery' ) )
					: __( 'The portfolio is off: grids show your posts, pages or Media Library images.', 'forma-grid-gallery' ),
				'action' => $portfolio ? [ admin_url( 'post-new.php?post_type=' . Portfolio::POST_TYPE ), __( 'Add a project', 'forma-grid-gallery' ) ] : null,
			],
			[
				'done'   => $layouts > 0,
				'title'  => __( 'Create a grid layout', 'forma-grid-gallery' ),
				'text'   => __( 'Pick the content, the layout, the card style, filters and pagination, and see it change in the live preview.', 'forma-grid-gallery' ),
				'action' => [ $new, __( 'Create a layout', 'forma-grid-gallery' ) ],
			],
			[
				'done'   => false,
				'title'  => __( 'Place it on a page', 'forma-grid-gallery' ),
				'text'   => __( 'Add the Forma block in the block editor, the Elementor widget or the WPBakery element, or paste its shortcode from Forma Layouts.', 'forma-grid-gallery' ),
				'action' => $layouts ? [ $list, __( 'Forma Layouts', 'forma-grid-gallery' ) ] : null,
			],
		];
		?>
		<div class="wrap vlt-settings-page vlt-welcome">
			<h1 class="screen-reader-text"><?php esc_html_e( 'Welcome to Forma', 'forma-grid-gallery' ); ?></h1>
			<hr class="wp-header-end">

			<?php Settings::header( __( 'welcome', 'forma-grid-gallery' ) ); ?>

			<div class="vlt-settings-page__panels">
				<section class="vlt-settings-page__card">
					<div class="vlt-settings-page__head">
						<h2><?php esc_html_e( 'Get started in three steps', 'forma-grid-gallery' ); ?></h2>
					</div>
					<ol class="vlt-welcome__steps">
						<?php foreach ( $steps as $number => $step ) : ?>
							<li class="vlt-welcome__step<?php echo $step['done'] ? ' is-done' : ''; ?>">
								<span class="vlt-welcome__step-number" aria-hidden="true"><?php echo $step['done'] ? '✓' : (int) ( $number + 1 ); ?></span>
								<div class="vlt-welcome__step-text">
									<strong><?php echo esc_html( $step['title'] ); ?></strong>
									<?php if ( $step['done'] ) : ?>
										<span class="screen-reader-text"><?php esc_html_e( '(done)', 'forma-grid-gallery' ); ?></span>
									<?php endif; ?>
									<p><?php echo esc_html( $step['text'] ); ?></p>
								</div>
								<?php if ( $step['action'] ) : ?>
									<a class="vlt-settings-page__button" href="<?php echo esc_url( $step['action'][0] ); ?>"><?php echo esc_html( $step['action'][1] ); ?></a>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ol>
				</section>

				<section class="vlt-settings-page__card">
					<div class="vlt-settings-page__head">
						<h2><?php esc_html_e( 'Seven layouts, one editor', 'forma-grid-gallery' ); ?></h2>
						<p><?php esc_html_e( 'Switch between them at any time; each keeps its own settings. Pick the card style separately.', 'forma-grid-gallery' ); ?></p>
					</div>
					<ul class="vlt-welcome__layouts">
						<?php foreach ( self::layouts() as $id => [ $label, $cells, $pro_only ] ) : ?>
							<li class="vlt-welcome__layout">
								<span class="vlt-welcome__sketch is-<?php echo esc_attr( $id ); ?>" aria-hidden="true">
									<?php echo str_repeat( '<i></i>', (int) $cells ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed markup ?>
								</span>
								<strong>
									<?php echo esc_html( $label ); ?>
									<?php if ( $pro_only && !$has_pro ) : ?>
										<span class="vlt-welcome__tag"><?php esc_html_e( 'Pro', 'forma-grid-gallery' ); ?></span>
									<?php endif; ?>
								</strong>
							</li>
						<?php endforeach; ?>
					</ul>
				</section>

				<section class="vlt-settings-page__card">
					<div class="vlt-settings-page__head">
						<h2><?php esc_html_e( 'What you can build', 'forma-grid-gallery' ); ?></h2>
					</div>
					<?php self::cards( self::features() ); ?>
				</section>

				<section class="vlt-welcome__pro">
					<div class="vlt-welcome__pro-head">
						<div>
							<h2>
								<?php esc_html_e( 'Forma Pro', 'forma-grid-gallery' ); ?>
								<?php if ( $has_pro ) : ?>
									<span class="vlt-welcome__badge is-<?php echo esc_attr( sanitize_html_class( $pro['status'] ?? 'active' ) ); ?>"><?php echo esc_html( $pro['badge'] ?? '' ); ?></span>
								<?php endif; ?>
							</h2>
							<p>
								<?php
								if ( !$has_pro ) {
									esc_html_e( 'The complete plugin with these added to the same editor. It replaces this one; your grids and settings stay as they are.', 'forma-grid-gallery' );
								} else {
									echo esc_html( ( $pro['text'] ?? '' ) ?: __( 'Its settings are in the same layout editor and in Settings.', 'forma-grid-gallery' ) );
								}
								?>
							</p>
						</div>
						<?php if ( !$has_pro ) : ?>
							<a class="vlt-settings-page__button is-primary" href="<?php echo esc_url( Settings::pro_url() ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Get Forma Pro', 'forma-grid-gallery' ); ?></a>
						<?php elseif ( !empty( $pro['action'][0] ) ) : ?>
							<a class="vlt-settings-page__button is-primary" href="<?php echo esc_url( $pro['action'][0] ); ?>"><?php echo esc_html( $pro['action'][1] ?? '' ); ?></a>
						<?php endif; ?>
					</div>
					<?php self::cards( self::pro_features() ); ?>
				</section>

				<footer class="vlt-welcome__help">
					<span><?php esc_html_e( 'Need a hand?', 'forma-grid-gallery' ); ?></span>
					<a href="<?php echo esc_url( Settings::docs_url() ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Documentation', 'forma-grid-gallery' ); ?></a>
					<a href="<?php echo esc_url( (string) apply_filters( 'forma_support_url', 'https://vlthemes.me/support-ticket/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Support', 'forma-grid-gallery' ); ?></a>
					<a href="<?php echo esc_url( Settings::url() ); ?>"><?php esc_html_e( 'Settings', 'forma-grid-gallery' ); ?></a>
					<?php if ( !$has_pro ) : ?>
						<a href="https://wordpress.org/support/plugin/forma-grid-gallery/reviews/#new-post" target="_blank" rel="noopener"><?php esc_html_e( 'Enjoying Forma? Leave a review', 'forma-grid-gallery' ); ?></a>
					<?php endif; ?>
				</footer>
			</div>
		</div>
		<?php
	}
}
