<?php

namespace VLT\Forma\Admin;

use VLT\Forma\Core\Config;
use VLT\Forma\Front\SkinManager;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Theme controls for the Forma editor
 *
 * Sidebar sections, values in $config['extra'][ section ][ field ]:
 *
 *     add_filter( 'forma_controls', function ( $controls ) {
 *         $controls['demo'] = [
 *             'title'     => __( 'Demo card', 'theme' ),
 *             'icon'      => 'admin-appearance',
 *             'after'     => 'skin',               // or 'panel' => 'skin' to add the fields to that section
 *             'condition' => [ 'skin' => 'demo' ],
 *             'fields'    => [
 *                 'overlay' => [ 'type' => 'toggle', 'label' => 'Overlay', 'default' => true, 'class' => 'has-overlay' ],
 *                 'tone'    => [ 'type' => 'select', 'label' => 'Tone', 'options' => [ 'light' => 'Light', 'dark' => 'Dark' ],
 *                                'class' => 'is-{value}', 'condition' => [ 'overlay' => true ] ],
 *                 'radius'  => [ 'type' => 'number', 'label' => 'Radius', 'min' => 0, 'max' => 40, 'responsive' => true,
 *                                'default' => [ 'desktop' => 12, 'tablet' => 8, 'mobile' => 4 ],
 *                                'style' => [ [ 'element' => '.card__media', 'property' => '--card-radius', 'mask' => '$px' ] ] ],
 *             ],
 *         ];
 *         return $controls;
 *     } );
 *
 * Media source image fields, values in $item['extra'][ field ]:
 *
 *     add_filter( 'forma_image_controls', fn( $fields ) => $fields + [
 *         'badge' => [ 'type' => 'text', 'label' => 'Badge' ],
 *     ] );
 *
 * A skin's own settings go in its folder instead, skins/{id}/settings.php returning its fields: Forma adds them to the Skin section while that skin is chosen.
 *
 * Field types: toggle, select, number, dimension, knob, position, align, text, textarea, color, image, separator, group.
 *
 * - group: an accordion of fields inside the section, closed unless 'open' => true. Its fields keep their values
 *   flat in the section (extra.demo.radius, not extra.demo.card.radius); a condition on the group applies to each.
 *
 *     'card'    => [ 'type' => 'group', 'label' => 'Card', 'fields' => [ 'radius' => [ … ] ] ],
 *     'overlay' => [ 'type' => 'group', 'label' => 'Overlay', 'open' => true, 'fields' => [ 'bg' => [ … ], 'color' => [ … ] ] ],
 *
 * - number: a number (min, max, step; unit shown next to it, e.g. 'unit' => 'px').
 * - dimension: a CSS value, '300px', '80vh' or '300ms' ('units' => [ 'px', 'vh' ], 'functions' => true for clamp() /
 *   min() / max() / calc() / var() or a list of them, e.g. [ 'var' ], 'keywords' => [ 'auto' ]). 'min' / 'max' limit the
 *   number: one for every unit ('max' => 100) or one per unit ('max' => [ 'px' => 100, '%' => 50 ]).
 * - knob: one of a few values on a dial, 'options' => [ 'auto' => 'Auto', 1 => '1', 2 => '2' ].
 * - color: a color; 'gradient' => true adds a Gradient tab (linear, radial, conic gradients).
 * - position: one of nine places (top left … bottom right, a 3×3 picker; '' = none). Its style property gets two
 *   declarations, {property}-y and {property}-x, each start, center or end (flex alignment and text-align alike).
 * - align: left, center or right as start, center, end ('' = none), for text-align and flex alignment alike.
 *
 * Sidebar field options:
 * - responsive: one value per device.
 * - class: added to the grid; "{value}" is replaced, a toggle adds it while on.
 * - style: [ element, property, mask ] rules. Element is a selector inside the grid ('' = the grid, '&.x' = the grid
 *   with a class), mask defaults to "$". A field with style and no class changes the preview live, without a reload;
 *   'live' => false reloads it instead (a skin that prints the value itself).
 * - condition: [ config path => value(s) ], all must match. A field of the same section can be named alone
 *   ( 'overlay' => true is 'extra.demo.overlay' => true ).
 */
class Controls {
	const TYPES = [ 'toggle', 'select', 'number', 'dimension', 'knob', 'position', 'align', 'text', 'textarea', 'color', 'image', 'separator', 'group' ];

	// A position field's value: vertical, horizontal
	const POSITIONS = [ 'top left', 'top center', 'top right', 'center left', 'center center', 'center right', 'bottom left', 'bottom center', 'bottom right' ];

	// CSS lengths a dimension field takes when it names none
	const UNITS = [ 'px', '%', 'em', 'rem', 'vw', 'vh' ];

	// CSS functions a dimension field can offer
	const FUNCTIONS = [ 'clamp', 'min', 'max', 'calc', 'var' ];

	/**
	 * @var array
	 */
	private static $cache = [];

	/**
	 * Sidebar sections
	 *
	 * @return array
	 */
	public static function all() {
		if ( isset( self::$cache['all'] ) ) {
			return self::$cache['all'];
		}

		$sections = [];

		foreach ( (array) apply_filters( 'forma_controls', self::skin_sections() ) as $id => $section ) {
			$id     = sanitize_key( $id );
			$fields = $id && is_array( $section ) ? self::sibling_conditions( self::fields( $section['fields'] ?? [] ), $id ) : [];

			if ( $fields ) {
				$sections[ $id ] = [
					'title'     => wp_strip_all_tags( (string) ( $section['title'] ?? $id ) ),
					'icon'      => sanitize_key( (string) ( $section['icon'] ?? 'admin-generic' ) ),
					'after'     => sanitize_key( (string) ( $section['after'] ?? '' ) ),
					'panel'     => sanitize_key( (string) ( $section['panel'] ?? '' ) ),
					'condition' => self::condition( $section['condition'] ?? [] ),
					'fields'    => $fields,
				];
			}
		}

		// Theme filters are added before init
		if ( did_action( 'init' ) ) {
			self::$cache['all'] = $sections;
		}

		return $sections;
	}

	/**
	 * Each skin's own settings: the fields its settings.php returns (skins/{id}/settings.php, a theme's copy first),
	 * in the Skin section while that skin is chosen; values in $config['extra'][ "skin_{id}" ]
	 *
	 * @return array [ section id => section ]
	 */
	private static function skin_sections() {
		$sections = [];

		foreach ( SkinManager::registered() as $id => $skin ) {
			$file = SkinManager::locate_file( SkinManager::path( $id, 'skins', 'settings.php' ) );
			// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound -- a skin's settings file
			$fields = $file ? include $file[0] : [];

			if ( is_array( $fields ) && $fields ) {
				$sections[ 'skin_' . $id ] = [
					'title'     => $skin['label'],
					'panel'     => 'skin',
					'condition' => [ 'skin' => $id ],
					'fields'    => $fields,
				];
			}
		}

		return $sections;
	}

	/**
	 * Media source image fields
	 *
	 * @return array
	 */
	public static function image_fields() {
		if ( isset( self::$cache['image'] ) ) {
			return self::$cache['image'];
		}

		$fields = self::fields( apply_filters( 'forma_image_controls', [] ), true );

		if ( did_action( 'init' ) ) {
			self::$cache['image'] = $fields;
		}

		return $fields;
	}

	/**
	 * @return array [ section => [ field => value ] ]
	 */
	public static function defaults() {
		return array_map( fn( $section ) => array_map( fn( $field ) => $field['default'], self::valued( $section['fields'] ) ), self::all() );
	}

	/**
	 * Values of the sections shown for a config (their condition matches, e.g. [ 'skin' => … ]), defaults filled in
	 *
	 * Skins get them as $options, so a skin reads its own fields without knowing its section id.
	 *
	 * @param array $config Layout config
	 *
	 * @return array [ field => value ]
	 */
	public static function values( array $config ) {
		$values = [];

		foreach ( self::all() as $id => $section ) {
			if ( self::matches( $section['condition'], $config ) ) {
				foreach ( self::valued( $section['fields'] ) as $key => $field ) {
					$values[ $key ] = $config['extra'][ $id ][ $key ] ?? $field['default'];
				}
			}
		}

		return $values;
	}

	/**
	 * @param mixed $raw config['extra']
	 *
	 * @return array
	 */
	public static function sanitize( $raw ) {
		$raw   = is_array( $raw ) ? $raw : [];
		$clean = [];

		foreach ( self::all() as $id => $section ) {
			foreach ( self::valued( $section['fields'] ) as $key => $field ) {
				$clean[ $id ][ $key ] = self::value( $field, $raw[ $id ][ $key ] ?? null );
			}
		}

		return $clean;
	}

	/**
	 * Image values that differ from the defaults
	 *
	 * @param mixed $raw image_data[ id ]['extra']
	 *
	 * @return array
	 */
	public static function sanitize_image( $raw ) {
		$raw   = is_array( $raw ) ? $raw : [];
		$clean = [];

		foreach ( self::valued( self::image_fields() ) as $key => $field ) {
			$value = self::value( $field, $raw[ $key ] ?? null );

			if ( $value !== $field['default'] ) {
				$clean[ $key ] = $value;
			}
		}

		return $clean;
	}

	/**
	 * @param array $saved Values from sanitize_image()
	 *
	 * @return array
	 */
	public static function image_values( array $saved ) {
		return $saved + array_map( fn( $field ) => $field['default'], self::valued( self::image_fields() ) );
	}

	/**
	 * Grid classes from the "class" option
	 *
	 * @param array $config Layout config
	 *
	 * @return array
	 */
	public static function classes( array $config ) {
		$classes = [];

		foreach ( self::active( $config ) as [ $field, $value ] ) {
			if ( !$field['class'] || $field['responsive'] ) {
				continue;
			}

			if ( 'toggle' === $field['type'] ) {
				$classes[] = $value ? $field['class'] : '';
			} elseif ( '' !== (string) $value ) {
				$classes[] = str_replace( '{value}', (string) $value, $field['class'] );
			}
		}

		return array_values( array_filter( array_map( 'sanitize_html_class', $classes ) ) );
	}

	/**
	 * CSS from the "style" option
	 *
	 * @param array  $config      Layout config
	 * @param string $scope       Grid selector
	 * @param array  $breakpoints [ device => max width ]
	 *
	 * @return string
	 */
	public static function css( array $config, $scope, array $breakpoints ) {
		$rules = array_fill_keys( Config::DEVICES, [] );

		foreach ( self::active( $config ) as [ $field, $value ] ) {
			if ( !$field['style'] ) {
				continue;
			}

			$values = $field['responsive'] ? $value : [ 'desktop' => $value ];
			$wider  = null;

			foreach ( Config::DEVICES as $device ) {
				$css = array_key_exists( $device, $values ) ? self::css_value( $field, $values[ $device ] ) : null;

				// Same as the wider device: inherited
				if ( null !== $css && '' !== $css && $css !== $wider ) {
					foreach ( $field['style'] as $rule ) {
						$selector = self::selector( $scope, $rule['element'] );

						$rules[ $device ][ $selector ] = ( $rules[ $device ][ $selector ] ?? '' ) . self::declarations( $field, $rule, $css );
					}
				}

				$wider = $css ?? $wider;
			}
		}

		$block = function ( array $selectors ) {
			$css = '';

			foreach ( $selectors as $selector => $declarations ) {
				$css .= $selector . '{' . $declarations . '}';
			}

			return $css;
		};

		$css = $block( $rules['desktop'] );

		foreach ( $breakpoints as $device => $max_width ) {
			$css .= !empty( $rules[ $device ] ) ? sprintf( '@media (max-width:%dpx){%s}', $max_width, $block( $rules[ $device ] ) ) : '';
		}

		return $css;
	}

	/**
	 * The declarations of a style rule: its property, or a position's -y and -x
	 *
	 * @param array  $field Field
	 * @param array  $rule  [ element, property, mask ]
	 * @param string $css   CSS value
	 *
	 * @return string
	 */
	private static function declarations( array $field, array $rule, $css ) {
		if ( 'position' !== $field['type'] ) {
			return $rule['property'] . ':' . str_replace( '$', $css, $rule['mask'] ) . ';';
		}

		$edge      = fn( $word ) => [ 'top' => 'start', 'left' => 'start', 'bottom' => 'end', 'right' => 'end' ][ $word ] ?? 'center';
		[ $y, $x ] = explode( ' ', $css ) + [ 'center', 'center' ];

		return $rule['property'] . '-y:' . $edge( $y ) . ';' . $rule['property'] . '-x:' . $edge( $x ) . ';';
	}

	/**
	 * Fields shown for this config, with their values
	 *
	 * @param array $config Layout config
	 *
	 * @return array [ [ field, value ], … ]
	 */
	private static function active( array $config ) {
		$active = [];

		foreach ( self::all() as $id => $section ) {
			if ( !self::matches( $section['condition'], $config ) ) {
				continue;
			}

			foreach ( self::valued( $section['fields'] ) as $key => $field ) {
				if ( self::matches( $field['condition'], $config ) ) {
					$active[] = [ $field, $config['extra'][ $id ][ $key ] ?? $field['default'] ];
				}
			}
		}

		return $active;
	}

	/**
	 * Same rules as matches() in panels/extra.js
	 *
	 * @param array $condition [ path => [ values ] ]
	 * @param array $config    Layout config
	 *
	 * @return bool
	 */
	private static function matches( array $condition, array $config ) {
		foreach ( $condition as $path => $values ) {
			$actual = $config;

			foreach ( explode( '.', $path ) as $key ) {
				$actual = is_array( $actual ) ? ( $actual[ $key ] ?? null ) : null;
			}

			$found = false;

			foreach ( $values as $value ) {
				$found = $found || ( is_bool( $value ) ? (bool) $actual === $value : (string) $value === (string) ( is_scalar( $actual ) ? $actual : '' ) );
			}

			if ( !$found ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * @param array $field Field
	 * @param mixed $value Clean value
	 *
	 * @return string '' = nothing to print
	 */
	private static function css_value( array $field, $value ) {
		switch ( $field['type'] ) {
			case 'number':
				return (string) $value;

			case 'toggle':
				return $value ? '1' : '0';

			case 'image':
				$url = $value ? wp_get_attachment_image_url( $value, 'full' ) : '';
				return $url ? 'url("' . esc_url_raw( $url ) . '")' : '';

			default:
				return trim( (string) preg_replace( '/[;{}<>\\\\]+/', '', (string) $value ) );
		}
	}

	/**
	 * @param array $field Raw field
	 *
	 * @return array [ [ element, property, mask ], … ]
	 */
	private static function style_rules( array $field ) {
		$rules = [];

		foreach ( (array) ( $field['style'] ?? [] ) as $rule ) {
			$property = (string) ( $rule['property'] ?? '' );
			$mask     = (string) preg_replace( '/[;{}<>\\\\]+/', '', (string) ( $rule['mask'] ?? '$' ) );

			if ( !preg_match( '/^(?:--[A-Za-z0-9_-]+|[a-z][a-z-]*)$/', $property ) ) {
				continue;
			}

			$rules[] = [
				'element'  => trim( (string) preg_replace( '/[{}<>;@\\\\]+/', '', (string) ( $rule['element'] ?? '' ) ) ),
				'property' => $property,
				'mask'     => false !== strpos( $mask, '$' ) ? $mask : '$',
			];
		}

		return $rules;
	}

	/**
	 * @param string $scope   Grid selector
	 * @param string $element '' = the grid, '&.x' = the grid with a class, otherwise a descendant
	 *
	 * @return string
	 */
	private static function selector( $scope, $element ) {
		if ( '' === $element ) {
			return $scope;
		}

		return implode( ',', array_map(
			fn( $part ) => 0 === strpos( $part, '&' ) ? $scope . substr( $part, 1 ) : $scope . ' ' . $part,
			array_filter( array_map( 'trim', explode( ',', $element ) ) ),
		) );
	}

	/**
	 * Fields with a value: not separators or groups
	 *
	 * @param array $fields Fields
	 *
	 * @return array
	 */
	private static function valued( array $fields ) {
		return array_filter( $fields, fn( $field ) => !in_array( $field['type'], [ 'separator', 'group' ], true ) );
	}

	/**
	 * @param mixed  $raw   [ key => field ]
	 * @param bool   $image Image fields: no responsive, class or style
	 * @param string $group Key of the group the fields are in ('' = none)
	 *
	 * @return array Groups flattened: the group, then its fields (with 'group' => its key)
	 */
	private static function fields( $raw, $image = false, $group = '' ) {
		$fields = [];

		foreach ( (array) $raw as $key => $field ) {
			$key  = sanitize_key( $key );
			$type = $field['type'] ?? '';

			// One level of groups, none among image fields
			if ( !$key || !is_array( $field ) || !in_array( $type, self::TYPES, true ) || ( 'group' === $type && ( $image || $group ) ) ) {
				continue;
			}

			if ( 'group' === $type ) {
				$children = self::fields( $field['fields'] ?? [], false, $key );

				if ( $children ) {
					$condition      = self::condition( $field['condition'] ?? [] );
					$fields[ $key ] = [
						'type'      => 'group',
						'label'     => wp_strip_all_tags( (string) ( $field['label'] ?? $key ) ),
						'help'      => wp_strip_all_tags( (string) ( $field['help'] ?? '' ) ),
						'open'      => !empty( $field['open'] ),
						'condition' => $condition,
						'group'     => '',
						'default'   => null,
					];

					// The group's condition holds for each of its fields: a closed-off group adds no class or CSS
					foreach ( $children as $child => $clean ) {
						$clean['condition'] += $condition;
						$fields[ $child ]    = $clean;
					}
				}

				continue;
			}

			$options = [];

			foreach ( (array) ( $field['options'] ?? [] ) as $value => $label ) {
				$options[ (string) $value ] = wp_strip_all_tags( (string) $label );
			}

			if ( in_array( $type, [ 'select', 'knob' ], true ) && !$options ) {
				continue;
			}

			$clean = [
				'type'       => $type,
				'label'      => wp_strip_all_tags( (string) ( $field['label'] ?? ( 'separator' === $type ? '' : $key ) ) ),
				'help'       => wp_strip_all_tags( (string) ( $field['help'] ?? '' ) ),
				'options'    => $options,
				'min'        => self::limit( $field['min'] ?? null, $type ),
				'max'        => self::limit( $field['max'] ?? null, $type ),
				'step'       => isset( $field['step'] ) ? (float) $field['step'] : 1,
				'unit'       => preg_replace( '/[^a-z%]/', '', strtolower( (string) ( $field['unit'] ?? '' ) ) ),
				'units'      => array_values( array_filter( array_map( fn( $unit ) => preg_replace( '/[^a-z%]/', '', strtolower( (string) $unit ) ), (array) ( $field['units'] ?? self::UNITS ) ) ) ),
				'functions'  => is_array( $field['functions'] ?? null ) ? array_values( array_intersect( self::FUNCTIONS, $field['functions'] ) ) : ( empty( $field['functions'] ) ? [] : self::FUNCTIONS ),
				'keywords'   => array_values( array_filter( array_map( 'sanitize_key', (array) ( $field['keywords'] ?? [] ) ) ) ),
				'condition'  => $image ? [] : self::condition( $field['condition'] ?? [] ),
				'responsive' => !$image && !empty( $field['responsive'] ) && !in_array( $type, [ 'toggle', 'image', 'textarea' ], true ),
				'class'      => $image ? '' : (string) preg_replace( '/[^A-Za-z0-9_{}-]/', '', (string) ( $field['class'] ?? '' ) ),
				'style'      => $image ? [] : self::style_rules( $field ),
				'group'      => $group,
				// color: gradients too ('gradient' => true)
				'gradient'   => 'color' === $type && !empty( $field['gradient'] ),
				// Shown in the preview as it changes, no reload: CSS only (no class, no image); 'live' => false opts out
				'live'       => !$image && !empty( $field['style'] ) && '' === (string) ( $field['class'] ?? '' ) && 'image' !== $type && false !== ( $field['live'] ?? true ),
			];

			$clean['default'] = 'separator' === $type ? null : self::value( $clean, $field['default'] ?? null, true );
			$fields[ $key ]   = $clean;
		}

		return $fields;
	}

	/**
	 * @param array $field   Field
	 * @param mixed $value   Raw, null = missing
	 * @param bool  $default Cleaning the default itself
	 *
	 * @return mixed
	 */
	private static function value( array $field, $value, $default = false ) {
		if ( null === $value && !$default ) {
			return $field['default'];
		}

		if ( !$field['responsive'] ) {
			return self::clean( $field, is_array( $value ) ? ( $value['desktop'] ?? null ) : $value );
		}

		// A missing device takes the wider one's value
		$values = is_array( $value ) ? $value : array_fill_keys( Config::DEVICES, $value );
		$clean  = [];
		$wider  = $values['desktop'] ?? null;

		foreach ( Config::DEVICES as $device ) {
			$raw              = $values[ $device ] ?? $wider;
			$clean[ $device ] = self::clean( $field, null === $raw && !$default ? ( $field['default'][ $device ] ?? null ) : $raw );
			$wider            = $raw ?? $wider;
		}

		return $clean;
	}

	/**
	 * @param array $field Field
	 * @param mixed $value Raw
	 *
	 * @return mixed
	 */
	private static function clean( array $field, $value ) {
		switch ( $field['type'] ) {
			case 'toggle':
				return (bool) $value;

			case 'select':
			case 'knob':
				$value = (string) $value;
				return isset( $field['options'][ $value ] ) ? $value : (string) array_key_first( $field['options'] );

			case 'dimension':
				return self::dimension( $field, (string) $value );

			case 'position':
				return in_array( (string) $value, self::POSITIONS, true ) ? (string) $value : '';

			case 'align':
				return in_array( (string) $value, [ 'start', 'center', 'end' ], true ) ? (string) $value : '';

			case 'number':
				$value = is_numeric( $value ) ? (float) $value : (float) ( $field['min'] ?? 0 );
				$value = null !== $field['min'] ? max( $field['min'], $value ) : $value;
				$value = null !== $field['max'] ? min( $field['max'], $value ) : $value;
				return floor( $value ) === $value ? (int) $value : $value;

			case 'textarea':
				return sanitize_textarea_field( (string) $value );

			case 'color':
				$value = trim( (string) $value );

				// A gradient of the picker's Gradient tab, when the field takes them
				if ( !empty( $field['gradient'] ) && preg_match( '/^(?:repeating-)?(?:linear|radial|conic)-gradient\([^;{}<>\\\\]+\)$/i', $value ) ) {
					return $value;
				}

				// The picker's colors with transparency are #rgba / #rrggbbaa, which sanitize_hex_color() turns away;
				// a palette color can be a CSS variable
				return preg_match( '/^(?:#(?:[\da-f]{3,4}|[\da-f]{6}|[\da-f]{8})|(?:rgba?|hsla?)\([\d\s.,%\/]+\)|var\(--[\w-]+\))$/i', $value ) ? $value : '';

			case 'image':
				return absint( $value );

			default:
				return sanitize_text_field( (string) $value );
		}
	}

	/**
	 * A min or max: a number, or for a dimension one per unit ([ 'px' => 100, '%' => 50 ])
	 *
	 * @param mixed  $raw  Raw
	 * @param string $type Field type
	 *
	 * @return float|array|null
	 */
	private static function limit( $raw, $type ) {
		if ( is_array( $raw ) && 'dimension' === $type ) {
			$limits = [];

			foreach ( $raw as $unit => $number ) {
				$limits[ preg_replace( '/[^a-z%]/', '', strtolower( (string) $unit ) ) ] = (float) $number;
			}

			return $limits;
		}

		return is_numeric( $raw ) ? (float) $raw : null;
	}

	/**
	 * Condition keys naming a field of the same section become its full path
	 *
	 * @param array  $fields  Fields of the section
	 * @param string $section Section id
	 *
	 * @return array
	 */
	private static function sibling_conditions( array $fields, $section ) {
		foreach ( $fields as $key => $field ) {
			$condition = [];

			foreach ( $field['condition'] as $path => $values ) {
				$condition[ isset( $fields[ $path ] ) ? 'extra.' . $section . '.' . $path : $path ] = $values;
			}

			$fields[ $key ]['condition'] = $condition;
		}

		return $fields;
	}

	/**
	 * @param mixed $condition [ path => value or [ values ] ]
	 *
	 * @return array
	 */
	private static function condition( $condition ) {
		$clean = [];

		foreach ( (array) $condition as $path => $values ) {
			if ( preg_match( '/^[a-z0-9_]+(?:\.[a-z0-9_]+)*$/', (string) $path ) ) {
				$clean[ $path ] = array_values( (array) $values );
			}
		}

		return $clean;
	}

	/**
	 * A CSS length of a dimension field: number + one of its units, a keyword of it or, with functions, a CSS
	 * function of lengths; '' otherwise
	 *
	 * @param array  $field Field
	 * @param string $value Raw
	 *
	 * @return string
	 */
	private static function dimension( array $field, $value ) {
		$value = strtolower( trim( $value ) );

		if ( in_array( $value, $field['keywords'], true ) ) {
			return $value;
		}

		if ( preg_match( '/^(-?\d*\.?\d+)([a-z%]+)$/', $value, $match ) && in_array( $match[2], $field['units'], true ) ) {
			// min / max of its unit (a number for every unit, or [ unit => number ])
			$bound  = fn( $limit ) => is_array( $limit ) ? ( $limit[ $match[2] ] ?? null ) : $limit;
			$number = (float) $match[1];
			$number = null !== $bound( $field['min'] ) ? max( $bound( $field['min'] ), $number ) : $number;
			$number = null !== $bound( $field['max'] ) ? min( $bound( $field['max'] ), $number ) : $number;

			return (float) $match[1] === $number ? $value : $number . $match[2];
		}

		// Numbers, units, operators, commas and custom property names only
		if ( $field['functions'] && preg_match( '/^(' . implode( '|', $field['functions'] ) . ')\([a-z0-9%.,+*\/\s()-]+\)$/', $value ) ) {
			return $value;
		}

		return '';
	}
}
