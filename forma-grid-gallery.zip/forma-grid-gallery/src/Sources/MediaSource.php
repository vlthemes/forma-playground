<?php

namespace VLT\Forma\Sources;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Images picked from the Media Library. query.image_data overrides title, caption, link and labels per image;
 * labels work as a virtual taxonomy for the filter.
 */
class MediaSource implements SourceInterface, VirtualTermsInterface {
	/**
	 * Virtual taxonomy of the per-image labels
	 */
	const LABELS = 'forma_label';

	/**
	 * Image fields an item's title or description can come from (query.media_title, query.media_description)
	 */
	const FIELDS = [ 'title', 'caption', 'alt', 'description', 'none' ];

	/**
	 * A field of an image in the Media Library, as plain text
	 *
	 * @param int    $id    Attachment ID
	 * @param string $field One of FIELDS
	 *
	 * @return string
	 */
	public static function field( $id, $field ) {
		switch ( $field ) {
			case 'title':
				return get_the_title( $id );
			case 'caption':
				return wp_strip_all_tags( (string) wp_get_attachment_caption( $id ) );
			case 'alt':
				return (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
			case 'description':
				return wp_strip_all_tags( (string) get_post_field( 'post_content', $id ) );
			default:
				return '';
		}
	}

	/**
	 * Get ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'media';
	}

	/**
	 * Get label
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Media Library images', 'forma-grid-gallery' );
	}

	/**
	 * Get taxonomies: the labels given to images in the layout
	 *
	 * @return array
	 */
	public function get_taxonomies() {
		return [ self::LABELS => __( 'Categories', 'forma-grid-gallery' ) ];
	}

	/**
	 * Labels used in the layout as terms, in the order they first appear in the selection
	 *
	 * ID = 1-based position in that list, stable for one config; count = images with the label.
	 *
	 * @param array  $query    Query config
	 * @param string $taxonomy Taxonomy
	 *
	 * @return \WP_Term[]|null
	 */
	public function get_virtual_terms( array $query, $taxonomy ) {
		if ( self::LABELS !== $taxonomy ) {
			return null;
		}

		$terms = [];

		foreach ( $query['images'] as $image_id ) {
			foreach ( $query['image_data'][ $image_id ]['labels'] ?? [] as $name ) {
				$key = mb_strtolower( $name );

				if ( !isset( $terms[ $key ] ) ) {
					$terms[ $key ] = new \WP_Term( (object) [
						'term_id'  => count( $terms ) + 1,
						'name'     => $name,
						'slug'     => sanitize_title( $name ),
						'taxonomy' => self::LABELS,
						'count'    => 0,
					] );
				}

				++$terms[ $key ]->count;
			}
		}

		return array_values( $terms );
	}

	/**
	 * Get orderby options
	 *
	 * @return array
	 */
	public function get_orderby_options() {
		return [
			'post__in' => __( 'Selection order', 'forma-grid-gallery' ),
			'date'     => __( 'Upload date', 'forma-grid-gallery' ),
			'title'    => __( 'Title', 'forma-grid-gallery' ),
			'rand'     => __( 'Random', 'forma-grid-gallery' ),
		];
	}

	/**
	 * Fetch items
	 *
	 * @param array $query Query config
	 * @param array $args  Runtime args
	 *
	 * @return array
	 */
	public function fetch( array $query, array $args ) {
		$terms  = $this->get_virtual_terms( $query, self::LABELS );
		// Without the images the grids above on the page show (query.skip_shown)
		$images = array_values( array_diff( $query['images'], $args['not_in'] ?? [] ) );

		// Front-end filter: the images carrying that label
		if ( $args['filter'] && self::LABELS === $args['filter']['taxonomy'] ) {
			$term   = wp_list_filter( $terms, [ 'term_id' => (int) $args['filter']['term'] ] );
			$term   = $term ? mb_strtolower( reset( $term )->name ) : null;
			$images = array_values( array_filter( $images, fn( $id ) => null !== $term && in_array( $term, array_map( 'mb_strtolower', $query['image_data'][ $id ]['labels'] ?? [] ), true ) ) );
		}

		// Match the text the visitor sees, overrides included
		if ( '' !== ( $args['search'] ?? '' ) && $images ) {
			_prime_post_caches( $images, false, false );

			$words  = preg_split( '/\s+/', mb_strtolower( $args['search'] ) );
			$images = array_values( array_filter( $images, function ( $id ) use ( $query, $words ) {
				$data = $query['image_data'][ $id ] ?? [];
				$text = mb_strtolower( implode( ' ', [
					( $data['title'] ?? '' ) ?: self::field( $id, $query['media_title'] ?? 'title' ),
					( $data['caption'] ?? '' ) ?: self::field( $id, $query['media_description'] ?? 'caption' ),
					implode( ' ', $data['labels'] ?? [] ),
				] ) );

				foreach ( $words as $word ) {
					if ( false === mb_strpos( $text, $word ) ) {
						return false;
					}
				}

				return true;
			} ) );
		}

		if ( !$images ) {
			return [
				'items' => [],
				'total' => 0,
			];
		}

		$query_args = [
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image',
			'post__in'       => $images,
			'posts_per_page' => self::limit( $args ),
			'offset'         => $args['skip'],
			'order'          => $query['order'],
			'orderby'        => 'rand' === $query['orderby'] ? 'RAND(' . (int) $args['seed'] . ')' : $query['orderby'],
			'no_found_rows'  => !$args['count'],
		];

		if ( '' !== $query['search'] ) {
			$query_args['s'] = $query['search'];
		}

		$query_args = apply_filters( 'forma_query_args', $query_args, $query, $args, $this->get_id() );
		$wp_query   = new \WP_Query( $query_args );

		return [
			'items' => array_map( fn( $attachment ) => $this->normalize( $attachment, $query['image_data'][ $attachment->ID ] ?? [], $terms, $query ), $wp_query->posts ),
			'total' => $args['count'] ? (int) $wp_query->found_posts : count( $wp_query->posts ),
		];
	}

	/**
	 * Normalize an attachment
	 *
	 * @param \WP_Post   $attachment Attachment
	 * @param array      $data       Overrides of this layout (query.image_data entry)
	 * @param \WP_Term[] $terms      Labels of the layout (get_virtual_terms())
	 * @param array      $query      Query config: the fields of the title and the description
	 *
	 * @return array
	 */
	public function normalize( $attachment, array $data = [], array $terms = [], array $query = [] ) {
		$labels = array_map( 'mb_strtolower', $data['labels'] ?? [] );

		return [
			'id'       => $attachment->ID,
			'type'     => 'image',
			// The layout's own text for the image first, else the image field it picked
			'title'    => ( $data['title'] ?? '' ) ?: self::field( $attachment->ID, $query['media_title'] ?? 'title' ),
			'url'      => ( $data['link'] ?? '' ) ?: (string) wp_get_attachment_url( $attachment->ID ),
			'image_id' => $attachment->ID,
			'excerpt'  => ( $data['caption'] ?? '' ) ?: self::field( $attachment->ID, $query['media_description'] ?? 'caption' ),
			'date'     => get_the_date( '', $attachment ),
			'object'   => $attachment,
			'labels'   => array_values( array_filter( $terms, fn( $term ) => in_array( mb_strtolower( $term->name ), $labels, true ) ) ),
			// The theme's image fields (forma_image_controls), defaults filled in
			'extra'    => \VLT\Forma\Admin\Controls::image_values( $data['extra'] ?? [] ),
		];
	}

	/**
	 * Labels of an image
	 *
	 * @param array  $item     Item
	 * @param string $taxonomy Taxonomy
	 *
	 * @return \WP_Term[]
	 */
	public function get_item_terms( array $item, $taxonomy ) {
		return self::LABELS === $taxonomy ? $item['labels'] ?? [] : [];
	}

	/**
	 * posts_per_page for WP_Query: "all" with an offset needs a real LIMIT, WP_Query ignores offset with -1
	 *
	 * @param array $args Runtime args
	 *
	 * @return int
	 */
	private static function limit( array $args ) {
		return -1 === $args['limit'] && $args['skip'] > 0 ? PHP_INT_MAX : $args['limit'];
	}
}
