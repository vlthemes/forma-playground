<?php

namespace VLT\Forma\Sources;

use VLT\Forma\Core\Forma;
use VLT\Forma\Core\IdList;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Available data sources, built from the post types actually registered
 *
 *     add_filter( 'forma_sources', fn( $sources ) => $sources + [ 'my' => new MySource() ] );
 *     add_filter( 'forma_exclude_sources', fn( $ids ) => [ ...$ids, 'elementor_library' ] );
 *     add_filter( 'forma_include_sources', fn( $ids ) => [ 'portfolio', 'post', 'media', 'terms-*' ] );
 */
class SourceRegistry {
	/**
	 * Sources cache
	 *
	 * @var SourceInterface[]|null
	 */
	private static $sources = null;

	/**
	 * Get all sources
	 *
	 * @return SourceInterface[] [ id => source ]
	 */
	public static function all() {
		if ( null !== self::$sources ) {
			return self::$sources;
		}

		$sources = [];

		// Portfolio first, it's what grids are mostly built from
		$post_types = get_post_types( [ 'public' => true ], 'objects' );
		$portfolio = Forma::portfolio();
		uksort( $post_types, fn( $a, $b ) => ( $portfolio === $b ) <=> ( $portfolio === $a ) );

		foreach ( $post_types as $post_type ) {
			if ( 'attachment' !== $post_type->name ) {
				$sources[ $post_type->name ] = new PostTypeSource( $post_type );
			}
		}

		$sources['media'] = new MediaSource();

		// Terms grids: categories, tags and the like of the post types above
		foreach ( get_taxonomies( [ 'public' => true, 'show_ui' => true ], 'objects' ) as $taxonomy ) {
			if ( 'post_format' !== $taxonomy->name && array_intersect( $taxonomy->object_type, array_keys( $sources ) ) ) {
				$sources[ TermsSource::PREFIX . $taxonomy->name ] = new TermsSource( $taxonomy );
			}
		}

		$sources = array_filter(
			(array) apply_filters( 'forma_sources', $sources ),
			fn( $source ) => $source instanceof SourceInterface,
		);

		// Narrowed by ID: forma_include_sources keeps only these (in this order), forma_exclude_sources drops these
		$sources = IdList::apply(
			$sources,
			(array) apply_filters( 'forma_include_sources', [] ),
			(array) apply_filters( 'forma_exclude_sources', [] )
		);

		// Post types are registered on init, don't freeze an incomplete list if asked earlier
		if ( did_action( 'wp_loaded' ) ) {
			self::$sources = $sources;
		}

		return $sources;
	}

	/**
	 * Get a source
	 *
	 * @param string $id Source ID
	 *
	 * @return SourceInterface|null
	 */
	public static function get( $id ) {
		return self::all()[ $id ] ?? null;
	}
}
