<?php

namespace VLT\Forma\Sources;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A source whose terms live in the layout config (e.g. MediaSource labels), not in a WordPress taxonomy
 */
interface VirtualTermsInterface {
	/**
	 * Terms of a virtual taxonomy, in display order
	 *
	 * @param array  $query    Sanitised "query" config section
	 * @param string $taxonomy Taxonomy
	 *
	 * @return \WP_Term[]|null Null when $taxonomy is a real WordPress taxonomy
	 */
	public function get_virtual_terms( array $query, $taxonomy );
}
