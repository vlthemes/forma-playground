<?php

namespace VLT\Forma\Sources;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Terms of a taxonomy as items. The image is the term's own (thumbnail_id meta), else its newest post's featured
 * image; forma_term_image_id changes it.
 */
class TermsSource implements SourceInterface {
	/**
	 * Prefix of the source IDs: "terms-{taxonomy}"
	 */
	const PREFIX = 'terms-';

	/**
	 * Taxonomy object
	 *
	 * @var \WP_Taxonomy
	 */
	private $taxonomy;

	/**
	 * Constructor
	 *
	 * @param \WP_Taxonomy $taxonomy Taxonomy
	 */
	public function __construct( \WP_Taxonomy $taxonomy ) {
		$this->taxonomy = $taxonomy;
	}

	/**
	 * Get ID
	 *
	 * @return string
	 */
	public function get_id() {
		return self::PREFIX . $this->taxonomy->name;
	}

	/**
	 * Get label
	 *
	 * @return string
	 */
	public function get_label() {
		/* translators: %s: taxonomy name, e.g. Categories */
		return sprintf( __( '%s (terms)', 'forma-grid-gallery' ), $this->taxonomy->labels->name );
	}

	/**
	 * The taxonomy shown
	 *
	 * @return string
	 */
	public function get_taxonomy() {
		return $this->taxonomy->name;
	}

	/**
	 * Terms aren't filtered by other terms
	 *
	 * @return array
	 */
	public function get_taxonomies() {
		return [];
	}

	/**
	 * Get orderby options
	 *
	 * @return array
	 */
	public function get_orderby_options() {
		return [
			'name'    => __( 'Name', 'forma-grid-gallery' ),
			'count'   => __( 'Number of items', 'forma-grid-gallery' ),
			'include' => __( 'Selection order (specific terms)', 'forma-grid-gallery' ),
			'term_id' => __( 'ID', 'forma-grid-gallery' ),
			'slug'    => __( 'Slug', 'forma-grid-gallery' ),
		];
	}

	/**
	 * Fetch items
	 *
	 * @param array $query Query config
	 * @param array $args  Runtime args
	 *
	 * @return array
	 */
	public function fetch( array $query, array $args ) {
		$term_args = [
			'taxonomy'   => $this->taxonomy->name,
			'hide_empty' => $query['hide_empty'],
			'orderby'    => $query['orderby'],
			'order'      => $query['order'],
			'exclude'    => $query['exclude'],
		];

		if ( $query['include'] ) {
			$term_args['include'] = array_values( array_diff( $query['include'], $query['exclude'] ) ) ?: [ 0 ];
			unset( $term_args['exclude'] );
		}

		if ( $query['top_level'] ) {
			$term_args['parent'] = 0;
		}

		// The layout's own words and the visitor's: both must match the name
		$search = trim( $query['search'] . ' ' . ( $args['search'] ?? '' ) );

		if ( '' !== $search ) {
			$term_args['name__like'] = $search;
		}

		$term_args = apply_filters( 'forma_terms_args', $term_args, $query, $args );
		$terms     = get_terms( $term_args + [
			// 0 = all; get_terms only skips with a number
			'number' => -1 === $args['limit'] ? ( $args['skip'] ? PHP_INT_MAX : 0 ) : $args['limit'],
			'offset' => $args['skip'],
		] );
		$terms     = is_array( $terms ) ? $terms : [];

		return [
			'items' => array_map( [ $this, 'normalize' ], $terms ),
			'total' => $args['count'] ? (int) wp_count_terms( $term_args ) : count( $terms ),
		];
	}

	/**
	 * Normalize a term
	 *
	 * @param \WP_Term $term Term
	 *
	 * @return array
	 */
	public function normalize( $term ) {
		$link = get_term_link( $term );

		return [
			'id'       => $term->term_id,
			'type'     => 'term',
			'title'    => $term->name,
			'url'      => is_wp_error( $link ) ? '' : $link,
			'image_id' => $this->image_id( $term ),
			'excerpt'  => wp_strip_all_tags( term_description( $term ) ),
			'date'     => '',
			'object'   => $term,
			'count'    => (int) $term->count,
		];
	}

	/**
	 * Terms have no terms of their own
	 *
	 * @param array  $item     Item
	 * @param string $taxonomy Taxonomy
	 *
	 * @return array
	 */
	public function get_item_terms( array $item, $taxonomy ) {
		return [];
	}

	/**
	 * Image of a term: its own, else the featured image of its newest post that has one
	 *
	 * @param \WP_Term $term Term
	 *
	 * @return int Attachment ID, 0 = none
	 */
	private function image_id( \WP_Term $term ) {
		$image_id = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );

		if ( !$image_id ) {
			$posts = get_posts( [
				'post_type'        => $this->taxonomy->object_type,
				'post_status'      => 'publish',
				'posts_per_page'   => 1,
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => false,
				'meta_key'         => '_thumbnail_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'tax_query'        => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					[
						'taxonomy' => $term->taxonomy,
						'field'    => 'term_id',
						'terms'    => [ $term->term_id ],
					],
				],
			] );

			$image_id = $posts ? (int) get_post_thumbnail_id( $posts[0] ) : 0;
		}

		/**
		 * Image of a term in a terms grid
		 *
		 * @param int      $image_id Attachment ID, 0 = none
		 * @param \WP_Term $term     Term
		 */
		return (int) apply_filters( 'forma_term_image_id', $image_id, $term );
	}
}
